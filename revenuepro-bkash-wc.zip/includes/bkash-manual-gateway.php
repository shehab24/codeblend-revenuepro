<?php
namespace RevenuePro;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Manual bKash Payment Gateway
 * 
 * Customer sends money to admin's bKash number manually,
 * then provides the Transaction ID at checkout.
 * Order is placed as "on-hold" until admin verifies.
 */
class BkashManualGateway extends \WC_Payment_Gateway
{
    public function __construct()
    {
        $this->id = 'revenuepro_bkash_manual';
        $this->has_fields = true;
        $this->method_title = __('bKash Manual (RevenuePro)', 'revenuepro-bkash-wc');
        $this->method_description = __('Accept manual bKash payments. Customer sends money to your bKash number and provides the transaction ID.', 'revenuepro-bkash-wc');
        $this->supports = ['products'];

        // Get settings from RevenuePro dashboard
        $rp_settings = get_option('revenuepro_bkash_wc_settings', []);
        $this->icon = !empty($rp_settings['bkash_logo_url']) ? $rp_settings['bkash_logo_url'] : '';

        $this->init_form_fields();
        $this->init_settings();

        // Use RevenuePro dashboard settings as primary source
        $this->title = !empty($rp_settings['bkash_manual_title']) 
            ? $rp_settings['bkash_manual_title'] 
            : ($this->get_option('title') ?: __('bKash (Send Money)', 'revenuepro-bkash-wc'));
        
        $this->description = !empty($rp_settings['bkash_manual_description']) 
            ? $rp_settings['bkash_manual_description'] 
            : ($this->get_option('description') ?: __('Send money to our bKash number and enter your Transaction ID below.', 'revenuepro-bkash-wc'));
        
        $this->enabled = $this->get_option('enabled');

        add_action('woocommerce_update_options_payment_gateways_' . $this->id, [$this, 'process_admin_options']);
    }

    /**
     * Gateway form fields for WooCommerce settings page
     */
    public function init_form_fields()
    {
        $this->form_fields = [
            'enabled' => [
                'title'   => __('Enable/Disable', 'revenuepro-bkash-wc'),
                'type'    => 'checkbox',
                'label'   => __('Enable bKash Manual Payment', 'revenuepro-bkash-wc'),
                'default' => 'no',
            ],
            'title' => [
                'title'       => __('Title', 'revenuepro-bkash-wc'),
                'type'        => 'text',
                'description' => __('Payment method title the customer sees on checkout.', 'revenuepro-bkash-wc'),
                'default'     => __('bKash (Send Money)', 'revenuepro-bkash-wc'),
                'desc_tip'    => true,
            ],
            'description' => [
                'title'       => __('Description', 'revenuepro-bkash-wc'),
                'type'        => 'textarea',
                'description' => __('Payment method description the customer sees on checkout.', 'revenuepro-bkash-wc'),
                'default'     => __('Send money to our bKash number and enter your Transaction ID below.', 'revenuepro-bkash-wc'),
            ],
        ];
    }

    /**
     * Check if the gateway is available for use.
     */
    public function is_available()
    {
        if ($this->get_option('enabled') !== 'yes') {
            return false;
        }

        // Must have a bKash number configured
        $rp_settings = get_option('revenuepro_bkash_wc_settings', []);
        if (empty($rp_settings['bkash_manual_number'])) {
            return false;
        }

        return true;
    }

    /**
     * Render payment fields on checkout (bKash number + TrxID input)
     */
    public function payment_fields()
    {
        $rp_settings = get_option('revenuepro_bkash_wc_settings', []);
        $bkash_number = !empty($rp_settings['bkash_manual_number']) ? $rp_settings['bkash_manual_number'] : '';
        $account_type = !empty($rp_settings['bkash_manual_account_type']) ? $rp_settings['bkash_manual_account_type'] : 'personal';
        $instructions = !empty($rp_settings['bkash_manual_instructions']) ? $rp_settings['bkash_manual_instructions'] : '';
        $qr_url = !empty($rp_settings['bkash_manual_qr_url']) ? $rp_settings['bkash_manual_qr_url'] : '';
        $display_mode = !empty($rp_settings['bkash_manual_display_mode']) ? $rp_settings['bkash_manual_display_mode'] : 'both';
        $cart_total = (WC()->cart) ? WC()->cart->get_total('edit') : 0;

        // Container
        echo '<div style="font-family: system-ui, -apple-system, sans-serif; margin-bottom: 12px;">';

        // Payment instruction card
        ?>
        <div style="background: linear-gradient(135deg, #e2136e 0%, #be0d58 100%); border-radius: 12px; padding: 16px; margin-bottom: 16px; color: #fff; display: flex; flex-direction: column; gap: 12px; box-shadow: 0 4px 15px rgba(226,19,110,0.15);">
            <?php if ($display_mode === 'qr_code' && !empty($qr_url)) : ?>
                <!-- QR Code Only Mode -->
                <div style="display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 12px; width: 100%;">
                    <div style="background: #fff; border-radius: 12px; padding: 12px; width: 100%; box-shadow: 0 4px 12px rgba(0,0,0,0.15); box-sizing: border-box;">
                        <img src="<?php echo esc_url($qr_url); ?>" alt="bKash QR Code" style="width: 100%; height: auto; max-width: 100%; border-radius: 8px; display: block; margin: 0 auto;" />
                    </div>
                    <span style="font-size: 14px; font-weight: 600; opacity: 0.95; text-align: center; letter-spacing: 0.3px;">
                        <?php esc_html_e('Scan this QR code to pay', 'revenuepro-bkash-wc'); ?>
                    </span>
                    <?php if (!empty($instructions)) : ?>
                        <div style="font-size: 11px; color: rgba(255,255,255,0.85); line-height: 1.4; border-top: 1px solid rgba(255,255,255,0.15); padding-top: 8px; margin-top: 4px; width: 100%; text-align: center;">
                            <?php echo wp_kses_post($instructions); ?>
                        </div>
                    <?php endif; ?>
                </div>
            <?php elseif ($display_mode === 'number') : ?>
                <!-- Number Only Mode -->
                <div style="display: flex; flex-direction: column; gap: 6px; width: 100%;">
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <span style="font-weight: 600; font-size: 13px; opacity: 0.9;"><?php esc_html_e('Send Money to', 'revenuepro-bkash-wc'); ?></span>
                        <div style="background: rgba(255,255,255,0.2); padding: 2px 6px; border-radius: 4px; font-size: 10px; text-transform: uppercase; letter-spacing: 0.5px; font-weight: 600;">
                            <?php echo esc_html(ucfirst($account_type)); ?>
                        </div>
                    </div>
                    
                    <div style="font-size: 20px; font-weight: 700; letter-spacing: 1px; display: flex; align-items: center; gap: 10px; margin: 4px 0;">
                        <?php echo esc_html($bkash_number); ?>
                        <button type="button" onclick="navigator.clipboard.writeText('<?php echo esc_js($bkash_number); ?>'); this.innerText='Copied!'; setTimeout(()=>this.innerText='Copy', 2000); return false;" style="background: rgba(255,255,255,0.15); border: 1px solid rgba(255,255,255,0.3); color: white; padding: 2px 8px; border-radius: 4px; font-size: 11px; cursor: pointer; transition: 0.2s;">Copy</button>
                    </div>

                    <?php if (!empty($instructions)) : ?>
                        <div style="font-size: 11px; color: rgba(255,255,255,0.85); line-height: 1.4; border-top: 1px solid rgba(255,255,255,0.15); padding-top: 6px; margin-top: 2px;">
                            <?php echo wp_kses_post($instructions); ?>
                        </div>
                    <?php endif; ?>
                </div>
            <?php else : ?>
                <!-- Both Mode (Default) -->
                <div style="display: flex; flex-wrap: wrap; gap: 16px; align-items: center;">
                    <?php if (!empty($qr_url)) : ?>
                        <div style="background: #fff; border-radius: 10px; padding: 8px; display: flex; align-items: center; justify-content: center; width: 140px; height: 140px; flex-shrink: 0; box-shadow: 0 4px 10px rgba(0,0,0,0.15);">
                            <img src="<?php echo esc_url($qr_url); ?>" alt="bKash QR Code" style="width: 100%; height: 100%; object-fit: contain; border-radius: 4px; display: block;" />
                        </div>
                    <?php endif; ?>
                    <div style="flex: 1; min-width: 150px; display: flex; flex-direction: column; gap: 6px;">
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <span style="font-weight: 600; font-size: 13px; opacity: 0.9;"><?php esc_html_e('Send Money to', 'revenuepro-bkash-wc'); ?></span>
                            <div style="background: rgba(255,255,255,0.2); padding: 2px 6px; border-radius: 4px; font-size: 10px; text-transform: uppercase; letter-spacing: 0.5px; font-weight: 600;">
                                <?php echo esc_html(ucfirst($account_type)); ?>
                            </div>
                        </div>
                        
                        <div style="font-size: 18px; font-weight: 700; letter-spacing: 1px; display: flex; align-items: center; gap: 10px;">
                            <?php echo esc_html($bkash_number); ?>
                            <button type="button" onclick="navigator.clipboard.writeText('<?php echo esc_js($bkash_number); ?>'); this.innerText='Copied!'; setTimeout(()=>this.innerText='Copy', 2000); return false;" style="background: rgba(255,255,255,0.15); border: 1px solid rgba(255,255,255,0.3); color: white; padding: 2px 8px; border-radius: 4px; font-size: 11px; cursor: pointer; transition: 0.2s;">Copy</button>
                        </div>

                        <?php if (!empty($instructions)) : ?>
                            <div style="font-size: 11px; color: rgba(255,255,255,0.85); line-height: 1.4; border-top: 1px solid rgba(255,255,255,0.15); padding-top: 6px; margin-top: 2px;">
                                <?php echo wp_kses_post($instructions); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>

        <div style="display: flex; flex-direction: column; gap: 10px; margin-bottom: 8px;">
            <div style="width: 100%;">
                <label for="bkash_manual_trx_id" style="display: block; margin-bottom: 6px; font-weight: 500; font-size: 13px; color: #475569;">
                    <?php esc_html_e('Transaction ID', 'revenuepro-bkash-wc'); ?> <span style="color:#e2136e">*</span>
                </label>
                <div style="display: flex; gap: 10px; align-items: center;">
                    <input 
                        type="text" 
                        class="input-text" 
                        name="bkash_manual_trx_id" 
                        id="bkash_manual_trx_id" 
                        placeholder="BK24XXXX"
                        style="flex: 1; width: 100% !important; min-width: 150px !important; box-sizing: border-box; padding: 10px 12px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 14px; background: #f8fafc; transition: all 0.2s; box-shadow: none; text-transform: uppercase;"
                        onfocus="this.style.borderColor='#e2136e'; this.style.background='#fff';" 
                        onblur="this.style.borderColor='#cbd5e1'; this.style.background='#f8fafc';"
                        required
                    />
                    <button 
                        type="button" 
                        id="revenuepro_bkash_verify_btn"
                        style="background: #e2136e; color: #fff; border: none; border-radius: 6px; padding: 10px 16px; font-weight: 600; font-size: 13px; cursor: pointer; transition: background 0.2s;"
                        onmouseover="this.style.background='#be0d58';"
                        onmouseout="this.style.background='#e2136e';"
                    >
                        <?php esc_html_e('Verify', 'revenuepro-bkash-wc'); ?>
                    </button>
                </div>
            </div>
            
            <!-- Verification result badge -->
            <div id="revenuepro_verify_status" style="display: none; padding: 8px 12px; border-radius: 6px; font-size: 12px; font-weight: 500; line-height: 1.4;"></div>
        </div>

        <script type="text/javascript">
        jQuery(document).ready(function($) {
            $(document).off('click', '#revenuepro_bkash_verify_btn').on('click', '#revenuepro_bkash_verify_btn', function(e) {
                e.preventDefault();
                var btn = $(this);
                var trxId = $('#bkash_manual_trx_id').val().trim();
                var statusBox = $('#revenuepro_verify_status');
                
                if (!trxId) {
                    alert('Please enter a Transaction ID first.');
                    return false;
                }
                
                btn.prop('disabled', true).text('Verifying...');
                statusBox.hide().removeClass('verified-success').css({
                    background: '#f1f5f9',
                    color: '#475569',
                    border: '1px solid #cbd5e1'
                }).text('Checking payment...').show();
                
                $.ajax({
                    url: '<?php echo esc_url(admin_url('admin-ajax.php')); ?>',
                    type: 'POST',
                    data: {
                        action: 'revenuepro_verify_bkash_trx',
                        trx_id: trxId,
                        amount: '<?php echo esc_js($cart_total); ?>'
                    },
                    success: function(response) {
                        btn.prop('disabled', false).text('Verify');
                        if (response.success) {
                            statusBox.css({
                                background: '#f0fdf4',
                                color: '#166534',
                                border: '1px solid #bbf7d0'
                            }).html(response.data.message);
                            $('#bkash_manual_trx_id').prop('readonly', true);
                            btn.hide();
                        } else {
                            statusBox.css({
                                background: '#fef2f2',
                                color: '#991b1b',
                                border: '1px solid #fecaca'
                            }).html(response.data.message);
                        }
                    },
                    error: function() {
                        btn.prop('disabled', false).text('Verify');
                        statusBox.css({
                            background: '#fef2f2',
                            color: '#991b1b',
                            border: '1px solid #fecaca'
                        }).text('Error connecting to verification server. Please try again.');
                    }
                });
                return false;
            });
        });
        </script>
        <?php
        echo '</div>';
    }

    /**
     * Validate checkout fields
     */
    public function validate_fields()
    {
        $trx_id = isset($_POST['bkash_manual_trx_id']) ? sanitize_text_field(wp_unslash($_POST['bkash_manual_trx_id'])) : '';

        if (empty($trx_id)) {
            wc_add_notice(__('Please enter your bKash Transaction ID.', 'revenuepro-bkash-wc'), 'error');
            return false;
        }

        if (strlen($trx_id) < 5) {
            wc_add_notice(__('Please enter a valid bKash Transaction ID.', 'revenuepro-bkash-wc'), 'error');
            return false;
        }

        return true;
    }

    /**
     * Process the payment
     */
    public function process_payment($order_id)
    {
        $order = wc_get_order($order_id);
        $trx_id = sanitize_text_field(wp_unslash($_POST['bkash_manual_trx_id'] ?? ''));
        $sender_number = sanitize_text_field(wp_unslash($_POST['bkash_manual_sender_number'] ?? ''));

        if (empty($sender_number)) {
            $sender_number = $order->get_billing_phone();
        }

        // Store transaction details
        $order->set_transaction_id($trx_id);
        $order->update_meta_data('_bkash_customer_number', $sender_number);
        $order->update_meta_data('_bkash_payment_type', 'manual');
        $order->set_payment_method($this->id);
        $order->set_payment_method_title($this->title);

        // Try to automatically verify the transaction in the DB
        $verify_amount = floatval($order->get_total());
        if ($order->get_meta('_is_partial_payment') === 'yes') {
            $partial_amt = floatval($order->get_meta('_partial_payment_amount'));
            if ($partial_amt > 0) {
                $verify_amount = $partial_amt;
            }
        }

        require_once REVENUEPRO_INCLUDES_DIR_PATH . 'bkash-manual-verifier.php';
        $verified = \RevenuePro\BkashManualVerifier::verify_and_claim_transaction($trx_id, $verify_amount, $order_id);

        if ($verified) {
            // Auto-approve the payment since it was found in the SMS log database!
            $order->payment_complete($trx_id);
            $order->add_order_note(
                sprintf(
                    __('✅ Manual bKash payment automatically verified. TrxID: %1$s | Sender: %2$s', 'revenuepro-bkash-wc'),
                    $trx_id,
                    $sender_number
                )
            );
        } else {
            // Not verified yet (e.g. SMS delayed or not matching) - place as on-hold for manual review
            $order->add_order_note(
                sprintf(
                    __('Manual bKash payment submitted. TrxID: %1$s | Sender: %2$s | Awaiting verification (not auto-matched yet).', 'revenuepro-bkash-wc'),
                    $trx_id,
                    $sender_number
                )
            );
            $order->update_status('on-hold', __('Awaiting manual bKash payment verification.', 'revenuepro-bkash-wc'));
        }
        
        $order->save();

        // Reduce stock levels
        wc_reduce_stock_levels($order_id);

        // Empty cart
        WC()->cart->empty_cart();

        return [
            'result'   => 'success',
            'redirect' => $this->get_return_url($order),
        ];
    }
}
