# bKash Gateway Debug Guide

## How to View Debug Logs

The bKash gateway now includes comprehensive debug logging to help you troubleshoot payment issues.

### Step 1: Enable WordPress Debug Mode

Make sure WordPress debug mode is enabled in your `wp-config.php`:

```php
define('WP_DEBUG', true);
define('WP_DEBUG_LOG', true);
define('WP_DEBUG_DISPLAY', false);
```

### Step 2: Try to Place an Order

1. Go to your checkout page
2. Fill in billing details
3. Select bKash as payment method
4. Click "Place Order"

### Step 3: View the Debug Logs

**Option 1: Using Docker (Recommended)**
```bash
# View real-time logs
docker compose logs -f wordpress | grep "bKash Gateway"

# Or view the last 50 lines
docker compose logs --tail=50 wordpress | grep "bKash Gateway"
```

**Option 2: Check the debug.log file**
```bash
# View the WordPress debug log
tail -f wp-content/debug.log | grep "bKash Gateway"

# Or view all bKash logs
grep "bKash Gateway" wp-content/debug.log
```

### What the Logs Show

The debug logs will show you:

1. **Order Information**
   - Order ID
   - Order Total
   
2. **Credential Check**
   - Whether App Key is present (and its length)
   - Whether App Secret is present (and its length)
   - Whether Username is present
   - Whether Password is present
   
3. **Token Request**
   - Full token response from bKash API
   - Whether token was received successfully
   
4. **Payment Creation**
   - Full payment creation response
   - Payment URL if successful
   - Error messages if failed

5. **Errors**
   - Exception messages
   - Stack traces

### Example Log Output

```
[bKash Gateway] === Starting bKash Payment Process ===
[bKash Gateway] Order ID: 123
[bKash Gateway] Order Total: 206.94
[bKash Gateway] Checking credentials...
[bKash Gateway] App Key: MISSING
[bKash Gateway] App Secret: MISSING
[bKash Gateway] Username: MISSING
[bKash Gateway] Password: MISSING
[bKash Gateway] ERROR: Missing credentials!
```

### Common Issues and Solutions

#### 1. "Missing credentials"
**Solution:** Configure bKash credentials in:
- WordPress Admin → RevenuePro bKash → Settings
- Or WooCommerce → Settings → Payments → bKash

#### 2. "Failed to authenticate with bKash"
**Solution:** Check if:
- Credentials are correct
- Using correct environment (sandbox vs production)
- bKash API is accessible from your server

#### 3. "Payment creation failed"
**Solution:** Check the full response in logs to see the exact error from bKash API

### Need More Help?

Check the full response in the logs - it will show you the exact error message from the bKash API.
