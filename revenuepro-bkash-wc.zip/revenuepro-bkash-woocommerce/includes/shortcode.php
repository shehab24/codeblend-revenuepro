<?php
namespace RevenuePro;

if (!defined('ABSPATH')) {
    exit;
}

class Shortcode
{

    public static function init()
    {
        $self = new self();
        add_shortcode('revenuepro_bkash_wc', [$self, 'render_shortcode']);
        add_action('template_redirect', [$self, 'handle_bkash_callback']);
    }

    public function handle_bkash_callback()
    {
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        if (isset($_GET['bkash_callback']) && $_GET['bkash_callback'] === 'true' && isset($_GET['paymentID'])) {
            
            // Get settings for redirect URLs
            $settings = get_option('revenuepro_bkash_wc_settings', []);
            $failure_url = $settings['bkash_failure_url'] ?? home_url();
            
            // Check for status parameter from bKash
            // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            if (isset($_GET['status']) && $_GET['status'] !== 'success') {
                // phpcs:ignore WordPress.Security.NonceVerification.Recommended
                $status = sanitize_text_field(wp_unslash($_GET['status']));
                // phpcs:ignore WordPress.Security.NonceVerification.Recommended
                $submission_id = isset($_GET['submission_id']) ? intval($_GET['submission_id']) : 0;
                
                // Mark submission as failed
                if ($submission_id) {
                    update_post_meta($submission_id, 'payment_status', 'failed');
                    update_post_meta($submission_id, 'payment_failure_reason', $status);
                    
                    // Send failure email
                    $email = new Email();
                    $email->send_failure_email($submission_id, $status);
                }
                
                // Redirect to failure page with error information
                $failure_url = add_query_arg([
                    'payment_status' => 'failed',
                    'reason' => $status
                ], $failure_url);
                
                wp_safe_redirect($failure_url);
                exit;
            }

            // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            $paymentID = sanitize_text_field(wp_unslash($_GET['paymentID']));
            // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            $submission_id = isset($_GET['submission_id']) ? intval($_GET['submission_id']) : 0;
            
            $bkash = new BkashPayment();
            $result = $bkash->execute_payment($paymentID);
            
            if ($result['status'] === 'success') {
                // Update submission
                if ($submission_id) {
                    update_post_meta($submission_id, 'payment_status', 'completed');
                    update_post_meta($submission_id, 'bkash_trx_id', $result['data']['trxID'] ?? '');
                    update_post_meta($submission_id, 'bkash_payment_data', $result['data']);
                    
                    // Send donation receipt email
                    $email = new Email();
                    $email->send_donation_receipt($submission_id);
                }
                
                // Redirect to success page
                $success_url = $settings['bkash_success_url'] ?? home_url();
                
                wp_safe_redirect($success_url);
                exit;
            } else {
                // Handle execution failure - redirect to failure page
                // Handle execution failure - redirect to failure page
                
                // Mark submission as failed
                if ($submission_id) {
                    update_post_meta($submission_id, 'payment_status', 'failed');
                    update_post_meta($submission_id, 'payment_failure_reason', $result['message']);
                    
                    // Send failure email
                    $email = new Email();
                    $email->send_failure_email($submission_id, $result['message']);
                }
                
                $failure_url = add_query_arg([
                    'payment_status' => 'failed',
                    'reason' => urlencode($result['message'])
                ], $failure_url);
                
                wp_safe_redirect($failure_url);
                exit;
            }
        }
    }

    public function render_shortcode($atts)
    {
        $atts = shortcode_atts([
            'id' => 0,
        ], $atts);

        $post_id = intval($atts['id']);

        if (!$post_id || get_post_type($post_id) !== 'revenuepro_bkash_wc') {
            return '';
        }

        // Enqueue Assets
        wp_enqueue_style('revenuepro-bkash-wc-css');
        wp_enqueue_script('revenuepro-bkash-wc-js');

        // Handle submission
        $submission_success = false;
        // phpcs:ignore WordPress.Security.NonceVerification.Missing
        if (isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['revenuepro_bkash_wc_id']) && intval($_POST['revenuepro_bkash_wc_id']) === $post_id) {
            $submission_result = $this->process_submission($post_id);
            
            if (is_array($submission_result) && $submission_result['status'] === 'redirect') {
                echo '<script>window.location.href = "' . esc_url_raw($submission_result['url']) . '";</script>';
                return;
            }
            
            $submission_success = $submission_result === true;
        }

        // Get form fields from the builder
        $form_fields = get_post_meta($post_id, 'form_fields', true);
        $form_fields = is_array($form_fields) ? $form_fields : [];

        // Get form title
        $form_title = get_the_title($post_id);

        ob_start();
        ?>
        <div class="revenuepro-bkash-wc-wrapper" id="revenuepro-bkash-wc-<?php echo esc_attr($post_id); ?>">
            <?php if ($submission_success) { ?>
                <div class="donation-success-message" style="background: #d4edda; color: #155724; padding: 15px; border-radius: 4px; margin-bottom: 20px; border: 1px solid #c3e6cb;">
                    <h4 style="margin: 0 0 10px 0; font-size: 18px;"><?php esc_html_e('Thank You!', 'revenuepro-bkash-wc'); ?></h4>
                    <p style="margin: 0;"><?php esc_html_e('Your submission has been received successfully.', 'revenuepro-bkash-wc'); ?></p>
                </div>
            <?php } else { ?>
                <form class="revenuepro-bkash-wc" method="post" action="">
                    <?php wp_nonce_field('revenuepro_bkash_wc_submit_' . $post_id, 'revenuepro_bkash_wc_nonce'); ?>
                    <input type="hidden" name="revenuepro_bkash_wc_id" value="<?php echo esc_attr($post_id); ?>">
                    
                    <?php // Form title removed - not displayed on frontend ?>

                    <?php if (empty($form_fields)) { ?>
                        <p><?php esc_html_e('No fields configured for this form.', 'revenuepro-bkash-wc'); ?></p>
                    <?php } else { ?>
                        <?php foreach ($form_fields as $field): ?>
                            <?php $this->render_field($field); ?>
                        <?php endforeach; ?>

                        <!-- Payment Method Section -->
                        <?php
                        clean_post_cache($post_id);
                        $settings = get_option("revenuepro_bkash_wc_settings", []);
                        $bkash_enabled = !empty($settings["bkash_enabled"]);
                        
                        $form_settings_meta = get_post_meta($post_id, "form_settings", true);
                        if (isset($form_settings_meta["paymentEnabled"])) {
                            $val = $form_settings_meta["paymentEnabled"];
                            $form_payment_enabled = ($val === true || $val === "true" || $val === 1 || $val === "1");
                        } else {
                            $form_payment_enabled = false;
                        }
    
                        $bkash_logo = $settings["bkash_logo_url"] ?? "";
                        
                        if ($bkash_enabled && $form_payment_enabled) {
                        ?>
                        <div class="donation-payment-methods" style="margin-bottom: 20px; border: 1px solid #ddd; padding: 15px; border-radius: 4px;">
                            <h4 style="margin: 0 0 10px 0; font-size: 16px;"><?php esc_html_e("Payment Method", "revenuepro-bkash-wc"); ?></h4>
                            <label style="display: flex; align-items: center; gap: 10px; cursor: pointer;">
                                <input type="radio" name="payment_method" value="bkash" checked>
                                <?php if ($bkash_logo) {  ?>
                                    <img src="<?php echo esc_url($bkash_logo); ?>" alt="bKash" style="max-height: 40px; width: auto;">
                                  <?php } else { ?>
                                    <span style="font-weight: 600; color: #e2136e;">bKash</span>
                                <?php } ?>
                            </label>
                        </div>
                        <?php } ?>

                        <!-- Submit Button -->
                        <?php
                        $submit_settings = get_post_meta($post_id, 'submit_button_settings', true);
                        $submit_settings = is_array($submit_settings) ? $submit_settings : [];
                        
                        $submit_text = $submit_settings['text'] ?? __('Submit', 'revenuepro-bkash-wc');
                        $submit_width = $submit_settings['width'] ?? '100';
                        $submit_style = $submit_settings['style'] ?? 'primary';
                        
                        $buttonColors = [
                            'primary' => 'background: #0073aa; color: #fff;',
                            'secondary' => 'background: #666; color: #fff;',
                            'success' => 'background: #46b450; color: #fff;',
                        ];
                        $style_attr = $buttonColors[$submit_style] ?? $buttonColors['primary'];
                        ?>
                        <div style="display: flex; justify-content: flex-start;">
                            <button 
                                type="submit" 
                                class="donation-submit-btn"
                                style="<?php echo esc_attr($style_attr); ?> width: <?php echo esc_attr($submit_width); ?>%; padding: 12px 24px; border: none; border-radius: 3px; font-size: 14px; font-weight: 600; cursor: pointer; margin-top: 10px;"
                            >
                                <?php echo esc_html($submit_text); ?>
                            </button>
                        </div>
                    <?php } ?>

                </form>
            <?php } ?>
        </div>
        <?php
        return ob_get_clean();
    }

    private function process_submission($form_id)
    {
        if (!isset($_POST['revenuepro_bkash_wc_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['revenuepro_bkash_wc_nonce'])), 'revenuepro_bkash_wc_submit_' . $form_id)) {
            return false;
        }

        $form_fields = get_post_meta($form_id, 'form_fields', true);
        $form_fields = is_array($form_fields) ? $form_fields : [];
        $submission_data = [];

        $submission_data = [];

        // Collect data based on POST fields
        foreach ($_POST as $key => $value) {
            if (strpos($key, 'field_') === 0) {
                $field_id = str_replace('field_', '', $key);
                // Find label for this field
                $label = $field_id; // Fallback
                $this->find_field_label($form_fields, $field_id, $label);
                
                $submission_data[$field_id] = [
                    'label' => $label,
                    'value' => is_array($value) ? implode(', ', array_map('sanitize_text_field', $value)) : sanitize_text_field($value)
                ];
            }
        }

        if (empty($submission_data)) {
            return false;
        }

        // Create submission post
        $post_data = [
            'post_title' => 'Submission for Form #' . $form_id . ' - ' . current_time('mysql'),
            'post_type' => 'revenuepro_submission',
            'post_status' => 'publish',
            'post_parent' => $form_id,
        ];

        $submission_id = wp_insert_post($post_data);

        if ($submission_id) {
            update_post_meta($submission_id, 'form_id', $form_id);
            update_post_meta($submission_id, 'submission_data', $submission_data);

            // Calculate Amount (First numeric field)
            $amount = 0;
            foreach ($submission_data as $field) {
                if (is_numeric($field['value'])) {
                    $amount = floatval($field['value']);
                    break;
                }
            }
            update_post_meta($submission_id, 'donation_amount', $amount);

            // Check Payment Method
            $form_settings_meta = get_post_meta($form_id, "form_settings", true);
            if (isset($form_settings_meta["paymentEnabled"])) {
                $val = $form_settings_meta["paymentEnabled"];
                $form_payment_enabled = ($val === true || $val === "true" || $val === 1 || $val === "1");
            } else {
                $form_payment_enabled = false;
            }

            // Check Payment Method
            if ($form_payment_enabled && isset($_POST["payment_method"]) && $_POST["payment_method"] === "bkash") {
                if ($amount > 0) {
                    $bkash = new BkashPayment();
                    // Use current URL as base for callback
                    global $wp;
                    $current_url = home_url(add_query_arg([], $wp->request));
                    $callback_url = add_query_arg([
                        'bkash_callback' => 'true', 
                        'submission_id' => $submission_id
                    ], $current_url);
                    
                    $result = $bkash->create_payment($amount, $submission_id, $callback_url);
                    
                    if ($result['status'] === 'success') {
                        return ['status' => 'redirect', 'url' => $result['bkashURL']];
                    } else {
                        // Log error or handle failure
                    }
                }
            }

            return true;
        }

        return false;
    }
    
    private function find_field_label($fields, $id, &$label) {
        foreach ($fields as $field) {
            if (isset($field['id']) && $field['id'] == $id) {
                $label = $field['label'];
                return;
            }
            if (isset($field['columns'])) {
                foreach ($field['columns'] as $column) {
                    if (isset($column['fields'])) {
                        $this->find_field_label($column['fields'], $id, $label);
                    }
                }
            }
        }
    }

    private function render_field($field)
    {
        $field_id = $field['id'] ?? '';
        $field_type = $field['type'] ?? 'text';
        $label = $field['label'] ?? '';
        $placeholder = $field['placeholder'] ?? '';
        $required = !empty($field['required']);
        $width = $field['width'] ?? '100';
        $options = $field['options'] ?? [];

        // Calculate field width style
        $width_style = '';
        if ($width != '100') {
            $width_style = "width: {$width}%; display: inline-block; vertical-align: top; padding-right: 15px; box-sizing: border-box;";
        }

        ?>
        <div class="donation-field" data-field-id="<?php echo esc_attr($field_id); ?>" style="<?php echo esc_attr($width_style); ?>">
            <?php if ($label && !in_array($field_type, ['columns', 'button'])): ?>
                <label class="donation-label">
                    <?php echo esc_html($label); ?>
                    <?php if ($required): ?>
                        <span class="required-mark" style="color: #d63638;">*</span>
                    <?php endif; ?>
                </label>
            <?php endif; ?>

            <?php
            switch ($field_type) {
                case 'textarea':
                    ?>
                    <textarea 
                        class="donation-input" 
                        name="field_<?php echo esc_attr($field_id); ?>" 
                        placeholder="<?php echo esc_attr($placeholder); ?>"
                        <?php echo $required ? 'required' : ''; ?>
                        rows="4"
                    ></textarea>
                    <?php
                    break;

                case 'dropdown':
                    ?>
                    <select 
                        class="donation-input" 
                        name="field_<?php echo esc_attr($field_id); ?>"
                        <?php echo $required ? 'required' : ''; ?>
                    >
                        <option value=""><?php echo esc_html($placeholder ?: __('Please Select', 'revenuepro-bkash-wc')); ?></option>
                        <?php foreach ($options as $option): ?>
                            <option value="<?php echo esc_attr($option); ?>"><?php echo esc_html($option); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <?php
                    break;

                case 'radio':
                    ?>
                    <div class="donation-radio-group">
                        <?php foreach ($options as $index => $option): ?>
                            <label class="donation-radio-option">
                                <input 
                                    type="radio" 
                                    name="field_<?php echo esc_attr($field_id); ?>" 
                                    value="<?php echo esc_attr($option); ?>"
                                    <?php echo $required && $index === 0 ? 'required' : ''; ?>
                                >
                                <span><?php echo esc_html($option); ?></span>
                            </label>
                        <?php endforeach; ?>
                    </div>
                    <?php
                    break;

                case 'checkboxes':
                    ?>
                    <div class="donation-checkbox-group">
                        <?php foreach ($options as $option): ?>
                            <label class="donation-checkbox-option">
                                <input 
                                    type="checkbox" 
                                    name="field_<?php echo esc_attr($field_id); ?>[]" 
                                    value="<?php echo esc_attr($option); ?>"
                                >
                                <span><?php echo esc_html($option); ?></span>
                            </label>
                        <?php endforeach; ?>
                    </div>
                    <?php
                    break;

                case 'number':
                    ?>
                    <input 
                        type="number" 
                        class="donation-input" 
                        name="field_<?php echo esc_attr($field_id); ?>" 
                        placeholder="<?php echo esc_attr($placeholder); ?>"
                        <?php echo $required ? 'required' : ''; ?>
                    >
                    <?php
                    break;

                case 'email':
                    ?>
                    <input 
                        type="email" 
                        class="donation-input" 
                        name="field_<?php echo esc_attr($field_id); ?>" 
                        placeholder="<?php echo esc_attr($placeholder); ?>"
                        <?php echo $required ? 'required' : ''; ?>
                    >
                    <?php
                    break;

                case 'phone':
                    ?>
                    <input 
                        type="tel" 
                        class="donation-input" 
                        name="field_<?php echo esc_attr($field_id); ?>" 
                        placeholder="<?php echo esc_attr($placeholder); ?>"
                        <?php echo $required ? 'required' : ''; ?>
                    >
                    <?php
                    break;

                case 'date':
                    ?>
                    <input 
                        type="date" 
                        class="donation-input" 
                        name="field_<?php echo esc_attr($field_id); ?>" 
                        <?php echo $required ? 'required' : ''; ?>
                    >
                    <?php
                    break;

                case 'website':
                    ?>
                    <input 
                        type="url" 
                        class="donation-input" 
                        name="field_<?php echo esc_attr($field_id); ?>" 
                        placeholder="<?php echo esc_attr($placeholder); ?>"
                        <?php echo $required ? 'required' : ''; ?>
                    >
                    <?php
                    break;

                case 'password':
                    ?>
                    <input 
                        type="password" 
                        class="donation-input" 
                        name="field_<?php echo esc_attr($field_id); ?>" 
                        placeholder="<?php echo esc_attr($placeholder); ?>"
                        <?php echo $required ? 'required' : ''; ?>
                    >
                    <?php
                    break;

                case 'file':
                    ?>
                    <input 
                        type="file" 
                        class="donation-input" 
                        name="field_<?php echo esc_attr($field_id); ?>" 
                        <?php echo $required ? 'required' : ''; ?>
                    >
                    <?php
                    break;

                case 'columns':
                    // Render column layout
                    $columnCount = $field['columnCount'] ?? 2;
                    $columns = $field['columns'] ?? [];
                    ?>
                    <div class="donation-columns" style="display: flex; gap: 15px; margin-bottom: 20px;">
                        <?php for ($i = 0; $i < $columnCount; $i++): ?>
                            <div class="donation-column" style="flex: 1;">
                                <?php 
                                $column = $columns[$i] ?? null;
                                if ($column && !empty($column['fields'])) {
                                    foreach ($column['fields'] as $nestedField) {
                                        $this->render_field($nestedField);
                                    }
                                }
                                ?>
                            </div>
                        <?php endfor; ?>
                    </div>
                    <?php
                    break;

                case 'button':
                    // Render button
                    $buttonText = $field['buttonText'] ?? $label;
                    $buttonValue = $field['buttonValue'] ?? '';
                    $buttonStyle = $field['buttonStyle'] ?? 'primary';
                    
                    $buttonColors = [
                        'primary' => 'background: #0073aa; color: #fff;',
                        'secondary' => 'background: #666; color: #fff;',
                        'success' => 'background: #46b450; color: #fff;',
                    ];
                    $buttonStyleAttr = $buttonColors[$buttonStyle] ?? $buttonColors['primary'];
                    ?>
                    <input type="hidden" name="field_<?php echo esc_attr($field_id); ?>" value="">
                    <button 
                        type="button" 
                        class="donation-button donation-button-<?php echo esc_attr($buttonStyle); ?>" 
                        data-value="<?php echo esc_attr($buttonValue); ?>"
                        data-field-id="<?php echo esc_attr($field_id); ?>"
                        style="<?php echo esc_attr($buttonStyleAttr); ?> width: 100%; padding: 12px 24px; border: none; border-radius: 3px; font-size: 14px; font-weight: 600; cursor: pointer; margin-bottom: 15px;"
                    >
                        <?php echo esc_html($buttonText); ?>
                    </button>
                    <?php
                    break;

                case 'text':
                default:
                    ?>
                    <input 
                        type="text" 
                        class="donation-input" 
                        name="field_<?php echo esc_attr($field_id); ?>" 
                        placeholder="<?php echo esc_attr($placeholder); ?>"
                        <?php echo $required ? 'required' : ''; ?>
                    >
                    <?php
                    break;
            }
            ?>
        </div>
        <?php
    }
}
