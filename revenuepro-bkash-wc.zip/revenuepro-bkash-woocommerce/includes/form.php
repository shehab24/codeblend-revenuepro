<?php
namespace RevenuePro;

if (!defined('ABSPATH')) {
	exit;
}

class Form
{

	public static function init()
	{
		$self = new self();
		add_action('init', [$self, 'register_cpt']);
		add_action('add_meta_boxes', [$self, 'add_meta_boxes']);
		add_action('save_post', [$self, 'save_meta_boxes']);
	}

	public function register_cpt()
	{
		$labels = [
			'name' => __('RevenuePros', 'revenuepro-bkash-wc'),
			'singular_name' => __('RevenuePro', 'revenuepro-bkash-wc'),
			'add_new' => __('Add New Form', 'revenuepro-bkash-wc'),
			'add_new_item' => __('Add New RevenuePro', 'revenuepro-bkash-wc'),
			'edit_item' => __('Edit RevenuePro', 'revenuepro-bkash-wc'),
			'new_item' => __('New RevenuePro', 'revenuepro-bkash-wc'),
			'view_item' => __('View RevenuePro', 'revenuepro-bkash-wc'),
			'search_items' => __('Search RevenuePros', 'revenuepro-bkash-wc'),
			'not_found' => __('No donation forms found', 'revenuepro-bkash-wc'),
			'not_found_in_trash' => __('No donation forms found in Trash', 'revenuepro-bkash-wc'),
			'menu_name' => __('RevenuePros', 'revenuepro-bkash-wc'),
		];

		$args = [
			'labels' => $labels,
			'hierarchical' => false,
			'description' => 'RevenuePros',
			'taxonomies' => [],
			'public' => false,
			'show_ui' => false, // Hide from standard admin UI
			'show_in_menu' => false,
			'show_in_rest' => true, // Enable REST API
			'show_in_admin_bar' => false,
			'menu_position' => null,
			'menu_icon' => 'dashicons-money',
			'show_in_nav_menus' => false,
			'publicly_queryable' => false,
			'exclude_from_search' => true,
			'has_archive' => false,
			'query_var' => true,
			'can_export' => true,
			'rewrite' => true,
			'capability_type' => 'post',
			'supports' => ['title', 'author', 'custom-fields'], // Ensure custom-fields for meta
		];

		register_post_type('revenuepro_bkash_wc', $args);


		// Register meta field for REST API with proper schema
		register_post_meta('revenuepro_bkash_wc', 'form_fields', [
			'show_in_rest' => [
				'schema' => [
					'type' => 'array',
					'items' => [
						'type' => 'object',
						'properties' => [
							'id' => ['type' => 'string'],
							'type' => ['type' => 'string'],
							'label' => ['type' => 'string'],
							'placeholder' => ['type' => 'string'],
							'required' => ['type' => 'boolean'],
							'width' => ['type' => 'string'],
							'options' => [
								'type' => 'array',
								'items' => ['type' => 'string'],
							],
							// Column layout fields
							'columnCount' => ['type' => 'integer'],
							'columns' => [
								'type' => 'array',
								'items' => [
									'type' => 'object',
									'properties' => [
										'id' => ['type' => 'string'],
										'fields' => [
											'type' => 'array',
											'items' => [
												'type' => 'object',
												'additionalProperties' => true,
											],
										],
									],
									'additionalProperties' => true,
								],
							],
							// Button fields
							'buttonText' => ['type' => 'string'],
							'buttonValue' => ['type' => 'string'],
							'buttonStyle' => ['type' => 'string'],
							// Additional fields
							'cssClass' => ['type' => 'string'],
							'description' => ['type' => 'string'],
						],
						'additionalProperties' => true,
					],
				],
			],
			'single' => true,
			'type' => 'array',
			'default' => [],
		]);

		register_post_meta('revenuepro_bkash_wc', 'submit_button_settings', [
			'show_in_rest' => [
				'schema' => [
					'type' => 'object',
					'properties' => [
						'text' => ['type' => 'string'],
						'width' => ['type' => 'string'],
						'style' => ['type' => 'string'],
					],
				],
			],
			'single' => true,
			'type' => 'object',
			'default' => [
				'text' => 'Submit',
				'width' => '100',
				'style' => 'primary',
			],
		]);

		// Register form settings meta field
		register_post_meta('revenuepro_bkash_wc', 'form_settings', [
			'single' => true,
			'type' => 'object',
			'show_in_rest' => [
				'schema' => [
					'type' => 'object',
					'additionalProperties' => true,
				],
				'prepare_callback' => function ($value) {
					return $value;
				},
			],
			'sanitize_callback' => function ($value) {
				// Allow any structure - just ensure it's an array/object
				return is_array($value) ? $value : [];
			},
		]);

		// Register separate styling meta field as string to bypass validation
		register_post_meta('revenuepro_bkash_wc', 'form_styling', [
			'single' => true,
			'type' => 'string',
			'show_in_rest' => true,
			'sanitize_callback' => 'sanitize_text_field',
		]);

	}

	public function add_meta_boxes()
	{
		add_meta_box(
			'revenuepro_bkash_wc_settings',
			__('Form Settings', 'revenuepro-bkash-wc'),
			[$this, 'render_settings_meta_box'],
			'revenuepro_bkash_wc',
			'normal',
			'high'
		);
	}

	public function render_settings_meta_box($post)
	{
		?>
		<div id="revenuepro-bkash-wc-builder-root">
			<!-- React App will mount here -->
			<div class="revenuepro-bkash-wc-initial-preloader"><?php esc_html_e('Loading Form Builder...', 'revenuepro-bkash-wc'); ?></div>
		</div>
		<?php
	}

	public function save_meta_boxes($post_id)
	{
		if (!isset($_POST['revenuepro_bkash_wc_nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['revenuepro_bkash_wc_nonce'])), 'revenuepro_bkash_wc_save_meta')) {
			return;
		}

		if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
			return;
		}

		if (!current_user_can('edit_post', $post_id)) {
			return;
		}

		if (isset($_POST['revenuepro_bkash_wc_settings'])) {
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			$settings = wp_unslash($_POST['revenuepro_bkash_wc_settings']);

			// Sanitize
			$clean_settings = [];
			$clean_settings['donation_types'] = isset($settings['donation_types']) ? array_map('sanitize_text_field', $settings['donation_types']) : [];
			$clean_settings['preset_amounts'] = sanitize_text_field($settings['preset_amounts']);
			$clean_settings['custom_amount'] = isset($settings['custom_amount']) ? 'yes' : 'no';

			$text_fields = ['label_amount', 'label_name', 'placeholder_name', 'label_email', 'placeholder_email', 'label_on_behalf', 'placeholder_on_behalf', 'label_payment', 'label_submit'];
			foreach ($text_fields as $field) {
				$clean_settings[$field] = sanitize_text_field($settings[$field]);
			}

			$clean_settings['payment_methods'] = isset($settings['payment_methods']) ? array_map('sanitize_text_field', $settings['payment_methods']) : [];

			update_post_meta($post_id, 'revenuepro_bkash_wc_settings', $clean_settings);
		}
	}
}
