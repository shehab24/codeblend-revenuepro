<?php
namespace RevenuePro;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Quick COD Order - Shows a "Cash on Delivery" button on product pages
 * that opens a popup checkout modal for instant ordering.
 */
class QuickOrder
{
    private static $settings = null;

    public static function init()
    {
        self::$settings = get_option('revenuepro_bkash_wc_settings', []);

        if (empty(self::$settings['quick_order_enabled'])) {
            return;
        }

        // Add COD button on single product pages
        add_action('woocommerce_after_add_to_cart_button', [__CLASS__, 'render_cod_button'], 5);

        // Register AJAX endpoints
        add_action('wp_ajax_rp_quick_order_submit', [__CLASS__, 'ajax_submit_order']);
        add_action('wp_ajax_nopriv_rp_quick_order_submit', [__CLASS__, 'ajax_submit_order']);
        add_action('wp_ajax_rp_quick_order_shipping', [__CLASS__, 'ajax_get_shipping']);
        add_action('wp_ajax_nopriv_rp_quick_order_shipping', [__CLASS__, 'ajax_get_shipping']);

        // Inject popup HTML + CSS + JS on single product pages
        add_action('wp_footer', [__CLASS__, 'render_popup']);
    }

    /**
     * Render the COD button after add-to-cart button
     */
    public static function render_cod_button()
    {
        if (!is_product()) return;

        global $product;
        if (!$product || !$product->is_purchasable() || !$product->is_in_stock()) return;

        $btn_text = !empty(self::$settings['quick_order_button_text'])
            ? self::$settings['quick_order_button_text']
            : 'ক্যাশ অন ডেলিভারিতে অর্ডার করুন';
        $btn_color = !empty(self::$settings['quick_order_button_color'])
            ? self::$settings['quick_order_button_color']
            : '#16a34a';
        ?>
        <div style="width:100%; margin-top:10px;">
            <button type="button" id="rp-quick-order-btn"
                data-product-id="<?php echo esc_attr($product->get_id()); ?>"
                data-product-name="<?php echo esc_attr($product->get_name()); ?>"
                data-product-price="<?php echo esc_attr($product->get_price()); ?>"
                data-product-regular-price="<?php echo esc_attr($product->get_regular_price()); ?>"
                data-product-image="<?php echo esc_attr(wp_get_attachment_url($product->get_image_id())); ?>"
                data-currency="<?php echo esc_attr(get_woocommerce_currency_symbol()); ?>"
                style="width:100%;padding:14px 24px;background:<?php echo esc_attr($btn_color); ?>;color:#fff;border:none;border-radius:8px;font-size:16px;font-weight:700;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:8px;transition:opacity .2s;">
                <span style="font-size:20px;">🛒</span>
                <?php echo esc_html($btn_text); ?>
            </button>
        </div>
        <?php
    }

    /**
     * AJAX: Get shipping methods for a given zone
     */
    public static function ajax_get_shipping()
    {
        $zones = \WC_Shipping_Zones::get_zones();
        $default_zone = new \WC_Shipping_Zone(0);
        $methods = [];

        // Get methods from all zones
        foreach ($zones as $zone_data) {
            $zone = new \WC_Shipping_Zone($zone_data['id']);
            foreach ($zone->get_shipping_methods(true) as $method) {
                if ($method->is_enabled()) {
                    $cost = 0;
                    if (method_exists($method, 'get_option')) {
                        $cost = $method->get_option('cost', 0);
                    }
                    $methods[] = [
                        'id' => $method->get_rate_id(),
                        'title' => $zone_data['zone_name'] . ' - ' . $method->get_title(),
                        'cost' => floatval($cost),
                    ];
                }
            }
        }

        // Default zone (Rest of the world)
        foreach ($default_zone->get_shipping_methods(true) as $method) {
            if ($method->is_enabled()) {
                $cost = 0;
                if (method_exists($method, 'get_option')) {
                    $cost = $method->get_option('cost', 0);
                }
                $methods[] = [
                    'id' => $method->get_rate_id(),
                    'title' => $method->get_title(),
                    'cost' => floatval($cost),
                ];
            }
        }

        // If no shipping methods, add a free one
        if (empty($methods)) {
            $methods[] = ['id' => 'free_shipping', 'title' => 'Free Shipping', 'cost' => 0];
        }

        wp_send_json_success($methods);
    }

    /**
     * AJAX: Submit the quick order
     */
    public static function ajax_submit_order()
    {
        $name = sanitize_text_field($_POST['name'] ?? '');
        $phone = sanitize_text_field($_POST['phone'] ?? '');
        $address = sanitize_textarea_field($_POST['address'] ?? '');
        $product_id = intval($_POST['product_id'] ?? 0);
        $quantity = max(1, intval($_POST['quantity'] ?? 1));
        $variation_id = intval($_POST['variation_id'] ?? 0);
        $shipping_id = sanitize_text_field($_POST['shipping_id'] ?? '');
        $shipping_cost = floatval($_POST['shipping_cost'] ?? 0);
        $shipping_title = sanitize_text_field($_POST['shipping_title'] ?? 'Shipping');
        $order_note = sanitize_textarea_field($_POST['order_note'] ?? '');
        $variation_attrs = isset($_POST['variation_attrs']) ? (array)$_POST['variation_attrs'] : [];

        // Validate required fields
        if (empty($name) || empty($phone) || empty($address) || $product_id <= 0) {
            wp_send_json_error(['message' => 'সকল তথ্য পূরণ করুন।']);
            return;
        }

        // Validate phone
        $clean_phone = preg_replace('/[^0-9]/', '', $phone);
        if (strlen($clean_phone) < 11) {
            wp_send_json_error(['message' => 'সঠিক ফোন নম্বর দিন।']);
            return;
        }

        $product = wc_get_product($product_id);
        if (!$product) {
            wp_send_json_error(['message' => 'পণ্য খুঁজে পাওয়া যায়নি।']);
            return;
        }

        try {
            $order = wc_create_order();

            // Add product
            if ($variation_id > 0) {
                $order->add_product(wc_get_product($variation_id), $quantity, [
                    'variation' => array_map('sanitize_text_field', $variation_attrs),
                ]);
            } else {
                $order->add_product($product, $quantity);
            }

            // Add shipping
            $shipping_item = new \WC_Order_Item_Shipping();
            $shipping_item->set_method_title($shipping_title);
            $shipping_item->set_method_id($shipping_id ?: 'flat_rate');
            $shipping_item->set_total($shipping_cost);
            $order->add_item($shipping_item);

            // Set address
            $name_parts = explode(' ', $name, 2);
            $first_name = $name_parts[0];
            $last_name = isset($name_parts[1]) ? $name_parts[1] : '';

            $order->set_billing_first_name($first_name);
            $order->set_billing_last_name($last_name);
            $order->set_billing_phone($phone);
            $order->set_billing_address_1($address);
            $order->set_billing_city('');
            $order->set_billing_country('BD');

            $order->set_shipping_first_name($first_name);
            $order->set_shipping_last_name($last_name);
            $order->set_shipping_address_1($address);
            $order->set_shipping_country('BD');

            // Set payment method
            $order->set_payment_method('cod');
            $order->set_payment_method_title('Cash on delivery');

            // Add order note
            if (!empty($order_note)) {
                $order->add_order_note($order_note, true);
            }

            // Mark as quick order
            $order->update_meta_data('_quick_order', '1');
            $order->update_meta_data('_quick_order_source', 'product_page');

            $order->calculate_totals();
            $order->update_status('processing', 'Quick COD order from product page.');

            // Empty cart so previous items don't linger for the user
            WC()->cart->empty_cart();

            wp_send_json_success([
                'message' => 'অর্ডার সফলভাবে সম্পন্ন হয়েছে!',
                'order_id' => $order->get_id(),
                'order_total' => $order->get_formatted_order_total(),
            ]);
        } catch (\Exception $e) {
            wp_send_json_error(['message' => 'অর্ডার তৈরি করতে সমস্যা হয়েছে: ' . $e->getMessage()]);
        }
    }

    /**
     * Render the popup modal HTML/CSS/JS on product pages
     */
    public static function render_popup()
    {
        if (!is_product()) return;

        $ajax_url = admin_url('admin-ajax.php');
        $nonce = wp_create_nonce('rp_quick_order');
        $currency = get_woocommerce_currency_symbol();
        $popup_title = !empty(self::$settings['quick_order_popup_title'])
            ? self::$settings['quick_order_popup_title']
            : 'ক্যাশ অন ডেলিভারিতে অর্ডার করতে আপনার তথ্য দিন';
        $confirm_text = !empty(self::$settings['quick_order_confirm_text'])
            ? self::$settings['quick_order_confirm_text']
            : 'ক্যাশ অন ডেলিভারিতে অর্ডার কনফার্ম করুন';

        // Parse custom labels from settings
        $lbl_name = 'আপনার নাম';
        $lbl_phone = 'ফোন নম্বর';
        $lbl_address = 'এড্রেস';

        if (!empty(self::$settings['checkout_fields_config'])) {
            $config = json_decode(self::$settings['checkout_fields_config'], true);
            if (!empty($config['billing'])) {
                if (!empty($config['billing']['billing_first_name']['label'])) {
                    $lbl_name = $config['billing']['billing_first_name']['label'];
                }
                if (!empty($config['billing']['billing_phone']['label'])) {
                    $lbl_phone = $config['billing']['billing_phone']['label'];
                }
                if (!empty($config['billing']['billing_address_1']['label'])) {
                    $lbl_address = $config['billing']['billing_address_1']['label'];
                }
            }
        }
        ?>
        <!-- Quick Order Popup -->
        <div id="rp-qo-overlay" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:99999;">
            <div style="display:flex;align-items:center;justify-content:center;min-height:100vh;padding:20px;box-sizing:border-box;">
                <div id="rp-qo-modal" style="background:#fff;max-width:500px;width:100%;border-radius:16px;box-shadow:0 25px 50px rgba(0,0,0,.15);animation:rpSlideUp .3s ease-out;max-height:80vh;overflow-y:auto;">
                <!-- Header -->
                <div style="display:flex;align-items:center;justify-content:space-between;padding:20px 24px;border-bottom:1px solid #f1f5f9;">
                    <h3 style="margin:0;font-size:16px;font-weight:700;color:#0f172a;"><?php echo esc_html($popup_title); ?></h3>
                    <button id="rp-qo-close" style="background:none;border:none;font-size:24px;cursor:pointer;color:#94a3b8;padding:0;line-height:1;">&times;</button>
                </div>

                <!-- Body -->
                <div style="padding:20px 24px;">
                    <!-- Customer Fields -->
                    <div style="display:grid;gap:14px;margin-bottom:20px;">
                        <div>
                            <label style="display:block;font-size:13px;font-weight:600;color:#334155;margin-bottom:4px;"><?php echo esc_html($lbl_name); ?> <span style="color:#ef4444;">*</span></label>
                            <div style="position:relative;">
                                <span style="position:absolute;left:12px;top:50%;transform:translateY(-50%);color:#94a3b8;">👤</span>
                                <input type="text" id="rp-qo-name" placeholder="<?php echo esc_attr($lbl_name); ?>" style="width:100%;padding:12px 12px 12px 40px;border:1px solid #e2e8f0;border-radius:8px;font-size:14px;outline:none;box-sizing:border-box;" />
                            </div>
                        </div>
                        <div>
                            <label style="display:block;font-size:13px;font-weight:600;color:#334155;margin-bottom:4px;"><?php echo esc_html($lbl_phone); ?> <span style="color:#ef4444;">*</span></label>
                            <div style="position:relative;">
                                <span style="position:absolute;left:12px;top:50%;transform:translateY(-50%);color:#94a3b8;">📞</span>
                                <input type="tel" id="rp-qo-phone" placeholder="<?php echo esc_attr($lbl_phone); ?>" style="width:100%;padding:12px 12px 12px 40px;border:1px solid #e2e8f0;border-radius:8px;font-size:14px;outline:none;box-sizing:border-box;" />
                            </div>
                        </div>
                        <div>
                            <label style="display:block;font-size:13px;font-weight:600;color:#334155;margin-bottom:4px;"><?php echo esc_html($lbl_address); ?> <span style="color:#ef4444;">*</span></label>
                            <div style="position:relative;">
                                <span style="position:absolute;left:12px;top:14px;color:#94a3b8;">📍</span>
                                <textarea id="rp-qo-address" placeholder="<?php echo esc_attr($lbl_address); ?>" rows="2" style="width:100%;padding:12px 12px 12px 40px;border:1px solid #e2e8f0;border-radius:8px;font-size:14px;outline:none;resize:vertical;box-sizing:border-box;"></textarea>
                            </div>
                        </div>
                    </div>

                    <!-- Shipping Methods -->
                    <div style="margin-bottom:20px;">
                        <h4 style="margin:0 0 10px;font-size:14px;font-weight:700;color:#0f172a;">শিপিং মেথড</h4>
                        <div id="rp-qo-shipping-list" style="display:grid;gap:8px;">
                            <div style="padding:14px;text-align:center;color:#94a3b8;font-size:13px;">Loading...</div>
                        </div>
                    </div>

                    <!-- Product Card -->
                    <div id="rp-qo-product-card" style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:12px;padding:16px;margin-bottom:20px;">
                        <div style="display:flex;align-items:center;gap:14px;">
                            <img id="rp-qo-product-img" src="" style="width:70px;height:70px;object-fit:cover;border-radius:8px;border:1px solid #e2e8f0;" />
                            <div style="flex:1;">
                                <div id="rp-qo-product-name" style="font-size:14px;font-weight:600;color:#0f172a;margin-bottom:4px;"></div>
                                <div id="rp-qo-product-variation" style="font-size:12px;color:#64748b;margin-bottom:8px;"></div>
                                <div style="display:flex;align-items:center;gap:10px;">
                                    <button id="rp-qo-qty-minus" style="width:32px;height:32px;border:1px solid #e2e8f0;background:#fff;color:#0f172a;border-radius:6px;cursor:pointer;font-size:18px;display:flex;align-items:center;justify-content:center;">&minus;</button>
                                    <span id="rp-qo-qty" style="font-size:15px;font-weight:700;min-width:20px;text-align:center;">1</span>
                                    <button id="rp-qo-qty-plus" style="width:32px;height:32px;border:1px solid #e2e8f0;background:#fff;color:#0f172a;border-radius:6px;cursor:pointer;font-size:18px;display:flex;align-items:center;justify-content:center;">+</button>
                                </div>
                            </div>
                            <div id="rp-qo-line-total" style="font-size:18px;font-weight:700;color:#0f172a;white-space:nowrap;"></div>
                        </div>
                    </div>

                    <!-- Price Breakdown -->
                    <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:12px;padding:16px;margin-bottom:20px;">
                        <div id="rp-qo-price-regular" style="display:none;justify-content:space-between;margin-bottom:6px;font-size:13px;color:#64748b;">
                            <span>রেগুলার মূল্য</span><span id="rp-qo-val-regular" style="text-decoration:line-through;"></span>
                        </div>
                        <div id="rp-qo-price-discount" style="display:none;justify-content:space-between;margin-bottom:6px;font-size:13px;color:#16a34a;font-weight:600;">
                            <span>ছাড়</span><span id="rp-qo-val-discount"></span>
                        </div>
                        <div style="display:flex;justify-content:space-between;margin-bottom:6px;font-size:13px;color:#334155;">
                            <span>মূল পণ্য</span><span id="rp-qo-val-subtotal"></span>
                        </div>
                        <div style="display:flex;justify-content:space-between;margin-bottom:8px;font-size:13px;color:#334155;">
                            <span>ডেলিভারি চার্জ</span><span id="rp-qo-val-shipping"></span>
                        </div>
                        <div style="display:flex;justify-content:space-between;padding-top:10px;border-top:2px solid #e2e8f0;font-size:16px;font-weight:800;color:#0f172a;">
                            <span>সর্বমোট</span><span id="rp-qo-val-total"></span>
                        </div>
                    </div>

                    <!-- Order Note -->
                    <div style="margin-bottom:20px;">
                        <label style="display:block;font-size:13px;font-weight:600;color:#334155;margin-bottom:4px;">অর্ডার নোট</label>
                        <textarea id="rp-qo-note" placeholder="অর্ডার নোট" rows="2" style="width:100%;padding:10px 12px;border:1px solid #e2e8f0;border-radius:8px;font-size:13px;outline:none;resize:none;box-sizing:border-box;"></textarea>
                    </div>

                    <!-- Submit Button -->
                    <button id="rp-qo-submit" style="width:100%;padding:16px;background:linear-gradient(135deg,#16a34a,#15803d);color:#fff;border:none;border-radius:10px;font-size:16px;font-weight:700;cursor:pointer;transition:opacity .2s;">
                        <?php echo esc_html($confirm_text); ?>
                    </button>

                    <!-- Success Message (hidden) -->
                    <div id="rp-qo-success" style="display:none;text-align:center;padding:40px 20px;">
                        <div style="font-size:48px;margin-bottom:16px;">✅</div>
                        <h3 style="margin:0 0 8px;font-size:20px;font-weight:700;color:#16a34a;">অর্ডার সফল!</h3>
                        <p id="rp-qo-success-msg" style="color:#64748b;font-size:14px;margin:0;"></p>
                    </div>
                    </div>
                </div>
            </div>
        </div>

        <style>
        @keyframes rpSlideUp{from{opacity:0;transform:translateY(30px)}to{opacity:1;transform:translateY(0)}}
        .rp-shipping-opt{padding:14px 16px;border:2px solid #e2e8f0;border-radius:10px;cursor:pointer;display:flex;justify-content:space-between;align-items:center;transition:all .15s;}
        .rp-shipping-opt.active{border-color:#f59e0b;background:#fffbeb;}
        .rp-shipping-opt:hover{border-color:#cbd5e1;}
        #rp-qo-submit:hover{opacity:.9;}
        #rp-quick-order-btn:hover{opacity:.9;}
        
        /* Thin Scrollbar for the modal */
        #rp-qo-modal::-webkit-scrollbar { width: 6px; }
        #rp-qo-modal::-webkit-scrollbar-track { background: transparent; }
        #rp-qo-modal::-webkit-scrollbar-thumb { background-color: #cbd5e1; border-radius: 10px; }
        #rp-qo-modal::-webkit-scrollbar-thumb:hover { background-color: #94a3b8; }
        </style>

        <script>
        jQuery(function($){
            var ajaxUrl = '<?php echo esc_url($ajax_url); ?>';
            var currency = '<?php echo esc_js($currency); ?>';
            var qty = 1, price = 0, regularPrice = 0, shippingCost = 0;
            var selectedShipping = {id:'',title:'',cost:0};
            var productId = 0, variationId = 0, variationAttrs = {};

            function fmt(v){ return currency + ' ' + parseFloat(v).toFixed(2); }

            function updateTotals(){
                var subtotal = price * qty;
                var total = subtotal + shippingCost;
                $('#rp-qo-line-total').html(fmt(subtotal));
                $('#rp-qo-val-subtotal').html(fmt(subtotal));
                $('#rp-qo-val-shipping').html(fmt(shippingCost));
                $('#rp-qo-val-total').html(fmt(total));

                if(regularPrice > price && regularPrice > 0){
                    var discount = (regularPrice - price) * qty;
                    $('#rp-qo-price-regular').css('display','flex');
                    $('#rp-qo-val-regular').html(fmt(regularPrice * qty));
                    $('#rp-qo-price-discount').css('display','flex');
                    $('#rp-qo-val-discount').html('-' + fmt(discount));
                } else {
                    $('#rp-qo-price-regular, #rp-qo-price-discount').hide();
                }
            }

            // Open popup
            $(document).on('click', '#rp-quick-order-btn', function(e){
                e.preventDefault();
                var btn = $(this);
                productId = btn.data('product-id');
                price = parseFloat(btn.data('product-price')) || 0;
                regularPrice = parseFloat(btn.data('product-regular-price')) || 0;
                qty = 1;

                // Get variation data if on a variable product
                var $form = btn.closest('form.variations_form, form.cart');
                if($form.length && $form.find('input[name="variation_id"]').length){
                    variationId = parseInt($form.find('input[name="variation_id"]').val()) || 0;
                    variationAttrs = {};
                    $form.find('select[name^="attribute_"]').each(function(){
                        variationAttrs[$(this).attr('name')] = $(this).val();
                    });
                    // Update price from variation if available
                    var varPrice = $form.find('.woocommerce-variation-price .amount').last().text();
                    if(varPrice){ price = parseFloat(varPrice.replace(/[^0-9.]/g,'')) || price; }
                }

                // Also read quantity from the product page qty field
                var pageQty = parseInt($form.find('input[name="quantity"]').val()) || 1;
                qty = pageQty;

                $('#rp-qo-product-img').attr('src', btn.data('product-image'));
                $('#rp-qo-product-name').text(btn.data('product-name'));
                $('#rp-qo-qty').text(qty);

                // Show variation info
                var varText = [];
                $.each(variationAttrs, function(k,v){ if(v) varText.push(v); });
                $('#rp-qo-product-variation').text(varText.join(' / '));

                updateTotals();
                $('#rp-qo-success').hide();
                $('#rp-qo-submit').show();
                $('#rp-qo-overlay').fadeIn(200);
                $('body').css('overflow','hidden');

                // Load shipping methods
                $.post(ajaxUrl, {action:'rp_quick_order_shipping'}, function(res){
                    if(res.success && res.data.length){
                        var html = '';
                        $.each(res.data, function(i, m){
                            var cls = i === 0 ? 'rp-shipping-opt active' : 'rp-shipping-opt';
                            html += '<div class="'+cls+'" data-id="'+m.id+'" data-cost="'+m.cost+'" data-title="'+m.title+'">';
                            html += '<span style="font-size:14px;font-weight:500;color:#334155;">'+m.title+'</span>';
                            html += '<span style="font-size:14px;font-weight:700;color:#0f172a;">'+fmt(m.cost)+'</span>';
                            html += '</div>';
                            if(i === 0){ selectedShipping = m; shippingCost = m.cost; }
                        });
                        $('#rp-qo-shipping-list').html(html);
                        updateTotals();
                    }
                });
            });

            // Select shipping
            $(document).on('click', '.rp-shipping-opt', function(){
                $('.rp-shipping-opt').removeClass('active');
                $(this).addClass('active');
                selectedShipping = {id:$(this).data('id'),title:$(this).data('title'),cost:parseFloat($(this).data('cost'))};
                shippingCost = selectedShipping.cost;
                updateTotals();
            });

            // Quantity controls
            $(document).on('click', '#rp-qo-qty-minus', function(){ if(qty > 1){ qty--; $('#rp-qo-qty').text(qty); updateTotals(); }});
            $(document).on('click', '#rp-qo-qty-plus', function(){ qty++; $('#rp-qo-qty').text(qty); updateTotals(); });

            // Close popup
            $(document).on('click', '#rp-qo-close, #rp-qo-overlay', function(e){
                if(e.target === this){ $('#rp-qo-overlay').fadeOut(200); $('body').css('overflow',''); }
            });

            // Submit order
            $(document).on('click', '#rp-qo-submit', function(e){
                e.preventDefault();
                var btn = $(this);
                var name = $('#rp-qo-name').val().trim();
                var phone = $('#rp-qo-phone').val().trim();
                var address = $('#rp-qo-address').val().trim();

                if(!name || !phone || !address){
                    alert('সকল তথ্য পূরণ করুন।');
                    return;
                }

                btn.prop('disabled', true).css('opacity','.6').text('অপেক্ষা করুন...');

                $.post(ajaxUrl, {
                    action: 'rp_quick_order_submit',
                    name: name,
                    phone: phone,
                    address: address,
                    product_id: productId,
                    quantity: qty,
                    variation_id: variationId,
                    variation_attrs: variationAttrs,
                    shipping_id: selectedShipping.id,
                    shipping_cost: selectedShipping.cost,
                    shipping_title: selectedShipping.title,
                    order_note: $('#rp-qo-note').val()
                }, function(res){
                    if(res.success){
                        btn.hide();
                        $('#rp-qo-success-msg').html('অর্ডার #' + res.data.order_id + ' — মোট: ' + res.data.order_total);
                        $('#rp-qo-success').show();
                    } else {
                        alert(res.data.message || 'সমস্যা হয়েছে।');
                        btn.prop('disabled', false).css('opacity','1').text('<?php echo esc_js($confirm_text); ?>');
                    }
                }).fail(function(){
                    alert('সার্ভারে সমস্যা হয়েছে।');
                    btn.prop('disabled', false).css('opacity','1').text('<?php echo esc_js($confirm_text); ?>');
                });
            });
        });
        </script>
        <?php
    }
}
