<?php
namespace RevenuePro;

if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly.
}

class Frontend
{
	public static function init()
	{
		$self = new self();
		$self->dispatch_hooks();
	}

	public function dispatch_hooks()
	{
		// Frontend\Template::init();
		Shortcode::init();
		
		// Add partial payment notice to checkout (in the payment section instead of the top)
		add_action('woocommerce_review_order_before_payment', [$this, 'show_partial_payment_notice'], 10);
		
		// Add fraud monitoring scripts to checkout
		add_action('woocommerce_after_checkout_form', [$this, 'inject_checkout_fraud_scripts'], 10);
		
		// Checkout UX Enhancements
		add_filter('woocommerce_checkout_fields', [$this, 'customize_checkout_fields'], 9999);
		add_filter('woocommerce_order_button_text', [$this, 'customize_order_button_text'], 9999);
		// Hide 'Ship to a different address?' when all shipping fields are disabled
		add_filter('woocommerce_cart_needs_shipping_address', [$this, 'maybe_hide_shipping_section'], 9999);
		add_filter('woocommerce_ship_to_different_address_checked', [$this, 'maybe_hide_shipping_section'], 9999);

		// Disable Cash on Delivery if Partial Payment is active
		add_filter('woocommerce_available_payment_gateways', [$this, 'disable_cod_if_partial_enabled'], 999);
	}

	public function customize_checkout_fields($fields) {
		$settings = get_option('revenuepro_bkash_wc_settings', []);
		
		if (!empty($settings['checkout_fields_config'])) {
			$config = json_decode($settings['checkout_fields_config'], true);
			if (is_array($config)) {
				foreach (['billing', 'shipping', 'order'] as $group) {
					if (!empty($config[$group]) && is_array($config[$group])) {
						foreach ($config[$group] as $field_key => $rules) {
							if (isset($fields[$group][$field_key])) {
								// Check Enabled Status
								if (isset($rules['enabled']) && $rules['enabled'] === false) {
									unset($fields[$group][$field_key]);
									continue; // Skip to next field since this one is dead
								}
								
								// Apply Required Status
								if (isset($rules['required'])) {
									$fields[$group][$field_key]['required'] = (bool)$rules['required'];
									if (!$rules['required']) {
										// Remove validate-required class if optional
										if (isset($fields[$group][$field_key]['label_class']) && is_array($fields[$group][$field_key]['label_class'])) {
											$fields[$group][$field_key]['label_class'] = array_diff($fields[$group][$field_key]['label_class'], ['validate-required']);
										}
									}
								}
								
								// Apply Overridden Label
								if (!empty($rules['label'])) {
									$fields[$group][$field_key]['label'] = sanitize_text_field($rules['label']);
								}
								
								// Apply Overridden Placeholder
								if (!empty($rules['placeholder'])) {
									$fields[$group][$field_key]['placeholder'] = sanitize_text_field($rules['placeholder']);
								}
							}
						}
					}
				}
			}
		}

		return $fields;
	}

	public function customize_order_button_text($button_text) {
		$settings = get_option('revenuepro_bkash_wc_settings', []);
		if (!empty($settings['general_custom_order_button'])) {
			return sanitize_text_field($settings['general_custom_order_button']);
		}
		return $button_text;
	}

	public function maybe_hide_shipping_section($val) {
		$settings = get_option('revenuepro_bkash_wc_settings', []);
		if (empty($settings['checkout_fields_config'])) {
			return $val;
		}
		$config = json_decode($settings['checkout_fields_config'], true);
		if (!is_array($config) || empty($config['shipping'])) {
			return $val;
		}

		// The standard shipping fields WooCommerce renders in the separate shipping section
		$shipping_keys = [
			'shipping_first_name', 'shipping_last_name', 'shipping_company',
			'shipping_country', 'shipping_address_1', 'shipping_address_2',
			'shipping_city', 'shipping_state', 'shipping_postcode', 'shipping_phone'
		];

		$all_disabled = true;
		foreach ($shipping_keys as $key) {
			// If a field isn't in config, it's still enabled by default
			if (!isset($config['shipping'][$key]) || $config['shipping'][$key]['enabled'] !== false) {
				$all_disabled = false;
				break;
			}
		}

		return $all_disabled ? false : $val;
	}

	public function disable_cod_if_partial_enabled($gateways) {
		if (is_admin() && !defined('DOING_AJAX')) {
			return $gateways;
		}

		$rp_settings = get_option('revenuepro_bkash_wc_settings', []);
		$wc_settings = get_option('woocommerce_revenuepro_bkash_settings', []);
		
		// Check if partial payment is enabled
		$enabled = false;
		if (isset($rp_settings['bkash_partial_enabled'])) {
			$enabled = ($rp_settings['bkash_partial_enabled'] === true || $rp_settings['bkash_partial_enabled'] === 'true' || $rp_settings['bkash_partial_enabled'] === 1 || $rp_settings['bkash_partial_enabled'] === '1');
		} elseif (isset($wc_settings['partial_enabled'])) {
			$enabled = ($wc_settings['partial_enabled'] === 'yes');
		}

		// If enabled, unset COD
		if ($enabled && isset($gateways['cod'])) {
			unset($gateways['cod']);
		}

		return $gateways;
	}
	
	public function show_partial_payment_notice() {
		// Prevent duplicate display
		static $displayed = false;
		if ($displayed) {
			return;
		}
		$displayed = true;
		
		$this->display_partial_payment_info();
	}
	
	private function display_partial_payment_info() {
		// Get settings
		$rp_settings = get_option('revenuepro_bkash_wc_settings', []);
		$wc_settings = get_option('woocommerce_revenuepro_bkash_settings', []);
		
		// Check if partial payment is enabled
		$enabled = false;
		if (isset($rp_settings['bkash_partial_enabled'])) {
			$enabled = ($rp_settings['bkash_partial_enabled'] === true || $rp_settings['bkash_partial_enabled'] === 'true' || $rp_settings['bkash_partial_enabled'] === 1 || $rp_settings['bkash_partial_enabled'] === '1');
		} elseif (isset($wc_settings['partial_enabled'])) {
			$enabled = ($wc_settings['partial_enabled'] === 'yes');
		}
		
		if (!$enabled || !WC()->cart) {
			return;
		}
		
		// Get partial settings
		$partial_type = isset($rp_settings['bkash_partial_type']) ? $rp_settings['bkash_partial_type'] : (isset($wc_settings['partial_type']) ? $wc_settings['partial_type'] : 'fixed');
		$partial_amount = isset($rp_settings['bkash_partial_amount']) ? floatval($rp_settings['bkash_partial_amount']) : (isset($wc_settings['partial_amount']) ? floatval($wc_settings['partial_amount']) : 100);
		
		// Calculate amounts
		$total = WC()->cart->total;
		$shipping_total = WC()->cart->get_shipping_total() + WC()->cart->get_shipping_tax();
		$product_total = $total - $shipping_total;
		
		$pay_now = $total;
		
		switch ($partial_type) {
			case 'percentage':
				$pay_now = $total * ($partial_amount / 100);
				break;
			case 'shipping':
				$pay_now = $shipping_total;
				break;
			case 'shipping_percentage':
				$pay_now = $shipping_total + ($product_total * ($partial_amount / 100));
				break;
			case 'shipping_fixed':
				$pay_now = $shipping_total + $partial_amount;
				break;
			case 'fixed':
			default:
				$pay_now = $partial_amount;
				break;
		}
		
		// Safety checks
		if ($pay_now <= 0) {
			$pay_now = $total;
		}
		if ($pay_now > $total) {
			$pay_now = $total;
		}
		
		// Only show if there's a difference
		if (abs($total - $pay_now) <= 0.01) {
			return;
		}
		
		$pay_later = $total - $pay_now;
		
		// Display the notice
		$type_label = '';
		switch ($partial_type) {
			case 'shipping':
				$type_label = __('Shipping Cost Only', 'revenuepro-bkash-wc');
				break;
			case 'shipping_percentage':
				$type_label = sprintf(__('Shipping + %s%% of Product Price', 'revenuepro-bkash-wc'), $partial_amount);
				break;
			case 'shipping_fixed':
				$type_label = sprintf(__('Shipping + %s', 'revenuepro-bkash-wc'), wc_price($partial_amount));
				break;
			case 'percentage':
				$type_label = sprintf(__('%s%% of Total', 'revenuepro-bkash-wc'), $partial_amount);
				break;
			case 'fixed':
				$type_label = __('Fixed Amount', 'revenuepro-bkash-wc');
				break;
		}
		
		// Enhanced compact professional design for the checkout flow
		?>
		<div class="revenuepro-bkash-partial-notice" id="revenuepro-partial-notice" 
			 data-partial-type="<?php echo esc_attr($partial_type); ?>"
			 data-partial-amount="<?php echo esc_attr($partial_amount); ?>"
			 style="background: #f8fafc; border: 1px solid #e2e8f0; border-left: 4px solid #e2136e; border-radius: 6px; padding: 12px 16px; margin: 0 0 20px 0; font-family: system-ui, -apple-system, sans-serif;">
			
			<div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 10px;">
				<div>
					<h3 style="margin: 0; color: #1e293b; font-size: 15px; font-weight: 600; display: flex; align-items: center; gap: 6px;">
						<span style="font-size: 16px;">💳</span>
						<?php _e('Partial Payment with bKash', 'revenuepro-bkash-wc'); ?>
					</h3>
					<p style="margin: 2px 0 0 0; color: #64748b; font-size: 12px;">
						<?php echo esc_html($type_label); ?> &mdash; <?php _e('Remaining on Delivery', 'revenuepro-bkash-wc'); ?>
					</p>
				</div>
			</div>
			
			<div style="display: flex; flex-direction: column; gap: 6px; background: #fff; border-radius: 6px; padding: 10px 12px; border: 1px solid #f1f5f9;">
				<div style="display: flex; justify-content: space-between; align-items: center;">
					<span style="color: #475569; font-size: 13px; font-weight: 500;">
						<?php _e('Pay Now (bKash)', 'revenuepro-bkash-wc'); ?>
					</span>
					<span id="revenuepro-pay-now-amount" style="color: #e2136e; font-size: 16px; font-weight: 700;">
						<?php echo wc_price($pay_now); ?>
					</span>
				</div>
				<div style="display: flex; justify-content: space-between; align-items: center;">
					<span style="color: #64748b; font-size: 13px;">
						<?php _e('Pay on Delivery (Cash)', 'revenuepro-bkash-wc'); ?>
					</span>
					<span id="revenuepro-pay-later-amount" style="color: #475569; font-size: 14px; font-weight: 600;">
						<?php echo wc_price($pay_later); ?>
					</span>
				</div>
			</div>
		</div>
		
		<script type="text/javascript">
		jQuery(function($) {
			// Update partial payment amounts when checkout updates
			$(document.body).on('updated_checkout', function() {
				var notice = $('#revenuepro-partial-notice');
				if (!notice.length) return;
				
				var partialType = notice.data('partial-type');
				var partialAmount = parseFloat(notice.data('partial-amount'));
				
				// Get current cart totals from the order review
				var totalText = $('.order-total .woocommerce-Price-amount').text();
				var shippingText = $('.shipping .woocommerce-Price-amount').text();
				
				// Extract numeric values (remove currency symbols)
				var total = parseFloat(totalText.replace(/[^0-9.]/g, ''));
				var shipping = parseFloat(shippingText.replace(/[^0-9.]/g, ''));
				
				if (isNaN(total)) return;
				if (isNaN(shipping)) shipping = 0;
				
				var product = total - shipping;
				var payNow = total;
				
				// Calculate based on partial type
				switch(partialType) {
					case 'percentage':
						payNow = total * (partialAmount / 100);
						break;
					case 'shipping':
						payNow = shipping;
						break;
					case 'shipping_percentage':
						payNow = shipping + (product * (partialAmount / 100));
						break;
					case 'shipping_fixed':
						payNow = shipping + partialAmount;
						break;
					case 'fixed':
					default:
						payNow = partialAmount;
						break;
				}
				
				// Safety checks
				if (payNow <= 0) payNow = total;
				if (payNow > total) payNow = total;
				
				var payLater = total - payNow;
				
				// Update the display
				var currencySymbol = totalText.replace(/[0-9.,]/g, '').trim();
				$('#revenuepro-pay-now-amount').html('<span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">' + currencySymbol + '</span>' + payNow.toFixed(2) + '</bdi></span>');
				$('#revenuepro-pay-later-amount').html('<span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">' + currencySymbol + '</span>' + payLater.toFixed(2) + '</bdi></span>');

				// Update Place Order button text if partial payment is active
				var orderBtn = $('#place_order');
				if (orderBtn.length) {
					var btnHtml = orderBtn.html();
					var symbol = currencySymbol.trim() || '৳';
					var regex = new RegExp('(?:' + symbol + '|৳|BDT)\\s*[0-9.,]+', 'i');
					if (regex.test(btnHtml)) {
						orderBtn.html(btnHtml.replace(regex, symbol + ' ' + payNow.toFixed(2)));
					} else {
						var decimalRegex = /[0-9.,]+/;
						if (decimalRegex.test(btnHtml)) {
							orderBtn.html(btnHtml.replace(decimalRegex, payNow.toFixed(2)));
						} else {
							orderBtn.html('Place Order ' + symbol + ' ' + payNow.toFixed(2));
						}
					}
				}
			});
		});
		</script>
		<?php
	}

	public function inject_checkout_fraud_scripts() {
		?>
		<style>
		/* Fix bKash logo alignment in checkout payment methods */
		.wc_payment_method label img,
		.wc_payment_methods label img {
			display: inline-block !important;
			vertical-align: middle !important;
			max-height: 28px !important;
			width: auto !important;
			margin-left: 8px !important;
			margin-bottom: 0 !important;
			position: relative !important;
			top: -1px !important;
		}
		</style>
		<script type="text/javascript">
		jQuery(function($) {
			const phoneInput = $('#billing_phone');
			const checkoutBtn = $('#place_order');
			
			if (!phoneInput.length) return;

			// Force phone field blank on load — prevents browser/WC autofill
			phoneInput.attr('autocomplete', 'new-password');
			phoneInput.val('');

			// Also clear phone after every WooCommerce checkout AJAX refresh
			// (WC re-populates saved customer data on each updated_checkout)
			$(document.body).on('updated_checkout', function() {
				if (phoneInput.val() && !phoneInput.data('user-typed')) {
					phoneInput.val('');
				}
			});

			// Track when user actually types into the field
			phoneInput.on('input', function() {
				$(this).data('user-typed', true);
			});

			let apiCheckDelay;
			
			phoneInput.on('input change blur', function() {
				clearTimeout(apiCheckDelay);
				
				const rawVal = $(this).val();
				let val = rawVal.replace(/[^0-9\+]/g, '');
				
				if (val.startsWith('+88')) val = val.substring(3);
				else if (val.startsWith('88') && val.length > 2 && val.charAt(2) === '0') val = val.substring(2);

				const bdPhoneRegex = /^(01[3-9]\d{8})$/;
				
				if (bdPhoneRegex.test(val) && val.length === 11) {
					console.log('Valid BD Phone Number format detected, preparing API check:', val);
					
					// Disable checkout button while we check
					checkoutBtn.prop('disabled', true);
					checkoutBtn.text('Verifying Courier Details...');
					
					apiCheckDelay = setTimeout(function() {
						$.ajax({
							url: '/wp-json/revenuepro-bkash-wc/v1/fraud/check-phone',
							type: 'POST',
							contentType: 'application/json',
							data: JSON.stringify({ phone: val }),
							success: function(response) {
								console.log('Fraud check response:', response);
								// Reactivate button
								checkoutBtn.prop('disabled', false);
								
								// Restore WooCommerce text
								if (checkoutBtn.data('value')) {
									checkoutBtn.text(checkoutBtn.data('value'));
								} else {
									checkoutBtn.text('Place order');
								}

								// Force WooCommerce to refresh the payment gateways visually
								// This runs the PHP `woocommerce_available_payment_gateways` filter again.
								$(document.body).trigger('update_checkout');
							},
							error: function() {
								console.error('Failed to verify phone number with server.');
								checkoutBtn.prop('disabled', false);
								if (checkoutBtn.data('value')) {
									checkoutBtn.text(checkoutBtn.data('value'));
								} else {
									checkoutBtn.text('Place order');
								}
							}
						});
					}, 500); // 500ms debounce
					
				} else {
					// We only disable if we are actively checking the 11th digit. Standard woo handles required fields.
				}
			});
			
			// Save default button text for restoration
			if (!checkoutBtn.data('value')) {
				checkoutBtn.data('value', checkoutBtn.val() || checkoutBtn.text());
			}
		});
		</script>
		<?php
	}
}
