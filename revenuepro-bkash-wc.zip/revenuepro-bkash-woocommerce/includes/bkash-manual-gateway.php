<?php
namespace RevenuePro;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Manual bKash Payment Gateway
 * 
 * Customer sends money to admin's bKash number manually,
 * then provides the Transaction ID at checkout.
 * Order is placed as "on-hold" until admin verifies.
 */
class BkashManualGateway extends \WC_Payment_Gateway
{
    public function __construct()
    {
        $this->id = 'revenuepro_bkash_manual';
        $this->has_fields = true;
        $this->method_title = __('bKash Manual (RevenuePro)', 'revenuepro-bkash-wc');
        $this->method_description = __('Accept manual bKash payments. Customer sends money to your bKash number and provides the transaction ID.', 'revenuepro-bkash-wc');
        $this->supports = ['products'];

        // Get settings from RevenuePro dashboard
        $rp_settings = get_option('revenuepro_bkash_wc_settings', []);
        $this->icon = !empty($rp_settings['bkash_logo_url']) ? $rp_settings['bkash_logo_url'] : '';

        $this->init_form_fields();
        $this->init_settings();

        // Use RevenuePro dashboard settings as primary source
        $this->title = !empty($rp_settings['bkash_manual_title']) 
            ? $rp_settings['bkash_manual_title'] 
            : ($this->get_option('title') ?: __('bKash (Send Money)', 'revenuepro-bkash-wc'));
        
        $this->description = !empty($rp_settings['bkash_manual_description']) 
            ? $rp_settings['bkash_manual_description'] 
            : ($this->get_option('description') ?: __('Send money to our bKash number and enter your Transaction ID below.', 'revenuepro-bkash-wc'));
        
        $this->enabled = $this->get_option('enabled');

        add_action('woocommerce_update_options_payment_gateways_' . $this->id, [$this, 'process_admin_options']);
    }

    /**
     * Gateway form fields for WooCommerce settings page
     */
    public function init_form_fields()
    {
        $this->form_fields = [
            'enabled' => [
                'title'   => __('Enable/Disable', 'revenuepro-bkash-wc'),
                'type'    => 'checkbox',
                'label'   => __('Enable bKash Manual Payment', 'revenuepro-bkash-wc'),
                'default' => 'no',
            ],
            'title' => [
                'title'       => __('Title', 'revenuepro-bkash-wc'),
                'type'        => 'text',
                'description' => __('Payment method title the customer sees on checkout.', 'revenuepro-bkash-wc'),
                'default'     => __('bKash (Send Money)', 'revenuepro-bkash-wc'),
                'desc_tip'    => true,
            ],
            'description' => [
                'title'       => __('Description', 'revenuepro-bkash-wc'),
                'type'        => 'textarea',
                'description' => __('Payment method description the customer sees on checkout.', 'revenuepro-bkash-wc'),
                'default'     => __('Send money to our bKash number and enter your Transaction ID below.', 'revenuepro-bkash-wc'),
            ],
        ];
    }

    /**
     * Check if the gateway is available for use.
     */
    public function is_available()
    {
        if ($this->get_option('enabled') !== 'yes') {
            return false;
        }

        // Must have a bKash number configured
        $rp_settings = get_option('revenuepro_bkash_wc_settings', []);
        if (empty($rp_settings['bkash_manual_number'])) {
            return false;
        }

        return true;
    }

    /**
     * Render payment fields on checkout (shows redirection notice)
     */
    public function payment_fields()
    {
        $rp_settings = get_option('revenuepro_bkash_wc_settings', []);
        $bkash_number = !empty($rp_settings['bkash_manual_number']) ? $rp_settings['bkash_manual_number'] : '';
        
        echo '<div style="font-family: system-ui, -apple-system, sans-serif; margin-bottom: 12px; padding: 12px; background: #fff5f8; border-radius: 8px; border-left: 4px solid #e2136e; font-size: 13px; font-weight: 500; color: #991b1b;">';
        echo __('পেমেন্ট সম্পন্ন করতে আপনাকে বিকাশ সেন্ট্রাল পেমেন্ট গেটওয়েতে রিডাইরেক্ট করা হবে।', 'revenuepro-bkash-wc') . '<br/>';
        echo '<span style="font-size:11px; color:#4b5563;">' . sprintf(__('You will be redirected to the secure bKash payment portal to pay and verify. (Send money to: %s)', 'revenuepro-bkash-wc'), esc_html($bkash_number)) . '</span>';
        echo '</div>';
    }

    /**
     * Validate checkout fields
     */
    public function validate_fields()
    {
        return true;
    }

    /**
     * Process the payment and redirect to pay.codeblend.co
     */
    public function process_payment($order_id)
    {
        $order = wc_get_order($order_id);
        
        $rp_settings = get_option('revenuepro_bkash_wc_settings', []);
        $license_token = isset($rp_settings['license_token']) ? $rp_settings['license_token'] : '';
        $merchant_id = '';
        if (!empty($license_token)) {
            $jwt_data = \RevenuePro\LicenseManager::verify_revenuepro_jwt_token($license_token);
            if ($jwt_data && !empty($jwt_data->userId)) {
                $merchant_id = $jwt_data->userId;
            }
        }

        // Store transaction/method details and set status to pending
        $order->set_payment_method($this->id);
        $order->set_payment_method_title($this->title);
        $order->update_status('pending', __('Awaiting manual bKash payment verification via pay.codeblend.co redirection.', 'revenuepro-bkash-wc'));
        $order->save();

        // Calculate amount to pay
        $verify_amount = floatval($order->get_total());
        if ($order->get_meta('_is_partial_payment') === 'yes') {
            $partial_amt = floatval($order->get_meta('_partial_payment_amount'));
            if ($partial_amt > 0) {
                $verify_amount = $partial_amt;
            }
        }

        $callback_url = $this->get_return_url($order);
        
        $pay_url = 'https://pay.codeblend.co/pay';
        $redirect_url = add_query_arg([
            'amount'       => $verify_amount,
            'order_id'     => $order->get_id(),
            'number'       => $rp_settings['bkash_manual_number'] ?? '',
            'merchant'     => get_bloginfo('name'),
            'merchant_id'  => $merchant_id,
            'callback'     => $callback_url,
            'qr_code'      => $rp_settings['bkash_manual_qr_url'] ?? '',
            'display_mode' => $rp_settings['bkash_manual_display_mode'] ?? 'both',
        ], $pay_url);

        // Reduce stock levels
        wc_reduce_stock_levels($order_id);

        // Empty cart
        WC()->cart->empty_cart();

        return [
            'result'   => 'success',
            'redirect' => $redirect_url,
        ];
    }
}
