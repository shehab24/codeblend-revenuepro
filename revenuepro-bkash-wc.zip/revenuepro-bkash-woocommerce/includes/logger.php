<?php
namespace RevenuePro;

if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly.
}

/**
 * Central logger for the plugin.
 * All plugin components should use this instead of calling wc_get_logger() directly.
 * Writes to wp-content/uploads/wc-logs/revenuepro-bkash-YYYY-MM-DD-xxxx.log
 * Only logs when the 'general_enable_logging' setting is enabled.
 */
class Logger
{
	const HANDLE = 'revenuepro-bkash';

	public static function is_enabled()
	{
		$settings = get_option('revenuepro_bkash_wc_settings', []);
		return !empty($settings['general_enable_logging']);
	}

	public static function log($message, $level = 'info', $context = [])
	{
		if (!self::is_enabled()) {
			return;
		}
		if (!function_exists('wc_get_logger')) {
			return;
		}
		$context['source'] = self::HANDLE;
		wc_get_logger()->log($level, $message, $context);
	}

	public static function info($message, $context = [])
	{
		self::log($message, 'info', $context);
	}

	public static function warning($message, $context = [])
	{
		self::log($message, 'warning', $context);
	}

	public static function error($message, $context = [])
	{
		self::log($message, 'error', $context);
	}

	public static function debug($message, $context = [])
	{
		self::log($message, 'debug', $context);
	}
}
