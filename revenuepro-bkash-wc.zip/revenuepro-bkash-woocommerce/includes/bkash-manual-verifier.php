<?php
namespace RevenuePro;

if (!defined('ABSPATH')) {
    exit;
}

class BkashManualVerifier
{
    private static $table_name = 'revenuepro_bkash_sms_transactions';

    public static function init()
    {
        // Add hook to create table during database checks
        add_action('admin_init', [self::class, 'ensure_table_exists']);
        
        // Register AJAX verification action for checkout page
        add_action('wp_ajax_revenuepro_verify_bkash_trx', [self::class, 'handle_ajax_verify_trx']);
        add_action('wp_ajax_nopriv_revenuepro_verify_bkash_trx', [self::class, 'handle_ajax_verify_trx']);
    }

    /**
     * Create database table
     */
    public static function create_table()
    {
        global $wpdb;
        $table_name = $wpdb->prefix . self::$table_name;
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE IF NOT EXISTS $table_name (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            trx_id varchar(100) NOT NULL,
            sender varchar(20) NOT NULL,
            amount decimal(10,2) NOT NULL,
            raw_message text NOT NULL,
            status varchar(20) DEFAULT 'unused',
            order_id bigint(20) DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY trx_id (trx_id)
        ) $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    public static function ensure_table_exists()
    {
        if (is_admin() && !get_option('revenuepro_bkash_sms_table_created')) {
            self::create_table();
            update_option('revenuepro_bkash_sms_table_created', true);
        }
    }

    /**
     * Parse bKash SMS for TrxID, Amount, and Sender Number
     */
    public static function parse_bkash_sms($message)
    {
        $amount = 0.0;
        $trx_id = '';
        $sender = '';

        // Regex to find TrxID (alphanumeric, typically 10 characters e.g. 8N34KJL98S)
        if (preg_match('/TrxID\s*:?\s*([A-Z0-9]{8,12})/i', $message, $matches)) {
            $trx_id = strtoupper(trim($matches[1]));
        }

        // Regex to find Amount
        if (preg_match('/(?:received|In)\s+(?:Tk|TK)\s*([\d,]+\.?\d*)/i', $message, $matches)) {
            $amount = floatval(str_replace(',', '', $matches[1]));
        } elseif (preg_match('/(?:Tk|TK)\s*([\d,]+\.?\d*)\s+received/i', $message, $matches)) {
            $amount = floatval(str_replace(',', '', $matches[1]));
        }

        // Regex to find sender phone number (typically 11 digits starting with 01)
        if (preg_match('/from\s+(01[3-9]\d{8})/i', $message, $matches)) {
            $sender = trim($matches[1]);
        }

        return [
            'trx_id' => $trx_id,
            'amount' => $amount,
            'sender' => $sender
        ];
    }

    /**
     * Handle incoming SMS Gateway Webhook
     */
    public static function handle_webhook_request($request)
    {
        $rp_settings = get_option('revenuepro_bkash_wc_settings', []);
        $expected_token = $rp_settings['bkash_manual_sms_token'] ?? '';
        
        // Optional safety: if no token is set, generate a default one
        if (empty($expected_token)) {
            $expected_token = wp_generate_password(24, false, false);
            $rp_settings['bkash_manual_sms_token'] = $expected_token;
            update_option('revenuepro_bkash_wc_settings', $rp_settings);
        }

        // Authenticate webhook request
        $token = $request->get_param('token');
        if (empty($token) || $token !== $expected_token) {
            return new \WP_REST_Response([
                'status' => 'error',
                'message' => 'Unauthorized. Invalid token.'
            ], 401);
        }

        $message = $request->get_param('message');
        $sender_num = $request->get_param('sender'); // Phone sending SMS, usually 29090 or bKash

        if (empty($message)) {
            return new \WP_REST_Response([
                'status' => 'error',
                'message' => 'Missing message field.'
            ], 400);
        }

        // Parse SMS details
        $parsed = self::parse_bkash_sms($message);
        
        if (empty($parsed['trx_id'])) {
            // Keep a log for debugging but don't error out (could be a generic bKash message like check balance)
            \RevenuePro\Logger::warning("bKash SMS webhook received non-transaction SMS: " . $message);
            return new \WP_REST_Response([
                'status' => 'ignored',
                'message' => 'SMS parsed, but no TrxID found.'
            ], 200);
        }

        global $wpdb;
        $table_name = $wpdb->prefix . self::$table_name;

        // Insert into table (or ignore if duplicate)
        $inserted = $wpdb->insert(
            $table_name,
            [
                'trx_id'      => $parsed['trx_id'],
                'sender'      => $parsed['sender'],
                'amount'      => $parsed['amount'],
                'raw_message' => $message,
                'status'      => 'unused'
            ],
            ['%s', '%s', '%f', '%s', '%s']
        );

        if ($inserted) {
            \RevenuePro\Logger::info("Successfully parsed and saved bKash SMS transaction: TrxID={$parsed['trx_id']}, Amount={$parsed['amount']}");
            
            // Retro-check: see if there is an order on hold waiting for this transaction
            self::check_and_approve_pending_order($parsed['trx_id'], $parsed['amount']);
            
            return new \WP_REST_Response([
                'status'  => 'success',
                'message' => 'Transaction saved successfully.',
                'data'    => $parsed
            ], 200);
        }

        return new \WP_REST_Response([
            'status' => 'duplicate',
            'message' => 'Transaction already exists.'
        ], 200);
    }

    /**
     * Customer verification click via AJAX
     */
    public static function handle_ajax_verify_trx()
    {
        $trx_id = isset($_POST['trx_id']) ? strtoupper(sanitize_text_field(wp_unslash($_POST['trx_id']))) : '';
        $amount = isset($_POST['amount']) ? floatval($_POST['amount']) : 0.0;

        if (empty($trx_id)) {
            wp_send_json_error(['message' => __('Please enter a Transaction ID.', 'revenuepro-bkash-wc')]);
        }

        global $wpdb;
        $table_name = $wpdb->prefix . self::$table_name;

        // Find transaction
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM $table_name WHERE trx_id = %s",
                $trx_id
            )
        );

        if (!$row) {
            wp_send_json_error([
                'verified' => false,
                'message'  => __('Transaction ID not found yet. If you just sent the payment, please wait a minute and verify again, or proceed to submit your order for manual approval.', 'revenuepro-bkash-wc')
            ]);
        }

        if ($row->status === 'used') {
            wp_send_json_error([
                'verified' => false,
                'message'  => __('This Transaction ID has already been used for another order.', 'revenuepro-bkash-wc')
            ]);
        }

        // Allow a small tolerance for fractional amounts or roundoff (e.g. within 1 Taka)
        $diff = abs(floatval($row->amount) - $amount);
        if ($diff > 1.0) {
            wp_send_json_error([
                'verified' => false,
                'message'  => sprintf(
                    __('Amount mismatch. Sent: ৳%1$s, but Order Total is ৳%2$s. Please verify the amount sent.', 'revenuepro-bkash-wc'),
                    number_format($row->amount, 2),
                    number_format($amount, 2)
                )
            ]);
        }

        wp_send_json_success([
            'verified' => true,
            'message'  => sprintf(__('✅ Payment Verified! bKash received: ৳%s', 'revenuepro-bkash-wc'), number_format($row->amount, 2))
        ]);
    }

    /**
     * Check if a transaction is valid and unused during order placement
     */
    public static function verify_and_claim_transaction($trx_id, $amount, $order_id)
    {
        global $wpdb;
        $table_name = $wpdb->prefix . self::$table_name;

        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM $table_name WHERE trx_id = %s AND status = 'unused'",
                strtoupper($trx_id)
            )
        );

        if ($row) {
            $diff = abs(floatval($row->amount) - floatval($amount));
            if ($diff <= 1.0) {
                // Claim it
                $wpdb->update(
                    $table_name,
                    ['status' => 'used', 'order_id' => $order_id],
                    ['id' => $row->id]
                );
                return true;
            }
        }
        return false;
    }

    /**
     * Retro-active check: when an SMS webhook arrives, check if any "On-Hold" orders
     * are waiting for this TrxID and auto-approve them!
     */
    private static function check_and_approve_pending_order($trx_id, $amount)
    {
        // Find orders on hold where payment method is bKash Manual and TrxID matches
        $orders = wc_get_orders([
            'status'         => 'on-hold',
            'payment_method' => 'revenuepro_bkash_manual',
            'limit'          => 5,
        ]);

        foreach ($orders as $order) {
            $order_trx_id = strtoupper($order->get_transaction_id());
            if ($order_trx_id === strtoupper($trx_id)) {
                $order_total = floatval($order->get_total());
                $diff = abs($amount - $order_total);
                
                if ($diff <= 1.0) {
                    // Update transaction in DB
                    global $wpdb;
                    $table_name = $wpdb->prefix . self::$table_name;
                    $wpdb->update(
                        $table_name,
                        ['status' => 'used', 'order_id' => $order->get_id()],
                        ['trx_id' => strtoupper($trx_id)]
                    );

                    // Complete payment on WooCommerce
                    $order->payment_complete($trx_id);
                    $order->add_order_note(
                        sprintf(
                            __('✅ Payment auto-verified via incoming bKash SMS webhook. TrxID: %s | Amount: ৳%s', 'revenuepro-bkash-wc'),
                            $trx_id,
                            number_format($amount, 2)
                        )
                    );
                    \RevenuePro\Logger::info("Order #{$order->get_id()} auto-approved and completed via post-webhook verification.");
                    break;
                }
            }
        }
    }
}
