<?php
namespace RevenuePro;

if (!defined('ABSPATH')) {
    exit;
}

class AbandonedCartDB
{
    private static $table_name = 'revenuepro_abandoned_carts';

    public static function create_table()
    {
        global $wpdb;
        $table_name = $wpdb->prefix . self::$table_name;
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE IF NOT EXISTS $table_name (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            session_id varchar(255) NOT NULL,
            user_id bigint(20) DEFAULT NULL,
            customer_name varchar(255) DEFAULT NULL,
            customer_email varchar(255) DEFAULT NULL,
            customer_phone varchar(50) DEFAULT NULL,
            cart_contents longtext DEFAULT NULL,
            cart_total decimal(10,2) DEFAULT 0.00,
            currency varchar(10) DEFAULT 'BDT',
            checkout_data longtext DEFAULT NULL,
            status varchar(50) DEFAULT 'active',
            email_sent tinyint(1) DEFAULT 0,
            email_sent_at datetime DEFAULT NULL,
            recovered tinyint(1) DEFAULT 0,
            recovered_at datetime DEFAULT NULL,
            recovery_order_id bigint(20) DEFAULT NULL,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            abandoned_at datetime DEFAULT NULL,
            PRIMARY KEY  (id),
            KEY session_id (session_id),
            KEY customer_email (customer_email),
            KEY status (status),
            KEY created_at (created_at)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }

    public static function get_table_name()
    {
        global $wpdb;
        return $wpdb->prefix . self::$table_name;
    }

    public static function save_cart($data)
    {
        global $wpdb;
        $table_name = self::get_table_name();

        $defaults = [
            'session_id' => '',
            'user_id' => null,
            'customer_name' => null,
            'customer_email' => null,
            'customer_phone' => null,
            'cart_contents' => '',
            'cart_total' => 0.00,
            'currency' => 'BDT',
            'checkout_data' => '',
            'status' => 'active',
            'created_at' => current_time('mysql'),
            'updated_at' => current_time('mysql'),
        ];

        $data = wp_parse_args($data, $defaults);

        // Check if cart already exists for this session
        $existing = $wpdb->get_row($wpdb->prepare(
            "SELECT id FROM $table_name WHERE session_id = %s AND status = 'active'",
            $data['session_id']
        ));

        if ($existing) {
            // Update existing cart
            $data['updated_at'] = current_time('mysql');
            unset($data['created_at']);
            
            $wpdb->update(
                $table_name,
                $data,
                ['id' => $existing->id],
                ['%s', '%d', '%s', '%s', '%s', '%s', '%f', '%s', '%s', '%s', '%s'],
                ['%d']
            );
            
            return $existing->id;
        } else {
            // Insert new cart
            $wpdb->insert($table_name, $data);
            return $wpdb->insert_id;
        }
    }

    public static function mark_as_abandoned($session_id)
    {
        global $wpdb;
        $table_name = self::get_table_name();

        return $wpdb->update(
            $table_name,
            [
                'status' => 'abandoned',
                'abandoned_at' => current_time('mysql'),
                'updated_at' => current_time('mysql'),
            ],
            ['session_id' => $session_id, 'status' => 'active'],
            ['%s', '%s', '%s'],
            ['%s', '%s']
        );
    }

    public static function mark_as_recovered($cart_id, $order_id)
    {
        global $wpdb;
        $table_name = self::get_table_name();

        return $wpdb->update(
            $table_name,
            [
                'status' => 'recovered',
                'recovered' => 1,
                'recovered_at' => current_time('mysql'),
                'recovery_order_id' => $order_id,
                'updated_at' => current_time('mysql'),
            ],
            ['id' => $cart_id],
            ['%s', '%d', '%s', '%d', '%s'],
            ['%d']
        );
    }

    public static function mark_email_sent($cart_id)
    {
        global $wpdb;
        $table_name = self::get_table_name();

        return $wpdb->update(
            $table_name,
            [
                'email_sent' => 1,
                'email_sent_at' => current_time('mysql'),
                'updated_at' => current_time('mysql'),
            ],
            ['id' => $cart_id],
            ['%d', '%s', '%s'],
            ['%d']
        );
    }

    public static function get_abandoned_carts($args = [])
    {
        global $wpdb;
        $table_name = self::get_table_name();

        $defaults = [
            'status' => 'abandoned',
            'limit' => 10,
            'offset' => 0,
            'orderby' => 'created_at',
            'order' => 'DESC',
        ];

        $args = wp_parse_args($args, $defaults);

        $where = "WHERE status = %s";
        $query_args = [$args['status']];

        $sql = $wpdb->prepare(
            "SELECT * FROM $table_name $where ORDER BY {$args['orderby']} {$args['order']} LIMIT %d OFFSET %d",
            array_merge($query_args, [$args['limit'], $args['offset']])
        );

        return $wpdb->get_results($sql);
    }

    public static function get_cart_by_id($cart_id)
    {
        global $wpdb;
        $table_name = self::get_table_name();

        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table_name WHERE id = %d",
            $cart_id
        ));
    }

    public static function get_cart_by_session($session_id)
    {
        global $wpdb;
        $table_name = self::get_table_name();

        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table_name WHERE session_id = %s AND status = 'active' ORDER BY created_at DESC LIMIT 1",
            $session_id
        ));
    }

    public static function get_total_count($status = 'abandoned')
    {
        global $wpdb;
        $table_name = self::get_table_name();

        return $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table_name WHERE status = %s",
            $status
        ));
    }

    public static function delete_old_carts($days = 30)
    {
        global $wpdb;
        $table_name = self::get_table_name();

        $date = date('Y-m-d H:i:s', strtotime("-$days days"));

        return $wpdb->query($wpdb->prepare(
            "DELETE FROM $table_name WHERE created_at < %s AND status IN ('active', 'abandoned') AND recovered = 0",
            $date
        ));
    }
    public static function get_carts_to_process($cutoff_time)
    {
        global $wpdb;
        $table_name = self::get_table_name();

        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $table_name 
            WHERE status = 'active' 
            AND updated_at < %s 
            AND (customer_email IS NOT NULL AND customer_email != '' OR customer_phone IS NOT NULL AND customer_phone != '')
            AND cart_total > 0",
            $cutoff_time
        ));
    }

    public static function recover_carts_matching($session_id, $email, $phone, $order_id)
    {
        global $wpdb;
        $table_name = self::get_table_name();
        
        // We want to recover carts that are Active OR Abandoned
        // And match ANY of the identifiers provided
        
        $where_clauses = ["session_id = %s"];
        $params = [$session_id];
        
        if (!empty($email)) {
            $where_clauses[] = "customer_email = %s";
            $params[] = $email;
        }
        
        if (!empty($phone)) {
            $where_clauses[] = "customer_phone = %s";
            $params[] = $phone;
        }
        
        $where_sql = implode(' OR ', $where_clauses);
        
        // Find matching IDs first
        $sql = "SELECT id FROM $table_name 
                WHERE status IN ('active', 'abandoned') 
                AND ($where_sql)";
                
        $results = $wpdb->get_results($wpdb->prepare($sql, $params));
        
        if (!empty($results)) {
            foreach ($results as $row) {
                self::mark_as_recovered($row->id, $order_id);
            }
        }
    }
}
