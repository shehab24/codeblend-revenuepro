<?php
namespace RevenuePro;

if (!defined('ABSPATH')) {
    exit;
}

class PartialPayment
{
    public static function init()
    {
        $self = new self();
        
        // Checkout hooks
        add_action('woocommerce_checkout_create_order', [$self, 'save_partial_payment_meta'], 10, 2);
        add_action('woocommerce_new_order', [$self, 'auto_apply_partial_payment_to_new_order'], 10, 2);
        
        // Front-end display hooks
        add_action('woocommerce_thankyou', [$self, 'show_partial_payment_thankyou'], 15);
        add_action('woocommerce_order_details_after_order_table', [$self, 'show_partial_payment_customer_view_order'], 15);

        // WP-Admin hooks
        add_action('woocommerce_admin_order_totals_after_total', [$self, 'display_partial_payment_totals_in_admin'], 15);
        add_filter('woocommerce_order_get_formatted_order_total', [$self, 'modify_formatted_total_in_admin'], 15, 2);
    }

    public static function is_enabled()
    {
        $rp_settings = get_option('revenuepro_bkash_wc_settings', []);
        $wc_settings = get_option('woocommerce_revenuepro_bkash_settings', []);
        
        if (isset($rp_settings['bkash_partial_enabled'])) {
            return ($rp_settings['bkash_partial_enabled'] === true || $rp_settings['bkash_partial_enabled'] === 'true' || $rp_settings['bkash_partial_enabled'] === 1 || $rp_settings['bkash_partial_enabled'] === '1');
        } elseif (isset($wc_settings['partial_enabled'])) {
            return ($wc_settings['partial_enabled'] === 'yes');
        }
        return false;
    }

    public static function get_partial_amounts($total, $shipping_total = 0)
    {
        if (!self::is_enabled()) {
            return [
                'pay_now' => $total,
                'pay_later' => 0,
                'is_partial' => false
            ];
        }

        $rp_settings = get_option('revenuepro_bkash_wc_settings', []);
        $wc_settings = get_option('woocommerce_revenuepro_bkash_settings', []);

        $partial_type = isset($rp_settings['bkash_partial_type']) ? $rp_settings['bkash_partial_type'] : (isset($wc_settings['partial_type']) ? $wc_settings['partial_type'] : 'fixed');
        $partial_amount = isset($rp_settings['bkash_partial_amount']) ? floatval($rp_settings['bkash_partial_amount']) : (isset($wc_settings['partial_amount']) ? floatval($wc_settings['partial_amount']) : 100);

        $product_total = $total - $shipping_total;
        $pay_now = $total;

        switch ($partial_type) {
            case 'percentage':
                $pay_now = $total * ($partial_amount / 100);
                break;
            case 'shipping':
                $pay_now = $shipping_total;
                break;
            case 'shipping_percentage':
                $pay_now = $shipping_total + ($product_total * ($partial_amount / 100));
                break;
            case 'shipping_fixed':
                $pay_now = $shipping_total + $partial_amount;
                break;
            case 'fixed':
            default:
                $pay_now = $partial_amount;
                break;
        }

        if ($pay_now <= 0) {
            $pay_now = $total;
        }
        if ($pay_now > $total) {
            $pay_now = $total;
        }

        $pay_later = $total - $pay_now;
        $is_partial = (abs($total - $pay_now) > 0.01);

        return [
            'pay_now' => round($pay_now, 2),
            'pay_later' => round($pay_later, 2),
            'is_partial' => $is_partial
        ];
    }

    public function save_partial_payment_meta($order, $data = null)
    {
        if (!self::is_enabled()) {
            return;
        }

        $total = floatval($order->get_total());
        $shipping = floatval($order->get_shipping_total()) + floatval($order->get_shipping_tax());
        
        $amounts = self::get_partial_amounts($total, $shipping);

        if ($amounts['is_partial']) {
            $order->update_meta_data('_is_partial_payment', 'yes');
            $order->update_meta_data('_partial_payment_amount', $amounts['pay_now']);
            $order->update_meta_data('_partial_payment_due', $amounts['pay_later']);
        }
    }

    public function auto_apply_partial_payment_to_new_order($order_id, $order)
    {
        if (!self::is_enabled()) {
            return;
        }

        // Avoid infinite loop
        remove_action('woocommerce_new_order', [$this, 'auto_apply_partial_payment_to_new_order'], 10);

        $total = floatval($order->get_total());
        $shipping = floatval($order->get_shipping_total()) + floatval($order->get_shipping_tax());
        
        $amounts = self::get_partial_amounts($total, $shipping);

        if ($amounts['is_partial'] && $order->get_meta('_is_partial_payment') !== 'yes') {
            $order->update_meta_data('_is_partial_payment', 'yes');
            $order->update_meta_data('_partial_payment_amount', $amounts['pay_now']);
            $order->update_meta_data('_partial_payment_due', $amounts['pay_later']);
            $order->save();
        }

        add_action('woocommerce_new_order', [$this, 'auto_apply_partial_payment_to_new_order'], 10, 2);
    }

    public function show_partial_payment_thankyou($order_id)
    {
        $order = wc_get_order($order_id);
        if (!$order) return;

        if ($order->get_meta('_is_partial_payment') === 'yes') {
            $paid = floatval($order->get_meta('_partial_payment_amount'));
            $due = floatval($order->get_meta('_partial_payment_due'));
            ?>
            <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-left: 4px solid #e2136e; border-radius: 8px; padding: 16px; margin: 20px 0; font-family: system-ui, -apple-system, sans-serif; box-sizing: border-box; width: 100%;">
                <h3 style="margin: 0 0 12px 0; color: #1e293b; font-size: 16px; font-weight: 600; display: flex; align-items: center; gap: 8px;">
                    <span>💳</span> <?php _e('Partial Payment Summary', 'revenuepro-bkash-wc'); ?>
                </h3>
                <div style="display: flex; flex-direction: column; gap: 8px; background: #fff; border-radius: 6px; padding: 12px; border: 1px solid #f1f5f9;">
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <span style="color: #475569; font-size: 14px; font-weight: 500;"><?php _e('Amount Paid (bKash)', 'revenuepro-bkash-wc'); ?></span>
                        <span style="color: #e2136e; font-size: 16px; font-weight: 700;"><?php echo wc_price($paid); ?></span>
                    </div>
                    <div style="display: flex; justify-content: space-between; align-items: center; border-top: 1px solid #f1f5f9; padding-top: 8px; margin-top: 4px;">
                        <span style="color: #64748b; font-size: 14px;"><?php _e('Due Amount (Cash on Delivery)', 'revenuepro-bkash-wc'); ?></span>
                        <span style="color: #475569; font-size: 15px; font-weight: 600;"><?php echo wc_price($due); ?></span>
                    </div>
                </div>
            </div>
            <?php
        }
    }

    public function show_partial_payment_customer_view_order($order)
    {
        if ($order->get_meta('_is_partial_payment') === 'yes') {
            $paid = floatval($order->get_meta('_partial_payment_amount'));
            $due = floatval($order->get_meta('_partial_payment_due'));
            ?>
            <section style="margin-top: 24px; font-family: system-ui, -apple-system, sans-serif;">
                <h2 style="font-size: 18px; font-weight: 600; margin-bottom: 12px;"><?php _e('Partial Payment Details', 'revenuepro-bkash-wc'); ?></h2>
                <table class="woocommerce-table order_details" style="width: 100%; border-collapse: collapse;">
                    <tbody>
                        <tr>
                            <th scope="row" style="text-align: left; padding: 12px; border: 1px solid #e2e8f0; background: #f8fafc; font-weight: 600; color: #475569;"><?php _e('Paid Amount (bKash)', 'revenuepro-bkash-wc'); ?></th>
                            <td style="padding: 12px; border: 1px solid #e2e8f0; text-align: right; font-weight: 700; color: #e2136e;"><?php echo wc_price($paid); ?></td>
                        </tr>
                        <tr>
                            <th scope="row" style="text-align: left; padding: 12px; border: 1px solid #e2e8f0; background: #f8fafc; font-weight: 600; color: #475569;"><?php _e('Due Amount (Cash on Delivery)', 'revenuepro-bkash-wc'); ?></th>
                            <td style="padding: 12px; border: 1px solid #e2e8f0; text-align: right; font-weight: 700; color: #475569;"><?php echo wc_price($due); ?></td>
                        </tr>
                    </tbody>
                </table>
            </section>
            <?php
        }
    }

    public function display_partial_payment_totals_in_admin($order_id)
    {
        $order = wc_get_order($order_id);
        if (!$order) return;

        if ($order->get_meta('_is_partial_payment') === 'yes') {
            $paid = floatval($order->get_meta('_partial_payment_amount'));
            $due = floatval($order->get_meta('_partial_payment_due'));
            ?>
            <tr>
                <td class="label" style="font-weight: bold; color: #e2136e; padding: 8px 10px;"><?php _e('Amount Paid (bKash):', 'revenuepro-bkash-wc'); ?></td>
                <td width="1%" style="font-weight: bold; color: #e2136e; text-align: right; padding: 8px 10px;"><?php echo wc_price($paid); ?></td>
            </tr>
            <tr>
                <td class="label" style="font-weight: bold; color: #475569; padding: 8px 10px;"><?php _e('Amount Due (Cash on Delivery):', 'revenuepro-bkash-wc'); ?></td>
                <td width="1%" style="font-weight: bold; color: #475569; text-align: right; padding: 8px 10px;"><?php echo wc_price($due); ?></td>
            </tr>
            <?php
        }
    }

    public function modify_formatted_total_in_admin($formatted_total, $order)
    {
        if (is_admin() && $order->get_meta('_is_partial_payment') === 'yes') {
            $paid = floatval($order->get_meta('_partial_payment_amount'));
            $due = floatval($order->get_meta('_partial_payment_due'));
            
            $formatted_total .= '<div style="font-size: 11px; margin-top: 5px; line-height: 1.3; font-weight: normal;">';
            $formatted_total .= '<span style="color: #16a34a; font-weight: 600; display: inline-block;">Paid: ' . wc_price($paid) . '</span><br>';
            $formatted_total .= '<span style="color: #ef4444; font-weight: 600; display: inline-block;">Due: ' . wc_price($due) . '</span>';
            $formatted_total .= '</div>';
        }
        return $formatted_total;
    }
}
