<?php
namespace RevenuePro;

if (!defined('ABSPATH')) {
    exit;
}

class Api
{
    public static function init()
    {
        $self = new self();
        add_action('rest_api_init', [$self, 'register_routes']);
        add_action('wp_ajax_revenuepro_get_cart_details', [$self, 'ajax_get_cart_details']);
    }

    public function register_routes()
    {
        register_rest_route('revenuepro-bkash-wc/v1', '/settings', [
            [
                'methods' => 'GET',
                'callback' => [$this, 'get_settings'],
                'permission_callback' => [$this, 'check_permission'],
            ],
            [
                'methods' => 'POST',
                'callback' => [$this, 'update_settings'],
                'permission_callback' => [$this, 'check_permission'],
            ],
        ]);

        register_rest_route('revenuepro-bkash-wc/v1', '/feature-request', [
            'methods' => 'POST',
            'callback' => [$this, 'handle_feature_request'],
            'permission_callback' => [$this, 'check_permission'],
        ]);
        register_rest_route('revenuepro-bkash-wc/v1', '/dashboard/stats', [
            'methods' => 'GET',
            'callback' => [$this, 'get_dashboard_stats'],
            'permission_callback' => [$this, 'check_permission'],
        ]);
        register_rest_route('revenuepro-bkash-wc/v1', '/transactions', [
            [
                'methods' => 'GET',
                'callback' => [$this, 'get_transaction_logs'],
                'permission_callback' => [$this, 'check_permission'],
            ],
            [
                'methods' => 'DELETE',
                'callback' => [$this, 'delete_transactions'],
                'permission_callback' => [$this, 'check_permission'],
            ]
        ]);
        register_rest_route('revenuepro-bkash-wc/v1', '/transactions/export', [
            'methods' => 'GET',
            'callback' => [$this, 'export_transactions'],
            'permission_callback' => [$this, 'check_permission'],
        ]);
        register_rest_route('revenuepro-bkash-wc/v1', '/abandoned-carts', [
            'methods' => 'GET',
            'callback' => [$this, 'get_abandoned_carts_api'],
            'permission_callback' => [$this, 'check_permission'],
        ]);

        register_rest_route('revenuepro-bkash-wc/v1', '/abandoned-carts/(?P<id>\d+)/recover', [
            'methods' => 'POST',
            'callback' => [$this, 'mark_abandoned_cart_recovered'],
            'permission_callback' => [$this, 'check_permission'],
            'args' => ['id' => ['validate_callback' => fn($p) => is_numeric($p)]],
        ]);

        register_rest_route('revenuepro-bkash-wc/v1', '/abandoned-carts/(?P<id>\d+)/create-order', [
            'methods' => 'POST',
            'callback' => [$this, 'create_order_from_cart'],
            'permission_callback' => [$this, 'check_permission'],
            'args' => ['id' => ['validate_callback' => fn($p) => is_numeric($p)]],
        ]);
        
        register_rest_route('revenuepro-bkash-wc/v1', '/fraud/stats', [
            'methods' => 'GET',
            'callback' => [$this, 'get_fraud_stats_api'],
            'permission_callback' => [$this, 'check_permission'],
        ]);

        // Public endpoint for frontend checkout
        register_rest_route('revenuepro-bkash-wc/v1', '/fraud/check-phone', [
            'methods' => 'POST',
            'callback' => [$this, 'frontend_check_phone_fraud'],
            'permission_callback' => '__return_true', // Open for checkout process
        ]);

        // Debug log viewer
        register_rest_route('revenuepro-bkash-wc/v1', '/debug-log', [
            [
                'methods' => 'GET',
                'callback' => [$this, 'get_debug_log'],
                'permission_callback' => [$this, 'check_permission'],
            ],
            [
                'methods' => 'DELETE',
                'callback' => [$this, 'clear_debug_log'],
                'permission_callback' => [$this, 'check_permission'],
            ],
        ]);

        // Write a test log entry to verify logging works
        register_rest_route('revenuepro-bkash-wc/v1', '/test-log', [
            'methods' => 'POST',
            'callback' => [$this, 'write_test_log'],
            'permission_callback' => [$this, 'check_permission'],
        ]);

        // Steadfast Webhook (public — auth is handled via Bearer token inside the handler)
        register_rest_route('revenuepro-bkash-wc/v1', '/webhook/steadfast', [
            'methods' => 'POST',
            'callback' => [new \RevenuePro\CourierManager(), 'handle_steadfast_webhook'],
            'permission_callback' => '__return_true',
        ]);

        // bKash Manual SMS Gateway Webhook
        register_rest_route('revenuepro-bkash-wc/v1', '/webhook/bkash-sms', [
            'methods'             => 'POST',
            'callback'            => ['\RevenuePro\BkashManualVerifier', 'handle_webhook_request'],
            'permission_callback' => '__return_true',
        ]);

        // Public site-data endpoint — authenticated via license token
        // Your Node.js server can call: GET {site_url}/wp-json/revenuepro-bkash-wc/v1/site-data?token=xxx
        register_rest_route('revenuepro-bkash-wc/v1', '/site-data', [
            'methods' => 'GET',
            'callback' => [$this, 'get_site_data'],
            'permission_callback' => '__return_true', // Auth handled inside callback via token
        ]);
    }

    public function get_abandoned_carts_api($request)
    {
        $page = isset($request['page']) ? intval($request['page']) : 1;
        $status = isset($request['status']) && !empty($request['status']) ? sanitize_text_field($request['status']) : 'abandoned';
        $per_page = 20;
        $offset = ($page - 1) * $per_page;

        $carts = \RevenuePro\AbandonedCartDB::get_abandoned_carts([
            'status' => $status,
            'limit' => $per_page,
            'offset' => $offset,
        ]);

        $total_carts = \RevenuePro\AbandonedCartDB::get_total_count($status);

        // Format for API
        $formatted_carts = [];
        foreach ($carts as $cart) {
            $cart_items = json_decode($cart->cart_contents, true) ?: [];
            $item_count = count($cart_items);
            $abandoned_time = human_time_diff(strtotime($cart->abandoned_at ?: $cart->created_at), current_time('timestamp'));
            
            $checkout = json_decode($cart->checkout_data, true) ?: [];
            $formatted_carts[] = [
                'id'              => $cart->id,
                'customer_name'   => $cart->customer_name ?: 'N/A',
                'customer_email'  => $cart->customer_email,
                'customer_phone'  => $cart->customer_phone,
                'cart_total'      => wc_price($cart->cart_total),
                'cart_total_raw'  => (float) $cart->cart_total,
                'item_count'      => $item_count,
                'cart_contents'   => $cart_items,
                'checkout_data'   => $checkout,
                'has_address'     => !empty($checkout['billing_address_1']) || !empty($checkout['billing_city']),
                'abandoned_time'  => $abandoned_time . ' ago',
                'email_sent'      => (bool) $cart->email_sent,
                'email_sent_at'   => $cart->email_sent_at ? human_time_diff(strtotime($cart->email_sent_at), current_time('timestamp')) . ' ago' : null,
                'status'          => $cart->status,
                'recovery_order_id' => $cart->recovery_order_id ? (int) $cart->recovery_order_id : null,
            ];
        }

        return rest_ensure_response([
            'carts' => $formatted_carts,
            'total' => $total_carts,
            'pages' => ceil($total_carts / $per_page)
        ]);
    }

    /**
     * POST /abandoned-carts/{id}/recover
     * Mark a cart as manually recovered by admin (no order created).
     */
    public function mark_abandoned_cart_recovered($request)
    {
        $cart_id = intval($request['id']);
        $cart = \RevenuePro\AbandonedCartDB::get_cart_by_id($cart_id);

        if (!$cart) {
            return new \WP_Error('not_found', 'Cart not found.', ['status' => 404]);
        }

        \RevenuePro\AbandonedCartDB::mark_as_recovered($cart_id, 0);

        return rest_ensure_response(['success' => true, 'message' => 'Cart marked as recovered.']);
    }

    /**
     * POST /abandoned-carts/{id}/create-order
     * Create a WooCommerce order from the abandoned cart data.
     */
    public function create_order_from_cart($request)
    {
        $cart_id = intval($request['id']);
        $cart    = \RevenuePro\AbandonedCartDB::get_cart_by_id($cart_id);

        if (!$cart) {
            return new \WP_Error('not_found', 'Cart not found.', ['status' => 404]);
        }

        $cart_items   = json_decode($cart->cart_contents, true) ?: [];
        $checkout     = json_decode($cart->checkout_data,  true) ?: [];

        if (empty($cart_items)) {
            return new \WP_Error('empty_cart', 'No cart items found.', ['status' => 400]);
        }

        try {
            $order = wc_create_order();

            // Add products
            foreach ($cart_items as $item) {
                $pid = intval($item['product_id'] ?? 0);
                $vid = intval($item['variation_id'] ?? 0);
                $qty = max(1, intval($item['quantity'] ?? 1));

                if ($vid > 0) {
                    $product = wc_get_product($vid);
                } else {
                    $product = wc_get_product($pid);
                }

                if ($product) {
                    $order->add_product($product, $qty);
                }
            }

            // Billing / Shipping from stored checkout_data
            $name_parts  = explode(' ', $cart->customer_name ?: '', 2);
            $first_name  = $checkout['billing_first_name'] ?? ($name_parts[0] ?? '');
            $last_name   = $checkout['billing_last_name']  ?? ($name_parts[1] ?? '');
            $phone       = $checkout['billing_phone']      ?? ($cart->customer_phone ?? '');
            $email       = $checkout['billing_email']      ?? ($cart->customer_email ?? '');
            $address1    = $checkout['billing_address_1']  ?? '';
            $address2    = $checkout['billing_address_2']  ?? '';
            $city        = $checkout['billing_city']       ?? '';
            $state       = $checkout['billing_state']      ?? '';
            $postcode    = $checkout['billing_postcode']   ?? '';
            $country     = $checkout['billing_country']    ?? 'BD';

            $order->set_billing_first_name($first_name);
            $order->set_billing_last_name($last_name);
            $order->set_billing_phone($phone);
            $order->set_billing_email($email);
            $order->set_billing_address_1($address1);
            $order->set_billing_address_2($address2);
            $order->set_billing_city($city);
            $order->set_billing_state($state);
            $order->set_billing_postcode($postcode);
            $order->set_billing_country($country);

            $order->set_shipping_first_name($first_name);
            $order->set_shipping_last_name($last_name);
            $order->set_shipping_address_1($address1);
            $order->set_shipping_address_2($address2);
            $order->set_shipping_city($city);
            $order->set_shipping_state($state);
            $order->set_shipping_postcode($postcode);
            $order->set_shipping_country($country);

            $order->set_payment_method('cod');
            $order->set_payment_method_title('Cash on Delivery');

            // Add custom order note if provided
            $note = isset($request['note']) ? sanitize_textarea_field(wp_unslash($request['note'])) : '';
            if (!empty($note)) {
                $order->add_order_note($note);
            }

            $order->update_meta_data('_recovered_abandoned_cart_id', $cart_id);
            $order->calculate_totals();
            $order->update_status('processing', 'Order created by admin from abandoned cart #' . $cart_id);

            // Mark cart as recovered
            \RevenuePro\AbandonedCartDB::mark_as_recovered($cart_id, $order->get_id());

            $order_edit_url = admin_url('post.php?post=' . $order->get_id() . '&action=edit');
            // HPOS compatible edit URL
            if (class_exists('\Automattic\WooCommerce\Internal\DataStores\Orders\CustomOrdersTableController')) {
                $order_edit_url = admin_url('admin.php?page=wc-orders&action=edit&id=' . $order->get_id());
            }

            return rest_ensure_response([
                'success'   => true,
                'order_id'  => $order->get_id(),
                'order_url' => $order_edit_url,
                'message'   => 'Order #' . $order->get_id() . ' created successfully.',
            ]);

        } catch (\Exception $e) {
            return new \WP_Error('order_failed', $e->getMessage(), ['status' => 500]);
        }
    }

    public function frontend_check_phone_fraud($request)
    {
        $params = $request->get_json_params();
        $phone = sanitize_text_field($params['phone'] ?? '');
        
        $phone = preg_replace('/[^0-9]/', '', $phone);
        if (strpos($phone, '8801') === 0) {
            $phone = substr($phone, 2);
        }

        if (strlen($phone) !== 11) {
            return rest_ensure_response(['status' => 'invalid_format']);
        }

        // We use FraudDetection class to do the logic.
        require_once __DIR__ . '/fraud-detection.php';
        
        // This method will handle both Local DB check and external API call
        $data = \RevenuePro\FraudDetection::check_and_cache_phone($phone);

        return rest_ensure_response([
            'status' => $data ? 'success' : 'failed',
            'data' => $data
        ]);
    }

    public function get_fraud_stats_api($request)
    {
        $page = isset($request['page']) ? intval($request['page']) : 1;
        $per_page = isset($request['per_page']) ? intval($request['per_page']) : 100;
        $offset = ($page - 1) * $per_page;

        require_once __DIR__ . '/fraud-detection-db.php';
        
        $stats = \RevenuePro\FraudDetectionDB::get_all_stats($per_page, $offset);
        $total = \RevenuePro\FraudDetectionDB::get_total_count();

        return rest_ensure_response([
            'data' => $stats,
            'total' => $total,
            'pages' => ceil($total / $per_page),
            'page' => $page
        ]);
    }

    public function export_transactions($request)
    {
        $ids_param = $request->get_param('ids');
        $ids = !empty($ids_param) ? explode(',', $ids_param) : [];

        $args = [
            'payment_method' => ['revenuepro_bkash', 'revenuepro_bkash_manual'],
            'limit' => -1, // Fetch all if no IDs
        ];

        if (!empty($ids)) {
            $args['post__in'] = $ids;
        }

        $orders = wc_get_orders($args);
        
        // Define CSV Headers
        $csv_data = "Transaction ID,bKash Number,Amount,Order ID,Date,Status\n";

        foreach ($orders as $order) {
            $trx_id = $order->get_transaction_id() ?: 'N/A';
            $customer_number = $order->get_meta('_bkash_customer_number') ?: 'N/A';
            $amount = $order->get_total();
            $order_number = $order->get_order_number();
            $date = $order->get_date_created()->format('Y-m-d H:i:s');
            $status = $order->get_status();

            // Sanitize for CSV (simple)
            $row = [
                '"' . str_replace('"', '""', $trx_id) . '"',
                '"' . str_replace('"', '""', $customer_number) . '"',
                '"' . str_replace('"', '""', $amount) . '"',
                '"' . str_replace('"', '""', $order_number) . '"',
                '"' . str_replace('"', '""', $date) . '"',
                '"' . str_replace('"', '""', $status) . '"',
            ];
            
            $csv_data .= implode(',', $row) . "\n";
        }

        return rest_ensure_response([
            'csv_data' => $csv_data,
            'filename' => 'bkash_transactions_' . date('Y-m-d') . '.csv'
        ]);
    }

    public function delete_transactions($request)
    {
        $params = $request->get_json_params();
        $ids = isset($params['ids']) ? $params['ids'] : [];

        if (empty($ids) || !is_array($ids)) {
            return new \WP_Error('invalid_ids', 'No IDs provided', ['status' => 400]);
        }

        $deleted_count = 0;
        foreach ($ids as $id) {
            $order = wc_get_order($id);
            if ($order) {
                $order->delete(false); // Move to trash
                $deleted_count++;
            }
        }

        return rest_ensure_response(['success' => true, 'deleted' => $deleted_count]);
    }

    public function get_transaction_logs($request)
    {
        $page = isset($_GET['page']) ? intval($_GET['page']) : 1;
        $per_page = 10;
        
        $args = [
            'payment_method' => ['revenuepro_bkash', 'revenuepro_bkash_manual'],
            'limit' => $per_page,
            'page'  => $page,
            'paginate' => true,
        ];

        $results = wc_get_orders($args);
        $orders = $results->orders;

        $logs = [];
        $successful_count = 0;
        
        foreach ($orders as $order) {
            // Only show orders with a bKash transaction ID (successful payments)
            $trx_id = $order->get_transaction_id();
            if (empty($trx_id)) {
                continue; // Skip orders without transaction ID (failed/cancelled)
            }
            
            $successful_count++;
            $logs[] = [
                'id' => $order->get_id(),
                'order_number' => $order->get_order_number(),
                'date' => $order->get_date_created()->format('Y-m-d H:i:s'),
                'amount' => $order->get_total(),
                'status' => $order->get_status(),
                'trx_id' => $trx_id,
                'customer_number' => $order->get_meta('_bkash_customer_number') ?: 'N/A',
                'view_url' => $order->get_edit_order_url(),
            ];
        }

        return rest_ensure_response([
            'logs' => $logs,
            'total' => $successful_count,
            'pages' => ceil($successful_count / $per_page)
        ]);
    }

    public function get_dashboard_stats()
    {
        global $wpdb;

        // 1. Total bKash Sales (Support for both HPOS and Legacy CPT)
        $bkash_orders = wc_get_orders([
            'payment_method' => ['revenuepro_bkash', 'revenuepro_bkash_manual'],
            'status'         => ['wc-processing', 'wc-completed'],
            'limit'          => -1,
            'return'         => 'objects',
        ]);

        $total_sales = 0;
        foreach ($bkash_orders as $order) {
            $total_sales += floatval($order->get_total());
        }

        // 2. Partial Orders (Count orders that have _bkash_partial_amount or _rp_partial_payment meta)
        $partial_orders = $wpdb->get_var("
            SELECT COUNT(DISTINCT post_id) 
            FROM {$wpdb->postmeta} 
            WHERE meta_key IN ('_rp_partial_payment_amount', '_rp_is_partial_payment', '_bkash_partial_amount')
            AND meta_value != ''
            AND meta_value != '0'
        ");

        // 3. Fraud Blocked (Total rows in the fraud stats table)
        require_once __DIR__ . '/fraud-detection-db.php';
        $fraud_blocked = \RevenuePro\FraudDetectionDB::get_total_count();

        // 4. Abandoned Carts
        $abandoned_carts = \RevenuePro\AbandonedCartDB::get_total_count('abandoned');
        $recovered_carts = \RevenuePro\AbandonedCartDB::get_total_count('recovered');
        
        $total_tracked = $abandoned_carts + $recovered_carts;
        $recovery_rate = $total_tracked > 0 ? round(($recovered_carts / $total_tracked) * 100, 1) . '%' : '0%';

        // 5. Courier Sent (Optional: Count steadfast + pathao)
        $courier_sent = $wpdb->get_var("
            SELECT COUNT(DISTINCT post_id) 
            FROM {$wpdb->postmeta} 
            WHERE meta_key IN ('_steadfast_consignment_id', '_pathao_consignment_id')
        ");

        // 6. Recent bKash Transactions
        $recent_orders = wc_get_orders([
            'payment_method' => ['revenuepro_bkash', 'revenuepro_bkash_manual'],
            'limit' => 5,
            'orderby' => 'date',
            'order' => 'DESC',
        ]);
        
        $recent_transactions = [];
        foreach ($recent_orders as $order) {
            $trx_id = $order->get_transaction_id();
            if (empty($trx_id)) continue;
            
            $recent_transactions[] = [
                'id' => $order->get_id(),
                'order_number' => $order->get_order_number(),
                'amount' => wc_price($order->get_total()),
                'status' => wc_get_order_status_name($order->get_status()),
                'trx_id' => $trx_id,
                'time' => human_time_diff($order->get_date_created()->getOffsetTimestamp(), current_time('timestamp')) . ' ago',
                'url' => $order->get_edit_order_url()
            ];
        }

        return rest_ensure_response([
            'total_sales' => html_entity_decode(wp_strip_all_tags(wc_price($total_sales))),
            'partial_orders' => intval($partial_orders),
            'fraud_blocked' => intval($fraud_blocked),
            'abandoned_carts' => intval($abandoned_carts),
            'recovery_rate' => $recovery_rate,
            'courier_sent' => intval($courier_sent),
            'recent_transactions' => $recent_transactions
        ]);
    }

    /**
     * Public endpoint: GET /wp-json/revenuepro-bkash-wc/v1/site-data?token=xxx
     * Returns comprehensive site stats. Authenticated via license token.
     * Your Node.js server can call this to pull live data from any customer site.
     */
    public function get_site_data($request)
    {
        // Authenticate via license token
        $token = $request->get_param('token');
        $settings = get_option('revenuepro_bkash_wc_settings', []);
        $stored_token = isset($settings['license_token']) ? $settings['license_token'] : '';

        if (empty($token)) {
            return new \WP_Error('unauthorized', 'Missing token', ['status' => 401]);
        }

        // Check if token matches stored token, OR if it's a valid signed token, OR if it's the license key itself
        $is_valid = false;
        $stored_license_key = isset($settings['license_key']) ? $settings['license_key'] : '';
        
        if (!empty($stored_token) && $token === $stored_token) {
            $is_valid = true;
        } elseif (!empty($stored_license_key) && $token === $stored_license_key) {
            // Fallback: accept the raw license key as auth (sent by CodeBlend server when JWT is unavailable)
            $is_valid = true;
        } else {
            require_once __DIR__ . '/license-manager.php';
            $jwt_data = \RevenuePro\LicenseManager::verify_revenuepro_jwt_token($token);
            if ($jwt_data !== false && isset($jwt_data->license)) {
                $is_valid = true;
            }
        }

        if (!$is_valid) {
            return new \WP_Error('unauthorized', 'Invalid token', ['status' => 401]);
        }

        // --- Gather site data ---

        // 1. Basic site info
        $site_info = [
            'site_url'       => get_site_url(),
            'site_name'      => get_bloginfo('name'),
            'wp_version'     => get_bloginfo('version'),
            'wc_version'     => defined('WC_VERSION') ? WC_VERSION : 'N/A',
            'plugin_version' => defined('REVENUEPRO_VERSION') ? REVENUEPRO_VERSION : '1.0.0',
            'php_version'    => phpversion(),
            'license_key'    => isset($settings['license_key']) ? $settings['license_key'] : '',
            'license_plan'   => isset($settings['license_plan']) ? $settings['license_plan'] : 'Free / Unlicensed',
            'payment_mode'   => isset($settings['bkash_payment_mode']) ? $settings['bkash_payment_mode'] : 'automated',
        ];

        // 2. ALL order stats (not just bKash)
        $all_success_orders = wc_get_orders([
            'status' => ['wc-processing', 'wc-completed'],
            'limit'  => -1,
            'return' => 'objects',
        ]);

        $total_revenue = 0;
        $bkash_revenue = 0;
        $cod_revenue = 0;
        $other_revenue = 0;
        $total_orders = count($all_success_orders);
        $bkash_orders_count = 0;
        $cod_orders_count = 0;
        $other_orders_count = 0;

        foreach ($all_success_orders as $order) {
            $amount = floatval($order->get_total());
            $total_revenue += $amount;
            $method = $order->get_payment_method();
            
            if (in_array($method, ['revenuepro_bkash', 'revenuepro_bkash_manual'])) {
                $bkash_revenue += $amount;
                $bkash_orders_count++;
            } elseif ($method === 'cod') {
                $cod_revenue += $amount;
                $cod_orders_count++;
            } else {
                $other_revenue += $amount;
                $other_orders_count++;
            }
        }

        // 3. Pending / On-hold orders (all methods)
        $pending_orders = wc_get_orders([
            'status' => ['wc-on-hold', 'wc-pending'],
            'limit'  => -1,
            'return' => 'ids',
        ]);

        // Cancelled / Failed orders count
        $cancelled_orders = wc_get_orders([
            'status' => ['wc-cancelled', 'wc-failed', 'wc-refunded'],
            'limit'  => -1,
            'return' => 'ids',
        ]);

        // 4. Fraud stats count
        require_once __DIR__ . '/fraud-detection-db.php';
        $fraud_count = \RevenuePro\FraudDetectionDB::get_total_count();

        // 5. Abandoned carts
        $abandoned_carts = \RevenuePro\AbandonedCartDB::get_total_count('abandoned');
        $recovered_carts = \RevenuePro\AbandonedCartDB::get_total_count('recovered');

        // 6. Recent transactions (ALL payment methods) — supports ?limit=N&status=x,y params
        $req_limit = intval($request->get_param('limit')) ?: 15;
        if ($req_limit > 100) $req_limit = 100; // safety cap
        $req_page  = intval($request->get_param('page')) ?: 1;
        
        $order_query = [
            'limit'   => $req_limit,
            'page'    => $req_page,
            'orderby' => 'date',
            'order'   => 'DESC',
        ];
        
        // Optional status filter: ?status=processing,completed
        $req_status = $request->get_param('status');
        if (!empty($req_status)) {
            $statuses = array_map(function($s) { 
                $s = trim($s);
                return strpos($s, 'wc-') === 0 ? $s : 'wc-' . $s; 
            }, explode(',', $req_status));
            $order_query['status'] = $statuses;
        } else {
            // Default: show all real order statuses, exclude checkout-draft and trash
            $order_query['status'] = ['wc-processing', 'wc-completed', 'wc-on-hold', 'wc-pending', 'wc-cancelled', 'wc-failed', 'wc-refunded', 'wc-ready-to-ship'];
        }
        
        // Optional campaign filter: ?campaign=summer_sale
        $req_campaign = $request->get_param('campaign');
        if (!empty($req_campaign)) {
            $order_query['meta_query'] = [
                'relation' => 'OR',
                [
                    'key'     => '_utm_campaign',
                    'value'   => $req_campaign,
                    'compare' => '='
                ],
                [
                    'key'     => 'utm_campaign',
                    'value'   => $req_campaign,
                    'compare' => '='
                ]
            ];
        }
        
        $recent_orders = wc_get_orders($order_query);

        $recent_transactions = [];
        foreach ($recent_orders as $order) {
            $method = $order->get_payment_method();
            $method_title = $order->get_payment_method_title() ?: ucfirst($method);
            
            // Determine payment method label
            if (in_array($method, ['revenuepro_bkash', 'revenuepro_bkash_manual'])) {
                $method_label = 'bKash';
                $payment_type = $order->get_meta('_bkash_payment_type') ?: 'automated';
            } elseif ($method === 'cod') {
                $method_label = 'COD';
                $payment_type = 'cash';
            } else {
                $method_label = $method_title;
                $payment_type = $method;
            }

            // Gather UTM / referral source data for future ad tracking
            $utm_source   = $order->get_meta('_utm_source') ?: $order->get_meta('utm_source') ?: null;
            $utm_medium   = $order->get_meta('_utm_medium') ?: $order->get_meta('utm_medium') ?: null;
            $utm_campaign = $order->get_meta('_utm_campaign') ?: $order->get_meta('utm_campaign') ?: null;
            $fbclid       = $order->get_meta('_fbclid') ?: $order->get_meta('fbclid') ?: null;

            $recent_transactions[] = [
                'order_id'       => $order->get_id(),
                'order_number'   => $order->get_order_number(),
                'amount'         => floatval($order->get_total()),
                'currency'       => $order->get_currency(),
                'status'         => $order->get_status(),
                'trx_id'         => $order->get_transaction_id() ?: null,
                'payment_method' => $method_label,
                'payment_type'   => $payment_type,
                'customer'       => trim($order->get_billing_first_name() . ' ' . $order->get_billing_last_name()),
                'phone'          => $order->get_billing_phone(),
                'date'           => $order->get_date_created() ? $order->get_date_created()->format('Y-m-d H:i:s') : null,
                // Ad tracking (for future Facebook Ads integration)
                'utm_source'     => $utm_source,
                'utm_medium'     => $utm_medium,
                'utm_campaign'   => $utm_campaign,
                'fbclid'         => $fbclid,
            ];
        }

        // Calculate per-status counts
        $status_counts = [
            'processing'    => intval(wc_orders_count('processing')),
            'completed'     => intval(wc_orders_count('completed')),
            'on-hold'       => intval(wc_orders_count('on-hold')),
            'pending'       => intval(wc_orders_count('pending')),
            'cancelled'     => intval(wc_orders_count('cancelled')),
            'failed'        => intval(wc_orders_count('failed')),
            'refunded'      => intval(wc_orders_count('refunded')),
            'ready-to-ship' => intval(wc_orders_count('ready-to-ship')),
        ];
        $status_counts['all'] = array_sum($status_counts);

        // Get unique campaigns from order meta (HPOS & Legacy Support)
        global $wpdb;
        $campaigns = [];
        
        // Check HPOS table first
        $hpos_table = $wpdb->prefix . 'wc_orders_meta';
        if ($wpdb->get_var("SHOW TABLES LIKE '$hpos_table'") === $hpos_table) {
            $campaigns = $wpdb->get_col("
                SELECT DISTINCT meta_value 
                FROM {$hpos_table} 
                WHERE meta_key IN ('_utm_campaign', 'utm_campaign') 
                AND meta_value != ''
                AND meta_value IS NOT NULL
            ");
        }
        
        // If empty or legacy, check postmeta
        if (empty($campaigns)) {
            $campaigns = $wpdb->get_col("
                SELECT DISTINCT meta_value 
                FROM {$wpdb->postmeta} 
                WHERE meta_key IN ('_utm_campaign', 'utm_campaign') 
                AND meta_value != ''
                AND meta_value IS NOT NULL
            ");
        }
        
        $campaigns = array_values(array_filter(array_unique($campaigns)));

        return rest_ensure_response([
            'success'     => true,
            'site'        => $site_info,
            'campaigns'   => $campaigns,
            'stats'       => [
                'total_revenue'        => $total_revenue,
                'total_orders'         => $total_orders,
                'total_bkash_sales'    => $bkash_revenue,
                'total_bkash_orders'   => $bkash_orders_count,
                'total_cod_sales'      => $cod_revenue,
                'total_cod_orders'     => $cod_orders_count,
                'total_other_sales'    => $other_revenue,
                'total_other_orders'   => $other_orders_count,
                'pending_orders'       => count($pending_orders),
                'cancelled_orders'     => count($cancelled_orders),
                'fraud_entries'        => intval($fraud_count),
                'abandoned_carts'      => intval($abandoned_carts),
                'recovered_carts'      => intval($recovered_carts),
                'status_counts'        => $status_counts,
            ],
            'recent_transactions' => $recent_transactions,
            'fetched_at'          => current_time('mysql'),
        ]);
    }

    public function check_permission()
    {
        return current_user_can('manage_options');
    }

    public function get_debug_log()
    {
        $log_dir = WC_LOG_DIR;
        $log_file = null;
        $log_handle = 'revenuepro-bkash';

        // Find the most recent log file for our plugin
        if (is_dir($log_dir)) {
            $files = glob($log_dir . $log_handle . '-*.log');
            if (!empty($files)) {
                // Sort by modification time, newest first
                usort($files, function($a, $b) {
                    return filemtime($b) - filemtime($a);
                });
                $log_file = $files[0];
            }
        }

        if (!$log_file || !file_exists($log_file)) {
            return rest_ensure_response([
                'lines' => [],
                'file' => null,
                'size' => 0,
                'message' => 'No log file found. Enable logging and trigger some plugin actions first.'
            ]);
        }

        // Read last 200 lines only (avoids memory issues with huge logs)
        $max_lines = 200;
        $all_lines = file($log_file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        $lines = array_slice((array)$all_lines, -$max_lines);
        $lines = array_reverse($lines); // Newest first

        // Parse lines into structured objects for easier display
        $parsed = [];
        foreach ($lines as $line) {
            // WooCommerce log format: [YYYY-MM-DD HH:MM:SS] CHANNEL.LEVEL: Message
            if (preg_match('/^\[(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\] ([\w.]+)\.([A-Z]+): (.+)$/', $line, $m)) {
                $parsed[] = [
                    'time'    => $m[1],
                    'channel' => $m[2],
                    'level'   => strtolower($m[3]),
                    'message' => $m[4],
                    'raw'     => $line,
                ];
            } else {
                $parsed[] = [
                    'time'    => '',
                    'channel' => '',
                    'level'   => 'info',
                    'message' => $line,
                    'raw'     => $line,
                ];
            }
        }

        return rest_ensure_response([
            'lines'   => $parsed,
            'file'    => basename($log_file),
            'size'    => filesize($log_file),
            'total'   => count($all_lines),
            'message' => null,
        ]);
    }

    public function clear_debug_log()
    {
        $log_dir  = WC_LOG_DIR;
        $log_handle = 'revenuepro-bkash';
        $deleted = 0;

        if (is_dir($log_dir)) {
            $files = glob($log_dir . $log_handle . '-*.log');
            foreach ((array)$files as $file) {
                if (file_exists($file)) {
                    file_put_contents($file, ''); // Truncate rather than delete, preserves file lock safety
                    $deleted++;
                }
            }
        }

        return rest_ensure_response([
            'success' => true,
            'cleared' => $deleted,
            'message' => $deleted > 0 ? 'Log cleared successfully.' : 'Nothing to clear.',
        ]);
    }

    public function get_settings()
    {
        $settings = get_option('revenuepro_bkash_wc_settings', []);

        // Failsafe Sync: Merge WooCommerce Gateway Settings for display
        // This ensures that if the sync hook failed, the dashboard still sees the current WC values.
        $wc_settings = get_option('woocommerce_revenuepro_bkash_settings', []);
        if (!empty($wc_settings)) {
             if (isset($wc_settings['enabled'])) $settings['bkash_enabled'] = ($wc_settings['enabled'] === 'yes');
             if (isset($wc_settings['testmode'])) $settings['bkash_is_sandbox'] = ($wc_settings['testmode'] === 'yes');
             if (isset($wc_settings['username'])) $settings['bkash_username'] = $wc_settings['username'];
             if (isset($wc_settings['password'])) $settings['bkash_password'] = $wc_settings['password'];
             if (isset($wc_settings['app_key'])) $settings['bkash_app_key'] = $wc_settings['app_key'];
             if (isset($wc_settings['app_secret'])) $settings['bkash_app_secret'] = $wc_settings['app_secret'];
             if (isset($wc_settings['title'])) $settings['bkash_title'] = $wc_settings['title'];
             if (isset($wc_settings['title'])) $settings['bkash_title'] = $wc_settings['title'];
             if (isset($wc_settings['description'])) $settings['bkash_description'] = $wc_settings['description'];

             if (isset($wc_settings['partial_enabled'])) $settings['bkash_partial_enabled'] = ($wc_settings['partial_enabled'] === 'yes');
             if (isset($wc_settings['partial_type'])) $settings['bkash_partial_type'] = $wc_settings['partial_type'];
             if (isset($wc_settings['partial_amount'])) $settings['bkash_partial_amount'] = $wc_settings['partial_amount'];
        }

        // Inject Steadfast webhook info (read-only, auto-generated)
        $settings['steadfast_webhook_url'] = rest_url('revenuepro-bkash-wc/v1/webhook/steadfast');
        $settings['steadfast_webhook_token'] = \RevenuePro\CourierManager::get_webhook_token();

        return rest_ensure_response($settings);
    }

    public function update_settings($request)
    {
        $params = $request->get_json_params();

        $current_settings = get_option('revenuepro_bkash_wc_settings', []);
        if (!is_array($current_settings)) {
            $current_settings = [];
        }

        // Merge new settings with existing ones
        $new_settings = array_merge($current_settings, $params);

        $updated = update_option('revenuepro_bkash_wc_settings', $new_settings);

        // Sync with WooCommerce Gateway Settings
        $wc_settings = get_option('woocommerce_revenuepro_bkash_settings', []);
        if (!is_array($wc_settings)) {
            $wc_settings = [];
        }

        // Map settings
        if (isset($new_settings['bkash_enabled'])) {
            $val = $new_settings['bkash_enabled'];
            $wc_settings['enabled'] = ($val === true || $val === 'true' || $val === 1 || $val === '1') ? 'yes' : 'no';
        }
        if (isset($new_settings['bkash_is_sandbox'])) {
             $val = $new_settings['bkash_is_sandbox'];
             $wc_settings['testmode'] = ($val === true || $val === 'true' || $val === 1 || $val === '1') ? 'yes' : 'no';
        }
        if (isset($new_settings['bkash_username'])) $wc_settings['username'] = $new_settings['bkash_username'];
        if (isset($new_settings['bkash_password'])) $wc_settings['password'] = $new_settings['bkash_password'];
        if (isset($new_settings['bkash_app_key'])) $wc_settings['app_key'] = $new_settings['bkash_app_key'];
        if (isset($new_settings['bkash_app_secret'])) $wc_settings['app_secret'] = $new_settings['bkash_app_secret'];
        if (isset($new_settings['bkash_title'])) $wc_settings['title'] = $new_settings['bkash_title'];
        if (isset($new_settings['bkash_description'])) $wc_settings['description'] = $new_settings['bkash_description'];

        // Partial Payment Sync
        if (isset($new_settings['bkash_partial_enabled'])) {
             $val = $new_settings['bkash_partial_enabled'];
             $wc_settings['partial_enabled'] = ($val === true || $val === 'true' || $val === 1 || $val === '1') ? 'yes' : 'no';
        }
        if (isset($new_settings['bkash_partial_type'])) $wc_settings['partial_type'] = $new_settings['bkash_partial_type'];
        if (isset($new_settings['bkash_partial_amount'])) $wc_settings['partial_amount'] = $new_settings['bkash_partial_amount'];

        update_option('woocommerce_revenuepro_bkash_settings', $wc_settings);

        // Sync Manual bKash Gateway Settings with WooCommerce
        $payment_mode = isset($new_settings['bkash_payment_mode']) ? $new_settings['bkash_payment_mode'] : 'automated';
        $manual_wc_settings = get_option('woocommerce_revenuepro_bkash_manual_settings', []);
        if (!is_array($manual_wc_settings)) {
            $manual_wc_settings = [];
        }

        // Enable/disable manual gateway based on payment mode
        $manual_enabled = ($payment_mode === 'manual');
        $manual_wc_settings['enabled'] = $manual_enabled ? 'yes' : 'no';

        // Sync manual-specific fields
        if (isset($new_settings['bkash_manual_title'])) {
            $manual_wc_settings['title'] = $new_settings['bkash_manual_title'];
        }
        if (isset($new_settings['bkash_manual_description'])) {
            $manual_wc_settings['description'] = $new_settings['bkash_manual_description'];
        }

        update_option('woocommerce_revenuepro_bkash_manual_settings', $manual_wc_settings);

        // Write a log entry whenever settings are saved, so the user can confirm logging is working
        if (!empty($new_settings['general_enable_logging'])) {
            \RevenuePro\Logger::info('RevenuePro settings saved by admin. Logging is active.');
        }

        return rest_ensure_response(['success' => true, 'settings' => $new_settings]);
    }

    public function write_test_log($request)
    {
        $params  = $request->get_json_params();
        $level   = sanitize_text_field($params['level']   ?? 'info');
        $message = sanitize_text_field($params['message'] ?? 'Test log entry from RevenuePro dashboard.');

        $allowed_levels = ['info', 'warning', 'error', 'debug'];
        if (!in_array($level, $allowed_levels, true)) {
            $level = 'info';
        }

        if (!\RevenuePro\Logger::is_enabled()) {
            return rest_ensure_response([
                'success' => false,
                'message' => 'Logging is disabled. Enable it in settings first.'
            ]);
        }

        \RevenuePro\Logger::log($message, $level);

        return rest_ensure_response(['success' => true, 'message' => 'Test log written: [' . strtoupper($level) . '] ' . $message]);
    }

    public function handle_feature_request($request)
    {
        $params = $request->get_json_params();
        $email = sanitize_email($params['email'] ?? '');
        $feature = sanitize_textarea_field($params['feature'] ?? '');

        if (empty($feature)) {
            return new \WP_Error('missing_feature', 'Feature description is required', ['status' => 400]);
        }

        $admin_email = get_option('admin_email');
        $subject = 'New Feature Request for RevenuePro Plugin';
        $message = "A new feature request has been submitted:\n\n";
        $message .= "Email: " . ($email ?: 'Not provided') . "\n";
        $message .= "Feature Request:\n" . $feature . "\n";

        // Send email
        wp_mail($admin_email, $subject, $message);

        return rest_ensure_response(['success' => true, 'message' => 'Request sent successfully']);
    }

    public function ajax_get_cart_details()
    {
        check_ajax_referer('revenuepro_cart_details', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Unauthorized']);
        }

        $cart_id = intval($_POST['cart_id'] ?? 0);
        if (!$cart_id) {
            wp_send_json_error(['message' => 'Invalid cart ID']);
        }

        $cart = AbandonedCartDB::get_cart_by_id($cart_id);
        if (!$cart) {
            wp_send_json_error(['message' => 'Cart not found']);
        }

        $cart_items = json_decode($cart->cart_contents, true) ?: [];
        
        ob_start();
        ?>
        <div style="padding: 20px;">
            <h3 style="margin-top: 0;">Customer Information</h3>
            <table style="width: 100%; border-collapse: collapse;">
                <tr>
                    <td style="padding: 8px; border-bottom: 1px solid #ddd;"><strong>Name:</strong></td>
                    <td style="padding: 8px; border-bottom: 1px solid #ddd;"><?php echo esc_html($cart->customer_name ?: 'N/A'); ?></td>
                </tr>
                <tr>
                    <td style="padding: 8px; border-bottom: 1px solid #ddd;"><strong>Email:</strong></td>
                    <td style="padding: 8px; border-bottom: 1px solid #ddd;">
                        <?php if ($cart->customer_email): ?>
                            <a href="mailto:<?php echo esc_attr($cart->customer_email); ?>"><?php echo esc_html($cart->customer_email); ?></a>
                        <?php else: ?>
                            N/A
                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <td style="padding: 8px; border-bottom: 1px solid #ddd;"><strong>Phone:</strong></td>
                    <td style="padding: 8px; border-bottom: 1px solid #ddd;">
                        <?php if ($cart->customer_phone): ?>
                            <a href="tel:<?php echo esc_attr($cart->customer_phone); ?>"><?php echo esc_html($cart->customer_phone); ?></a>
                        <?php else: ?>
                            N/A
                        <?php endif; ?>
                    </td>
                </tr>
            </table>

            <h3>Cart Items</h3>
            <table style="width: 100%; border-collapse: collapse;">
                <thead>
                    <tr style="background: #f8f9fa;">
                        <th style="padding: 8px; text-align: left; border-bottom: 2px solid #ddd;">Product</th>
                        <th style="padding: 8px; text-align: center; border-bottom: 2px solid #ddd;">Quantity</th>
                        <th style="padding: 8px; text-align: right; border-bottom: 2px solid #ddd;">Price</th>
                        <th style="padding: 8px; text-align: right; border-bottom: 2px solid #ddd;">Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($cart_items as $item): ?>
                        <tr>
                            <td style="padding: 8px; border-bottom: 1px solid #ddd;"><?php echo esc_html($item['name']); ?></td>
                            <td style="padding: 8px; text-align: center; border-bottom: 1px solid #ddd;"><?php echo esc_html($item['quantity']); ?></td>
                            <td style="padding: 8px; text-align: right; border-bottom: 1px solid #ddd;"><?php echo wc_price($item['price']); ?></td>
                            <td style="padding: 8px; text-align: right; border-bottom: 1px solid #ddd;"><?php echo wc_price($item['total']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
                <tfoot>
                    <tr style="background: #f8f9fa; font-weight: bold;">
                        <td colspan="3" style="padding: 12px; text-align: right; border-top: 2px solid #ddd;">Total:</td>
                        <td style="padding: 12px; text-align: right; border-top: 2px solid #ddd;"><?php echo wc_price($cart->cart_total); ?></td>
                    </tr>
                </tfoot>
            </table>
        </div>
        <?php
        $html = ob_get_clean();

        wp_send_json_success(['html' => $html]);
    }
}
