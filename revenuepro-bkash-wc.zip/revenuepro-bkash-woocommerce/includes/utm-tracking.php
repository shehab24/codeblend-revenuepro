<?php
namespace RevenuePro;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * UTM Attribution Tracking
 * 
 * Captures UTM parameters from ad URLs (Facebook, Google, etc.), stores them
 * in a 30-day cookie, and attaches them as order meta when the customer checks out.
 * This allows store owners to see exactly which ad campaign generated each order.
 */
class UtmTracking
{
    private static $settings = null;

    /**
     * List of all UTM parameters we capture
     */
    private static $utm_params = [
        'utm_source',
        'utm_medium',
        'utm_campaign',
        'utm_term',
        'utm_content',
        'utm_adset',     // Facebook-specific
        'utm_ad',        // Facebook-specific
        'fbclid',        // Facebook Click ID
        'gclid',         // Google Click ID
    ];

    public static function init()
    {
        self::$settings = get_option('revenuepro_bkash_wc_settings', []);

        if (empty(self::$settings['tracking_utm_enabled'])) {
            return;
        }

        // Inject JS on frontend to capture UTM params from URL into cookie
        add_action('wp_footer', [__CLASS__, 'inject_utm_capture_script'], 5);

        // Save UTM data to order when checkout is processed
        add_action('woocommerce_checkout_order_processed', [__CLASS__, 'save_utm_to_order'], 10, 1);

        // Also support HPOS order creation hook
        add_action('woocommerce_store_api_checkout_order_processed', [__CLASS__, 'save_utm_to_order_object'], 10, 1);

        // Display UTM data in admin order detail page via Meta Box
        add_action('add_meta_boxes', [__CLASS__, 'register_utm_meta_box'], 10, 2);
    }

    /**
     * Inject lightweight JS to capture UTM parameters from the URL
     * and store them in a cookie that persists for 30 days.
     * Uses first-touch attribution (only saves if no existing UTM cookie).
     */
    public static function inject_utm_capture_script()
    {
        if (is_admin()) return;
        ?>
        <script>
        /* RevenuePro UTM Attribution Tracking */
        (function() {
            var params = ['utm_source','utm_medium','utm_campaign','utm_term','utm_content','utm_adset','utm_ad','fbclid','gclid'];
            var url = new URL(window.location.href);
            var found = {};
            var hasAny = false;

            for (var i = 0; i < params.length; i++) {
                var val = url.searchParams.get(params[i]);
                if (val) {
                    found[params[i]] = val;
                    hasAny = true;
                }
            }

            if (hasAny) {
                // Merge with existing cookie data (last-touch wins for new params)
                var existing = {};
                try {
                    var raw = document.cookie.match(/(?:^|;\s*)rp_utm=([^;]*)/);
                    if (raw) existing = JSON.parse(decodeURIComponent(raw[1]));
                } catch(e) {}

                // Overwrite with fresh UTM data (last-touch attribution)
                for (var key in found) {
                    existing[key] = found[key];
                }

                // Also capture the landing page URL
                existing['landing_page'] = window.location.pathname;
                existing['timestamp'] = new Date().toISOString();

                var expires = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toUTCString();
                document.cookie = 'rp_utm=' + encodeURIComponent(JSON.stringify(existing)) + ';path=/;expires=' + expires + ';SameSite=Lax';
            }
        })();
        </script>
        <?php
    }

    /**
     * Save UTM data from cookie to order meta when checkout is processed.
     * Works with both classic checkout and block checkout.
     */
    public static function save_utm_to_order($order_id)
    {
        $order = wc_get_order($order_id);
        if (!$order) return;

        self::attach_utm_data($order);
    }

    /**
     * HPOS / Block Checkout support: receives order object directly
     */
    public static function save_utm_to_order_object($order)
    {
        if (!$order) return;

        self::attach_utm_data($order);
    }

    /**
     * Read UTM cookie and attach data to order
     */
    private static function attach_utm_data($order)
    {
        // Don't overwrite if UTM data was already saved
        if ($order->get_meta('_utm_source')) return;

        $utm_data = [];

        // Try to read from the cookie
        if (isset($_COOKIE['rp_utm'])) {
            $raw = sanitize_text_field(wp_unslash($_COOKIE['rp_utm']));
            $decoded = json_decode(stripslashes($raw), true);
            if (is_array($decoded)) {
                $utm_data = $decoded;
            }
        }

        // If no cookie data, check POST data (some plugins pass UTM via hidden fields)
        if (empty($utm_data)) {
            foreach (self::$utm_params as $param) {
                if (!empty($_POST[$param])) {
                    $utm_data[$param] = sanitize_text_field($_POST[$param]);
                }
            }
        }

        if (empty($utm_data)) return;

        // Save each UTM parameter as individual order meta for easy querying
        $meta_keys = [
            'utm_source'   => '_utm_source',
            'utm_medium'   => '_utm_medium',
            'utm_campaign' => '_utm_campaign',
            'utm_term'     => '_utm_term',
            'utm_content'  => '_utm_content',
            'utm_adset'    => '_utm_adset',
            'utm_ad'       => '_utm_ad',
            'fbclid'       => '_fbclid',
            'gclid'        => '_gclid',
            'landing_page' => '_utm_landing_page',
        ];

        foreach ($meta_keys as $param => $meta_key) {
            if (!empty($utm_data[$param])) {
                $order->update_meta_data($meta_key, sanitize_text_field($utm_data[$param]));
            }
        }

        // Also save the full UTM JSON for reference
        $order->update_meta_data('_revenuepro_utm_data', wp_json_encode($utm_data));

        // Save timestamp
        if (!empty($utm_data['timestamp'])) {
            $order->update_meta_data('_utm_timestamp', sanitize_text_field($utm_data['timestamp']));
        }

        $order->save();

        // Add an order note for visibility
        $source = $utm_data['utm_source'] ?? 'Unknown';
        $campaign = $utm_data['utm_campaign'] ?? '';
        $note_parts = ["Source: {$source}"];
        if ($campaign) $note_parts[] = "Campaign: {$campaign}";
        if (!empty($utm_data['utm_adset'])) $note_parts[] = "Ad Set: {$utm_data['utm_adset']}";
        if (!empty($utm_data['utm_ad'])) $note_parts[] = "Ad: {$utm_data['utm_ad']}";

        $order->add_order_note('🔗 UTM Attribution: ' . implode(' | ', $note_parts));
    }

    /**
     * Register a custom Meta Box for WooCommerce orders (supports HPOS and Classic)
     */
    public static function register_utm_meta_box($post_type, $post = null)
    {
        if ($post_type === 'shop_order' || strpos($post_type, 'wc-orders') !== false) {
            add_meta_box(
                'revenuepro_utm_meta_box',
                '🔗 RevenuePro UTM (Ad Tracking)',
                [__CLASS__, 'render_utm_meta_box'],
                $post_type,
                'side',
                'high' // Put it higher up
            );
        }
    }

    /**
     * Render the Meta Box content
     */
    public static function render_utm_meta_box($post_or_order_object)
    {
        // Handle both Classic ($post object) and HPOS ($order object)
        $order_id = $post_or_order_object instanceof \WC_Order ? $post_or_order_object->get_id() : $post_or_order_object->ID;
        $order = wc_get_order($order_id);

        if (!$order) return;

        $utm_json = $order->get_meta('_revenuepro_utm_data');
        if (empty($utm_json)) {
            echo '<p style="color: #64748b;">No UTM data captured for this order.</p>';
            return;
        }

        $utm_data = json_decode($utm_json, true);
        if (!is_array($utm_data) || empty($utm_data)) {
            echo '<p style="color: #64748b;">No UTM data captured for this order.</p>';
            return;
        }

        // Filter out non-UTM keys like timestamp and landing_page for the main display
        $display_params = [
            'utm_source'   => 'Source',
            'utm_medium'   => 'Medium',
            'utm_campaign' => 'Campaign',
            'utm_term'     => 'Term',
            'utm_content'  => 'Content',
            'utm_adset'    => 'Ad Set',
            'utm_ad'       => 'Ad Name',
            'fbclid'       => 'FB Click ID',
            'gclid'        => 'Google Click ID',
            'landing_page' => 'Landing Page',
        ];
        ?>
        <div style="margin: -6px -12px; padding: 12px; background: linear-gradient(135deg, #faf5ff, #f5f3ff); border-bottom: 1px solid #e9d5ff;">
            <table style="width: 100%; font-size: 13px; border-collapse: collapse;">
                <?php foreach ($display_params as $key => $label): ?>
                    <?php if (!empty($utm_data[$key])): ?>
                        <tr>
                            <td style="padding: 6px 0; color: #7c3aed; font-weight: 600; width: 110px; vertical-align: top; border-bottom: 1px dashed #e9d5ff;"><?php echo esc_html($label); ?></td>
                            <td style="padding: 6px 0; color: #334155; word-break: break-all; border-bottom: 1px dashed #e9d5ff; font-family: monospace;"><?php echo esc_html($utm_data[$key]); ?></td>
                        </tr>
                    <?php endif; ?>
                <?php endforeach; ?>
            </table>
        </div>
        <?php
    }
}
