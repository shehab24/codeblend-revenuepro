<?php
namespace RevenuePro;

if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly.
}

class Admin
{
	public static function init()
	{
		$self = new self();
		$self->dispatch_hooks();
	}

	public function dispatch_hooks()
	{
		Admin\Menu::init();
		add_filter('plugin_row_meta', array($this, 'add_plugin_links'), 10, 2);
		add_filter('plugin_action_links_' . REVENUEPRO_FORM_BASENAME, [$this, 'plugin_action_links']);
	}

	public function add_plugin_links($links, $file)
	{
		if (REVENUEPRO_FORM_BASENAME !== $file) {
			return $links;
		}

		$map_block_links = array(
			// 'docs' => array(
			// 	'url' => '',
			// 	'label' => __('Docs', 'revenuepro-bkash-wc'),
			// 	'aria-label' => __('View documentation', 'revenuepro-bkash-wc'),
			// ),
			// 'support' => array(
			// 	'url' => '',
			// 	'label' => __('Community Support', 'revenuepro-bkash-wc'),
			// 	'aria-label' => __('Visit community forums', 'revenuepro-bkash-wc'),
			// ),
			// 'review' => array(
			// 	'url' => '',
			// 	'label' => __('Rate the plugin ★★★★★', 'revenuepro-bkash-wc'),
			// 	'aria-label' => __('Rate the plugin.', 'revenuepro-bkash-wc'),
			// ),
		);

		foreach ($map_block_links as $key => $link) {
			$links[$key] = sprintf(
				'<a target="_blank" href="%s" aria-label="%s">%s</a>',
				esc_url($link['url']),
				esc_attr($link['aria-label']),
				esc_html($link['label'])
			);
		}

		return $links;
	}
	public function plugin_action_links($links)
	{
		// $settings_link = sprintf( '<a href="%1$s">%2$s</a>', admin_url( 'admin.php?page=ablocks' ), esc_html__( 'Settings', 'ablocks' ) );

		// array_unshift( $links, $settings_link );

		// if (!defined('REVENUEPRO_FORM_PRO_VERSION')) {
		// 	$links['go_pro'] = sprintf('<a href="%1$s" target="_blank" class="revenuepro-bkash-wc-plugins-gopro" style="color: #7b68ee; font-weight: bold;">%2$s</a>', 'https://example.com/pricing/', esc_html__('Get Pro', 'revenuepro-bkash-wc'));
		// }
		return $links;
	}

}
