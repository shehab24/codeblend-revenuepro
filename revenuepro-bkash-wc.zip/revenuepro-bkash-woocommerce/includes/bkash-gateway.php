<?php
namespace RevenuePro;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Bkash Payment Gateway
 */
class BkashGateway extends \WC_Payment_Gateway
{
    public function __construct()
    {
        $this->id = 'revenuepro_bkash';
        $this->icon = ''; // Add icon URL later
        $this->has_fields = false;
        $this->method_title = __('bKash (RevenuePro)', 'revenuepro-bkash-wc');
        $this->method_description = __('Pay securely with bKash.', 'revenuepro-bkash-wc');
        $this->supports = ['products'];

        // Get icon from RevenuePro settings
        $rp_settings = get_option('revenuepro_bkash_wc_settings', []);
        $this->icon = !empty($rp_settings['bkash_logo_url']) ? $rp_settings['bkash_logo_url'] : '';

        $this->init_form_fields();
        $this->init_settings();

        $this->title = $this->get_option('title');
        $this->description = $this->get_option('description');
        $this->enabled = $this->get_option('enabled');

        add_action('woocommerce_update_options_payment_gateways_' . $this->id, [$this, 'process_admin_options']);
        add_action('woocommerce_receipt_' . $this->id, [$this, 'receipt_page']);
        add_action('woocommerce_api_revenuepro_bkash', [$this, 'payment_callback']);
    }

    /**
     * Check if the gateway is available for use.
     *
     * @return bool
     */
    public function is_available()
    {
        if ($this->get_option('enabled') !== 'yes') {
            return false;
        }

        return true;
    }

    private function get_partial_setting($key) {
        $rp = get_option('revenuepro_bkash_wc_settings', []);
        $dash_key = 'bkash_partial_' . $key;
        
        // Priority 1: Dashboard Settings (Source of Truth)
        if (isset($rp[$dash_key])) {
            if ($key === 'enabled') {
                return ($rp[$dash_key] === true || $rp[$dash_key] === 'true' || $rp[$dash_key] === 1 || $rp[$dash_key] === '1');
            }
            return $rp[$dash_key];
        }

        // Priority 2: Gateway Settings (Legacy/Synced)
        $val = $this->get_option('partial_' . $key);
        if ($key === 'enabled') {
            return $val === 'yes';
        }
        return $val;
    }

    public function payment_fields()
    {
        $description = $this->get_option('description');

        if ($this->get_partial_setting('enabled') && WC()->cart) {
            $total = WC()->cart->total;
            $shipping_total = WC()->cart->get_shipping_total() + WC()->cart->get_shipping_tax();
            
            $pay_now = $this->calculate_amount($total, $shipping_total);
            
            // Show message if pay_now is significantly different from total
            if (abs($total - $pay_now) > 0.01) {
                $pay_later = $total - $pay_now;
                
                // Get type label
                $partial_type = $this->get_partial_setting('type');
                $partial_amount = floatval($this->get_partial_setting('amount'));
                
                $type_label = '';
                switch ($partial_type) {
                    case 'shipping':
                        $type_label = __('Shipping Cost Only', 'revenuepro-bkash-wc');
                        break;
                    case 'shipping_percentage':
                        $type_label = sprintf(__('Shipping + %s%% of Product', 'revenuepro-bkash-wc'), $partial_amount);
                        break;
                    case 'shipping_fixed':
                        $type_label = sprintf(__('Shipping + %s', 'revenuepro-bkash-wc'), wc_price($partial_amount));
                        break;
                    case 'percentage':
                        $type_label = sprintf(__('%s%% of Total', 'revenuepro-bkash-wc'), $partial_amount);
                        break;
                    case 'fixed':
                        $type_label = __('Fixed Amount', 'revenuepro-bkash-wc');
                        break;
                }
                
                // Beautiful gradient design
                $msg = '<div class="revenuepro-bkash-payment-info" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 8px; padding: 16px 20px; margin: 12px 0; border: none; box-shadow: 0 2px 8px rgba(102, 126, 234, 0.25);">';
                $msg .= '<div style="color: #ffffff; font-size: 15px; font-weight: 600; margin-bottom: 10px;">📱 ' . __('Partial Payment Information', 'revenuepro-bkash-wc') . '</div>';
                $msg .= '<div style="background: rgba(255,255,255,0.15); border-radius: 6px; padding: 12px; backdrop-filter: blur(10px);">';
                $msg .= '<div style="display: flex; justify-content: space-between; margin-bottom: 8px;">';
                $msg .= '<span style="color: rgba(255,255,255,0.9); font-size: 13px;">💳 ' . __('Pay Now', 'revenuepro-bkash-wc') . '</span>';
                $msg .= '<span style="color: #ffffff; font-size: 16px; font-weight: 700;">' . wc_price($pay_now) . '</span>';
                $msg .= '</div>';
                $msg .= '<div style="display: flex; justify-content: space-between;">';
                $msg .= '<span style="color: rgba(255,255,255,0.9); font-size: 13px;">💵 ' . __('Pay on Delivery', 'revenuepro-bkash-wc') . '</span>';
                $msg .= '<span style="color: #ffffff; font-size: 14px; font-weight: 600;">' . wc_price($pay_later) . '</span>';
                $msg .= '</div>';
                $msg .= '</div>';
                $msg .= '<div style="color: rgba(255,255,255,0.85); font-size: 12px; margin-top: 10px; line-height: 1.4;">';
                $msg .= '(' . esc_html($type_label) . ')';
                $msg .= '</div>';
                $msg .= '</div>';
                
                $description .= $msg;
            }
        }

        if ($description) {
            echo '<div class="woocommerce-bkash-description">';
            echo wp_kses_post(wpautop($description));
            echo '</div>';
        }
    }

    private function calculate_amount($total, $shipping_total)
    {
        $amount = $total;
        $partial_amount = floatval($this->get_partial_setting('amount'));
        $partial_type = $this->get_partial_setting('type');
        $product_total = $total - $shipping_total;

        switch ($partial_type) {
            case 'percentage':
                // Percentage of entire order
                $amount = $total * ($partial_amount / 100);
                break;

            case 'shipping':
                // Only shipping cost
                $amount = $shipping_total;
                break;

            case 'shipping_percentage':
                // Shipping cost + Percentage of Product Total
                $amount = $shipping_total + ($product_total * ($partial_amount / 100));
                break;

            case 'shipping_fixed':
                // Shipping cost + Fixed Amount
                $amount = $shipping_total + $partial_amount;
                break;

            case 'fixed':
            default:
                // Fixed Amount
                $amount = $partial_amount;
                break;
        }

        if ($amount <= 0) {
             $amount = $total; 
        }
        if ($amount > $total) {
            $amount = $total;
        }

        return $amount;
    }

    public function get_payment_amount($order) {
        if ($order->get_meta('_is_partial_payment') === 'yes') {
            $amt = floatval($order->get_meta('_partial_payment_amount'));
            if ($amt > 0) {
                return number_format($amt, 2, '.', '');
            }
        }

        $total = floatval($order->get_total());
        
        if ($this->get_partial_setting('enabled')) {
            $shipping_total = floatval($order->get_shipping_total()) + floatval($order->get_shipping_tax());
            $amount = $this->calculate_amount($total, $shipping_total);
        } else {
            $amount = $total;
        }

        return number_format($amount, 2, '.', '');
    }

    public function process_payment($order_id)
    {
        $order = wc_get_order($order_id);
        
        // Enable debug logging
        $this->log('=== Starting bKash Payment Process ===');
        $this->log('Order ID: ' . $order_id);
        $this->log('Order Total: ' . $order->get_total());

        // Check if bKash credentials are configured
        $app_key = $this->get_option('app_key');
        $app_secret = $this->get_option('app_secret');
        $username = $this->get_option('username');
        $password = $this->get_option('password');
        
        $this->log('Checking credentials...');
        $this->log('App Key: ' . (empty($app_key) ? 'MISSING' : 'Present (length: ' . strlen($app_key) . ')'));
        $this->log('App Secret: ' . (empty($app_secret) ? 'MISSING' : 'Present (length: ' . strlen($app_secret) . ')'));
        $this->log('Username: ' . (empty($username) ? 'MISSING' : 'Present'));
        $this->log('Password: ' . (empty($password) ? 'MISSING' : 'Present'));
        
        if (empty($app_key) || empty($app_secret) || empty($username) || empty($password)) {
            $this->log('ERROR: Missing credentials!');
            wc_add_notice(__('bKash payment gateway is not configured. Please configure your bKash credentials in the plugin settings or contact the store administrator.', 'revenuepro-bkash-wc'), 'error');
            return [
                'result' => 'fail',
                'redirect' => ''
            ];
        }

        try {
            // 1. Get Token
            $this->log('Step 1: Requesting bKash token...');
            $token_data = $this->grant_token();
            
            $this->log('Token Response: ' . json_encode($token_data));
            
            if (!$token_data || !isset($token_data['id_token'])) {
                $this->log('ERROR: Token request failed or id_token missing');
                throw new \Exception(__('Failed to authenticate with bKash.', 'revenuepro-bkash-wc'));
            }
            
            $id_token = $token_data['id_token'];
            $this->log('SUCCESS: Token received (length: ' . strlen($id_token) . ')');

            // 2. Create Payment
            $this->log('Step 2: Creating payment...');
            $payment_data = $this->create_payment($order, $id_token);
            
            $this->log('Payment Creation Response: ' . json_encode($payment_data));
            
            if (!$payment_data || !isset($payment_data['bkashURL'])) {
                $msg = isset($payment_data['statusMessage']) ? $payment_data['statusMessage'] : __('Payment creation failed.', 'revenuepro-bkash-wc');
                $this->log('ERROR: Payment creation failed - ' . $msg);
                $this->log('Full response: ' . print_r($payment_data, true));
                throw new \Exception($msg);
            }

            $this->log('SUCCESS: Payment created, redirecting to: ' . $payment_data['bkashURL']);
            $this->log('=== bKash Payment Process Complete ===');
            
            return [
                'result' => 'success',
                'redirect' => $payment_data['bkashURL']
            ];

        } catch (\Exception $e) {
            $this->log('EXCEPTION: ' . $e->getMessage());
            $this->log('Stack trace: ' . $e->getTraceAsString());
            wc_add_notice('bKash Error: ' . $e->getMessage(), 'error');
            return [
                'result' => 'fail',
                'redirect' => ''
            ];
        }
    }
    
    /**
     * Log debug messages
     */
    private function log($message)
    {
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('[bKash Gateway] ' . $message);
        }
    }

    public function payment_callback()
    {
        $payment_id = isset($_GET['paymentID']) ? sanitize_text_field($_GET['paymentID']) : '';
        $status = isset($_GET['status']) ? sanitize_text_field($_GET['status']) : '';
        
        $order_id = isset($_GET['order_id']) ? intval($_GET['order_id']) : 0;

        if (!$payment_id || !$order_id) {
             // Invalid callback
             wp_redirect(home_url('/'));
             exit;
        }

        $order = wc_get_order($order_id);
        if (!$order) {
            wp_redirect(home_url('/'));
             exit;
        }

        if ($status === 'cancel' || $status === 'failure') {
            $order->update_status('failed', __('bKash payment cancelled or failed.', 'revenuepro-bkash-wc'));
            wp_redirect($order->get_cancel_order_url());
            exit;
        }

        try {
            $token_data = $this->grant_token();
            $id_token = $token_data['id_token'];

            $execute_data = $this->execute_payment($payment_id, $id_token);

            if (isset($execute_data['statusCode']) && $execute_data['statusCode'] === '0000' && $execute_data['transactionStatus'] === 'Completed') {
                
                $charged_amount = floatval($execute_data['amount']);
                $order_total = floatval($order->get_total());
                
                $order->set_transaction_id($execute_data['trxID']);
				if (isset($execute_data['customerMsisdn'])) {
					$order->update_meta_data('_bkash_customer_number', sanitize_text_field($execute_data['customerMsisdn']));
				}

                if ($charged_amount < $order_total && ($order_total - $charged_amount) > 0.01) {
                     // Partial Logic
                     $remaining = $order_total - $charged_amount;
                     $order->update_status('processing', sprintf(__('Partial payment of %s received via bKash. Remaining due: %s. TrxID: %s', 'revenuepro-bkash-wc'), wc_price($charged_amount), wc_price($remaining), $execute_data['trxID']));
                     $order->add_order_note(sprintf(__('Partial payment of %s received. Remainder of %s to be collected via COD.', 'revenuepro-bkash-wc'), wc_price($charged_amount), wc_price($remaining)));
                     $order->update_meta_data('_bkash_partial_paid', $charged_amount);
                     $order->update_meta_data('_bkash_remaining', $remaining);
                     $order->save();
                     
                     // Reduce stock for partial payment too as the order is confirmed
                     wc_reduce_stock_levels($order_id);
                } else {
                    // Full Payment
                    $order->payment_complete($execute_data['trxID']);
                    $order->update_status('ready-to-ship', __('bKash payment verified and order ready to ship.', 'revenuepro-bkash-wc'));
                    $order->add_order_note(sprintf(__('bKash payment successful. TrxID: %s', 'revenuepro-bkash-wc'), $execute_data['trxID']));
                    wc_reduce_stock_levels($order_id);
                    $order->save();
                }

                WC()->cart->empty_cart();
                wp_redirect($this->get_return_url($order));
                exit;
            } else {
                 $msg = isset($execute_data['statusMessage']) ? $execute_data['statusMessage'] : __('Payment execution failed.', 'revenuepro-bkash-wc');
                 throw new \Exception($msg);
            }

        } catch (\Exception $e) {
            $order->update_status('failed', 'bKash Error: ' . $e->getMessage());
            wc_add_notice($e->getMessage(), 'error');
            wp_redirect($order->get_checkout_payment_url(true)); 
            exit;
        }
    }

    // --- API Helpers ---

    private function get_base_url()
    {
        return ($this->get_option('testmode') === 'yes') 
            ? 'https://tokenized.sandbox.bka.sh/v1.2.0-beta' 
            : 'https://tokenized.pay.bka.sh/v1.2.0-beta';
    }

    private function get_headers($id_token = null)
    {
        $headers = [
            'Content-Type' => 'application/json',
            'username' => $this->get_option('username'),
            'password' => $this->get_option('password')
        ];
        if ($id_token) {
            $headers['Authorization'] = $id_token;
            $headers['x-app-key'] = $this->get_option('app_key');
        }
        return $headers;
    }

    private function grant_token()
    {
        $url = $this->get_base_url() . '/tokenized/checkout/token/grant';
        $body = [
            'app_key' => $this->get_option('app_key'),
            'app_secret' => $this->get_option('app_secret')
        ];

        $response = wp_remote_post($url, [
            'headers' => $this->get_headers(),
            'body' => json_encode($body),
            'timeout' => 30
        ]);

        if (is_wp_error($response)) return null;
        return json_decode(wp_remote_retrieve_body($response), true);
    }

    private function create_payment($order, $id_token)
    {
        // Try non-beta endpoint for payment creation if beta is failing
        // Or stick to beta but ensure clean URL
        $base_url = $this->get_base_url();
        $url = $base_url . '/tokenized/checkout/create';
        
        $this->log('Creating payment request...');
        $this->log('API URL: ' . $url);
        
        $callback_url = add_query_arg([
            'order_id' => $order->get_id(),
        ], WC()->api_request_url('revenuepro_bkash'));

        // Log the generated callback URL for debugging
        $this->log('Generated Callback URL: ' . $callback_url);

        $amount = $this->get_payment_amount($order);
        
        $this->log('Callback URL: ' . $callback_url);
        $this->log('Payment Amount: ' . $amount);

        $body = [
            'mode' => '0011',
            'payerReference' => (string) $order->get_id(),
            'callbackURL' => $callback_url,
            'amount' => $amount, 
            'currency' => 'BDT',
            'intent' => 'sale',
            'merchantInvoiceNumber' => $order->get_id() . 'T' . time() // Use T instead of - just in case
        ];
        
        $this->log('Request Body: ' . json_encode($body));
        
        // Prepare headers - Standard method with User-Agent fix for WAF
        $headers = [
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . $id_token, 
            'x-app-key' => $this->get_option('app_key'),
            'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'
        ];
        
        $this->log('Request Headers: ' . print_r($headers, true));

        $response = wp_remote_post($url, [
            'headers' => $headers,
            'body' => json_encode($body),
            'timeout' => 30
        ]);
        
        $this->log('Raw Response Code: ' . wp_remote_retrieve_response_code($response));
        $this->log('Raw Response Body: ' . wp_remote_retrieve_body($response));
        
        if (is_wp_error($response)) {
            $this->log('WP_Error: ' . $response->get_error_message());
            return null;
        }
        
        $decoded = json_decode(wp_remote_retrieve_body($response), true);
        $this->log('Decoded Response: ' . print_r($decoded, true));
        
        return $decoded;
    }

    private function execute_payment($payment_id, $id_token)
    {
        $url = $this->get_base_url() . '/tokenized/checkout/execute';
        $body = [
            'paymentID' => $payment_id
        ];

        $response = wp_remote_post($url, [
            'headers' => $this->get_headers($id_token),
            'body' => json_encode($body),
            'timeout' => 30
        ]);

        if (is_wp_error($response)) return null;
        return json_decode(wp_remote_retrieve_body($response), true);
    }



    public function receipt_page($order)
    {
        // echo '<iframe>...</iframe>'; or JS button
    }
}
