<?php
namespace RevenuePro;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * AbandonedCartEmail — now sends SMS/WhatsApp instead of email
 * Class name kept for backwards compatibility with init() calls.
 */
class AbandonedCartEmail
{
    public static function init()
    {
        add_action('revenuepro_process_abandoned_carts', [__CLASS__, 'process_carts']);
        add_action('wp_ajax_revenuepro_force_process_carts', [__CLASS__, 'ajax_force_process']);
        
        if (!wp_next_scheduled('revenuepro_process_abandoned_carts')) {
            wp_schedule_event(time(), 'every_5_minutes', 'revenuepro_process_abandoned_carts');
        }

        // Add custom cron interval
        add_filter('cron_schedules', function ($schedules) {
            $schedules['every_5_minutes'] = [
                'interval' => 300,
                'display' => __('Every 5 Minutes', 'revenuepro-bkash-wc')
            ];
            return $schedules;
        });
    }

    public static function ajax_force_process() {
        check_ajax_referer('revenuepro_cart_details', 'nonce');
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Unauthorized');
        }
        
        self::process_carts();
        wp_send_json_success(['message' => 'Processed successfully']);
    }

    public static function process_carts()
    {
        $settings = get_option('revenuepro_bkash_wc_settings', []);
        
        // Check if feature is enabled
        if (empty($settings['abandoned_cart_enabled'])) {
            return;
        }

        $wait_time = intval($settings['abandoned_cart_wait_time'] ?? 60); // minutes
        $cutoff_time = date('Y-m-d H:i:s', strtotime("-{$wait_time} minutes"));

        $carts = AbandonedCartDB::get_carts_to_process($cutoff_time);

        foreach ($carts as $cart) {
            // Send recovery SMS
            self::send_recovery_sms($cart, $settings);
            
            // Mark as abandoned and message sent
            AbandonedCartDB::mark_as_abandoned($cart->session_id);
            AbandonedCartDB::mark_email_sent($cart->id); // Column name kept for DB compatibility
        }
    }

    /**
     * Send recovery SMS via BulkSMSBD API
     */
    private static function send_recovery_sms($cart, $settings)
    {
        $phone = $cart->customer_phone;
        
        if (empty($phone)) {
            return;
        }

        // Get SMS API credentials from settings
        $api_url  = $settings['sms_api_url'] ?? 'http://bulksmsbd.net/api/smsapi';
        $api_key  = $settings['sms_api_key'] ?? '';
        $sender_id = $settings['sms_sender_id'] ?? '';

        if (empty($api_key)) {
            return; // No SMS API key configured
        }

        // Build message from template
        $template = $settings['abandoned_cart_sms_template'] ?? 'Hi {name}, you left items worth {cart_total} in your cart at {site_name}. Complete your order now: {checkout_url}';

        // Build recovery URL
        $checkout_url = add_query_arg('rp_recover_cart', $cart->session_id, wc_get_checkout_url());

        // Parse cart items
        $items_list = '';
        $items = json_decode($cart->cart_contents, true);
        if (is_array($items)) {
            $names = [];
            foreach ($items as $item) {
                $names[] = $item['name'] . ' x' . $item['quantity'];
            }
            $items_list = implode(', ', $names);
        }

        $replacements = [
            '{name}'         => $cart->customer_name ?: 'Customer',
            '{phone}'        => $cart->customer_phone,
            '{cart_total}'   => $cart->cart_total . ' BDT',
            '{cart_items}'   => $items_list,
            '{checkout_url}' => $checkout_url,
            '{site_name}'    => get_bloginfo('name'),
        ];

        $message = str_replace(array_keys($replacements), array_values($replacements), $template);

        // Format phone for API (BD format: 88 + 11 digits)
        $api_phone = $phone;
        if (strpos($api_phone, '0') === 0) {
            $api_phone = '88' . $api_phone;
        }

        // Send via BulkSMSBD API
        $response = wp_remote_post($api_url, [
            'body' => [
                'api_key'   => $api_key,
                'senderid'  => $sender_id,
                'number'    => $api_phone,
                'message'   => $message,
            ],
            'timeout' => 30,
        ]);

        if (is_wp_error($response)) {
            if (function_exists('wc_get_logger')) {
                wc_get_logger()->error('Abandoned cart SMS failed for phone ' . $phone . ': ' . $response->get_error_message(), ['source' => 'revenuepro_abandoned_cart']);
            }
        }
    }
}
