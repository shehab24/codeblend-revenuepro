<?php
namespace RevenuePro;

if (!defined('ABSPATH')) {
    exit;
}

class BkashPayment
{
    private $base_url;
    private $app_key;
    private $app_secret;
    private $username;
    private $password;
    private $is_sandbox;

    public function __construct()
    {
        $settings = get_option('revenuepro_bkash_wc_settings', []);
        $this->is_sandbox = !empty($settings['bkash_is_sandbox']);
        $this->app_key = $settings['bkash_app_key'] ?? '';
        $this->app_secret = $settings['bkash_app_secret'] ?? '';
        $this->username = $settings['bkash_username'] ?? '';
        $this->password = $settings['bkash_password'] ?? '';

        // Using the standard tokenized API endpoints
        $this->base_url = $this->is_sandbox
            ? 'https://tokenized.sandbox.bka.sh/v1.2.0-beta'
            : 'https://tokenized.pay.bka.sh/v1.2.0-beta';
    }

    public function get_token()
    {
        $url = $this->base_url . '/tokenized/checkout/token/grant';

        $headers = [
            'Content-Type' => 'application/json',
            'username' => $this->username,
            'password' => $this->password,
        ];

        $body = [
            'app_key' => $this->app_key,
            'app_secret' => $this->app_secret,
        ];

        $response = wp_remote_post($url, [
            'headers' => $headers,
            'body' => json_encode($body),
            'timeout' => 30,
        ]);

        if (is_wp_error($response)) {

            return false;
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        if (isset($data['id_token'])) {
            return $data['id_token'];
        }


        return false;
    }

    public function create_payment($amount, $invoice_number, $callback_url)
    {


        $token = $this->get_token();
        if (!$token) {
            return ['status' => 'error', 'message' => 'Failed to get bKash token'];
        }

        $url = $this->base_url . '/tokenized/checkout/create';

        $headers = [
            'Content-Type' => 'application/json',
            'Authorization' => $token,
            'X-APP-Key' => $this->app_key,
        ];

        $body = [
            'mode' => '0011',
            'payerReference' => $invoice_number,
            'callbackURL' => $callback_url,
            'amount' => $amount,
            'currency' => 'BDT',
            'intent' => 'sale',
            'merchantInvoiceNumber' => $invoice_number
        ];



        $response = wp_remote_post($url, [
            'headers' => $headers,
            'body' => json_encode($body),
            'timeout' => 30,
        ]);

        if (is_wp_error($response)) {

            return ['status' => 'error', 'message' => $response->get_error_message()];
        }

        $response_body = wp_remote_retrieve_body($response);
        $data = json_decode($response_body, true);



        if (isset($data['bkashURL'])) {

            return ['status' => 'success', 'bkashURL' => $data['bkashURL']];
        }

        $error_message = $data['statusMessage'] ?? 'Unknown error from bKash';


        return ['status' => 'error', 'message' => $error_message];
    }

    public function execute_payment($paymentID)
    {
        $token = $this->get_token();
        if (!$token) {
            return ['status' => 'error', 'message' => 'Failed to get bKash token'];
        }

        $url = $this->base_url . '/tokenized/checkout/execute';

        $headers = [
            'Content-Type' => 'application/json',
            'Authorization' => $token,
            'X-APP-Key' => $this->app_key,
        ];

        $body = [
            'paymentID' => $paymentID
        ];

        $response = wp_remote_post($url, [
            'headers' => $headers,
            'body' => json_encode($body),
            'timeout' => 30,
        ]);

        if (is_wp_error($response)) {
            return ['status' => 'error', 'message' => $response->get_error_message()];
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        if (isset($data['transactionStatus']) && ($data['transactionStatus'] === 'Completed' || $data['transactionStatus'] === 'Authorized')) {
            return ['status' => 'success', 'data' => $data];
        }

        return ['status' => 'error', 'message' => $data['statusMessage'] ?? 'Payment execution failed'];
    }
}
