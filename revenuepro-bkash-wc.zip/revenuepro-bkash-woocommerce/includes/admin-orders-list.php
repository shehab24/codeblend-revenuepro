<?php
namespace RevenuePro;

if (!defined('ABSPATH')) {
    exit;
}

class AdminOrdersList {
    public static function init() {
        $self = new self();
        // Classic WP list
        add_filter('manage_edit-shop_order_columns', [$self, 'add_order_ratio_column'], 20);
        add_action('manage_shop_order_posts_custom_column', [$self, 'display_order_ratio_column_content'], 10, 2);
        
        // HPOS Woo list
        add_filter('manage_woocommerce_page_wc-orders_columns', [$self, 'add_order_ratio_column'], 20);
        add_action('manage_woocommerce_page_wc-orders_custom_column', [$self, 'display_order_ratio_column_content'], 10, 2);
        
        // CSS + JS + Modal HTML
        add_action('admin_head', [$self, 'inject_admin_css']);
        add_action('admin_footer', [$self, 'inject_modal_html_and_js']);
    }

    public function add_order_ratio_column($columns) {
        $new_columns = [];
        foreach ($columns as $key => $column) {
            $new_columns[$key] = $column;
            if ($key === 'order_total') {
                $new_columns['order_ratio'] = __('Order Success Ratio', 'revenuepro-bkash-wc');
            }
        }
        
        if (!isset($new_columns['order_ratio'])) {
            $new_columns['order_ratio'] = __('Order Success Ratio', 'revenuepro-bkash-wc');
        }
        return $new_columns;
    }

    public function inject_admin_css() {
        $screen = get_current_screen();
        if (!$screen || !in_array($screen->id, ['edit-shop_order', 'woocommerce_page_wc-orders'])) {
            return;
        }

        wp_enqueue_style('dashicons');
        ?>
        <style>
        /* === Column Styles === */
        .bdc-ratio-minimal { display: flex; flex-direction: column; gap: 4px; font-size: 11px; font-weight: 600; font-family: -apple-system, system-ui, sans-serif; align-items: flex-start; }
        .bdc-minimal-counts { display:flex; align-items:center; gap:4px; }
        .bdc-count-total { color: #0ea5e9; }
        .bdc-count-success { color: #22c55e; }
        .bdc-count-cancel { color: #ef4444; }
        .bdc-separator { color: #cbd5e1; font-weight: 300; }
        .bdc-view-eye-icon { font-size: 15px; width: 15px; height: 15px; color: #3b82f6; margin-left: 6px; cursor: pointer; transition: color 0.15s; }
        .bdc-view-eye-icon:hover { color: #1e40af; }
        .bdc-minimal-second-line { width: 100%; max-width: 130px; margin-top: 2px; }
        .bdc-minimal-progress-wrapper { width: 100%; }
        .bdc-minimal-progress-bar { width: 100%; background: #e2e8f0; height: 14px; border-radius: 8px; overflow: hidden; display: flex; position: relative; box-shadow: inset 0 1px 2px rgba(0,0,0,0.05); }
        .bdc-progress-success { background: #22c55e; height: 100%; transition: width 0.5s ease-out; }
        .bdc-progress-cancel { background: #ef4444; height: 100%; transition: width 0.5s ease-out; }
        .bdc-progress-percentage { position: absolute; width: 100%; text-align: center; color: white; font-size: 10px; line-height: 14px; font-weight: 700; text-shadow: 0px 1px 1.5px rgba(0,0,0,0.3); }
        .bdc-ratio-empty { background: #f8fafc; border: 1px dashed #cbd5e1; padding: 6px 8px; border-radius: 6px; text-align: center; width: 100%; max-width: 130px; }
        .bdc-empty-text { font-size: 10px; color: #64748b; }
        th.column-order_ratio { width: 16ch; }

        /* === Modal Overlay === */
        .rp-modal-overlay { display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.55); z-index:999999; justify-content:center; align-items:center; backdrop-filter:blur(3px); }
        .rp-modal-overlay.active { display:flex; }
        .rp-modal { background:#fff; border-radius:16px; width:800px; max-width:95vw; max-height:90vh; overflow-y:auto; box-shadow:0 25px 60px rgba(0,0,0,0.25); animation: rp-modal-in 0.25s ease-out; font-family:-apple-system,system-ui,'Segoe UI',Roboto,sans-serif; }
        @keyframes rp-modal-in { from{opacity:0;transform:scale(0.95) translateY(10px)} to{opacity:1;transform:scale(1) translateY(0)} }

        /* Header */
        .rp-modal-header { background:linear-gradient(135deg,#1e3a5f 0%,#2563eb 100%); color:white; padding:20px 28px; border-radius:16px 16px 0 0; display:flex; align-items:center; justify-content:space-between; }
        .rp-modal-header-left { display:flex; align-items:center; gap:14px; }
        .rp-modal-header-icon { width:42px; height:42px; background:rgba(255,255,255,0.15); border-radius:12px; display:flex; align-items:center; justify-content:center; }
        .rp-modal-header-icon .dashicons { font-size:22px; width:22px; height:22px; }
        .rp-modal-title { font-size:18px; font-weight:700; letter-spacing:-0.3px; }
        .rp-modal-phone { font-size:13px; opacity:0.85; margin-top:2px; }
        .rp-modal-close { background:rgba(255,255,255,0.15); border:none; color:white; width:36px; height:36px; border-radius:10px; cursor:pointer; font-size:20px; display:flex; align-items:center; justify-content:center; transition:background .15s; }
        .rp-modal-close:hover { background:rgba(255,255,255,0.3); }

        /* Body */
        .rp-modal-body { padding:24px 28px; display:flex; gap:28px; }
        @media(max-width:700px){ .rp-modal-body{flex-direction:column;} }

        /* Table */
        .rp-modal-table-wrapper { flex:1; }
        .rp-courier-table { width:100%; border-collapse:separate; border-spacing:0; border:1px solid #e2e8f0; border-radius:10px; overflow:hidden; font-size:13px; }
        .rp-courier-table thead th { background:linear-gradient(135deg,#1e3a5f,#2563eb); color:white; padding:10px 14px; font-weight:600; text-transform:uppercase; font-size:11px; letter-spacing:0.5px; }
        .rp-courier-table tbody td { padding:10px 14px; border-bottom:1px solid #f1f5f9; }
        .rp-courier-table tbody tr:last-child td { border-bottom:none; }
        .rp-courier-table tbody tr:hover { background:#f8fafc; }
        .rp-courier-name { display:flex; align-items:center; gap:8px; font-weight:500; }
        .rp-courier-logo { width:30px; height:20px; object-fit:contain; border-radius:3px; }
        .rp-col-total { color:#0ea5e9; font-weight:700; }
        .rp-col-success { color:#22c55e; font-weight:700; }
        .rp-col-return { color:#ef4444; font-weight:700; }
        .rp-summary-row td { background:linear-gradient(135deg,#1e3a5f,#2563eb); color:white!important; font-weight:700; font-size:13px; }
        .rp-summary-row td span { color:white!important; }

        /* Chart side */
        .rp-modal-chart-wrapper { width:280px; min-width:250px; display:flex; flex-direction:column; align-items:center; gap:16px; }
        .rp-chart-title { font-size:16px; font-weight:700; color:#1e293b; text-align:center; }
        .rp-chart-subtitle { font-size:12px; color:#64748b; margin-top:-10px; text-align:center; }
        .rp-donut-svg { width:180px; height:180px; }
        .rp-chart-legend { display:flex; gap:20px; justify-content:center; font-size:12px; }
        .rp-legend-dot { width:10px; height:10px; border-radius:50%; display:inline-block; margin-right:5px; }
        .rp-legend-item { display:flex; align-items:center; font-weight:500; color:#475569; }

        /* Summary cards */
        .rp-summary-cards { display:flex; gap:12px; width:100%; }
        .rp-summary-card { flex:1; padding:14px; border-radius:10px; }
        .rp-summary-card.success { background:#f0fdf4; border:1px solid #bbf7d0; }
        .rp-summary-card.returned { background:#fef2f2; border:1px solid #fecaca; }
        .rp-summary-card-label { display:flex; align-items:center; gap:6px; font-size:11px; font-weight:600; text-transform:uppercase; letter-spacing:0.5px; }
        .rp-summary-card-label .dot { width:8px; height:8px; border-radius:50%; }
        .rp-summary-card.success .rp-summary-card-label { color:#16a34a; }
        .rp-summary-card.success .dot { background:#22c55e; }
        .rp-summary-card.returned .rp-summary-card-label { color:#dc2626; }
        .rp-summary-card.returned .dot { background:#ef4444; }
        .rp-summary-card-value { font-size:24px; font-weight:800; color:#0f172a; margin-top:4px; }
        .rp-summary-card-pct { font-size:13px; color:#64748b; font-weight:500; }
        </style>
        <?php
    }

    public function display_order_ratio_column_content($column, $order_id) {
        if ('order_ratio' !== $column) return;

        $order = wc_get_order($order_id);
        if (!$order) return;

        $phone = $order->get_billing_phone();
        $clean_phone = preg_replace('/[^0-9]/', '', $phone);
        if (strpos($clean_phone, '8801') === 0) {
            $clean_phone = substr($clean_phone, 2);
        }

        require_once __DIR__ . '/fraud-detection-db.php';
        $stats = FraudDetectionDB::get_stats($clean_phone);

        if ($stats) {
            $total_parcel = intval($stats['total_parcel']);
            $success_parcel = intval($stats['success_parcel']);
            $cancel_parcel = intval($stats['cancelled_parcel']);
            $success_ratio = floatval($stats['success_ratio']);
            $cancel_ratio = $total_parcel > 0 ? (100 - $success_ratio) : 0;

            // Build JSON data for popup
            $popup_data = json_encode([
                'phone' => $clean_phone,
                'total' => $total_parcel,
                'success' => $success_parcel,
                'cancel' => $cancel_parcel,
                'success_ratio' => round($success_ratio, 1),
                'cancel_ratio' => round($cancel_ratio, 1),
                'couriers' => [
                    ['name' => 'Pathao',    'success' => intval($stats['pathao_success'] ?? 0),    'cancel' => intval($stats['pathao_cancel'] ?? 0)],
                    ['name' => 'SteadFast', 'success' => intval($stats['steadfast_success'] ?? 0), 'cancel' => intval($stats['steadfast_cancel'] ?? 0)],
                    ['name' => 'ParcelDex', 'success' => intval($stats['parceldex_success'] ?? 0), 'cancel' => intval($stats['parceldex_cancel'] ?? 0)],
                    ['name' => 'Redx',      'success' => intval($stats['redx_success'] ?? 0),      'cancel' => intval($stats['redx_cancel'] ?? 0)],
                    ['name' => 'PaperFly',  'success' => intval($stats['paperfly_success'] ?? 0),  'cancel' => intval($stats['paperfly_cancel'] ?? 0)],
                    ['name' => 'CarryBee',  'success' => intval($stats['carrybee_success'] ?? 0),  'cancel' => intval($stats['carrybee_cancel'] ?? 0)],
                ],
            ]);

            echo '<div class="bdc-ratio-minimal" title="Fetched from cached database">';
            echo '<div class="bdc-minimal-counts">';
            echo '<span class="bdc-count-total" title="Total">' . esc_html($total_parcel) . '</span>';
            echo '<span class="bdc-separator">|</span>';
            echo '<span class="bdc-count-success" title="Success">' . esc_html($success_parcel) . '</span>';
            echo '<span class="bdc-separator">|</span>';
            echo '<span class="bdc-count-cancel" title="Cancelled">' . esc_html($cancel_parcel) . '</span>';
            echo '<a href="#" class="bdc-view-eye-icon dashicons dashicons-visibility" title="View Details" data-stats=\'' . esc_attr($popup_data) . '\' onclick="event.preventDefault();event.stopPropagation();return false;"></a>';
            echo '</div>';

            echo '<div class="bdc-minimal-second-line">';
            echo '<div class="bdc-minimal-progress-wrapper">';
            echo '<div class="bdc-minimal-progress-bar">';
            if ($success_ratio > 0) {
                echo '<div class="bdc-progress-success" style="width:' . esc_attr($success_ratio) . '%;"></div>';
            }
            if ($cancel_ratio > 0) {
                echo '<div class="bdc-progress-cancel" style="width:' . esc_attr($cancel_ratio) . '%;"></div>';
            }
            echo '<span class="bdc-progress-percentage">' . esc_html(number_format($success_ratio, 1)) . '%</span>';
            echo '</div>'; 
            echo '</div>'; 
            echo '</div>'; 
            echo '</div>'; 

        } else {
            echo '<div class="bdc-ratio-empty">';
            echo '<div class="bdc-empty-text">' . esc_html__('No previous order data', 'revenuepro-bkash-wc') . '</div>';
            echo '</div>';
        }
    }

    public function inject_modal_html_and_js() {
        $screen = get_current_screen();
        if (!$screen || !in_array($screen->id, ['edit-shop_order', 'woocommerce_page_wc-orders'])) {
            return;
        }
        ?>
        <!-- RevenuePro Courier Ratio Popup -->
        <div class="rp-modal-overlay" id="rp-ratio-modal-overlay">
            <div class="rp-modal" id="rp-ratio-modal">
                <div class="rp-modal-header">
                    <div class="rp-modal-header-left">
                        <div class="rp-modal-header-icon"><span class="dashicons dashicons-chart-bar"></span></div>
                        <div>
                            <div class="rp-modal-title">Courier Order Ratio</div>
                            <div class="rp-modal-phone" id="rp-modal-phone">Phone: --</div>
                        </div>
                    </div>
                    <button class="rp-modal-close" id="rp-modal-close" title="Close">&times;</button>
                </div>
                <div class="rp-modal-body">
                    <div class="rp-modal-table-wrapper">
                        <table class="rp-courier-table">
                            <thead><tr><th>Courier</th><th>Total</th><th>Success</th><th>Return</th></tr></thead>
                            <tbody id="rp-courier-tbody"></tbody>
                        </table>
                    </div>
                    <div class="rp-modal-chart-wrapper">
                        <div class="rp-chart-title">Success vs Returned</div>
                        <div class="rp-chart-subtitle">Order Distribution Overview</div>
                        <div id="rp-donut-container"></div>
                        <div class="rp-chart-legend">
                            <span class="rp-legend-item"><span class="rp-legend-dot" style="background:#22c55e"></span> Successful</span>
                            <span class="rp-legend-item"><span class="rp-legend-dot" style="background:#ef4444"></span> Returned</span>
                        </div>
                        <div class="rp-summary-cards">
                            <div class="rp-summary-card success">
                                <div class="rp-summary-card-label"><span class="dot"></span> SUCCESS</div>
                                <div class="rp-summary-card-value" id="rp-card-success-val">0</div>
                                <div class="rp-summary-card-pct" id="rp-card-success-pct">0.0%</div>
                            </div>
                            <div class="rp-summary-card returned">
                                <div class="rp-summary-card-label"><span class="dot"></span> RETURNED</div>
                                <div class="rp-summary-card-value" id="rp-card-return-val">0</div>
                                <div class="rp-summary-card-pct" id="rp-card-return-pct">0.0%</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <script>
        (function(){
            var overlay = document.getElementById('rp-ratio-modal-overlay');
            var closeBtn = document.getElementById('rp-modal-close');

            // Delegate click on eye icons — capture phase to fire before WooCommerce row handlers
            document.addEventListener('click', function(e) {
                var eye = e.target.closest('.bdc-view-eye-icon');
                if (!eye) return;
                e.preventDefault();
                e.stopPropagation();
                e.stopImmediatePropagation();
                var raw = eye.getAttribute('data-stats');
                if (!raw) return;
                try { var d = JSON.parse(raw); } catch(err) { return; }
                openModal(d);
            }, true);

            // Close
            closeBtn.addEventListener('click', function(){ overlay.classList.remove('active'); });
            overlay.addEventListener('click', function(e){ if(e.target===overlay) overlay.classList.remove('active'); });
            document.addEventListener('keydown', function(e){ if(e.key==='Escape') overlay.classList.remove('active'); });

            function openModal(d) {
                // Phone
                document.getElementById('rp-modal-phone').textContent = 'Phone: +88' + d.phone;

                // Build table rows
                var tbody = document.getElementById('rp-courier-tbody');
                var html = '';
                var couriers = d.couriers || [];
                for (var i = 0; i < couriers.length; i++) {
                    var c = couriers[i];
                    var t = c.success + c.cancel;
                    html += '<tr>' +
                        '<td class="rp-courier-name">' + esc(c.name) + '</td>' +
                        '<td class="rp-col-total">' + t + '</td>' +
                        '<td class="rp-col-success">' + c.success + '</td>' +
                        '<td class="rp-col-return">' + c.cancel + '</td>' +
                    '</tr>';
                }
                // Summary row
                html += '<tr class="rp-summary-row">' +
                    '<td><strong>SUMMARY</strong></td>' +
                    '<td><span>' + d.total + '</span></td>' +
                    '<td><span>' + d.success + '</span></td>' +
                    '<td><span>' + d.cancel + '</span></td>' +
                '</tr>';
                tbody.innerHTML = html;

                // Summary cards
                document.getElementById('rp-card-success-val').textContent = d.success;
                document.getElementById('rp-card-success-pct').textContent = d.success_ratio + '%';
                document.getElementById('rp-card-return-val').textContent = d.cancel;
                document.getElementById('rp-card-return-pct').textContent = d.cancel_ratio + '%';

                // Donut chart via SVG
                drawDonut(d.success_ratio, d.cancel_ratio);

                overlay.classList.add('active');
            }

            function drawDonut(successPct, cancelPct) {
                var container = document.getElementById('rp-donut-container');
                var size = 180, cx = 90, cy = 90, r = 65, stroke = 28;
                var circ = 2 * Math.PI * r;
                // Ensure at least some visual for 0% scenarios
                var sLen = (successPct / 100) * circ;
                var cLen = (cancelPct / 100) * circ;

                var svg = '<svg class="rp-donut-svg" viewBox="0 0 ' + size + ' ' + size + '">' +
                    // Background circle
                    '<circle cx="'+cx+'" cy="'+cy+'" r="'+r+'" fill="none" stroke="#e2e8f0" stroke-width="'+stroke+'"/>';

                if (successPct > 0) {
                    svg += '<circle cx="'+cx+'" cy="'+cy+'" r="'+r+'" fill="none" ' +
                        'stroke="#22c55e" stroke-width="'+stroke+'" ' +
                        'stroke-dasharray="'+sLen+' '+circ+'" ' +
                        'stroke-dashoffset="0" ' +
                        'transform="rotate(-90 '+cx+' '+cy+')" ' +
                        'style="transition:stroke-dasharray 0.5s ease"/>';
                }

                if (cancelPct > 0) {
                    svg += '<circle cx="'+cx+'" cy="'+cy+'" r="'+r+'" fill="none" ' +
                        'stroke="#ef4444" stroke-width="'+stroke+'" ' +
                        'stroke-dasharray="'+cLen+' '+circ+'" ' +
                        'stroke-dashoffset="-'+sLen+'" ' +
                        'transform="rotate(-90 '+cx+' '+cy+')" ' +
                        'style="transition:stroke-dasharray 0.5s ease"/>';
                }

                // Center text
                svg += '<text x="'+cx+'" y="'+(cy-6)+'" text-anchor="middle" fill="#22c55e" font-size="11" font-weight="600">Successful '+successPct+'%</text>';
                svg += '<text x="'+cx+'" y="'+(cy+14)+'" text-anchor="middle" fill="#ef4444" font-size="11" font-weight="600">Returned '+cancelPct+'%</text>';
                svg += '</svg>';

                container.innerHTML = svg;
            }

            function esc(s) {
                var d = document.createElement('div');
                d.textContent = s;
                return d.innerHTML;
            }
        })();
        </script>
        <?php
    }
}
