<?php
namespace RevenuePro;

if (!defined('ABSPATH')) {
    exit;
}

class LicenseManager
{
    /**
     * Initializes the License verification hooks.
     */
    public static function init()
    {
        add_action('admin_notices', [__CLASS__, 'display_license_notices']);
        add_action('admin_init', [__CLASS__, 'check_license_on_save']);
        add_action('revenuepro_license_revalidate', [__CLASS__, 'cron_revalidate']);

        // Schedule daily license re-check
        if (!wp_next_scheduled('revenuepro_license_revalidate')) {
            wp_schedule_event(time(), 'daily', 'revenuepro_license_revalidate');
        }
    }

    /**
     * Globally validates the activated JWT Token on every page rendering loop.
     * Use this method to turn Premium capabilities ON or OFF securely.
     */
    public static function is_license_active()
    {
        $settings = get_option('revenuepro_bkash_wc_settings', []);
        $license_plan  = isset($settings['license_plan']) ? $settings['license_plan'] : '';
        $license_token = isset($settings['license_token']) ? $settings['license_token'] : '';

        // Must have a plan that isn't free/invalid/expired
        if (empty($license_plan) || $license_plan === 'Free / Unlicensed' || strpos($license_plan, 'Invalid') !== false || strpos($license_plan, 'Expired') !== false) {
            return false;
        }

        // If there's a JWT token, validate its expiry
        if (!empty($license_token)) {
            $jwt_data = self::verify_revenuepro_jwt_token($license_token);
            
            if ($jwt_data === false) {
                return false; // Signature breached
            }

            $expiry_ts = isset($jwt_data->expiresAt) ? self::parse_expiry_to_timestamp($jwt_data->expiresAt) : 0;
            if ($expiry_ts > 0 && time() > $expiry_ts) {
                return false; // Token expired
            }
        }

        // Check stored expiresAt from API (for token-less plans)
        if (!empty($settings['license_expires_at'])) {
            $expiry_ts = self::parse_expiry_to_timestamp($settings['license_expires_at']);
            if ($expiry_ts > 0 && time() > $expiry_ts) {
                return false; // License expired!
            }
        }

        // Valid plan with no expiry (Lifetime) or not yet expired
        return true; 
    }

    /**
     * Parse any expiresAt value into a unix timestamp (seconds).
     * Handles: null, unix seconds, unix milliseconds, ISO date strings.
     */
    private static function parse_expiry_to_timestamp($val)
    {
        if (empty($val)) return 0;
        
        // If numeric (int or numeric string)
        if (is_numeric($val)) {
            $num = (int) $val;
            return $num > 9999999999 ? intval($num / 1000) : $num;
        }
        
        // Try parsing as date string (ISO 8601 etc.)
        $ts = strtotime($val);
        return $ts !== false ? $ts : 0;
    }

    /**
     * Verifies a RevenuePro RSA JWT Signature securely offline against hacks!
     */
    public static function verify_revenuepro_jwt_token($token)
    {
        if (empty($token) || !is_string($token)) {
            return false;
        }

        $public_key = <<<EOD
-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEApoPYWBmSmMvgUWnbHoYm
OEra3nM7HXIhcaIJlYcM1i8/QZEr3Vq5f1160o2idrFPGnCjEb1A+Yvge1STSTvG
OSLEmmBjAPC71FJhV5qqMC8uB8v+iGqi6XwF4KyxrrUbghR8AmZZbK9FBj9H2eIs
sMk69pAVGXzdvGEgrsBjWO3IoPcby6keO9jPanHWtW8urfahGzrJG49eTXN+Rpc0
1+/fRUibDY6C6Nr/eIqVb9fSkaDT4PeX7uaqQ0hMmZh2MQSi4f9PMBlzt1VzyIGY
pnWcIw7yrBl5NTCBDuO8TSLB9zzZqFnqxUQjJRD4D7F9pVlrT7+u0UkbzxKfJChL
BQIDAQAB
-----END PUBLIC KEY-----
EOD;

        $parts = explode('.', $token);
        if (count($parts) !== 3) {
            return false;
        }

        $data_to_verify = $parts[0] . '.' . $parts[1];
        $signature = base64_decode(strtr($parts[2], '-_', '+/'));

        // Math! Does the Private Key algorithm match this payload exactly?
        $is_valid = openssl_verify($data_to_verify, $signature, $public_key, OPENSSL_ALGO_SHA256);

        if ($is_valid === 1) {
            return json_decode(base64_decode(strtr($parts[1], '-_', '+/'))); // Valid payload
        } 
        
        return false; // Tampering detected
    }

    /**
     * Shows a WordPress Admin Notice if the plugin is unlicensed.
     */
    public static function display_license_notices()
    {
        $screen = get_current_screen();
        if (!$screen || (!strpos($screen->id, 'revenuepro') && $screen->id !== 'plugins')) {
            return;
        }

        if (!self::is_license_active()) {
            ?>
            <div class="notice notice-error is-dismissible">
                <p><strong>RevenuePro Licensing Error:</strong> Your license validates as missing, invalid, or expired. Premium features have been halted. Please visit the <a href="<?php echo esc_url(admin_url('admin.php?page=revenuepro-bkash-wc-settings#license')); ?>">RevenuePro License Settings</a> to secure your connection.</p>
            </div>
            <?php
        }
    }

    /**
     * Dropped cache clearing since we evaluate structurally offline now natively via RSA.
     */
    public static function check_license_on_save()
    {
        // No caching loops needed for instant offline JWT verifications!
    }

    /**
     * Cron: Re-verify license with the live API server.
     * Runs daily to detect expired/revoked licenses.
     */
    public static function cron_revalidate()
    {
        $settings = get_option('revenuepro_bkash_wc_settings', []);
        $license_key = isset($settings['license_key']) ? $settings['license_key'] : '';
        $account_email = isset($settings['account_email']) ? $settings['account_email'] : '';

        if (empty($license_key)) {
            return;
        }

        $api_url = defined('REVENUEPRO_API_BASE_URL') ? REVENUEPRO_API_BASE_URL : 'https://codeblend.co';
        $response = wp_remote_post($api_url . '/api/v1/license/verify', [
            'method'  => 'POST',
            'timeout' => 15,
            'headers' => ['Content-Type' => 'application/json'],
            'body'    => wp_json_encode([
                'key'    => sanitize_text_field($license_key),
                'email'  => sanitize_email($account_email),
                'domain' => trailingslashit(get_site_url()),
            ]),
        ]);

        if (is_wp_error($response)) {
            return; // Network error — don't change status
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);

        if (!empty($body) && (isset($body['valid']) && $body['valid'] === false)) {
            // License expired or revoked on server — lock plugin
            $settings['license_plan'] = 'Expired / Please Renew';
            $settings['license_token'] = '';
            $settings['license_expires_at'] = '';
            update_option('revenuepro_bkash_wc_settings', $settings);
        } elseif (!empty($body) && !empty($body['valid'])) {
            // License still valid — update expiry if provided
            if (isset($body['expiresAt'])) {
                $settings['license_expires_at'] = $body['expiresAt'];
            }
            if (isset($body['plan'])) {
                $settings['license_plan'] = $body['plan'];
            }
            update_option('revenuepro_bkash_wc_settings', $settings);
        }
    }

    /**
     * Fires instantly when the user clicks 'Deactivate' on the plugin in WordPress.
     * 
     * IMPORTANT: We intentionally do NOT wipe the license key here.
     * The license should persist across deactivate/reactivate cycles.
     * Only the explicit "Revoke License" button in the dashboard should clear it.
     */
    public static function deactivate_plugin()
    {
        // Clean up scheduled cron events
        wp_clear_scheduled_hook('revenuepro_license_revalidate');
        
        // Clear any cached transients
        delete_transient('revenuepro_server_ip');
    }
}
