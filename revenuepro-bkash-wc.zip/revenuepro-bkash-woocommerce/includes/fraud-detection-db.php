<?php
namespace RevenuePro;

if (!defined('ABSPATH')) {
    exit;
}

class FraudDetectionDB
{
    private static $table_name = 'revenuepro_fraud_stats';

    public static function create_table()
    {
        global $wpdb;
        $table_name = $wpdb->prefix . self::$table_name;
        $charset_collate = $wpdb->get_charset_collate();

        // Expanding table to explicitly store the granular courier stats per user request
        $sql = "CREATE TABLE IF NOT EXISTS $table_name (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            phone varchar(20) NOT NULL,
            total_parcel int(11) DEFAULT 0,
            success_parcel int(11) DEFAULT 0,
            cancelled_parcel int(11) DEFAULT 0,
            success_ratio float DEFAULT 0,
            
            pathao_success int(11) DEFAULT 0,
            pathao_cancel int(11) DEFAULT 0,
            
            steadfast_success int(11) DEFAULT 0,
            steadfast_cancel int(11) DEFAULT 0,
            
            parceldex_success int(11) DEFAULT 0,
            parceldex_cancel int(11) DEFAULT 0,
            
            redx_success int(11) DEFAULT 0,
            redx_cancel int(11) DEFAULT 0,
            
            paperfly_success int(11) DEFAULT 0,
            paperfly_cancel int(11) DEFAULT 0,
            
            carrybee_success int(11) DEFAULT 0,
            carrybee_cancel int(11) DEFAULT 0,

            courier_data longtext DEFAULT NULL,
            reports longtext DEFAULT NULL,
            last_checked datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY phone (phone)
        ) $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    /**
     * Store the BD Courier API response in the local DB
     */
    public static function store_api_response($phone, $api_data)
    {
        global $wpdb;
        $table_name = $wpdb->prefix . self::$table_name;
        
        $phone = self::sanitize_phone($phone);
        if (!$phone || empty($api_data) || !isset($api_data['data']['summary'])) {
            return false;
        }

        $summary = $api_data['data']['summary'];
        $couriers = $api_data['data'];
        unset($couriers['summary']);

        $total_parcel = intval($summary['total_parcel'] ?? 0);
        $success_parcel = intval($summary['success_parcel'] ?? 0);
        $cancelled_parcel = intval($summary['cancelled_parcel'] ?? 0);
        $success_ratio = floatval($summary['success_ratio'] ?? 0);
        
        // Granular courier mapping
        $p_success = intval($couriers['pathao']['success_parcel'] ?? 0);
        $p_cancel  = intval($couriers['pathao']['cancelled_parcel'] ?? 0);
        
        $s_success = intval($couriers['steadfast']['success_parcel'] ?? 0);
        $s_cancel  = intval($couriers['steadfast']['cancelled_parcel'] ?? 0);
        
        $px_success = intval($couriers['parceldex']['success_parcel'] ?? 0);
        $px_cancel  = intval($couriers['parceldex']['cancelled_parcel'] ?? 0);
        
        $r_success = intval($couriers['redx']['success_parcel'] ?? 0);
        $r_cancel  = intval($couriers['redx']['cancelled_parcel'] ?? 0);
        
        $pf_success = intval($couriers['paperfly']['success_parcel'] ?? 0);
        $pf_cancel  = intval($couriers['paperfly']['cancelled_parcel'] ?? 0);
        
        $c_success = intval($couriers['carrybee']['success_parcel'] ?? 0);
        $c_cancel  = intval($couriers['carrybee']['cancelled_parcel'] ?? 0);

        $courier_json = json_encode($couriers);
        $reports_json = json_encode($api_data['reports'] ?? []);

        $wpdb->query(
            $wpdb->prepare(
                "INSERT INTO $table_name 
                (
                    phone, total_parcel, success_parcel, cancelled_parcel, success_ratio, 
                    pathao_success, pathao_cancel, 
                    steadfast_success, steadfast_cancel, 
                    parceldex_success, parceldex_cancel, 
                    redx_success, redx_cancel, 
                    paperfly_success, paperfly_cancel, 
                    carrybee_success, carrybee_cancel, 
                    courier_data, reports, last_checked
                ) 
                VALUES (%s, %d, %d, %d, %f, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %s, %s, CURRENT_TIMESTAMP)
                ON DUPLICATE KEY UPDATE 
                total_parcel = VALUES(total_parcel),
                success_parcel = VALUES(success_parcel),
                cancelled_parcel = VALUES(cancelled_parcel),
                success_ratio = VALUES(success_ratio),
                
                pathao_success = VALUES(pathao_success),
                pathao_cancel = VALUES(pathao_cancel),
                
                steadfast_success = VALUES(steadfast_success),
                steadfast_cancel = VALUES(steadfast_cancel),
                
                parceldex_success = VALUES(parceldex_success),
                parceldex_cancel = VALUES(parceldex_cancel),
                
                redx_success = VALUES(redx_success),
                redx_cancel = VALUES(redx_cancel),
                
                paperfly_success = VALUES(paperfly_success),
                paperfly_cancel = VALUES(paperfly_cancel),
                
                carrybee_success = VALUES(carrybee_success),
                carrybee_cancel = VALUES(carrybee_cancel),
                
                courier_data = VALUES(courier_data),
                reports = VALUES(reports),
                last_checked = CURRENT_TIMESTAMP",
                $phone,
                $total_parcel,
                $success_parcel,
                $cancelled_parcel,
                $success_ratio,
                $p_success, $p_cancel,
                $s_success, $s_cancel,
                $px_success, $px_cancel,
                $r_success, $r_cancel,
                $pf_success, $pf_cancel,
                $c_success, $c_cancel,
                $courier_json,
                $reports_json
            )
        );

        return true;
    }
    /**
     * Upsert stats from pre-parsed Node.js API response
     * Accepts a flat array with keys: total_parcel, success_parcel, cancelled_parcel, success_ratio, 
     * pathao_success, pathao_cancel, steadfast_success, steadfast_cancel, etc.
     */
    public static function upsert_stats($phone, $stats)
    {
        global $wpdb;
        $table_name = $wpdb->prefix . self::$table_name;
        
        $phone = self::sanitize_phone($phone);
        if (!$phone) return false;

        $wpdb->query(
            $wpdb->prepare(
                "INSERT INTO $table_name 
                (
                    phone, total_parcel, success_parcel, cancelled_parcel, success_ratio, 
                    pathao_success, pathao_cancel, 
                    steadfast_success, steadfast_cancel, 
                    parceldex_success, parceldex_cancel, 
                    redx_success, redx_cancel, 
                    paperfly_success, paperfly_cancel, 
                    carrybee_success, carrybee_cancel, 
                    last_checked
                ) 
                VALUES (%s, %d, %d, %d, %f, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, CURRENT_TIMESTAMP)
                ON DUPLICATE KEY UPDATE 
                total_parcel = VALUES(total_parcel),
                success_parcel = VALUES(success_parcel),
                cancelled_parcel = VALUES(cancelled_parcel),
                success_ratio = VALUES(success_ratio),
                pathao_success = VALUES(pathao_success),
                pathao_cancel = VALUES(pathao_cancel),
                steadfast_success = VALUES(steadfast_success),
                steadfast_cancel = VALUES(steadfast_cancel),
                parceldex_success = VALUES(parceldex_success),
                parceldex_cancel = VALUES(parceldex_cancel),
                redx_success = VALUES(redx_success),
                redx_cancel = VALUES(redx_cancel),
                paperfly_success = VALUES(paperfly_success),
                paperfly_cancel = VALUES(paperfly_cancel),
                carrybee_success = VALUES(carrybee_success),
                carrybee_cancel = VALUES(carrybee_cancel),
                last_checked = CURRENT_TIMESTAMP",
                $phone,
                intval($stats['total_parcel'] ?? 0),
                intval($stats['success_parcel'] ?? 0),
                intval($stats['cancelled_parcel'] ?? 0),
                floatval($stats['success_ratio'] ?? 0),
                intval($stats['pathao_success'] ?? 0),
                intval($stats['pathao_cancel'] ?? 0),
                intval($stats['steadfast_success'] ?? 0),
                intval($stats['steadfast_cancel'] ?? 0),
                intval($stats['parceldex_success'] ?? 0),
                intval($stats['parceldex_cancel'] ?? 0),
                intval($stats['redx_success'] ?? 0),
                intval($stats['redx_cancel'] ?? 0),
                intval($stats['paperfly_success'] ?? 0),
                intval($stats['paperfly_cancel'] ?? 0),
                intval($stats['carrybee_success'] ?? 0),
                intval($stats['carrybee_cancel'] ?? 0)
            )
        );

        return true;
    }

    /**
     * Get statistics for a specific phone number
     */
    public static function get_stats($phone)
    {
        global $wpdb;
        $table_name = $wpdb->prefix . self::$table_name;
        
        $phone = self::sanitize_phone($phone);
        if (!$phone) return null;

        return $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE phone = %s", $phone), ARRAY_A);
    }

    /**
     * Get all fraud statistics for API export
     */
    public static function get_all_stats($limit = 100, $offset = 0)
    {
        global $wpdb;
        $table_name = $wpdb->prefix . self::$table_name;
        
        return $wpdb->get_results(
            $wpdb->prepare("SELECT * FROM $table_name ORDER BY last_checked DESC LIMIT %d OFFSET %d", $limit, $offset),
            ARRAY_A
        );
    }

    /**
     * Get total count for pagination
     */
    public static function get_total_count()
    {
        global $wpdb;
        $table_name = $wpdb->prefix . self::$table_name;
        return $wpdb->get_var("SELECT COUNT(*) FROM $table_name");
    }

    /**
     * Helper to clean phone numbers
     */
    private static function sanitize_phone($phone)
    {
        $phone = preg_replace('/[^0-9+]/', '', $phone);
        if (empty($phone)) return false;
        
        if (strpos($phone, '+88') === 0) {
            $phone = substr($phone, 3);
        } elseif (strpos($phone, '88') === 0) {
            $phone = substr($phone, 2);
        }
        return $phone;
    }
}
