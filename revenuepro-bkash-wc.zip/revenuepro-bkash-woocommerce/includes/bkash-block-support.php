<?php
namespace RevenuePro;

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

final class BkashBlockSupport extends AbstractPaymentMethodType
{
    protected $name = 'revenuepro_bkash';

    public function initialize()
    {
        $this->settings = get_option('woocommerce_revenuepro_bkash_settings', []);
    }

    public function is_active()
    {
        return !empty($this->settings['enabled']) && 'yes' === $this->settings['enabled'];
    }

    public function get_payment_method_script_handles()
    {
        $asset_path = REVENUEPRO_FORM_ROOT_DIR_PATH . 'assets/build/bkash-payment.asset.php';
        $version = REVENUEPRO_VERSION;
        $dependencies = [];
        
        if (file_exists($asset_path)) {
            $asset = require $asset_path;
            $version = $asset['version'];
            $dependencies = $asset['dependencies'];
        }

        wp_register_script(
            'revenuepro-bkash-block',
            REVENUEPRO_FORM_ROOT_URL . 'assets/build/bkash-payment.js',
            $dependencies,
            $version,
            true
        );

        return ['revenuepro-bkash-block'];
    }

    public function get_payment_method_data()
    {
        $rp_settings = get_option('revenuepro_bkash_wc_settings', []);
        $icon = !empty($rp_settings['bkash_logo_url']) ? $rp_settings['bkash_logo_url'] : '';

        return [
            'title' => $this->settings['title'] ?? 'bKash',
            'description' => $this->settings['description'] ?? 'Pay with bKash',
            'icon' => $icon,
            'supports' => ['products'],
        ];
    }
}
