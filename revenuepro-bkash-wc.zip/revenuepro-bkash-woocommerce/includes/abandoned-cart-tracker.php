<?php
namespace RevenuePro;

if (!defined('ABSPATH')) {
    exit;
}

class AbandonedCartTracker
{
    public static function init()
    {
        $self = new self();
        
        // Enqueue tracking script on checkout page
        add_action('wp_enqueue_scripts', [$self, 'enqueue_tracking_script']);
        
        // AJAX handlers
        add_action('wp_ajax_revenuepro_save_cart', [$self, 'ajax_save_cart']);
        add_action('wp_ajax_nopriv_revenuepro_save_cart', [$self, 'ajax_save_cart']);
        
        // Mark cart as recovered when order is completed
        add_action('woocommerce_thankyou', [$self, 'mark_cart_recovered'], 10, 1);
        
        // Clean up old carts daily
        add_action('revenuepro_cleanup_abandoned_carts', [$self, 'cleanup_old_carts']);
        
        if (!wp_next_scheduled('revenuepro_cleanup_abandoned_carts')) {
            wp_schedule_event(time(), 'daily', 'revenuepro_cleanup_abandoned_carts');
        }
    }

    public function enqueue_tracking_script()
    {
        if (!is_checkout() || is_order_received_page()) {
            return;
        }

        wp_enqueue_script(
            'revenuepro-cart-tracker',
            REVENUEPRO_FORM_ASSETS_URL . 'js/cart-tracker.js',
            ['jquery'],
            '1.0.0',
            true
        );

        wp_localize_script('revenuepro-cart-tracker', 'revenueProCart', [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('revenuepro_cart_nonce'),
            'session_id' => $this->get_session_id(),
        ]);
    }

    public function ajax_save_cart()
    {
        check_ajax_referer('revenuepro_cart_nonce', 'nonce');

        $session_id = sanitize_text_field($_POST['session_id'] ?? '');
        $customer_name = sanitize_text_field($_POST['customer_name'] ?? '');
        $customer_email = sanitize_email($_POST['customer_email'] ?? '');
        $customer_phone = sanitize_text_field($_POST['customer_phone'] ?? '');

        if (empty($session_id)) {
            wp_send_json_error(['message' => 'Invalid session']);
        }

        // Normalize and validate BD phone number
        $customer_phone = $this->normalize_bd_phone($customer_phone);
        if (empty($customer_phone)) {
            wp_send_json_error(['message' => 'Valid BD phone number required']);
            return;
        }

        // Get cart contents
        $cart = WC()->cart;
        if (!$cart || $cart->is_empty()) {
            wp_send_json_error(['message' => 'Cart is empty']);
        }

        $cart_contents = [];
        foreach ($cart->get_cart() as $cart_item_key => $cart_item) {
            $product = $cart_item['data'];
            $cart_contents[] = [
                'product_id' => $cart_item['product_id'],
                'variation_id' => $cart_item['variation_id'] ?? 0,
                'quantity' => $cart_item['quantity'],
                'name' => $product->get_name(),
                'price' => $product->get_price(),
                'total' => $cart_item['line_total'],
            ];
        }

        $data = [
            'session_id' => $session_id,
            'user_id' => get_current_user_id() ?: null,
            'customer_name' => $customer_name,
            'customer_email' => $customer_email,
            'customer_phone' => $customer_phone,
            'cart_contents' => json_encode($cart_contents),
            'cart_total' => $cart->total,
            'currency' => get_woocommerce_currency(),
            'checkout_data' => json_encode($_POST['checkout_data'] ?? []),
            'status' => 'active',
        ];

        $cart_id = AbandonedCartDB::save_cart($data);

        if ($cart_id) {
            wp_send_json_success(['cart_id' => $cart_id, 'message' => 'Cart saved']);
        } else {
            global $wpdb;
            $error = $wpdb->last_error;
            
            // Check if table doesn't exist or has wrong schema
            if (strpos($error, "doesn't exist") !== false || strpos($error, "Unknown column") !== false) {
                // Drop and recreate table with correct schema
                $table_name = $wpdb->prefix . 'revenuepro_abandoned_carts';
                $wpdb->query("DROP TABLE IF EXISTS $table_name");
                AbandonedCartDB::create_table();
                
                // Retry save
                $cart_id = AbandonedCartDB::save_cart($data);
                if ($cart_id) {
                    wp_send_json_success(['cart_id' => $cart_id, 'message' => 'Cart saved (table recreated)']);
                }
                $error .= " (Recreated table and retried)";
            }
            
            wp_send_json_error(['message' => 'Failed to save cart', 'db_error' => $error]);
        }
    }

    public function mark_cart_recovered($order_id)
    {
        if (!$order_id) {
            return;
        }

        $session_id = $this->get_session_id();
        $email = '';
        $phone = '';
        
        if (function_exists('wc_get_order')) {
            $order = wc_get_order($order_id);
            if ($order) {
                $email = $order->get_billing_email();
                $phone = $order->get_billing_phone();
            }
        }

        AbandonedCartDB::recover_carts_matching($session_id, $email, $phone, $order_id);
    }

    public function cleanup_old_carts()
    {
        AbandonedCartDB::delete_old_carts(30); // Delete carts older than 30 days
    }

    private function get_session_id()
    {
        // Try to get WooCommerce session
        if (WC()->session) {
            $session_id = WC()->session->get_customer_id();
            if ($session_id) {
                return $session_id;
            }
        }

        // Fallback to cookie-based session
        if (isset($_COOKIE['revenuepro_session_id'])) {
            return sanitize_text_field($_COOKIE['revenuepro_session_id']);
        }

        // Generate new session ID
        $session_id = 'rp_' . uniqid() . '_' . time();
        setcookie('revenuepro_session_id', $session_id, time() + (86400 * 30), '/');
        
        return $session_id;
    }

    /**
     * Normalize and validate a BD phone number.
     * Returns a valid 11-digit string (01XXXXXXXXX) or empty string if invalid.
     */
    private function normalize_bd_phone($phone)
    {
        $clean = preg_replace('/[^0-9]/', '', $phone);
        // Handle +880 / 880 prefix
        if (strpos($clean, '880') === 0) {
            $clean = '0' . substr($clean, 3);
        }
        // Must be 11 digits starting with 01
        if (strlen($clean) === 11 && strpos($clean, '01') === 0) {
            return $clean;
        }
        return '';
    }
}
