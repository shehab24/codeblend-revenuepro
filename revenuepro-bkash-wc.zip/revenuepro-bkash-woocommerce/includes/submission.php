<?php
namespace RevenuePro;

if (!defined('ABSPATH')) {
    exit;
}

class Submission
{
    public static function init()
    {
        $self = new self();
        add_action('init', [$self, 'register_cpt']);
        add_filter('rest_revenuepro_sub_query', [$self, 'filter_by_form_id'], 10, 2);
    }

    public function filter_by_form_id($args, $request)
    {
        if ($request->get_param('form_id')) {
            $args['post_parent'] = absint($request->get_param('form_id'));
        }
        return $args;
    }

    public function register_cpt()
    {
        $labels = [
            'name' => __('Submissions', 'revenuepro-bkash-wc'),
            'singular_name' => __('Submission', 'revenuepro-bkash-wc'),
            'menu_name' => __('Submissions', 'revenuepro-bkash-wc'),
        ];

        $args = [
            'labels' => $labels,
            'public' => false,
            'show_ui' => false,
            'show_in_menu' => false,
            'show_in_rest' => true,
            'capability_type' => 'post',
            'supports' => ['title', 'custom-fields'],
        ];

        register_post_type('revenuepro_sub', $args);

        // Register meta fields for REST API
        register_post_meta('revenuepro_sub', 'form_id', [
            'show_in_rest' => true,
            'single' => true,
            'type' => 'integer',
        ]);

        register_post_meta('revenuepro_sub', 'submission_data', [
            'show_in_rest' => [
                'schema' => [
                    'type' => 'object',
                    'additionalProperties' => true,
                ],
            ],
            'single' => true,
            'type' => 'object',
            'auth_callback' => function() { return true; }
        ]);

        register_post_meta('revenuepro_sub', 'payment_status', [
            'show_in_rest' => true,
            'single' => true,
            'type' => 'string',
        ]);

        register_post_meta('revenuepro_sub', 'bkash_trx_id', [
            'show_in_rest' => true,
            'single' => true,
            'type' => 'string',
        ]);

        register_post_meta('revenuepro_sub', 'payment_failure_reason', [
            'show_in_rest' => true,
            'single' => true,
            'type' => 'string',
        ]);

        register_post_meta('revenuepro_sub', 'donation_amount', [
            'show_in_rest' => true,
            'single' => true,
            'type' => 'number',
        ]);
    }
}
