<?php
namespace RevenuePro\Admin;

if (!defined('ABSPATH')) {
	exit;
}

use RevenuePro\Helper;

class Menu
{

	public static function init()
	{
		$self = new self();
		add_action('admin_menu', array($self, 'admin_menu'));
		add_action('admin_head', array($self, 'add_admin_menu_css'));
	}

	/**
	 * Add admin menu page
	 *
	 * @return void
	 */
	public function admin_menu()
	{
		$icon_url = $this->get_toplevel_menu_icon_url();
		$page_title = $this->get_toplevel_menu_title();
		add_menu_page($page_title, $page_title, 'manage_options', REVENUEPRO_FORM_SLUG, [$this, 'load_main_template'], $icon_url, 50);
		foreach (Helper::get_admin_menu_list() as $item_key => $item) {
			add_submenu_page($item['parent_slug'], $item['title'], $item['title'], $item['capability'], $item_key, [$this, 'load_main_template']);
		}
	}
	public function get_toplevel_menu_icon_url()
	{
		return 'dashicons-chart-line';
	}
	public function load_main_template()
	{
		$preloader_html = apply_filters('revenuepro_bkash_wc/preloader', Helper::get_preloader_html());
		echo '<div id="revenuepro-bkash-wc-wrap" class="revenuepro-bkash-wc-wrap">' . wp_kses_post($preloader_html) . '</div>';
	}
	public function get_toplevel_menu_title()
	{
		return apply_filters('revenuepro_bkash_wc/admin/toplevel_menu_title', __('RevenuePro', 'revenuepro-bkash-wc'));
	}

	function add_admin_menu_css()
	{
		// Get menu list to find hidden items
		$menu_list = Helper::get_admin_menu_list();
		$hidden_pages = [];
		foreach ($menu_list as $key => $item) {
			if (isset($item['hidden']) && $item['hidden']) {
				if ($key === REVENUEPRO_FORM_SLUG . '-get-pro') {
					continue;
				}
				$hidden_pages[] = $key;
			}
		}

		echo '<style>';
		// Hide menu items marked as hidden
		foreach ($hidden_pages as $page) {
			echo '#adminmenu li.toplevel_page_revenuepro-bkash-wc ul.wp-submenu li a[href*="page=' . esc_attr($page) . '"] { display: none !important; }' . "\n";
			echo '#adminmenu li.toplevel_page_revenuepro-bkash-wc ul.wp-submenu li a[href*="page=' . esc_attr($page) . '"] + ul { display: none !important; }' . "\n";
		}
		echo '
			#adminmenu li.toplevel_page_revenuepro-bkash-wc ul li a, #adminmenu li.toplevel_page_revenuepro-bkash-wc .wp-submenu > li > a {
				padding: 7px 12px;
			}

			#adminmenu li.toplevel_page_revenuepro-bkash-wc ul.wp-submenu li {
				clear: both;
			}
			#adminmenu li.toplevel_page_revenuepro-bkash-wc ul.wp-submenu li.wp-first-item a[href^="admin.php?page=revenuepro-bkash-wc"]:after,
			#adminmenu li.toplevel_page_revenuepro-bkash-wc ul.wp-submenu li.wp-first-item a[href*="admin.php?page=revenuepro-bkash-wc"]:after,
			#adminmenu li.toplevel_page_revenuepro-bkash-wc ul.wp-submenu li a[href*="admin.php?page=revenuepro-bkash-wc-tools"]:after,
			#adminmenu li.toplevel_page_revenuepro-bkash-wc ul.wp-submenu li a[href^="admin.php?page=revenuepro-bkash-wc-tools"]:after {
				border-bottom: 1px solid hsla(0,0%,100%,.2);
				display: block;
				float: left;
				margin: 15px -15px 7px;
				content: "";
				width: calc(100% + 26px);
			}
		</style>';

		// Highlight "All Forms" when on create/edit pages

	}
}
