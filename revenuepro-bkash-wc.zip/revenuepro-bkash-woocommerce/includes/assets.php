<?php
namespace RevenuePro;

if (!defined('ABSPATH')) {
	exit;
}


use RevenuePro\Admin\Menu;
use RevenuePro\Helper;

class Assets
{

	public static function init()
	{
		$self = new self();
		add_action('admin_enqueue_scripts', [$self, 'dashboard_scripts'], 10);
		add_action('wp_enqueue_scripts', [$self, 'frontend_scripts']);
	}

	public function frontend_scripts()
	{
		wp_register_style('revenuepro-bkash-wc-css', REVENUEPRO_FORM_ASSETS_URL . 'css/revenuepro-bkash-wc.css', [], REVENUEPRO_VERSION);
		wp_register_script('revenuepro-bkash-wc-js', REVENUEPRO_FORM_ASSETS_URL . 'js/revenuepro-bkash-wc.js', [], REVENUEPRO_VERSION, true);
	}

	public function get_localize_script_data()
	{
		$menu = new Menu();
		return [
			'rest_url' => esc_url_raw(rest_url()),
			'namespace' => REVENUEPRO_FORM_SLUG . '/v1/',
			'plugin_root_url' => REVENUEPRO_FORM_ROOT_URL,
			'plugin_root_path' => REVENUEPRO_FORM_ROOT_DIR_PATH,
			'admin_url' => admin_url(),
			'site_url' => site_url(),
			'route_path' => wp_parse_url(admin_url(), PHP_URL_PATH),
			'ajax_url' => esc_url(admin_url('admin-ajax.php')),
			'menu' => wp_json_encode(Helper::get_admin_menu_list()),
			'nonce' => wp_create_nonce('wp_rest'),
			'revenuepro_bkash_wc_nonce' => wp_create_nonce('revenuepro_bkash_wc_nonce'),
			'toplevel_menu_icon_url' => $menu->get_toplevel_menu_icon_url(),
			'is_pro' => false,
			'server_ip' => \RevenuePro\Sms::get_server_ip(),
			'api_base_url' => defined('REVENUEPRO_API_BASE_URL') ? REVENUEPRO_API_BASE_URL : 'http://localhost:3000',
			'wc_order_statuses' => function_exists('wc_get_order_statuses') ? wc_get_order_statuses() : [],
		];
	}

	public function dashboard_scripts($hook)
	{
		global $post_type;
		if (strpos($hook, '_page_' . REVENUEPRO_FORM_SLUG) !== false || 'revenuepro_bkash_wc' === $post_type) {
			// Remove Notices
			remove_all_actions('admin_notices');
			// dequeue third party plugin assets
			// add_action(
			// 	'wp_print_scripts',
			// 	function () {
			// 		$isSkip = apply_filters( 'revenuepro_bkash_wc/skip_no_conflict_backend_scripts', Helper::is_dev_mode_enable() );

			// 		if ( $isSkip ) {
			// 			return;
			// 		}

			// 		global $wp_scripts;
			// 		if ( ! $wp_scripts ) {
			// 			return;
			// 		}

			// 		$pluginUrl = plugins_url();
			// 		foreach ( $wp_scripts->queue as $script ) {
			// 			$src = $wp_scripts->registered[ $script ]->src;
			// 			if ( strpos( $src, $pluginUrl ) !== false && ! strpos( $src, ABLOCKS_PLUGIN_SLUG ) !== false ) {
			// 				wp_dequeue_script( $wp_scripts->registered[ $script ]->handle );
			// 			}
			// 		}
			// 	},
			// 	1
			// );

			wp_enqueue_media();
			wp_enqueue_style('revenuepro-bkash-wc-dashboard-style', REVENUEPRO_FORM_ASSETS_URL . 'build/dashboard.css', array('wp-components'), filemtime(REVENUEPRO_FORM_ASSETS_PATH . 'build/dashboard.css'), 'all');

			$dependencies = include REVENUEPRO_FORM_ASSETS_PATH . 'build/dashboard.asset.php';
			wp_enqueue_script(
				'revenuepro-bkash-wc-dashboard-scripts',
				REVENUEPRO_FORM_ASSETS_URL . 'build/dashboard.js',
				$dependencies['dependencies'],
				$dependencies['version'],
				true
			);
			wp_localize_script('revenuepro-bkash-wc-dashboard-scripts', 'RevenueProGlobal', $this->get_localize_script_data());
			wp_set_script_translations('revenuepro-bkash-wc-dashboard-scripts', 'revenuepro-bkash-wc', REVENUEPRO_FORM_ROOT_DIR_PATH . 'languages');
		}//end if
	}



}
