<?php
namespace RevenuePro;

if (!defined('ABSPATH')) {
    exit;
}

class AbandonedCartRecovery
{
    public static function init()
    {
        add_action('init', [__CLASS__, 'handle_recovery_link']);
    }

    public static function handle_recovery_link()
    {
        if (empty($_GET['rp_recover_cart'])) {
            return;
        }

        $session_id = sanitize_text_field($_GET['rp_recover_cart']);
        $cart = AbandonedCartDB::get_cart_by_session($session_id);

        // Allow recovering abandoned carts too
        if (!$cart) {
            global $wpdb;
            $table_name = AbandonedCartDB::get_table_name();
            $cart = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM $table_name WHERE session_id = %s order by id desc limit 1",
                $session_id
            ));
        }

        if (!$cart) {
            wc_add_notice('Invalid recovery link or cart expired.', 'error');
            wp_redirect(wc_get_page_permalink('shop'));
            exit;
        }

        // Restore Cart
        if (function_exists('WC') && WC()->cart) {
            WC()->cart->empty_cart();
            
            $cart_items = json_decode($cart->cart_contents, true);
            if (is_array($cart_items)) {
                foreach ($cart_items as $item) {
                    $product_id = $item['product_id'];
                    $variation_id = $item['variation_id'];
                    $quantity = $item['quantity'];
                    
                    WC()->cart->add_to_cart($product_id, $quantity, $variation_id);
                }
            }
            
            // Restore customer data if needed (optional)
            // We can pre-fill checkout fields by setting session data possibly
            
            wc_add_notice('Your cart has been restored successfully.', 'success');
            wp_redirect(wc_get_checkout_url());
            exit;
        }
    }
}
