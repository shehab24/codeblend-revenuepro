<?php
namespace RevenuePro;

if (!defined('ABSPATH')) {
    exit;
}

class CourierManager
{
    private $settings;

    public function __construct()
    {
        $this->settings = get_option('revenuepro_bkash_wc_settings', []);
    }

    public static function init()
    {
        $self = new self();

        // Auto dispatch hook (only when automation is enabled)
        if (!empty($self->settings['courier_auto_dispatch'])) {
            $trigger = $self->settings['courier_trigger_status'] ?? 'ready-to-ship';
            add_action('woocommerce_order_status_' . $trigger, [$self, 'auto_dispatch'], 10, 1);
        }

        // Manual dispatch buttons on the orders list
        add_action('admin_head', [$self, 'inject_courier_button_css']);
        add_filter('woocommerce_admin_order_actions', [$self, 'add_manual_dispatch_buttons'], 10, 2);
        add_action('wp_ajax_revenuepro_courier_dispatch', [$self, 'handle_manual_dispatch']);

        // Ensure the Actions column is visible by default in the orders screen
        add_filter('default_hidden_columns', [$self, 'ensure_order_actions_visible'], 10, 2);

        // Send WooCommerce "Processing Order" email when status changes to Ready to Ship
        add_action('woocommerce_order_status_ready-to-ship', function($order_id) {
            $order = wc_get_order($order_id);
            if ($order) {
                $mailer = WC()->mailer();
                $mails  = $mailer->get_emails();
                if (!empty($mails['WC_Email_Customer_Processing_Order'])) {
                    $mails['WC_Email_Customer_Processing_Order']->trigger($order_id, $order);
                }
            }
        }, 10, 1);

        // Register custom "Ready to Ship" order status
        add_action('init', function() {
            register_post_status('wc-ready-to-ship', array(
                'label'                     => 'Ready to Ship',
                'public'                    => true,
                'show_in_admin_status_list' => true,
                'show_in_admin_all_list'    => true,
                'exclude_from_search'       => false,
                'label_count'               => _n_noop('Ready to Ship <span class="count">(%s)</span>', 'Ready to Ship <span class="count">(%s)</span>')
            ));
        });

        add_filter('wc_order_statuses', function($order_statuses) {
            $new_order_statuses = array();
            // Inject right after processing
            foreach ($order_statuses as $key => $status) {
                $new_order_statuses[$key] = $status;
                if ('wc-processing' === $key) {
                    $new_order_statuses['wc-ready-to-ship'] = 'Ready to Ship';
                }
            }
            return $new_order_statuses; // If processing is missing, it will just drop it, so adding fallback
        });
    }

    /**
     * Helper to write logs to WooCommerce Status => Logs
     */
    private function log($message, $level = 'info')
    {
        \RevenuePro\Logger::log($message, $level);
    }

    /**
     * Dispatch a WooCommerce order to Steadfast Courier
     */
    public function dispatch_to_steadfast($order_id)
    {
        $this->settings = get_option('revenuepro_bkash_wc_settings', []);
        $this->log("Triggered Steadfast dispatch for Order #{$order_id}");

        // Check if Steadfast is enabled
        if (empty($this->settings['courier_steadfast_enabled'])) {
            $this->log("Steadfast integration is disabled in settings. Aborting.", "warning");
            return;
        }

        $api_key    = $this->settings['courier_steadfast_api_key'] ?? '';
        $secret_key = $this->settings['courier_steadfast_secret_key'] ?? '';

        if (empty($api_key) || empty($secret_key)) {
            $this->log("Steadfast API credentials missing. Aborting.", "error");
            $this->add_order_note($order_id, '❌ Steadfast dispatch failed: API credentials missing.');
            return;
        }

        $order = wc_get_order($order_id);
        if (!$order) {
            $this->log("Could not retrieve Order #{$order_id}.", "error");
            return;
        }

        // Prevent double dispatch
        if ($order->get_meta('_steadfast_consignment_id')) {
            $this->log("Order #{$order_id} already dispatched (Consignment ID exists). Aborting.", "warning");
            return;
        }

        // Build recipient data
        $recipient_name = trim($order->get_billing_first_name() . ' ' . $order->get_billing_last_name());
        $recipient_phone = $order->get_billing_phone();
        
        // Build address
        $address_parts = array_filter([
            $order->get_billing_address_1(),
            $order->get_billing_address_2(),
            $order->get_billing_city(),
            $order->get_billing_state(),
            $order->get_billing_postcode()
        ]);
        $recipient_address = implode(', ', $address_parts);

        // COD amount: if payment method is COD, send order total; otherwise 0
        $payment_method = $order->get_payment_method();
        $cod_amount = ($payment_method === 'cod') ? $order->get_total() : 0;

        // Build item description from product names
        $items = [];
        foreach ($order->get_items() as $item) {
            $items[] = $item->get_name() . ' x' . $item->get_quantity();
        }
        $item_description = implode(', ', $items);

        // Customer note
        $note = $order->get_customer_note();

        // Prepare payload
        $payload = [
            'invoice'           => strval($order_id),
            'recipient_name'    => $recipient_name,
            'recipient_phone'   => $this->normalize_phone($recipient_phone),
            'recipient_address' => $recipient_address,
            'cod_amount'        => floatval($cod_amount),
            'note'              => $note ?: '',
            'item_description'  => $item_description,
        ];
        
        $this->log("Payload built for Order #{$order_id}: " . print_r($payload, true));

        // Send to Steadfast API
        $base_url = 'https://portal.packzy.com/api/v1';
        $response = wp_remote_post($base_url . '/create_order', [
            'timeout' => 30,
            'headers' => [
                'Api-Key'      => $api_key,
                'Secret-Key'   => $secret_key,
                'Content-Type' => 'application/json',
            ],
            'body' => wp_json_encode($payload),
        ]);

        if (is_wp_error($response)) {
            $err = $response->get_error_message();
            $this->log("wp_remote_post failed for Order #{$order_id}: {$err}", "error");
            $this->add_order_note($order_id, '❌ Steadfast dispatch failed: ' . $err);
            return;
        }

        $status_code = wp_remote_retrieve_response_code($response);
        $raw_body = wp_remote_retrieve_body($response);
        $this->log("API Response for Order #{$order_id} (HTTP {$status_code}): {$raw_body}");
        
        $body = json_decode($raw_body, true);

        if ($status_code === 200 && isset($body['consignment'])) {
            $consignment = $body['consignment'];
            
            // Save meta data to order
            $order->update_meta_data('_steadfast_consignment_id', $consignment['consignment_id']);
            $order->update_meta_data('_steadfast_tracking_code', $consignment['tracking_code']);
            $order->update_meta_data('_steadfast_status', $consignment['status']);
            $order->save();

            $this->add_order_note(
                $order_id,
                sprintf(
                    '✅ Sent to Steadfast Courier — Consignment ID: %s | Tracking Code: %s | Status: %s',
                    $consignment['consignment_id'],
                    $consignment['tracking_code'],
                    $consignment['status']
                )
            );
            $this->log("Order #{$order_id} successfully mapped to Consignment {$consignment['consignment_id']}.");
        } else {
            $error_msg = isset($body['errors']) ? wp_json_encode($body['errors']) : (isset($body['message']) ? $body['message'] : 'Unknown error');
            $this->log("Steadfast mapping failed for Order #{$order_id}. Error: {$error_msg}", "error");
            $this->add_order_note($order_id, '❌ Steadfast dispatch failed (HTTP ' . $status_code . '): ' . $error_msg);
        }
    }

    /**
     * Normalize BD phone number to 11 digits
     */
    private function normalize_phone($phone)
    {
        $clean = preg_replace('/[^0-9]/', '', $phone);
        if (strpos($clean, '8801') === 0) {
            $clean = substr($clean, 2);
        }
        return $clean;
    }

    /**
     * Add a note to the WooCommerce order
     */
    private function add_order_note($order_id, $message)
    {
        $order = wc_get_order($order_id);
        if ($order) {
            $order->add_order_note($message);
        }
    }

    /**
     * Issue or retrieve cached Pathao access token
     */
    private function issue_pathao_token()
    {
        $access_token = get_option('_revenuepro_pathao_access_token');
        if (!empty($access_token)) {
            return $access_token;
        }

        $client_id = $this->settings['courier_pathao_client_id'] ?? '';
        $client_secret = $this->settings['courier_pathao_client_secret'] ?? '';
        $username = $this->settings['courier_pathao_username'] ?? '';
        $password = $this->settings['courier_pathao_password'] ?? '';

        if (empty($client_id) || empty($client_secret) || empty($username) || empty($password)) {
            $this->log("Pathao token issuance failed: missing credentials.", "error");
            return false;
        }

        $base_url = 'https://api-hermes.pathao.com';
        
        $this->log("Issuing new Pathao token via {$base_url}/aladdin/api/v1/issue-token.");
        
        $payload = [
            'client_id'     => $client_id,
            'client_secret' => $client_secret,
            'username'      => $username,
            'password'      => $password,
            'grant_type'    => 'password',
        ];

        $response = wp_remote_post("{$base_url}/aladdin/api/v1/issue-token", [
            'timeout' => 30,
            'headers' => ['Content-Type' => 'application/json'],
            'body'    => wp_json_encode($payload),
        ]);

        if (is_wp_error($response)) {
            $this->log("Pathao token issuance request failed: " . $response->get_error_message(), "error");
            return false;
        }

        $status = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);

        if ($status === 200 && !empty($body['access_token'])) {
            // Cache token for a bit less than the expiry time
            update_option('_revenuepro_pathao_access_token', $body['access_token']);
            update_option('_revenuepro_pathao_refresh_token', $body['refresh_token']);
            return $body['access_token'];
        }

        $this->log("Pathao token generation failed (HTTP {$status}): " . wp_json_encode($body), "error");
        return false;
    }

    /**
     * Dispatch a WooCommerce order to Pathao Courier
     */
    public function dispatch_to_pathao($order_id)
    {
        $this->settings = get_option('revenuepro_bkash_wc_settings', []);
        
        if (empty($this->settings['courier_pathao_enabled'])) {
            return;
        }

        $this->log("Triggered Pathao dispatch for Order #{$order_id}");

        $store_id = $this->settings['courier_pathao_store_id'] ?? '';
        if (empty($store_id)) {
            $this->log("Pathao Store ID missing. Aborting.", "error");
            $this->add_order_note($order_id, '❌ Pathao dispatch failed: Store ID missing.');
            return;
        }

        $order = wc_get_order($order_id);
        if (!$order) return;

        if ($order->get_meta('_pathao_consignment_id')) {
            $this->log("Order #{$order_id} already dispatched to Pathao. Aborting.", "warning");
            return;
        }

        $token = $this->issue_pathao_token();
        if (!$token) {
            $this->add_order_note($order_id, '❌ Pathao dispatch failed: Could not obtain access token.');
            return;
        }

        $recipient_name = trim($order->get_billing_first_name() . ' ' . $order->get_billing_last_name());
        $recipient_phone = $this->normalize_phone($order->get_billing_phone());

        $address_parts = array_filter([
            $order->get_billing_address_1(),
            $order->get_billing_address_2(),
            $order->get_billing_city(),
            $order->get_billing_state()
        ]);
        $recipient_address = implode(', ', $address_parts);

        $payment_method = $order->get_payment_method();
        $amount_to_collect = ($payment_method === 'cod') ? intval(round($order->get_total())) : 0;

        $items = [];
        foreach ($order->get_items() as $item) {
            $items[] = $item->get_name() . ' x' . $item->get_quantity();
        }
        $item_description = implode(', ', $items);

        $payload = [
            'store_id'            => intval($store_id),
            'merchant_order_id'   => strval($order_id),
            'recipient_name'      => $recipient_name,
            'recipient_phone'     => $recipient_phone,
            'recipient_address'   => $recipient_address,
            'recipient_city'      => 1,
            'recipient_zone'      => 1,
            'recipient_area'      => 1,
            'delivery_type'       => 48, // 48 for normal delivery
            'item_type'           => 2, // 2 for parcel
            'special_instruction' => $order->get_customer_note() ?: '',
            'item_quantity'       => 1,
            'item_weight'         => 0.5,
            'item_description'    => $item_description,
            'amount_to_collect'   => $amount_to_collect
        ];

        $this->log("Pathao payload built for Order #{$order_id}: " . print_r($payload, true));

        $base_url = 'https://api-hermes.pathao.com';
        
        $response = wp_remote_post("{$base_url}/aladdin/api/v1/orders", [
            'timeout' => 30,
            'headers' => [
                'Authorization' => 'Bearer ' . $token,
                'Content-Type'  => 'application/json',
                'Accept'        => 'application/json',
            ],
            'body' => wp_json_encode($payload),
        ]);

        if (is_wp_error($response)) {
            $err = $response->get_error_message();
            $this->log("wp_remote_post failed for Pathao Order #{$order_id}: {$err}", "error");
            $this->add_order_note($order_id, '❌ Pathao dispatch failed: ' . $err);
            return;
        }

        $status_code = wp_remote_retrieve_response_code($response);
        $raw_body = wp_remote_retrieve_body($response);
        $this->log("Pathao API Response for Order #{$order_id} (HTTP {$status_code}): {$raw_body}");
        
        $body = json_decode($raw_body, true);

        // Pathao returns type 'error' if it fails, or sets consignment_id directly in 'data'
        if ($status_code === 200 && isset($body['data']['consignment_id'])) {
            $consignment_id = $body['data']['consignment_id'];
            
            $order->update_meta_data('_pathao_consignment_id', $consignment_id);
            if (isset($body['data']['delivery_fee'])) {
                 $order->update_meta_data('_pathao_delivery_fee', $body['data']['delivery_fee']);
            }
            $order->save();

            $this->add_order_note($order_id, "✅ Sent to Pathao Courier — Consignment ID: {$consignment_id}");
            $this->log("Order #{$order_id} successfully mapped to Pathao Consignment {$consignment_id}.");
        } else {
            // Check if it's an unauthorized token error, clear caching!
            if ($status_code === 401) {
                delete_option('_revenuepro_pathao_access_token');
            }
            
            $error_msg = isset($body['errors']) ? wp_json_encode($body['errors']) : (isset($body['message']) ? $body['message'] : 'Unknown error');
            $this->log("Pathao mapping failed for Order #{$order_id}. Error: {$error_msg}", "error");
            $this->add_order_note($order_id, "❌ Pathao dispatch failed (HTTP {$status_code}): {$error_msg}");
        }
    }

    /**
     * Auto Dispatch (Triggered by Order Status)
     */
    public function auto_dispatch($order_id)
    {
        $this->settings = get_option('revenuepro_bkash_wc_settings', []);
        $default = $this->settings['courier_default'] ?? 'steadfast';
        if ($default === 'pathao') {
            $this->dispatch_to_pathao($order_id);
        } else {
            $this->dispatch_to_steadfast($order_id);
        }
    }

    /**
     * Ensure the Actions column is not hidden by default on the orders screen.
     */
    public function ensure_order_actions_visible($hidden, $screen)
    {
        if (isset($screen->id) && in_array($screen->id, ['edit-shop_order', 'woocommerce_page_wc-orders'])) {
            $this->settings = get_option('revenuepro_bkash_wc_settings', []);
            $any_enabled = !empty($this->settings['courier_steadfast_enabled']) || !empty($this->settings['courier_pathao_enabled']);

            if ($any_enabled) {
                // Remove from hidden so column is shown
                $hidden = array_diff($hidden, ['wc_actions']);
            } else {
                // Add to hidden so column is unticket by default
                if (!in_array('wc_actions', $hidden)) {
                    $hidden[] = 'wc_actions';
                }
            }
        }
        return $hidden;
    }

    /**
     * Inject inline CSS for order column action buttons
     */
    public function inject_courier_button_css()
    {
        echo '<style>
            .wc-action-button-steadfast::after { font-family: dashicons; content: "\f538" !important; }
            .wc-action-button-pathao::after    { font-family: dashicons; content: "\f226" !important; }
            /* Sent (already dispatched) state */
            .wc-action-button-steadfast-sent { background: #16a34a !important; border-color: #16a34a !important; }
            .wc-action-button-steadfast-sent::after { font-family: dashicons; content: "\f147" !important; color: #fff !important; }
            .wc-action-button-pathao-sent    { background: #16a34a !important; border-color: #16a34a !important; }
            .wc-action-button-pathao-sent::after    { font-family: dashicons; content: "\f147" !important; color: #fff !important; }
        </style>';
    }

    /**
     * Add manual dispatch buttons to the Orders list
     */
    public function add_manual_dispatch_buttons($actions, $order)
    {
        $this->settings = get_option('revenuepro_bkash_wc_settings', []);
        $order_id = $order->get_id();

        if (!empty($this->settings['courier_steadfast_enabled'])) {
            $already_sent = (bool) $order->get_meta('_steadfast_consignment_id');
            $actions['steadfast'] = array(
                'url'    => $already_sent ? '#' : wp_nonce_url(admin_url('admin-ajax.php?action=revenuepro_courier_dispatch&courier=steadfast&order_id=' . $order_id), 'revenuepro_courier_dispatch'),
                'name'   => $already_sent ? __('Sent to Steadfast ✓', 'revenuepro-bkash-wc') : __('Send to Steadfast', 'revenuepro-bkash-wc'),
                'action' => $already_sent ? 'steadfast-sent' : 'steadfast',
            );
        }

        if (!empty($this->settings['courier_pathao_enabled'])) {
            $already_sent = (bool) $order->get_meta('_pathao_consignment_id');
            $actions['pathao'] = array(
                'url'    => $already_sent ? '#' : wp_nonce_url(admin_url('admin-ajax.php?action=revenuepro_courier_dispatch&courier=pathao&order_id=' . $order_id), 'revenuepro_courier_dispatch'),
                'name'   => $already_sent ? __('Sent to Pathao ✓', 'revenuepro-bkash-wc') : __('Send to Pathao', 'revenuepro-bkash-wc'),
                'action' => $already_sent ? 'pathao-sent' : 'pathao',
            );
        }

        return $actions;
    }

    /**
     * Handle Manual Dispatch Clicks
     */
    public function handle_manual_dispatch()
    {
        check_ajax_referer('revenuepro_courier_dispatch', '_wpnonce');
        if (!current_user_can('manage_woocommerce')) {
            wp_die('Unauthorized');
        }
        
        $order_id = isset($_GET['order_id']) ? intval($_GET['order_id']) : 0;
        $courier = isset($_GET['courier']) ? sanitize_text_field($_GET['courier']) : '';

        if ($order_id && $courier) {
            if ($courier === 'steadfast') {
                $this->dispatch_to_steadfast($order_id);
            } elseif ($courier === 'pathao') {
                $this->dispatch_to_pathao($order_id);
            }
        }
        
        wp_safe_redirect(wp_get_referer() ? wp_get_referer() : admin_url('edit.php?post_type=shop_order'));
        exit;
    }

    /**
     * Generate or retrieve webhook auth token for Steadfast
     */
    public static function get_webhook_token()
    {
        $token = get_option('_revenuepro_steadfast_webhook_token', '');
        if (empty($token)) {
            $token = wp_generate_password(48, false, false);
            update_option('_revenuepro_steadfast_webhook_token', $token);
        }
        return $token;
    }

    /**
     * Regenerate webhook auth token
     */
    public static function regenerate_webhook_token()
    {
        $token = wp_generate_password(48, false, false);
        update_option('_revenuepro_steadfast_webhook_token', $token);
        return $token;
    }

    /**
     * Handle incoming Steadfast Webhook POST requests
     * 
     * Notification types: delivery_status, tracking_update
     */
    public function handle_steadfast_webhook($request)
    {
        $this->settings = get_option('revenuepro_bkash_wc_settings', []);

        // Verify Bearer token
        $auth_header = $request->get_header('Authorization');
        $expected_token = self::get_webhook_token();

        if (empty($auth_header) || $auth_header !== 'Bearer ' . $expected_token) {
            $this->log('Steadfast webhook rejected: invalid or missing Authorization header.', 'error');
            return new \WP_REST_Response([
                'status'  => 'error',
                'message' => 'Unauthorized. Invalid Bearer token.',
            ], 401);
        }

        $body = $request->get_json_params();

        if (empty($body) || empty($body['notification_type'])) {
            $this->log('Steadfast webhook received empty or malformed payload.', 'error');
            return new \WP_REST_Response([
                'status'  => 'error',
                'message' => 'Invalid payload. Missing notification_type.',
            ], 400);
        }

        $type = sanitize_text_field($body['notification_type']);
        $invoice = isset($body['invoice']) ? sanitize_text_field($body['invoice']) : '';
        $consignment_id = isset($body['consignment_id']) ? intval($body['consignment_id']) : 0;

        $this->log("Steadfast Webhook received: type={$type}, invoice={$invoice}, consignment_id={$consignment_id}");

        // Find the WooCommerce order by invoice (which is the order ID)
        $order = null;
        if (!empty($invoice)) {
            $order = wc_get_order($invoice);
        }

        // Fallback: search by consignment_id meta
        if (!$order && $consignment_id) {
            $orders = wc_get_orders([
                'meta_key'   => '_steadfast_consignment_id',
                'meta_value' => $consignment_id,
                'limit'      => 1,
            ]);
            $order = !empty($orders) ? $orders[0] : null;
        }

        if (!$order) {
            $this->log("Steadfast webhook: Could not find order for invoice={$invoice}, consignment_id={$consignment_id}", 'warning');
            return new \WP_REST_Response([
                'status'  => 'error',
                'message' => 'Order not found.',
            ], 404);
        }

        $order_id = $order->get_id();

        switch ($type) {
            case 'delivery_status':
                $this->process_delivery_status($order, $body);
                break;

            case 'tracking_update':
                $this->process_tracking_update($order, $body);
                break;

            default:
                $this->log("Steadfast webhook: Unknown notification_type '{$type}' for Order #{$order_id}.", 'warning');
                break;
        }

        return new \WP_REST_Response([
            'status'  => 'success',
            'message' => 'Webhook received successfully.',
        ], 200);
    }

    /**
     * Process delivery_status webhook from Steadfast
     */
    private function process_delivery_status($order, $data)
    {
        $order_id = $order->get_id();
        $status = isset($data['status']) ? strtolower(sanitize_text_field($data['status'])) : '';
        $tracking_message = isset($data['tracking_message']) ? sanitize_text_field($data['tracking_message']) : '';
        $cod_amount = isset($data['cod_amount']) ? floatval($data['cod_amount']) : 0;
        $delivery_charge = isset($data['delivery_charge']) ? floatval($data['delivery_charge']) : 0;

        $this->log("Processing delivery_status for Order #{$order_id}: status={$status}");

        // Update Steadfast meta
        $order->update_meta_data('_steadfast_status', $status);
        if ($delivery_charge > 0) {
            $order->update_meta_data('_steadfast_delivery_charge', $delivery_charge);
        }

        // Add order note with details
        $note = sprintf(
            '📦 Steadfast Status Update: %s | COD: ৳%s | Delivery Charge: ৳%s',
            ucfirst($status),
            number_format($cod_amount, 2),
            number_format($delivery_charge, 2)
        );
        if (!empty($tracking_message)) {
            $note .= ' | ' . $tracking_message;
        }
        $order->add_order_note($note);

        // Map Steadfast status to WooCommerce order status
        $status_map = [
            'delivered'                          => 'completed',
            'delivered_approval_pending'         => 'completed',
            'partial_delivered'                  => 'completed',
            'partial_delivered_approval_pending' => 'completed',
            'cancelled'                          => 'cancelled',
            'cancelled_approval_pending'         => 'cancelled',
            'returned'                           => 'cancelled',
            'return'                             => 'cancelled',
            'hold'                               => 'on-hold',
        ];

        if (isset($status_map[$status])) {
            $wc_status = $status_map[$status];
            $current_status = $order->get_status();
            if ($current_status !== $wc_status) {
                $order->update_status($wc_status, sprintf(
                    __('Order auto-updated to "%s" via Steadfast webhook.', 'revenuepro-bkash-wc'),
                    $wc_status
                ));
                $this->log("Order #{$order_id} status updated to '{$wc_status}' via Steadfast webhook.");
            }
        }

        $order->save();
    }

    /**
     * Process tracking_update webhook from Steadfast
     */
    private function process_tracking_update($order, $data)
    {
        $order_id = $order->get_id();
        $tracking_message = isset($data['tracking_message']) ? sanitize_text_field($data['tracking_message']) : '';
        $updated_at = isset($data['updated_at']) ? sanitize_text_field($data['updated_at']) : '';

        $this->log("Processing tracking_update for Order #{$order_id}: {$tracking_message}");

        // Add as order note
        $note = '📍 Steadfast Tracking: ' . $tracking_message;
        if (!empty($updated_at)) {
            $note .= ' (' . $updated_at . ')';
        }
        $order->add_order_note($note);
    }
}

