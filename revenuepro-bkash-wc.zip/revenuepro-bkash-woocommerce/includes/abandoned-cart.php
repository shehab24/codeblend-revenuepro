<?php
namespace RevenuePro;

if (!defined('ABSPATH')) {
    exit;
}

class AbandonedCart
{
    public static function init()
    {
        // Initialize Components
        if (is_admin()) {
            AbandonedCartAdmin::init();
        }

        AbandonedCartTracker::init();
        AbandonedCartRecovery::init();
        AbandonedCartEmail::init();
    }
}
