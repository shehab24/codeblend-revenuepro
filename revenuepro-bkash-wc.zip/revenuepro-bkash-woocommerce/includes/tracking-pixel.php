<?php
namespace RevenuePro;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Tracking & Pixel Manager
 * Handles Meta (Facebook) Pixel, Conversions API, Google Analytics 4, and Google Ads.
 */
class TrackingPixel
{
    private static $settings = null;

    public static function init()
    {
        self::$settings = get_option('revenuepro_bkash_wc_settings', []);

        $trigger = self::get('tracking_purchase_trigger', 'checkout');

        // Browser-side pixel injection
        add_action('wp_head', [__CLASS__, 'inject_pixel_scripts'], 1);
        add_action('wp_footer', [__CLASS__, 'inject_event_scripts'], 99);

        // Server-side Conversions API AddToCart
        add_action('woocommerce_add_to_cart', [__CLASS__, 'server_add_to_cart_event'], 10, 6);

        // ALWAYS fire Server-side Conversions API Purchase on Checkout if Purchase event is enabled
        add_action('woocommerce_thankyou', [__CLASS__, 'server_purchase_event'], 10, 1);

        // ALWAYS fire Custom Status event if enabled via the legacy trigger setting
        if ($trigger === 'order_status' || $trigger === 'completed') {
            $status_trigger = self::get('tracking_purchase_status_trigger', 'wc-completed');
            $status_slug = str_replace('wc-', '', $status_trigger); // woocommerce hooks omit the 'wc-' prefix
            add_action("woocommerce_order_status_{$status_slug}", [__CLASS__, 'server_custom_status_event'], 10, 1);
        }
    }

    /**
     * Get a setting value with a default fallback.
     */
    private static function get($key, $default = '')
    {
        return isset(self::$settings[$key]) ? self::$settings[$key] : $default;
    }

    private static function is_enabled($key)
    {
        $val = self::get($key, false);
        return $val === true || $val === 'true' || $val === '1' || $val === 1;
    }

    /**
     * Inject base pixel scripts into <head>
     */
    public static function inject_pixel_scripts()
    {
        $fb_enabled = self::is_enabled('tracking_fb_pixel_enabled');
        $ga_enabled = self::is_enabled('tracking_google_analytics_enabled');
        $gads_enabled = self::is_enabled('tracking_google_ads_enabled');

        if (!$fb_enabled && !$ga_enabled && !$gads_enabled) {
            return;
        }

        echo "\n<!-- RevenuePro Tracking & Pixel -->\n";

        // === Domain Verification ===
        $domain_verification = trim(self::get('tracking_fb_domain_verification'));
        if (!empty($domain_verification)) {
            // Handle both raw hash or full meta tag safely
            if (strpos($domain_verification, '<meta') !== false) {
                echo wp_kses($domain_verification, ['meta' => ['name' => [], 'content' => []]]) . "\n";
            } else {
                echo "<meta name=\"facebook-domain-verification\" content=\"" . esc_attr($domain_verification) . "\" />\n";
            }
        }

        // === Meta (Facebook) Pixel Base Code ===
        if ($fb_enabled) {
            $pixel_id = esc_attr(self::get('tracking_fb_pixel_id'));
            if (!empty($pixel_id)) {
                ?>
<script>
!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
document,'script','https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '<?php echo $pixel_id; ?>');
<?php if (self::is_enabled('tracking_events_page_view')): ?>
fbq('track', 'PageView');
<?php endif; ?>
</script>
<noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=<?php echo $pixel_id; ?>&ev=PageView&noscript=1"/></noscript>
                <?php
            }
        }

        // === Google Analytics 4 (gtag.js) ===
        if ($ga_enabled) {
            $ga_id = esc_attr(self::get('tracking_google_analytics_id'));
            if (!empty($ga_id)) {
                ?>
<script async src="https://www.googletagmanager.com/gtag/js?id=<?php echo $ga_id; ?>"></script>
<script>
window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}
gtag('js', new Date());
gtag('config', '<?php echo $ga_id; ?>');
<?php
                // Also configure Google Ads if enabled
                if ($gads_enabled) {
                    $gads_id = esc_attr(self::get('tracking_google_ads_id'));
                    if (!empty($gads_id)) {
                        echo "gtag('config', '" . $gads_id . "');\n";
                    }
                }
?>
</script>
                <?php
            }
        } elseif ($gads_enabled) {
            // Google Ads standalone (without GA4)
            $gads_id = esc_attr(self::get('tracking_google_ads_id'));
            if (!empty($gads_id)) {
                ?>
<script async src="https://www.googletagmanager.com/gtag/js?id=<?php echo $gads_id; ?>"></script>
<script>
window.dataLayer = window.dataLayer || [];
function gtag(){dataLayer.push(arguments);}
gtag('js', new Date());
gtag('config', '<?php echo $gads_id; ?>');
</script>
                <?php
            }
        }

        echo "<!-- /RevenuePro Tracking & Pixel -->\n";
    }

    /**
     * Inject WooCommerce event-specific scripts into the footer
     */
    public static function inject_event_scripts()
    {
        if (!self::is_enabled('tracking_fb_pixel_enabled') && !self::is_enabled('tracking_google_analytics_enabled')) {
            return;
        }

        $pixel_id = esc_attr(self::get('tracking_fb_pixel_id'));
        $ga_id = esc_attr(self::get('tracking_google_analytics_id'));
        $fb_enabled = self::is_enabled('tracking_fb_pixel_enabled') && !empty($pixel_id);
        $ga_enabled = self::is_enabled('tracking_google_analytics_enabled') && !empty($ga_id);

        echo "\n<script>/* RevenuePro Event Tracking */\n";

        // ViewContent — Single product page
        if (is_singular('product') && self::is_enabled('tracking_events_view_content')) {
            global $product;
            if ($product) {
                $product_data = [
                    'content_name' => $product->get_name(),
                    'content_ids' => [$product->get_id()],
                    'content_type' => 'product',
                    'value' => (float) $product->get_price(),
                    'currency' => get_woocommerce_currency(),
                ];
                if ($fb_enabled) {
                    echo "fbq('track', 'ViewContent', " . wp_json_encode($product_data) . ");\n";
                }
                if ($ga_enabled) {
                    echo "gtag('event', 'view_item', {currency: '" . get_woocommerce_currency() . "', value: " . (float)$product->get_price() . ", items: [{item_id: '" . $product->get_id() . "', item_name: '" . esc_js($product->get_name()) . "'}]});\n";
                }
            }
        }

        // InitiateCheckout — Checkout page
        if (function_exists('is_checkout') && is_checkout() && !is_order_received_page() && self::is_enabled('tracking_events_initiate_checkout')) {
            $cart = WC()->cart;
            if ($cart) {
                $checkout_data = [
                    'value' => (float) $cart->get_cart_contents_total(),
                    'currency' => get_woocommerce_currency(),
                    'num_items' => $cart->get_cart_contents_count(),
                ];
                if ($fb_enabled) {
                    echo "fbq('track', 'InitiateCheckout', " . wp_json_encode($checkout_data) . ");\n";
                }
                if ($ga_enabled) {
                    echo "gtag('event', 'begin_checkout', {currency: '" . get_woocommerce_currency() . "', value: " . (float)$cart->get_cart_contents_total() . "});\n";
                }
            }
        }

        // Purchase — Thank you page (Always fire if Purchase tracking is enabled)
        if (function_exists('is_order_received_page') && is_order_received_page() && self::is_enabled('tracking_events_purchase')) {
            global $wp;
            $order_id = isset($wp->query_vars['order-received']) ? absint($wp->query_vars['order-received']) : 0;
            if ($order_id) {
                $order = wc_get_order($order_id);
                if ($order && !$order->get_meta('_revenuepro_pixel_tracked')) {
                    $purchase_data = [
                        'value' => (float) $order->get_total(),
                        'currency' => $order->get_currency(),
                        'content_type' => 'product',
                        'contents' => [],
                    ];
                    $ga_items = [];
                    foreach ($order->get_items() as $item) {
                        $purchase_data['contents'][] = [
                            'id' => $item->get_product_id(),
                            'quantity' => $item->get_quantity(),
                        ];
                        $ga_items[] = [
                            'item_id' => $item->get_product_id(),
                            'item_name' => $item->get_name(),
                            'quantity' => $item->get_quantity(),
                            'price' => (float) $item->get_total(),
                        ];
                    }

                    if ($fb_enabled) {
                        echo "fbq('track', 'Purchase', " . wp_json_encode($purchase_data) . ");\n";
                    }
                    if ($ga_enabled) {
                        echo "gtag('event', 'purchase', {transaction_id: '" . $order->get_id() . "', value: " . (float)$order->get_total() . ", currency: '" . $order->get_currency() . "', items: " . wp_json_encode($ga_items) . "});\n";
                    }

                    // Google Ads conversion
                    if (self::is_enabled('tracking_google_ads_enabled')) {
                        $gads_id = self::get('tracking_google_ads_id');
                        $gads_label = self::get('tracking_google_ads_conversion_label');
                        if (!empty($gads_id) && !empty($gads_label)) {
                            echo "gtag('event', 'conversion', {'send_to': '" . esc_js($gads_id) . "/" . esc_js($gads_label) . "', 'value': " . (float)$order->get_total() . ", 'currency': '" . $order->get_currency() . "', 'transaction_id': '" . $order->get_id() . "'});\n";
                        }
                    }

                    $order->update_meta_data('_revenuepro_pixel_tracked', 1);
                    $order->save();
                }
            }
        }

        // Search
        if (is_search() && self::is_enabled('tracking_events_search')) {
            $search_term = get_search_query();
            if ($fb_enabled) {
                echo "fbq('track', 'Search', {search_string: '" . esc_js($search_term) . "'});\n";
            }
            if ($ga_enabled) {
                echo "gtag('event', 'search', {search_term: '" . esc_js($search_term) . "'});\n";
            }
        }

        echo "</script>\n";

        // AddToCart via AJAX (inline script for WC add-to-cart buttons)
        if (self::is_enabled('tracking_events_add_to_cart') && ($fb_enabled || $ga_enabled)) {
            ?>
<script>
jQuery(document.body).on('added_to_cart', function(e, fragments, hash, btn) {
    var name = btn.closest('.product')?.querySelector('.woocommerce-loop-product__title')?.textContent || '';
    var price = btn.data('price') || 0;
    var id = btn.data('product_id') || 0;
    <?php if ($fb_enabled): ?>
    if(typeof fbq!=='undefined') fbq('track','AddToCart',{content_name:name,content_ids:[id],content_type:'product',value:parseFloat(price),currency:'<?php echo get_woocommerce_currency(); ?>'});
    <?php endif; ?>
    <?php if ($ga_enabled): ?>
    if(typeof gtag!=='undefined') gtag('event','add_to_cart',{currency:'<?php echo get_woocommerce_currency(); ?>',value:parseFloat(price),items:[{item_id:id,item_name:name}]});
    <?php endif; ?>
});
</script>
            <?php
        }
    }

    /**
     * Server-Side: Send Purchase event via Conversions API
     */
    public static function server_purchase_event($order_id)
    {
        if (!self::is_enabled('tracking_fb_capi_enabled') || !self::is_enabled('tracking_events_purchase')) {
            return;
        }

        $order = wc_get_order($order_id);
        if (!$order || $order->get_meta('_revenuepro_capi_sent')) {
            return;
        }

        $pixel_id = self::get('tracking_fb_pixel_id');
        $access_token = self::get('tracking_fb_capi_token');
        $test_code = self::get('tracking_fb_test_code');

        if (empty($pixel_id) || empty($access_token)) {
            return;
        }

        $event_data = [
            'event_name' => 'Purchase',
            'event_time' => time(),
            'action_source' => 'website',
            'event_source_url' => $order->get_checkout_order_received_url(),
            'user_data' => [
                'em' => [hash('sha256', strtolower(trim($order->get_billing_email())))],
                'ph' => [hash('sha256', preg_replace('/[^0-9]/', '', $order->get_billing_phone()))],
                'fn' => [hash('sha256', strtolower(trim($order->get_billing_first_name())))],
                'ln' => [hash('sha256', strtolower(trim($order->get_billing_last_name())))],
                'ct' => [hash('sha256', strtolower(trim($order->get_billing_city())))],
                'zp' => [hash('sha256', trim($order->get_billing_postcode()))],
                'country' => [hash('sha256', strtolower(trim($order->get_billing_country())))],
                'client_ip_address' => $order->get_customer_ip_address(),
                'client_user_agent' => $order->get_customer_user_agent(),
            ],
            'custom_data' => [
                'currency' => $order->get_currency(),
                'value' => (float) $order->get_total(),
                'order_id' => $order->get_id(),
                'content_type' => 'product',
                'contents' => [],
            ],
        ];

        foreach ($order->get_items() as $item) {
            $event_data['custom_data']['contents'][] = [
                'id' => (string) $item->get_product_id(),
                'quantity' => $item->get_quantity(),
                'item_price' => (float) ($item->get_total() / max($item->get_quantity(), 1)),
            ];
        }

        $payload = ['data' => [$event_data]];
        if (!empty($test_code)) {
            $payload['test_event_code'] = $test_code;
        }

        $api_url = "https://graph.facebook.com/v18.0/{$pixel_id}/events?access_token={$access_token}";

        $response = wp_remote_post($api_url, [
            'headers' => ['Content-Type' => 'application/json'],
            'body' => wp_json_encode($payload),
            'timeout' => 15,
        ]);

        if (is_wp_error($response)) {
            \RevenuePro\Logger::error('CAPI Purchase failed for order #' . $order_id . ': ' . $response->get_error_message());
        }

        $order->update_meta_data('_revenuepro_capi_sent', 1);
        $order->save();
    }

    /**
     * Server-Side: Send Custom Event via Conversions API when Order Status Changes
     */
    public static function server_custom_status_event($order_id)
    {
        if (!self::is_enabled('tracking_fb_capi_enabled')) {
            return;
        }

        $order = wc_get_order($order_id);
        if (!$order || $order->get_meta('_revenuepro_capi_custom_status_sent')) {
            return;
        }

        $pixel_id = self::get('tracking_fb_pixel_id');
        $access_token = self::get('tracking_fb_capi_token');
        $test_code = self::get('tracking_fb_test_code');
        $event_name = self::get('tracking_custom_event_name', 'Purchase_Delivered');

        if (empty($pixel_id) || empty($access_token) || empty($event_name)) {
            return;
        }

        $event_data = [
            'event_name' => $event_name,
            'event_time' => time(),
            'action_source' => 'website',
            'event_source_url' => $order->get_checkout_order_received_url(),
            'user_data' => [
                'em' => [hash('sha256', strtolower(trim($order->get_billing_email())))],
                'ph' => [hash('sha256', preg_replace('/[^0-9]/', '', $order->get_billing_phone()))],
                'fn' => [hash('sha256', strtolower(trim($order->get_billing_first_name())))],
                'ln' => [hash('sha256', strtolower(trim($order->get_billing_last_name())))],
                'ct' => [hash('sha256', strtolower(trim($order->get_billing_city())))],
                'zp' => [hash('sha256', trim($order->get_billing_postcode()))],
                'country' => [hash('sha256', strtolower(trim($order->get_billing_country())))],
                'client_ip_address' => $order->get_customer_ip_address(),
                'client_user_agent' => $order->get_customer_user_agent(),
            ],
            'custom_data' => [
                'currency' => $order->get_currency(),
                'value' => (float) $order->get_total(),
                'order_id' => $order->get_id(),
                'content_type' => 'product',
                'contents' => [],
            ],
        ];

        foreach ($order->get_items() as $item) {
            $event_data['custom_data']['contents'][] = [
                'id' => (string) $item->get_product_id(),
                'quantity' => $item->get_quantity(),
                'item_price' => (float) ($item->get_total() / max($item->get_quantity(), 1)),
            ];
        }

        $payload = ['data' => [$event_data]];
        if (!empty($test_code)) {
            $payload['test_event_code'] = $test_code;
        }

        $api_url = "https://graph.facebook.com/v18.0/{$pixel_id}/events?access_token={$access_token}";

        $response = wp_remote_post($api_url, [
            'headers' => ['Content-Type' => 'application/json'],
            'body' => wp_json_encode($payload),
            'timeout' => 15,
        ]);

        if (is_wp_error($response)) {
            \RevenuePro\Logger::error('CAPI Custom Status Event failed for order #' . $order_id . ': ' . $response->get_error_message());
        }

        $order->update_meta_data('_revenuepro_capi_custom_status_sent', 1);
        $order->save();
    }

    /**
     * Server-Side: Send AddToCart event via Conversions API
     */
    public static function server_add_to_cart_event($cart_item_key, $product_id, $quantity, $variation_id, $variation, $cart_item_data)
    {
        if (!self::is_enabled('tracking_fb_capi_enabled') || !self::is_enabled('tracking_events_add_to_cart')) {
            return;
        }

        $pixel_id = self::get('tracking_fb_pixel_id');
        $access_token = self::get('tracking_fb_capi_token');
        $test_code = self::get('tracking_fb_test_code');

        if (empty($pixel_id) || empty($access_token)) {
            return;
        }

        $product = wc_get_product($product_id);
        if (!$product) return;

        $event_data = [
            'event_name' => 'AddToCart',
            'event_time' => time(),
            'action_source' => 'website',
            'event_source_url' => wc_get_cart_url(),
            'user_data' => [
                'client_ip_address' => isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field($_SERVER['REMOTE_ADDR']) : '',
                'client_user_agent' => isset($_SERVER['HTTP_USER_AGENT']) ? sanitize_text_field($_SERVER['HTTP_USER_AGENT']) : '',
            ],
            'custom_data' => [
                'currency' => get_woocommerce_currency(),
                'value' => (float) $product->get_price() * $quantity,
                'content_type' => 'product',
                'contents' => [[
                    'id' => (string) $product_id,
                    'quantity' => $quantity,
                    'item_price' => (float) $product->get_price(),
                ]],
            ],
        ];

        $payload = ['data' => [$event_data]];
        if (!empty($test_code)) {
            $payload['test_event_code'] = $test_code;
        }

        $api_url = "https://graph.facebook.com/v18.0/{$pixel_id}/events?access_token={$access_token}";

        wp_remote_post($api_url, [
            'headers' => ['Content-Type' => 'application/json'],
            'body' => wp_json_encode($payload),
            'timeout' => 10,
            'blocking' => false, // Non-blocking to avoid slowing down the add-to-cart
        ]);
    }
}
