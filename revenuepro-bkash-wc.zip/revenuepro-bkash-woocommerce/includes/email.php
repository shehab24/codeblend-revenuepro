<?php
namespace RevenuePro;

if (!defined('ABSPATH')) {
    exit;
}

class Email
{
    private $settings;

    public function __construct()
    {
        $this->settings = get_option('revenuepro_bkash_wc_settings', []);

        // Configure SMTP if enabled
        if (!empty($this->settings['email_enabled'])) {
            add_action('phpmailer_init', [$this, 'configure_smtp']);
        }
    }

    /**
     * Configure SMTP settings for PHPMailer
     */
    public function configure_smtp($phpmailer)
    {
        if (empty($this->settings['email_smtp_host'])) {
            return;
        }

        $phpmailer->isSMTP();
        $phpmailer->Host = $this->settings['email_smtp_host'];
        $phpmailer->SMTPAuth = true;
        $phpmailer->Port = $this->settings['email_smtp_port'] ?? 587;
        $phpmailer->Username = $this->settings['email_smtp_user'];
        $phpmailer->Password = $this->settings['email_smtp_pass'];
        $phpmailer->SMTPSecure = ($phpmailer->Port == 465) ? 'ssl' : 'tls';
        $phpmailer->From = $this->settings['email_sender_email'];
        $phpmailer->FromName = $this->settings['email_sender_name'];


    }

    /**
     * Send donation receipt email
     */
    public function send_donation_receipt($submission_id)
    {
        // Check if email is enabled
        if (empty($this->settings['email_enabled'])) {

            return false;
        }

        // Get submission data
        $submission_data = get_post_meta($submission_id, 'submission_data', true);
        $amount = get_post_meta($submission_id, 'donation_amount', true);
        $trx_id = get_post_meta($submission_id, 'bkash_trx_id', true);

        if (!is_array($submission_data)) {

            return false;
        }

        // Extract donor info
        $donor_info = $this->extract_donor_info($submission_data);

        if (empty($donor_info['email'])) {

            return false;
        }

        // Prepare email content
        $subject = $this->settings['email_subject'] ?? 'Donation Receipt';
        $heading = $this->settings['email_heading'] ?? 'Thank you for your donation!';
        $body = $this->settings['email_body'] ?? 'Thank you for your generous donation.';

        // Replace placeholders
        $placeholders = [
            '{name}' => $donor_info['name'],
            '{amount}' => $amount ? number_format($amount, 2) : '0.00',
            '{trx_id}' => $trx_id ?: 'N/A',
            '{date}' => date_i18n(get_option('date_format'), current_time('timestamp')),
            '{site_name}' => get_bloginfo('name'),
        ];

        $subject = str_replace(array_keys($placeholders), array_values($placeholders), $subject);
        $heading = str_replace(array_keys($placeholders), array_values($placeholders), $heading);
        $body = str_replace(array_keys($placeholders), array_values($placeholders), $body);
        $body = nl2br($body);

        // Build HTML email
        $html_body = $this->get_success_email_template($heading, $body, $amount, $trx_id);

        // Send email
        return $this->send_email($donor_info['email'], $subject, $html_body, 'receipt');
    }

    /**
     * Send payment failure email
     */
    public function send_failure_email($submission_id, $reason = 'Unknown')
    {
        // Check if email is enabled
        if (empty($this->settings['email_enabled'])) {

            return false;
        }

        // Get submission data
        $submission_data = get_post_meta($submission_id, 'submission_data', true);
        $amount = get_post_meta($submission_id, 'donation_amount', true);

        if (!is_array($submission_data)) {

            return false;
        }

        // Extract donor info
        $donor_info = $this->extract_donor_info($submission_data);

        if (empty($donor_info['email'])) {

            return false;
        }

        // Prepare email content
        $subject = $this->settings['email_failure_subject'] ?? 'Payment Failed - {site_name}';
        $heading = $this->settings['email_failure_heading'] ?? 'Payment Could Not Be Completed';
        $body = $this->settings['email_failure_body'] ?? 'Unfortunately, your payment could not be processed.\n\nPlease try again or contact support.';

        // Replace placeholders
        $placeholders = [
            '{name}' => $donor_info['name'],
            '{amount}' => $amount ? number_format($amount, 2) : '0.00',
            '{reason}' => ucfirst($reason),
            '{date}' => date_i18n(get_option('date_format'), current_time('timestamp')),
            '{site_name}' => get_bloginfo('name'),
        ];

        $subject = str_replace(array_keys($placeholders), array_values($placeholders), $subject);
        $heading = str_replace(array_keys($placeholders), array_values($placeholders), $heading);
        $body = str_replace(array_keys($placeholders), array_values($placeholders), $body);
        $body = nl2br($body);

        // Build HTML email
        $html_body = $this->get_failure_email_template($heading, $body, $amount, $reason);

        // Send email
        return $this->send_email($donor_info['email'], $subject, $html_body, 'failure');
    }

    /**
     * Extract donor information from submission data
     */
    private function extract_donor_info($submission_data)
    {
        $donor_email = '';
        $donor_name = '';

        foreach ($submission_data as $field) {
            if (!isset($field['value']))
                continue;

            // Look for email field
            if (is_email($field['value'])) {
                $donor_email = $field['value'];
            }

            // Look for name field (first text field that's not email)
            if (empty($donor_name) && !is_email($field['value']) && !is_numeric($field['value'])) {
                $donor_name = $field['value'];
            }
        }

        return [
            'email' => $donor_email,
            'name' => $donor_name ?: 'Valued Donor'
        ];
    }

    /**
     * Send email
     */
    private function send_email($to, $subject, $html_body, $type = 'general')
    {
        // Set headers
        $headers = ['Content-Type: text/html; charset=UTF-8'];

        if (!empty($this->settings['email_sender_email'])) {
            $headers[] = 'From: ' . $this->settings['email_sender_name'] . ' <' . $this->settings['email_sender_email'] . '>';
        }



        // Send email
        $sent = wp_mail($to, $subject, $html_body, $headers);

        if ($sent) {
            // Email sent successfully
        } else {
            // Email failed to send
        }

        return $sent;
    }

    /**
     * Modern minimalistic success email template
     */
    private function get_success_email_template($heading, $body, $amount, $trx_id)
    {
        $amount_formatted = number_format($amount, 2);
        $site_name = get_bloginfo('name');

        $template = '
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, \'Helvetica Neue\', Arial, sans-serif; background-color: #f5f5f5;">
    <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color: #f5f5f5; padding: 40px 0;">
        <tr>
            <td align="center">
                <table width="600" cellpadding="0" cellspacing="0" border="0" style="background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,0.05);">
                    
                    <!-- Success Icon -->
                    <tr>
                        <td align="center" style="padding: 48px 40px 24px;">
                            <div style="width: 64px; height: 64px; background: linear-gradient(135deg, #10b981 0%, #059669 100%); border-radius: 50%; display: inline-flex; align-items: center; justify-content: center;">
                                <svg width="32" height="32" fill="none" stroke="#ffffff" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M20 6L9 17l-5-5"/>
                                </svg>
                            </div>
                        </td>
                    </tr>
                    
                    <!-- Heading -->
                    <tr>
                        <td align="center" style="padding: 0 40px 32px;">
                            <h1 style="margin: 0; font-size: 28px; font-weight: 600; color: #0f172a; letter-spacing: -0.5px;">' . esc_html($heading) . '</h1>
                        </td>
                    </tr>
                    
                    <!-- Amount Badge -->
                    <tr>
                        <td align="center" style="padding: 0 40px 24px;">
                            <div style="display: inline-block; background: #f0fdf4; border: 2px solid #10b981; border-radius: 12px; padding: 16px 32px;">
                                <div style="font-size: 14px; color: #059669; font-weight: 600; margin-bottom: 4px;">AMOUNT</div>
                                <div style="font-size: 36px; font-weight: 700; color: #0f172a; letter-spacing: -1px;">' . $amount_formatted . ' <span style="font-size: 20px; color: #64748b;">BDT</span></div>
                            </div>
                        </td>
                    </tr>
                    
                    <!-- Body Text -->
                    <tr>
                        <td style="padding: 0 40px 32px; font-size: 16px; line-height: 1.6; color: #475569;">
                            ' . $body . '
                        </td>
                    </tr>
                    
                    <!-- Transaction Details -->
                    <tr>
                        <td style="padding: 0 40px 40px;">
                            <table width="100%" cellpadding="12" cellspacing="0" border="0" style="background: #f8fafc; border-radius: 8px; border: 1px solid #e2e8f0;">
                                <tr>
                                    <td style="font-size: 13px; color: #64748b; font-weight: 600;">TRANSACTION ID</td>
                                    <td align="right" style="font-size: 14px; color: #0f172a; font-family: monospace;">' . esc_html($trx_id) . '</td>
                                </tr>
                                <tr>
                                    <td style="font-size: 13px; color: #64748b; font-weight: 600; border-top: 1px solid #e2e8f0; padding-top: 12px;">DATE</td>
                                    <td align="right" style="font-size: 14px; color: #0f172a; border-top: 1px solid #e2e8f0; padding-top: 12px;">' . date_i18n(get_option('date_format'), current_time('timestamp')) . '</td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                    
                    <!-- Footer -->
                    <tr>
                        <td align="center" style="padding: 32px 40px; background: #f8fafc; border-top: 1px solid #e2e8f0;">
                            <p style="margin: 0 0 8px; font-size: 13px; color: #64748b;">This is an automated receipt from</p>
                            <p style="margin: 0; font-size: 14px; font-weight: 600; color: #0f172a;">' . esc_html($site_name) . '</p>
                        </td>
                    </tr>
                    
                </table>
            </td>
        </tr>
    </table>
</body>
</html>';

        return $template;
    }

    /**
     * Modern minimalistic failure email template
     */
    private function get_failure_email_template($heading, $body, $amount, $reason)
    {
        $amount_formatted = number_format($amount, 2);
        $site_name = get_bloginfo('name');

        $template = '
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, \'Segoe UI\', Roboto, \'Helvetica Neue\', Arial, sans-serif; background-color: #f5f5f5;">
    <table width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color: #f5f5f5; padding: 40px 0;">
        <tr>
            <td align="center">
                <table width="600" cellpadding="0" cellspacing="0" border="0" style="background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,0.05);">
                    
                    <!-- Error Icon -->
                    <tr>
                        <td align="center" style="padding: 48px 40px 24px;">
                            <div style="width: 64px; height: 64px; background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%); border-radius: 50%; display: inline-flex; align-items: center; justify-content: center;">
                                <svg width="32" height="32" fill="none" stroke="#ffffff" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">
                                    <line x1="12" y1="12" x2="20" y2="20"/>
                                    <line x1="20" y1="12" x2="12" y2="20"/>
                                </svg>
                            </div>
                        </td>
                    </tr>
                    
                    <!-- Heading -->
                    <tr>
                        <td align="center" style="padding: 0 40px 32px;">
                            <h1 style="margin: 0; font-size: 28px; font-weight: 600; color: #0f172a; letter-spacing: -0.5px;">' . esc_html($heading) . '</h1>
                        </td>
                    </tr>
                    
                    <!-- Amount Badge -->
                    <tr>
                        <td align="center" style="padding: 0 40px 24px;">
                            <div style="display: inline-block; background: #fef2f2; border: 2px solid #ef4444; border-radius: 12px; padding: 16px 32px;">
                                <div style="font-size: 14px; color: #dc2626; font-weight: 600; margin-bottom: 4px;">ATTEMPTED AMOUNT</div>
                                <div style="font-size: 36px; font-weight: 700; color: #0f172a; letter-spacing: -1px;">' . $amount_formatted . ' <span style="font-size: 20px; color: #64748b;">BDT</span></div>
                            </div>
                        </td>
                    </tr>
                    
                    <!-- Body Text -->
                    <tr>
                        <td style="padding: 0 40px 32px; font-size: 16px; line-height: 1.6; color: #475569;">
                            ' . $body . '
                        </td>
                    </tr>
                    
                    <!-- Failure Details -->
                    <tr>
                        <td style="padding: 0 40px 40px;">
                            <table width="100%" cellpadding="12" cellspacing="0" border="0" style="background: #fef2f2; border-radius: 8px; border: 1px solid #fecaca;">
                                <tr>
                                    <td style="font-size: 13px; color: #991b1b; font-weight: 600;">REASON</td>
                                    <td align="right" style="font-size: 14px; color: #0f172a;">' . esc_html(ucfirst($reason)) . '</td>
                                </tr>
                                <tr>
                                    <td style="font-size: 13px; color: #991b1b; font-weight: 600; border-top: 1px solid #fecaca; padding-top: 12px;">DATE</td>
                                    <td align="right" style="font-size: 14px; color: #0f172a; border-top: 1px solid #fecaca; padding-top: 12px;">' . date_i18n(get_option('date_format'), current_time('timestamp')) . '</td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                    
                    <!-- CTA Button -->
                    <tr>
                        <td align="center" style="padding: 0 40px 40px;">
                            <a href="' . home_url() . '" style="display: inline-block; padding: 14px 32px; background: #0f172a; color: #ffffff; text-decoration: none; border-radius: 8px; font-weight: 600; font-size: 15px;">Try Again</a>
                        </td>
                    </tr>
                    
                    <!-- Footer -->
                    <tr>
                        <td align="center" style="padding: 32px 40px; background: #f8fafc; border-top: 1px solid #e2e8f0;">
                            <p style="margin: 0 0 8px; font-size: 13px; color: #64748b;">Need help? Contact our support team</p>
                            <p style="margin: 0; font-size: 14px; font-weight: 600; color: #0f172a;">' . esc_html($site_name) . '</p>
                        </td>
                    </tr>
                    
                </table>
            </td>
        </tr>
    </table>
</body>
</html>';

        return $template;
    }
}
