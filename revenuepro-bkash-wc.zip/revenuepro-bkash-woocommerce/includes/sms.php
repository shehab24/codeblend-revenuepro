<?php
namespace RevenuePro;

if (!defined('ABSPATH')) {
    exit;
}

class Sms
{
    private $settings;

    public function __construct()
    {
        $this->settings = get_option('revenuepro_bkash_wc_settings', []);
    }

    public static function init()
    {
        $self = new self();
        $settings = get_option('revenuepro_bkash_wc_settings', []);

        // Send SMS based on configured order statuses (default processing & completed)
        $success_statuses = isset($settings['sms_success_statuses']) && is_array($settings['sms_success_statuses']) 
            ? $settings['sms_success_statuses'] 
            : ['processing', 'completed'];

        foreach ($success_statuses as $status) {
            add_action('woocommerce_order_status_' . $status, [$self, 'send_order_completed_sms'], 10, 1);
        }

        // Send failure SMS when bKash order fails
        add_action('woocommerce_order_status_failed', [$self, 'send_order_failed_sms'], 10, 1);
        add_action('woocommerce_order_status_cancelled', [$self, 'send_order_failed_sms'], 10, 1);
    }

    /**
     * Send SMS when a bKash order is completed or processing
     */
    public function send_order_completed_sms($order_id)
    {
        $this->settings = get_option('revenuepro_bkash_wc_settings', []);

        if (empty($this->settings['sms_enabled'])) {
            return;
        }

        $order = wc_get_order($order_id);
        if (!$order || !in_array($order->get_payment_method(), ['revenuepro_bkash', 'revenuepro_bkash_manual', 'cod'])) {
            return;
        }

        // Check Trigger Condition (always vs no email only)
        $trigger_condition = $this->settings['sms_trigger_condition'] ?? 'always';
        if ($trigger_condition === 'no_email_only') {
            $email = $order->get_billing_email();
            if (!empty($email)) {
                $this->log('Skipping SMS for order #' . $order_id . ' because email is provided and SMS condition is set to "no email only".');
                return;
            }
        }

        // Prevent duplicate SMS
        if ($order->get_meta('_revenuepro_sms_sent') === 'yes') {
            return;
        }

        $phone = $order->get_billing_phone();
        if (empty($phone)) {
            $this->log('No phone number found for order #' . $order_id);
            return;
        }

        $template = $this->settings['sms_message_template'] ?? 'Dear {customer_name}, your order #{order_id} of {order_total} has been confirmed. Payment received via bKash. TrxID: {trx_id}. Thank you for shopping with {site_name}!';
        $message = $this->prepare_message($order, $template);
        $result = $this->send_sms($phone, $message);

        if ($result) {
            $order->update_meta_data('_revenuepro_sms_sent', 'yes');
            $order->update_meta_data('_revenuepro_sms_sent_at', current_time('mysql'));
            $order->save();
            $order->add_order_note(__('SMS notification sent to customer via RevenuePro.', 'revenuepro-bkash-wc'));
        } else {
            $order->add_order_note(__('Failed to send SMS notification to customer.', 'revenuepro-bkash-wc'));
        }
    }

    /**
     * Send SMS when a bKash order fails or is cancelled
     */
    public function send_order_failed_sms($order_id)
    {
        $this->settings = get_option('revenuepro_bkash_wc_settings', []);

        if (empty($this->settings['sms_enabled'])) {
            return;
        }

        $order = wc_get_order($order_id);
        if (!$order || !in_array($order->get_payment_method(), ['revenuepro_bkash', 'revenuepro_bkash_manual', 'cod'])) {
            return;
        }

        // Check Trigger Condition (always vs no email only)
        $trigger_condition = $this->settings['sms_trigger_condition'] ?? 'always';
        if ($trigger_condition === 'no_email_only') {
            $email = $order->get_billing_email();
            if (!empty($email)) {
                return;
            }
        }

        // Prevent duplicate failure SMS
        if ($order->get_meta('_revenuepro_sms_failure_sent') === 'yes') {
            return;
        }

        $phone = $order->get_billing_phone();
        if (empty($phone)) {
            return;
        }

        $template = $this->settings['sms_failure_message_template'] ?? 'Dear {customer_name}, your bKash payment for order #{order_id} of {order_total} could not be completed. Please try again or contact us. - {site_name}';
        $message = $this->prepare_message($order, $template);
        $result = $this->send_sms($phone, $message);

        if ($result) {
            $order->update_meta_data('_revenuepro_sms_failure_sent', 'yes');
            $order->save();
            $order->add_order_note(__('Failure SMS notification sent to customer via RevenuePro.', 'revenuepro-bkash-wc'));
        } else {
            $order->add_order_note(__('Failed to send failure SMS notification.', 'revenuepro-bkash-wc'));
        }
    }

    /**
     * Prepare SMS message with placeholders replaced
     */
    private function prepare_message($order, $template)
    {
        $trx_id = $order->get_transaction_id() ?: 'N/A';
        $partial_paid = $order->get_meta('_bkash_partial_paid');
        $remaining = $order->get_meta('_bkash_remaining');

        // Clean price: strip HTML tags AND decode entities
        $clean_price = function($amount) {
            return html_entity_decode(strip_tags(wc_price($amount)), ENT_QUOTES, 'UTF-8');
        };

        $placeholders = [
            '{customer_name}'  => $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
            '{order_id}'       => $order->get_order_number(),
            '{order_total}'    => $clean_price($order->get_total()),
            '{trx_id}'         => $trx_id,
            '{payment_method}' => 'bKash',
            '{site_name}'      => get_bloginfo('name'),
            '{date}'           => date_i18n(get_option('date_format'), current_time('timestamp')),
            '{phone}'          => $order->get_billing_phone(),
            '{paid_amount}'    => $partial_paid ? $clean_price($partial_paid) : $clean_price($order->get_total()),
            '{remaining}'      => $remaining ? $clean_price($remaining) : $clean_price(0),
        ];

        return str_replace(array_keys($placeholders), array_values($placeholders), $template);
    }

    /**
     * Send SMS via BulkSMSBD API
     */
    private function send_sms($phone, $message)
    {
        $api_url = $this->settings['sms_api_url'] ?? 'http://bulksmsbd.net/api/smsapi';
        $api_key = $this->settings['sms_api_key'] ?? '';
        $sender_id = $this->settings['sms_sender_id'] ?? '';

        if (empty($api_url) || empty($api_key)) {
            $this->log('SMS API URL or API Key is missing.');
            return false;
        }

        $this->log('Sending SMS to: ' . $phone);

        $body = [
            'api_key'  => $api_key,
            'senderid' => $sender_id,
            'number'   => $phone,
            'message'  => $message,
            'type'     => 'text',
        ];

        $this->log('SMS API URL: ' . $api_url);
        $this->log('SMS Payload: ' . json_encode($body));

        $response = wp_remote_post($api_url, [
            'timeout'   => 30,
            'body'      => $body,
            'sslverify' => false,
        ]);

        if (is_wp_error($response)) {
            $this->log('SMS sending failed: ' . $response->get_error_message());
            return false;
        }

        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);

        $this->log('SMS API Response Code: ' . $response_code);
        $this->log('SMS API Response Body: ' . $response_body);

        $data = json_decode($response_body, true);

        if (is_array($data) && isset($data['response_code'])) {
            if ($data['response_code'] == 202) {
                $this->log('SMS sent successfully to ' . $phone . ' (BulkSMSBD code: 202)');
                return true;
            }

            $error_msg = $data['error_message'] ?? ($data['message'] ?? 'Unknown error');
            $this->log('BulkSMSBD error: ' . $error_msg . ' (code: ' . $data['response_code'] . ')');
            
            // Clever fix: If BulkSMSBD tells us the IP isn't whitelisted, it means our server's outbound 
            // NAT IP is different from the one we detected. Let's extract their detected IP and cache it 
            // so the dashboard updates to show the exact IP that BulkSMSBD expects.
            if (preg_match('/Your ip ([\d\.]+) not Whitelisted/i', $error_msg, $matches)) {
                set_transient('revenuepro_server_ip', $matches[1], DAY_IN_SECONDS);
            }

            return false;
        }

        if ($response_code >= 200 && $response_code < 300) {
            $this->log('SMS sent successfully to ' . $phone . ' (HTTP ' . $response_code . ')');
            return true;
        }

        $this->log('SMS API returned non-success. HTTP: ' . $response_code);
        return false;
    }

    /**
     * Get server's external IP address (cached for 24 hours)
     */
    public static function get_server_ip()
    {
        $cached_ip = get_transient('revenuepro_server_ip');
        if ($cached_ip) {
            return $cached_ip;
        }

        // Try multiple services
        $services = [
            'https://api.ipify.org',
            'https://ifconfig.me/ip',
            'https://icanhazip.com',
        ];

        foreach ($services as $service) {
            $response = wp_remote_get($service, ['timeout' => 5, 'sslverify' => false]);
            if (!is_wp_error($response)) {
                $ip = trim(wp_remote_retrieve_body($response));
                if (filter_var($ip, FILTER_VALIDATE_IP)) {
                    set_transient('revenuepro_server_ip', $ip, DAY_IN_SECONDS);
                    return $ip;
                }
            }
        }

        return $_SERVER['SERVER_ADDR'] ?? 'Unable to detect';
    }

    private function log($message)
    {
        // Route SMS logs through the centralized plugin logger
        // so they appear in the Dashboard "System Debug Logging" viewer.
        \RevenuePro\Logger::info('[SMS] ' . $message);
    }
}
