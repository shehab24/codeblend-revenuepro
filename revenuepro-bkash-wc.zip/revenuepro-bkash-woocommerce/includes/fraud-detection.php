<?php
namespace RevenuePro;

if (!defined('ABSPATH')) {
    exit;
}

class FraudDetection
{
    private $settings;
    private $api_endpoint = REVENUEPRO_API_BASE_URL . '/api/v1/fraud-stats/check';

    public function __construct()
    {
        $this->settings = get_option('revenuepro_bkash_wc_settings', []);
    }

    public static function init()
    {
        $self = new self();
        
        // Checkout Validation Hook (uses $errors so messages appear inside the checkout form, works with CartFlows)
        add_action('woocommerce_after_checkout_validation', [$self, 'validate_checkout_for_fraud'], 10, 2);
        
        // Duplicate/Spam Order Prevention Hook (uses $errors for inline form errors)
        add_action('woocommerce_after_checkout_validation', [$self, 'validate_duplicate_orders'], 10, 2);
        
        // Dynamically disable COD during checkout if fraud threshold exceeded
        add_filter('woocommerce_available_payment_gateways', [$self, 'filter_gateways_for_fraud']);

        // Save browser fingerprint as order meta
        add_action('woocommerce_checkout_order_processed', [__CLASS__, 'save_fingerprint_to_order']);

        // Inject fingerprint JS on any page with a checkout form (works with CartFlows/landing pages)
        add_action('wp_footer', [__CLASS__, 'inject_fingerprint_script']);
    }

    /**
     * Inject lightweight browser fingerprint script on checkout
     */
    public static function inject_fingerprint_script()
    {
        $settings = get_option('revenuepro_bkash_wc_settings', []);
        if (empty($settings['spam_fingerprint_enabled'])) return;
        
        // Only inject if there's a checkout form on this page
        ?>
        <script>
        (function() {
            var form = document.querySelector('form.checkout, form.woocommerce-checkout');
            if (!form) return;
            var fp = [
                screen.width, screen.height, screen.colorDepth,
                navigator.language, navigator.platform,
                Intl.DateTimeFormat().resolvedOptions().timeZone,
                new Date().getTimezoneOffset(),
                navigator.hardwareConcurrency || 0,
                navigator.userAgent
            ].join('|');
            var hash = 0;
            for (var i = 0; i < fp.length; i++) {
                hash = ((hash << 5) - hash) + fp.charCodeAt(i);
                hash |= 0;
            }
            var field = document.createElement('input');
            field.type = 'hidden';
            field.name = 'revenuepro_fingerprint';
            field.value = 'fp_' + Math.abs(hash).toString(36);
            form.appendChild(field);
        })();
        </script>
        <?php
    }

    /**
     * Block checkout if the same phone number has exceeded the daily order limit
     */
    public function validate_duplicate_orders($data, $errors)
    {
        $this->settings = get_option('revenuepro_bkash_wc_settings', []);
        $block_msg = $this->settings['spam_block_message'] ?? 'You have exceeded the maximum number of orders allowed. Please try again later.';

        // --- Phone Number Check ---
        if (!empty($this->settings['spam_phone_enabled'])) {
            $billing_phone = isset($_POST['billing_phone']) ? sanitize_text_field($_POST['billing_phone']) : '';
            if (!empty($billing_phone)) {
                $clean_phone = preg_replace('/[^0-9]/', '', $billing_phone);
                if (strpos($clean_phone, '8801') === 0) $clean_phone = substr($clean_phone, 2);
                
                if (strlen($clean_phone) === 11) {
                    $limit = intval($this->settings['spam_phone_limit'] ?? 3);
                    $hours = intval($this->settings['spam_phone_duration'] ?? 24);
                    $count = $this->count_orders_by_field('billing_phone', $clean_phone, $hours);
                    // Also check +88 variant
                    $count += $this->count_orders_by_field('billing_phone', '+88' . $clean_phone, $hours);
                    if ($count >= $limit) {
                        $msg = __('You have exceeded the maximum number of orders allowed with this phone number. Please try a new one.', 'revenuepro-bkash-wc');
                        $errors->add('billing_phone', $msg);
                        return;
                    }
                }
            }
        }

        // --- Email Address Check ---
        if (!empty($this->settings['spam_email_enabled'])) {
            $billing_email = isset($_POST['billing_email']) ? sanitize_email($_POST['billing_email']) : '';
            if (!empty($billing_email)) {
                $limit = intval($this->settings['spam_email_limit'] ?? 3);
                $hours = intval($this->settings['spam_email_duration'] ?? 24);
                $count = $this->count_orders_by_field('billing_email', $billing_email, $hours);
                if ($count >= $limit) {
                    $msg = __('You have exceeded the maximum number of orders allowed with this email address. Please try a new one.', 'revenuepro-bkash-wc');
                    $errors->add('billing_email', $msg);
                    return;
                }
            }
        }

        // --- IP Address Check ---
        if (!empty($this->settings['spam_ip_enabled'])) {
            $ip = self::get_client_ip();
            if (!empty($ip)) {
                $limit = intval($this->settings['spam_ip_limit'] ?? 5);
                $hours = intval($this->settings['spam_ip_duration'] ?? 24);
                $count = $this->count_orders_by_meta('_customer_ip_address', $ip, $hours);
                if ($count >= $limit) {
                    $errors->add('spam_ip', __($block_msg, 'revenuepro-bkash-wc'));
                    return;
                }
            }
        }

        // --- Browser Fingerprint Check ---
        if (!empty($this->settings['spam_fingerprint_enabled'])) {
            $fingerprint = isset($_POST['revenuepro_fingerprint']) ? sanitize_text_field($_POST['revenuepro_fingerprint']) : '';
            if (!empty($fingerprint)) {
                $limit = intval($this->settings['spam_fingerprint_limit'] ?? 5);
                $hours = intval($this->settings['spam_fingerprint_duration'] ?? 24);
                $count = $this->count_orders_by_meta('_revenuepro_fingerprint', $fingerprint, $hours);
                if ($count >= $limit) {
                    $errors->add('spam_fingerprint', __($block_msg, 'revenuepro-bkash-wc'));
                    return;
                }
            }
        }
    }

    /**
     * Count WooCommerce orders by a billing field within a given time window
     */
    private function count_orders_by_field($field, $value, $hours)
    {
        $date_after = date('Y-m-d H:i:s', strtotime("-{$hours} hours"));
        $args = [
            $field         => $value,
            'date_created' => '>=' . $date_after,
            'status'       => ['wc-processing', 'wc-completed', 'wc-on-hold', 'wc-pending'],
            'limit'        => -1,
            'return'       => 'ids',
        ];
        return count(wc_get_orders($args));
    }

    /**
     * Count WooCommerce orders by order meta within a given time window
     */
    private function count_orders_by_meta($meta_key, $meta_value, $hours)
    {
        global $wpdb;
        $date_after = date('Y-m-d H:i:s', strtotime("-{$hours} hours"));
        
        // Use HPOS-compatible query if available, otherwise fallback to meta
        if (class_exists('\Automattic\WooCommerce\Utilities\OrderUtil') && \Automattic\WooCommerce\Utilities\OrderUtil::custom_orders_table_usage_is_enabled()) {
            $count = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(o.id) FROM {$wpdb->prefix}wc_orders o
                 INNER JOIN {$wpdb->prefix}wc_orders_meta om ON o.id = om.order_id
                 WHERE om.meta_key = %s AND om.meta_value = %s
                 AND o.date_created_gmt >= %s
                 AND o.status IN ('wc-processing','wc-completed','wc-on-hold','wc-pending')",
                $meta_key, $meta_value, $date_after
            ));
        } else {
            $count = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(p.ID) FROM {$wpdb->posts} p
                 INNER JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id
                 WHERE pm.meta_key = %s AND pm.meta_value = %s
                 AND p.post_date >= %s
                 AND p.post_type = 'shop_order'
                 AND p.post_status IN ('wc-processing','wc-completed','wc-on-hold','wc-pending')",
                $meta_key, $meta_value, $date_after
            ));
        }
        return intval($count);
    }

    /**
     * Get the real client IP behind proxies / CloudFlare
     */
    public static function get_client_ip()
    {
        $headers = ['HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'REMOTE_ADDR'];
        foreach ($headers as $header) {
            if (!empty($_SERVER[$header])) {
                $ip = $_SERVER[$header];
                if (strpos($ip, ',') !== false) $ip = trim(explode(',', $ip)[0]);
                if (filter_var($ip, FILTER_VALIDATE_IP)) return $ip;
            }
        }
        return $_SERVER['REMOTE_ADDR'] ?? '';
    }

    /**
     * Save browser fingerprint as order meta when order is created
     */
    public static function save_fingerprint_to_order($order_id)
    {
        if (isset($_POST['revenuepro_fingerprint']) && !empty($_POST['revenuepro_fingerprint'])) {
            update_post_meta($order_id, '_revenuepro_fingerprint', sanitize_text_field($_POST['revenuepro_fingerprint']));
        }
    }

    public function add_custom_cron_schedule($schedules)
    {
        if (!isset($schedules['revenuepro_5min'])) {
            $schedules['revenuepro_5min'] = [
                'interval' => 300,
                'display'  => __('Every 5 Minutes', 'revenuepro-bkash-wc')
            ];
        }
        return $schedules;
    }

    public function sync_fraud_stats_to_server()
    {
        global $wpdb;
        $table = $wpdb->prefix . 'revenuepro_fraud_stats';
        
        // Ensure table exists to prevent errors
        if ($wpdb->get_var("SHOW TABLES LIKE '$table'") != $table) {
            error_log('REVENUEPRO SYNC ERROR: Table does not exist');
            return;
        }

        $rows = $wpdb->get_results("SELECT * FROM $table", ARRAY_A);
        if (empty($rows)) {
            error_log('REVENUEPRO SYNC PASS: Table is empty, nothing to sync');
            return; // No stats to sync
        }

        $settings = get_option('revenuepro_bkash_wc_settings', []);
        $license_key = isset($settings['license_key']) ? $settings['license_key'] : '';

        $node_api_host = REVENUEPRO_API_BASE_URL;

        error_log('REVENUEPRO SYNC BOOT: Sending ' . count($rows) . ' rows to Node Server... [Key: ' . $license_key . ', Domain: ' . get_site_url() .']');

        // Blocking temporarily inverted to true to debug backend response locally
        $response = wp_remote_post($node_api_host . '/api/v1/fraud-stats/sync', [
            'blocking' => true,
            'timeout'  => 10,
            'headers'  => ['Content-Type' => 'application/json'],
            'body'     => wp_json_encode([
                'key'    => sanitize_text_field($license_key),
                'domain' => trailingslashit(get_site_url()),
                'stats'  => $rows
            ])
        ]);

        if (is_wp_error($response)) {
            error_log('REVENUEPRO SYNC FAIL: ' . $response->get_error_message());
        } else {
            error_log('REVENUEPRO SYNC FINISHED: Node Server Responded HTTP ' . wp_remote_retrieve_response_code($response) . ' Body: ' . wp_remote_retrieve_body($response));
        }
    }

    /**
     * Hook during checkout to validate specific BD numbers against BD Courier API
     */
    public function validate_checkout_for_fraud($data, $errors)
    {
        $this->settings = get_option('revenuepro_bkash_wc_settings', []);
        
        if (empty($this->settings['fraud_enabled'])) {
            return;
        }

        $billing_phone = isset($_POST['billing_phone']) ? sanitize_text_field($_POST['billing_phone']) : '';
        if (empty($billing_phone)) {
            return; // let WC handle required validation
        }

        // Validate BD Phone Format locally
        if (!$this->is_valid_bd_phone($billing_phone)) {
            $errors->add('fraud_phone_invalid', __('Please enter a valid Bangladeshi phone number.', 'revenuepro-bkash-wc'));
            return;
        }

        // Format to exact 11 digits (remove +88 / 88)
        $clean_phone = preg_replace('/[^0-9]/', '', $billing_phone);
        if (strpos($clean_phone, '8801') === 0) {
            $clean_phone = substr($clean_phone, 2);
        }

        // Only call API if it is exactly 11 digits
        if (strlen($clean_phone) !== 11) {
            return;
        }

        // Check cache or BD Courier API
        $fraud_data = self::check_and_cache_phone($clean_phone);

        $threshold = floatval($this->settings['fraud_success_threshold'] ?? 70);
        $action = $this->settings['fraud_action'] ?? 'disable_cod';
        $block_zero = !empty($this->settings['fraud_block_zero_ratio']);

        // If no data at all (API failed, no cache), treat as unknown
        if (!$fraud_data || !is_array($fraud_data)) {
            if ($block_zero && $action === 'block_checkout') {
                $msg = $this->settings['fraud_block_message'] ?? 'Your order cannot be processed due to high courier cancellation risk. Please contact support.';
                $errors->add('fraud_block', __($msg, 'revenuepro-bkash-wc'));
            }
            return;
        }
        
        $total_parcel = intval($fraud_data['total_parcel'] ?? 0);
        $ratio = floatval($fraud_data['success_ratio'] ?? 0);

        $is_fraud = false;
        if ($total_parcel === 0 || $ratio === 0.0) {
            if ($block_zero) $is_fraud = true;
        } else {
            if ($ratio < $threshold) $is_fraud = true;
        }
        
        // If action is to block checkout, we do it here. If disable_cod, we handle it in `filter_gateways_for_fraud`.
        if ($action === 'block_checkout' && $is_fraud) {
            $msg = $this->settings['fraud_block_message'] ?? 'Your order cannot be processed due to high courier cancellation risk. Please contact support.';
            $errors->add('fraud_block', __($msg, 'revenuepro-bkash-wc'));
        }
    }

    /**
     * Disable COD gateway dynamically based on typed phone number ratio
     */
    public function filter_gateways_for_fraud($gateways)
    {
        if (is_admin()) return $gateways; // Don't block admin order creation

        $this->settings = get_option('revenuepro_bkash_wc_settings', []);
        
        if (empty($this->settings['fraud_enabled'])) {
            return $gateways;
        }

        $action = $this->settings['fraud_action'] ?? 'disable_cod';
        if ($action !== 'disable_cod') {
            return $gateways;
        }

        $threshold = floatval($this->settings['fraud_success_threshold'] ?? 70);
        $block_zero = !empty($this->settings['fraud_block_zero_ratio']);

        // Try getting phone from POST data during ajax update, or WC customer session
        $phone = '';
        if (isset($_POST['post_data'])) {
            parse_str($_POST['post_data'], $post_data);
            $phone = isset($post_data['billing_phone']) ? sanitize_text_field($post_data['billing_phone']) : '';
        } elseif (WC()->customer) {
            $phone = WC()->customer->get_billing_phone();
        }

        $clean_phone = preg_replace('/[^0-9]/', '', $phone);
        if (strpos($clean_phone, '8801') === 0) {
            $clean_phone = substr($clean_phone, 2);
        }

        if (strlen($clean_phone) === 11) {
            // Check cache (we only check cache during frontend ajax redraws to prevent spamming BD courier directly inside the filter)
            require_once __DIR__ . '/fraud-detection-db.php';
            $local_stats = FraudDetectionDB::get_stats($clean_phone);
            
            if ($local_stats) {
                $total_parcel = intval($local_stats['total_parcel']);
                $ratio = floatval($local_stats['success_ratio']);
                
                $is_fraud = false;
                if ($total_parcel === 0 || $ratio === 0.0) {
                    if ($block_zero) $is_fraud = true;
                } else {
                    if ($ratio < $threshold) $is_fraud = true;
                }

                // If they are under the threshold, remove COD
                if ($is_fraud && isset($gateways['cod'])) {
                    unset($gateways['cod']);
                }
            }
        }

        return $gateways;
    }

    /**
     * Reusable method for the frontend REST API and backend validation.
     * Hits DB first. If not found, hits BD Courier API and saves it.
     */
    public static function check_and_cache_phone($phone)
    {
        require_once __DIR__ . '/fraud-detection-db.php';
        $local_stats = FraudDetectionDB::get_stats($phone);

        // If we have cached data locally from the last 24 hours (we use the DB row presence for now)
        if ($local_stats) {
            return [
                'source' => 'local',
                'success_ratio' => $local_stats['success_ratio'],
                'total_parcel' => $local_stats['total_parcel'],
                'cancelled_parcel' => $local_stats['cancelled_parcel']
            ];
        }

        // If not in local DB, fetch from external API
        $instance = new self();
        $api_data = $instance->fetch_and_store_courier_api($phone);

        if ($api_data && isset($api_data['data']['summary'])) {
            $summary = $api_data['data']['summary'];
            return [
                'source' => 'api',
                'success_ratio' => $summary['success_ratio'],
                'total_parcel' => $summary['total_parcel'],
                'cancelled_parcel' => $summary['cancelled_parcel']
            ];
        }

        return false;
    }

    private function is_valid_bd_phone($phone)
    {
        $phone = preg_replace('/[^0-9\+]/', '', $phone);
        return preg_match('/^(?:\+88|88)?(01[3-9]\d{8})$/', $phone);
    }

    private function fetch_and_store_courier_api($phone)
    {
        $license_key = $this->settings['license_key'] ?? '';

        $url = $this->api_endpoint;
        $response = wp_remote_post($url, [
            'timeout' => 30,
            'headers' => [
                'Authorization' => 'Bearer ' . $license_key,
                'Content-Type'  => 'application/json'
            ],
            'body' => wp_json_encode([
                'phone'  => $phone,
                'key'    => $license_key,
                'domain' => trailingslashit(get_site_url()),
            ]),
            'sslverify' => false
        ]);

        if (is_wp_error($response)) {
            return false;
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        // Node API returns: { success: true, source: "...", data: { phone, total_parcel, success_parcel, cancelled_parcel, success_ratio, ... } }
        if (is_array($data) && !empty($data['success']) && isset($data['data'])) {
            $stats = $data['data'];

            $total_parcel     = intval($stats['total_parcel'] ?? 0);
            $success_parcel   = intval($stats['success_parcel'] ?? 0);
            $cancelled_parcel = intval($stats['cancelled_parcel'] ?? 0);
            $success_ratio    = floatval($stats['success_ratio'] ?? 0);

            // Store into local WP database for caching
            require_once __DIR__ . '/fraud-detection-db.php';
            FraudDetectionDB::upsert_stats($phone, [
                'total_parcel'      => $total_parcel,
                'success_parcel'    => $success_parcel,
                'cancelled_parcel'  => $cancelled_parcel,
                'success_ratio'     => $success_ratio,
                'pathao_success'    => intval($stats['pathao_success'] ?? 0),
                'pathao_cancel'     => intval($stats['pathao_cancel'] ?? 0),
                'steadfast_success' => intval($stats['steadfast_success'] ?? 0),
                'steadfast_cancel'  => intval($stats['steadfast_cancel'] ?? 0),
                'parceldex_success' => intval($stats['parceldex_success'] ?? 0),
                'parceldex_cancel'  => intval($stats['parceldex_cancel'] ?? 0),
                'redx_success'      => intval($stats['redx_success'] ?? 0),
                'redx_cancel'       => intval($stats['redx_cancel'] ?? 0),
                'paperfly_success'  => intval($stats['paperfly_success'] ?? 0),
                'paperfly_cancel'   => intval($stats['paperfly_cancel'] ?? 0),
                'carrybee_success'  => intval($stats['carrybee_success'] ?? 0),
                'carrybee_cancel'   => intval($stats['carrybee_cancel'] ?? 0),
            ]);

            return [
                'source'           => $data['source'] ?? 'api',
                'total_parcel'     => $total_parcel,
                'success_parcel'   => $success_parcel,
                'cancelled_parcel' => $cancelled_parcel,
                'success_ratio'    => $success_ratio,
            ];
        }

        return false;
    }
}
