<?php
namespace RevenuePro;

if (!defined('ABSPATH')) {
    exit;
}

class AbandonedCartAdmin
{
    public static function init()
    {
        $self = new self();
        add_action('admin_menu', [$self, 'add_menu_page'], 60);
        add_action('admin_enqueue_scripts', [$self, 'enqueue_admin_scripts']);
    }

    public function add_menu_page()
    {
        add_submenu_page(
            null, // Hide from native menu
            __('Abandoned Carts', 'revenuepro-bkash-wc'),
            __('Abandoned Carts', 'revenuepro-bkash-wc'),
            'manage_options',
            'revenuepro-abandoned-carts',
            [$this, 'render_page']
        );
    }

    public function enqueue_admin_scripts($hook)
    {
        // Check for our page hook (strpos is safer for hidden pages)
        if (strpos($hook, 'revenuepro-abandoned-carts') !== false) {
            
            // Remove Admin Notices to keep the UI clean
            remove_all_actions('admin_notices');
            
            $asset_file = include REVENUEPRO_FORM_ASSETS_PATH . 'build/dashboard.asset.php';
            
            wp_enqueue_script(
                'revenuepro-bkash-dashboard',
                REVENUEPRO_FORM_ASSETS_URL . 'build/dashboard.js',
                $asset_file['dependencies'],
                $asset_file['version'],
                true
            );

            wp_enqueue_style('revenuepro-bkash-dashboard', REVENUEPRO_FORM_ASSETS_URL . 'build/dashboard.css');
            
            // Localize script with global data
            $assets = new Assets();
            $data = $assets->get_localize_script_data();
            $data['ajax_nonce'] = wp_create_nonce('revenuepro_cart_details'); // Add our specific nonce

            wp_localize_script('revenuepro-bkash-dashboard', 'RevenueProGlobal', $data);
            
            // Should also enqueue translations like Assets.php does
            wp_set_script_translations('revenuepro-bkash-dashboard', 'revenuepro-bkash-wc', REVENUEPRO_FORM_ROOT_DIR_PATH . 'languages');
        }
    }

    public function render_page()
    {
        echo '<div id="revenuepro-bkash-wc-wrap"></div>';
    }
}
