# Email Functionality - RevenuePro Plugin

## Overview
The plugin now sends automated email receipts to donors after successful payments.

## Configuration

### 1. Enable Email in Settings
Go to **Settings → Email Notifications** and:
- Toggle "Enable Email Notifications" to ON
- Fill in Sender Details:
  - Sender Name (e.g., "Donation Team")
  - Sender Email (e.g., "donations@example.com")

### 2. Configure SMTP (Required for sending emails)
Fill in the SMTP Settings:
- **SMTP Host**: e.g., `smtp.mailtrap.io` (for testing) or your production SMTP
- **SMTP Port**: Usually `2525` (Mailtrap), `587` (TLS), or `465` (SSL)
- **SMTP Username**: Your SMTP username
- **SMTP Password**: Your SMTP password

**Testing with Mailtrap:**
1. Sign up at https://mailtrap.io (free)
2. Get your SMTP credentials from the inbox
3. Use these for testing without sending real emails

### 3. Customize Email Template
- **Email Subject**: Subject line (supports placeholders)
- **Email Heading**: Main heading in email
- **Email Body**: Email content (supports placeholders)

**Available Placeholders:**
- `{name}` - Donor's name
- `{amount}` - Donation amount
- `{trx_id}` - Transaction ID from bKash
- `{date}` - Payment date
- `{site_name}` - Your website name

## How It Works

1. **Donor completes payment**
2. **System extracts donor email** from form submission
3. **Replaces placeholders** in template with actual data
4. **Sends HTML email** via configured SMTP
5. **Logs success/failure** in debug log

## Email Template Features

- Modern HTML design
- Mobile responsive
- Professional gradient header
- Clean typography
- Automated footer with site name and date

## Troubleshooting

### Email not sending?
1. Check if "Enable Email Notifications" is ON
2. Verify SMTP credentials are correct
3. Check debug log: `/wp-content/debug.log`
4. Look for errors like "Email: Failed to send to..."

### How to find donor email?
The system automatically looks for:
- Any field with valid email format
- You must include an email field in your form

### Testing emails locally
Use Mailtrap or similar service to capture test emails without sending real ones.

## Files Modified

- `includes/email.php` - Email handler class
- `includes/shortcode.php` - Triggers email after successful payment
- `src/dashboard/pages/Settings.js` - Email settings UI

## Example Email Template

```
Subject: Donation Receipt - {site_name}

Heading: Thank you for your generous donation!

Body:
Dear {name},

Thank you for your generous donation of {amount} BDT.

Your contribution helps us make a difference.

Transaction Details:
- Transaction ID: {trx_id}
- Date: {date}

We greatly appreciate your support!

Warm regards,
{site_name} Team
```
