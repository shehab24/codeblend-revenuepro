const defaultConfig = require('@wordpress/scripts/config/webpack.config');
const path = require('path');

async function getWebpackConfig() {
	// Simplify: Only define the dashboard entry point for now
	const config = {
		...defaultConfig,
		entry: {
			// Only keeping the dashboard entry point
			dashboard: path.resolve(__dirname, 'src/dashboard.js'),
            'bkash-payment': path.resolve(__dirname, 'src/payments/bkash.js'),
		},
		output: {
			// Output the build files to the assets/build folder
			...defaultConfig.output,
			path: path.resolve(__dirname, 'assets/build'),
		},
		resolve: {
			// Resolving aliases (optional)
			alias: {
				...defaultConfig.resolve.alias,
				'@Components': path.resolve(__dirname, 'src/components/'),
				'@Dashboard': path.resolve(__dirname, 'src/dashboard/'),
                '@Utils': path.resolve(__dirname, 'src/utils/'),
			},
		},
		plugins: [
			// Keep existing plugins if necessary
			...defaultConfig.plugins,
		],
	};

	return config;
}

module.exports = getWebpackConfig();
