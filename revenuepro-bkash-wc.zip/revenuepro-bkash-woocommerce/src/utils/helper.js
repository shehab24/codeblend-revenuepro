import { useLocation } from 'react-router-dom';
import axios from 'axios';
export const {
	ajax_url,
	namespace,
	plugin_root_path,
	plugin_root_url,
	is_pro,
	route_path,
	menu,
	nonce,
	revenuepro_bkash_wc_nonce,
	rest_url,
	toplevel_menu_icon_url,
	third_party_plugin_status,
	settings,
} = window.RevenueProGlobal ?? {};

export const API = axios.create({
	baseURL: rest_url,
	headers: {
		'content-type': 'application/json',
		'X-WP-Nonce': nonce,
		'Cache-Control': 'no-cache', // Prevent caching
	},
});

export const objectUniqueCheck = (defaultObject, savedObject) => {
	const changes = {};
	for (const key in savedObject) {
		const defaultValue = defaultObject[key];
		const changeValue = savedObject[key];
		if (
			changeValue !== null &&
			JSON.stringify(defaultValue) !== JSON.stringify(changeValue)
		) {
			changes[key] = changeValue;
		}
	}
	return changes;
};

export const getRenderDomElement = (selector, childSelector = null) => {
	let domElement = document.querySelector(selector);
	if (domElement) {
		if (childSelector) {
			return domElement.querySelector(childSelector);
		}
		return domElement; // Return the element itself if no childSelector provided
	}
	const editorCanvas = document.querySelector('iframe[name="editor-canvas"]');
	if (editorCanvas && editorCanvas.contentDocument) {
		domElement = editorCanvas.contentDocument.querySelector(selector);
		if (childSelector) {
			return domElement?.querySelector(childSelector);
		}
		return domElement; // Return the element itself if no childSelector provided
	}

	return null; // Return null if no element found
};

export const getUnit = (attributeValue, device = '') => {
	const unit = attributeValue.unit;

	if (!device) {
		return unit;
	}

	const unitTablet = attributeValue.unitTablet;
	const unitMobile = attributeValue.unitMobile;

	if (device === 'Tablet') {
		return unitTablet || unit;
	} else if (device === 'Mobile') {
		return unitMobile || unitTablet || unit;
	}

	return unit;
};

export const noop = () => { };

export const useQuery = () => {
	return new URLSearchParams(useLocation().search);
};

export const makeRequest = async (payload = {}, isRaw = false) => {
	let form_data = new FormData(); // eslint-disable-line
	form_data.append('security', revenuepro_bkash_wc_nonce);
	Object.entries(payload).forEach(([key, value]) => {
		if (!isRaw && typeof value === 'object' && value !== null) {
			form_data.append(key, JSON.stringify(value));
		} else {
			form_data.append(key, value);
		}
	});
	return await axios.post(ajaxurl, form_data).then(
		(response) => {
			return response;
		},
		(error) => {
			// fireNotify(error?.message, 'error');
			console.log(error); // eslint-disable-line
		}
	);
};

export const isObject = (value) => {
	return value !== null && typeof value === 'object';
};

export const showNotice = ({
	type = 'error',
	message = 'Error! cannot access copied data in "http" protocol. Please use "https"',
	config = {},
}) => {
	window.wp.data.dispatch('core/notices').createNotice(type, message, {
		isDismissible: true,
		...config,
	});
};
