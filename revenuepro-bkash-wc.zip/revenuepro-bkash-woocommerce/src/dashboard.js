import { createRoot } from 'react-dom/client';
import { createPortal } from '@wordpress/element';
import AdminMenu from './dashboard/AdminMenu/index';
import Dashboard from './dashboard/index';
import { Provider } from 'react-redux';
import { BrowserRouter as Router } from 'react-router-dom';
import store from './dashboard/redux/store';
import FormBuilder from './dashboard/pages/FormBuilder';
// import './../assets/scss/dashboard.scss';

document.addEventListener('DOMContentLoaded', () => {
	const container = document.getElementById('revenuepro-bkash-wc-wrap');
	const builderContainer = document.getElementById('revenuepro-bkash-wc-builder-root');

	if (builderContainer) {
		const root = createRoot(builderContainer);
		root.render(<FormBuilder />);
	} else if (container) {
		const root = createRoot(container);
		const menuPage = document.getElementById('toplevel_page_revenuepro-bkash-wc');
		function MenuPortal({ children }) {
			if (!menuPage) return null;
			menuPage.innerHTML = '';
			return createPortal(children, menuPage);
		}
		root.render(
			<Provider store={store}>
				<Router>
					<MenuPortal>
						<AdminMenu />
					</MenuPortal>
					<Dashboard />
				</Router>
			</Provider>
		);
	}
});
