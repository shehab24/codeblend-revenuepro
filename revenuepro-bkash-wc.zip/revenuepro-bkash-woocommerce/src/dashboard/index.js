import React from 'react';
import { useQuery } from '@Utils/helper';
import DashboardPage from './pages/dashboard';
import Settings from './pages/Settings';
import FeatureRequest from './pages/FeatureRequest';
// import Notification from '../components/Notification';

import Logs from './pages/Logs';
import AbandonedCarts from './pages/AbandonedCarts';

const renderSwitch = (page) => {
	switch (page) {
		case 'revenuepro-bkash-wc':
			return <DashboardPage />;
		case 'revenuepro-bkash-wc-settings':
			return <Settings />;
		case 'revenuepro-bkash-wc-feature-request':
			return <FeatureRequest />;
		case 'revenuepro-bkash-wc-logs':
			return <Logs />;
        case 'revenuepro-abandoned-carts':
            return <AbandonedCarts />;
		default:
			return <DashboardPage />;
	}
};

export default function Dashboard() {
	const query = useQuery();
	return (
		<React.Fragment>
			{/* <Notification /> */}
			{renderSwitch(
				query.get('page'),
				parseInt(query.get('id')),
				query.get('action'),
				query.get('path')
			)}
		</React.Fragment>
	);
}
