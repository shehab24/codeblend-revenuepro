import { GET_BLOCK_VISIBILITY, SAVE_BLOCK_VISIBILITY } from '../types/blocks';

function blocks(state = {}, action) {
	const payload = action.payload;
	switch (action.type) {
		case GET_BLOCK_VISIBILITY:
			return {
				...state,
				data: payload,
			};

		case SAVE_BLOCK_VISIBILITY:
			return {
				...state,
				data: payload,
			};

		default:
			return state;
	}
}
export default blocks;
