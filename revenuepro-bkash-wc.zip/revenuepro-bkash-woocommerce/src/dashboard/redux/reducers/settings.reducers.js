import { FETCH_SETTINGS, UPDATE_SETTINGS } from '../types/settings.js';

function settings(state = {}, action) {
	const payload = action.payload;
	switch (action.type) {
		case FETCH_SETTINGS:
			return {
				...state,
				data: payload,
			};

		case UPDATE_SETTINGS:
			return {
				...state,
				data: {
					...state.data,
					...payload,
				},
			};

		default:
			return state;
	}
}
export default settings;
