import { combineReducers } from 'redux';
import adminmenu from './adminmenu.reducers';
import settings from './settings.reducers';
import notification from './notification.reducers';
import blocks from './blocks.reducers';

export default combineReducers({
	adminmenu,
	settings,
	notification,
	blocks,
});
