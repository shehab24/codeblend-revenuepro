import { SHOW_NOTIFICATION } from '../types/notification';

function notification(
	state = {
		message: '',
		showNotification: false,
		type: 'success',
	},
	action
) {
	const payload = action.payload;
	switch (action.type) {
		case SHOW_NOTIFICATION:
			return {
				message: payload.message,
				showNotification: payload.isShow,
				type: payload.type,
			};
		default:
			return state;
	}
}

export default notification;
