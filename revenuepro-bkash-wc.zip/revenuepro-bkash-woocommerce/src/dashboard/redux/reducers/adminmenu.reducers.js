import { FETCH_ADMIN_MENU } from '../types/adminmenu';
import { menu } from '@Utils/helper';

function adminmenu(state = JSON.parse(menu), action) {
	const payload = action.payload;
	switch (action.type) {
		case FETCH_ADMIN_MENU:
			return {
				...payload,
			};
		default:
			return state;
	}
}
export default adminmenu;
