import { FETCH_SETTINGS, UPDATE_SETTINGS } from '../types/settings.js';
import { makeRequest } from '@Utils/helper';
import { __ } from '@wordpress/i18n';
import { showNotification } from './notification.actions.js';

export const FetchSettings = () => async (dispatch) => {
	try {
		return await makeRequest({
			action: 'ablocks/get_settings',
		}).then((res) => {
			dispatch({
				type: FETCH_SETTINGS,
				payload: res?.data?.data,
			});
			return res;
		});
	} catch (e) {
		dispatch(
			showNotification(
				e?.response?.data?.message ?? e?.message,
				true,
				'error'
			)
		);
	}
};

export const updateSettings =
	(values, action = 'ablocks/save_settings') =>
	async (dispatch) => {
		try {
			return await makeRequest({
				action,
				...values,
			}).then((res) => {
				if (res.data.success) {
					dispatch({
						type: UPDATE_SETTINGS,
						payload: values,
					});
					dispatch(
						showNotification(
							__('Settings Saved!', 'ablocks'),
							true,
							'success'
						)
					);
					return res;
				}
				dispatch(showNotification(res.data.data, true, 'error'));
			});
		} catch (e) {
			dispatch(
				showNotification(
					e?.response?.data?.message ?? e?.message,
					true,
					'error'
				)
			);
		}
	};
