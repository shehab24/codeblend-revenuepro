import { FETCH_ADMIN_MENU } from './../types/adminmenu';
import { makeRequest } from '@Utils/helper';
import { showNotification } from '@Redux/actions/notification.actions';

export const fetchAdminMenuItems = () => async (dispatch) => {
	return makeRequest({
		action: 'ablocks/get_admin_menu_items',
	}).then(
		(res) => {
			dispatch({
				type: FETCH_ADMIN_MENU,
				payload: JSON.parse(res.data?.data),
			});
			return res;
		},
		(e) => {
			dispatch(
				showNotification(
					e?.response?.data?.message ?? e?.message,
					true,
					'error'
				)
			);
		}
	);
};
