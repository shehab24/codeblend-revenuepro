import { SHOW_NOTIFICATION } from '../types/notification';

export const showNotification = (message, isShow, type) => (dispatch) => {
	dispatch({
		type: SHOW_NOTIFICATION,
		payload: {
			message,
			isShow,
			type,
		},
	});
};
