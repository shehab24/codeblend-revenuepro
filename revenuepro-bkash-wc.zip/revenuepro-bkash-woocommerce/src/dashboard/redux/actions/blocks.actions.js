import { GET_BLOCK_VISIBILITY, SAVE_BLOCK_VISIBILITY } from '../types/blocks';
import { makeRequest } from '@Utils/helper';
import { showNotification } from './notification.actions.js';

export const fetchBlockVisibility = () => async (dispatch) => {
	return makeRequest({
		action: 'ablocks/get_blocks_visibility',
	}).then(
		(res) => {
			dispatch({
				type: GET_BLOCK_VISIBILITY,
				payload: res.data.data,
			});
			return res;
		},
		(e) => {
			dispatch();
			showNotification(
				e?.response?.data?.message ?? e?.message,
				true,
				'error'
			);
		}
	);
};

export const saveBlockVisibility = (blockData) => async (dispatch) => {
	return makeRequest({
		action: 'ablocks/save_block_visibility',
		...blockData,
	}).then(
		(res) => {
			dispatch({
				type: SAVE_BLOCK_VISIBILITY,
				payload: res.data.data,
			});
			return res;
		},
		(e) => {
			dispatch();
			showNotification(
				e?.response?.data?.message ?? e?.message,
				true,
				'error'
			);
		}
	);
};
