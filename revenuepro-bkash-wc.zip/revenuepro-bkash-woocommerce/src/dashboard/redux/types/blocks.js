export const GET_BLOCK_VISIBILITY = 'get_blocks_visibility';
export const SAVE_BLOCK_VISIBILITY = 'save_block_visibility';
