export const FETCH_SETTINGS = 'fetch_settings';
export const UPDATE_SETTINGS = 'update_settings';
