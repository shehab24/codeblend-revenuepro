import React from 'react';
import { __ } from '@wordpress/i18n';
import { useQuery, plugin_root_url, route_path } from '@Utils/helper';
import { useNavigate } from 'react-router-dom';
import './styles.scss';

export default function TopBar(props) {
	const location = useQuery();
	const navigate = useNavigate();
	const page = location.get('page');
	const path = location.get('path');

	const onClickHandler = (paramPage = '', paramPath = '') => {
		navigate(
			`${route_path}admin.php?page=${paramPage}${
				paramPath ? `&path=${paramPath}` : ''
			}`,
			{ replace: true }
		);
	};
	return (
		<React.Fragment>
			<div className="ablocks-topbar">
				<div className="ablocks-topbar__entry-left">
					<img
						className="ablocks-entry-icon"
						src={plugin_root_url + 'assets/images/logo.svg'}
						alt={__('logo', 'ablocks')}
					/>
					<ul className="ablocks-topbar__menu">
						<li
							className={`ablocks-topbar-menu-item${
								page === 'ablocks' && !path
									? ' ablocks-topbar-menu-item--selected'
									: ''
							}`}
							role="presentation"
							onClick={() => onClickHandler('ablocks')}
						>
							<span className="ablocks-topbar__menu__title">
								{__('Welcome', 'ablocks')}
							</span>
						</li>
						<li
							className={`ablocks-topbar-menu-item${
								path === 'blocks'
									? ' ablocks-topbar-menu-item--selected'
									: ''
							}`}
							role="presentation"
							onClick={() => onClickHandler('ablocks', 'blocks')}
						>
							<span className="ablocks-topbar__menu__title">
								{__('Blocks/ Extensions', 'ablocks')}
							</span>
						</li>
						<li
							className={`ablocks-topbar-menu-item${
								page === 'ablocks-settings'
									? ' ablocks-topbar-menu-item--selected'
									: ''
							}`}
							role="presentation"
							onClick={() => onClickHandler('ablocks-settings')}
						>
							<span className="ablocks-topbar__menu__title">
								{__('Settings', 'ablocks')}
							</span>
						</li>
					</ul>
				</div>
				<div className="ablocks-topbar__entry-right">
					{props?.render && props?.render()}
				</div>
			</div>
		</React.Fragment>
	);
}
