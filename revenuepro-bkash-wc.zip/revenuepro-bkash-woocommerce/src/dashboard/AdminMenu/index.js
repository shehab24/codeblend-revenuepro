import React, { useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { __ } from '@wordpress/i18n';
import { route_path, toplevel_menu_icon_url, is_pro } from '@Utils/helper';
import { useSelector } from 'react-redux';
import MenuItem from './MenuItem';

function useQuery() {
	const { search } = useLocation();

	return React.useMemo(() => new URLSearchParams(search), [search]);
}
const AdminMenu = () => {
	const adminmenu = useSelector((state) => state.adminmenu);
	const location = useQuery();
	const page = location.get('page');
	const path = location.get('path');
	useEffect(() => {
		let pageTitle = adminmenu[page]?.title || __('Form Builder', 'revenuepro-bkash-wc');
		if (page === 'revenuepro-bkash-wc-create') {
			pageTitle = __('Add New Form', 'revenuepro-bkash-wc');
		} else if (page === 'revenuepro-bkash-wc-edit') {
			pageTitle = __('Edit Form', 'revenuepro-bkash-wc');
		}
		document.title = pageTitle + ' - ' + __('RevenuePro', 'revenuepro-bkash-wc');
	}, [page, adminmenu]);

	return (
		<React.Fragment>
			<Link
				to={`${route_path}admin.php?page=revenuepro-bkash-wc`}
				className="wp-has-submenu wp-has-current-submenu wp-menu-open menu-top toplevel_page_revenuepro-bkash-wc menu-top-last"
				aria-haspopup="false"
			>
				<div className="wp-menu-arrow">
					<div></div>
				</div>
				<div
					className={`wp-menu-image ${toplevel_menu_icon_url && toplevel_menu_icon_url.includes('dashicons') ? `dashicons-before ${toplevel_menu_icon_url}` : 'svg'}`}
					aria-hidden="true"
					style={toplevel_menu_icon_url && !toplevel_menu_icon_url.includes('dashicons') ? {
						backgroundImage: `url('${toplevel_menu_icon_url}')`,
					} : {}}
				>
					<br />
				</div>
				<div className="wp-menu-name">{__('RevenuePro', 'revenuepro-bkash-wc')}</div>
			</Link>
			<ul className="wp-submenu wp-submenu-wrap">
				<li className="wp-submenu-head" aria-hidden="true">
					{__('RevenuePro', 'revenuepro-bkash-wc')}
				</li>
				{Object.entries(adminmenu).map(([key, item], index) => {
					if (['revenuepro-bkash-wc-get-pro', 'revenuepro-bkash-wc-license', 'revenuepro-bkash-wc-get-pro'].includes(key)) {
						return null;
					}
					const menuItemClassName =
						index === 0 ? 'wp-first-item ' : '';

					// Highlight "All Forms" when on create/edit pages
					const isCurrentPage = page === key ||
						(key === 'revenuepro-bkash-wc-all-forms' && ['revenuepro-bkash-wc-create', 'revenuepro-bkash-wc-edit', 'revenuepro-bkash-wc-submissions'].includes(page));

					return (
						<MenuItem
							className={
								isCurrentPage
									? menuItemClassName + 'current'
									: menuItemClassName
							}
							key={index}
							parent={key}
							currentPath={path}
							subMenuItems={item.sub_items}
						>
							<Link to={`${route_path}admin.php?page=${key}`}>
								{item.title}
								{item?.sub_items && (
									<span className="revenuepro-bkash-wc-icon revenuepro-bkash-wc-icon--angle-right"></span>
								)}
							</Link>
						</MenuItem>
					);
				})}
				<>
					{/* {is_pro ? (
						<li
							className={
								page === 'revenuepro-bkash-wc-license' ? 'current' : ''
							}
						>
							<a href="admin.php?page=revenuepro-bkash-wc-license">
								{__('License', 'revenuepro-bkash-wc')}
							</a>
						</li>
					) : (
						<li
							className={
								page === 'revenuepro-bkash-wc-get-pro' ? 'current' : ''
							}
						>
							<a href="admin.php?page=revenuepro-bkash-wc-get-pro">
								<span className="dashicons dashicons-awards revenuepro-bkash-wc-blue-color"></span>{' '}
								{__('Get Pro', 'revenuepro-bkash-wc')}
							</a>
						</li>
					)} */}
				</>
			</ul>
		</React.Fragment>
	);
};

export default AdminMenu;
