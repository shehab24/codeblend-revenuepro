import React, { useState, useEffect } from 'react';
import { __ } from '@wordpress/i18n';

// Modern Toggle Switch Component
const Toggle = ({ checked, onChange, label }) => (
	<label style={{ display: 'flex', alignItems: 'center', gap: '12px', cursor: 'pointer' }}>
		<div style={{ position: 'relative', width: '44px', height: '24px' }}>
			<input
				type="checkbox"
				checked={checked}
				onChange={onChange}
				style={{ opacity: 0, width: 0, height: 0 }}
			/>
			<span style={{
				position: 'absolute',
				cursor: 'pointer',
				top: 0, left: 0, right: 0, bottom: 0,
				backgroundColor: checked ? '#2563eb' : '#cbd5e1',
				transition: '.3s',
				borderRadius: '34px',
			}}></span>
			<span style={{
				position: 'absolute',
				content: '""',
				height: '18px',
				width: '18px',
				left: checked ? '22px' : '4px',
				bottom: '3px',
				backgroundColor: 'white',
				transition: '.3s',
				borderRadius: '50%',
				boxShadow: '0 1px 2px rgba(0,0,0,0.1)'
			}}></span>
		</div>
		<span style={{ fontSize: '14px', fontWeight: '500', color: '#334155' }}>{label}</span>
	</label>
);

// Modern Input Component
const InputGroup = ({ label, type = "text", value, onChange, placeholder, helpText, multiline = false, disabled = false }) => (
	<div style={{ marginBottom: '24px' }}>
		<label style={{ display: 'block', marginBottom: '8px', fontSize: '14px', fontWeight: '600', color: '#334155' }}>
			{label}
		</label>
		{multiline ? (
			<textarea
				value={value}
				onChange={onChange}
				placeholder={placeholder}
				disabled={disabled}
				rows="4"
				style={{
					width: '100%',
					padding: '12px 16px',
					fontSize: '14px',
					border: '1px solid #e2e8f0',
					borderRadius: '8px',
					backgroundColor: disabled ? '#e2e8f0' : '#f8fafc',
					color: '#1e293b',
					outline: 'none',
					transition: 'all 0.2s',
					fontFamily: 'inherit',
					cursor: disabled ? 'not-allowed' : 'text'
				}}
				onFocus={(e) => {
					if (!disabled) {
						e.target.style.borderColor = '#3b82f6';
						e.target.style.backgroundColor = '#fff';
						e.target.style.boxShadow = '0 0 0 3px rgba(59, 130, 246, 0.1)';
					}
				}}
				onBlur={(e) => {
					e.target.style.borderColor = '#e2e8f0';
					e.target.style.backgroundColor = disabled ? '#e2e8f0' : '#f8fafc';
					e.target.style.boxShadow = 'none';
				}}
			/>
		) : (
			<input
				type={type}
				value={value}
				onChange={onChange}
				placeholder={placeholder}
				disabled={disabled}
				style={{
					width: '100%',
					padding: '12px 16px',
					fontSize: '14px',
					border: '1px solid #e2e8f0',
					borderRadius: '8px',
					backgroundColor: disabled ? '#e2e8f0' : '#f8fafc',
					color: '#1e293b',
					outline: 'none',
					transition: 'all 0.2s',
					cursor: disabled ? 'not-allowed' : 'text'
				}}
				onFocus={(e) => {
					if (!disabled) {
						e.target.style.borderColor = '#3b82f6';
						e.target.style.backgroundColor = '#fff';
						e.target.style.boxShadow = '0 0 0 3px rgba(59, 130, 246, 0.1)';
					}
				}}
				onBlur={(e) => {
					e.target.style.borderColor = '#e2e8f0';
					e.target.style.backgroundColor = disabled ? '#e2e8f0' : '#f8fafc';
					e.target.style.boxShadow = 'none';
				}}
			/>
		)}
		{helpText && <p style={{ margin: '6px 0 0', fontSize: '13px', color: '#64748b' }}>{helpText}</p>}
	</div>
);

// Modern Select Component
const SelectGroup = ({ label, value, onChange, options, helpText }) => (
	<div style={{ marginBottom: '24px' }}>
		<label style={{ display: 'block', marginBottom: '8px', fontSize: '14px', fontWeight: '600', color: '#334155' }}>
			{label}
		</label>
		<select
			value={value}
			onChange={onChange}
			style={{
				width: '100%',
				padding: '12px 16px',
				fontSize: '14px',
				border: '1px solid #e2e8f0',
				borderRadius: '8px',
				backgroundColor: '#f8fafc',
				color: '#1e293b',
				outline: 'none',
				transition: 'all 0.2s',
				appearance: 'none',
				backgroundImage: `url("data:image/svg+xml;charset=US-ASCII,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22292.4%22%20height%3D%22292.4%22%3E%3Cpath%20fill%3D%22%23475569%22%20d%3D%22M287%2069.4a17.6%2017.6%200%200%200-13-5.4H18.4c-5%200-9.3%201.8-12.9%205.4A17.6%2017.6%200%200%200%200%2082.2c0%205%201.8%209.3%205.4%2012.9l128%20127.9c3.6%203.6%207.8%205.4%2012.8%205.4s9.2-1.8%2012.8-5.4L287%2095c3.5-3.5%205.4-7.8%205.4-12.8%200-5-1.9-9.2-5.5-12.8z%22%2F%3E%3C%2Fsvg%3E")`,
				backgroundRepeat: 'no-repeat',
				backgroundPosition: 'right 16px center',
				backgroundSize: '12px'
			}}
			onFocus={(e) => {
				e.target.style.borderColor = '#3b82f6';
				e.target.style.backgroundColor = '#fff';
				e.target.style.boxShadow = '0 0 0 3px rgba(59, 130, 246, 0.1)';
			}}
			onBlur={(e) => {
				e.target.style.borderColor = '#e2e8f0';
				e.target.style.backgroundColor = '#f8fafc';
				e.target.style.boxShadow = 'none';
			}}
		>
			{options && options.map(opt => (
				<option key={opt.value} value={opt.value}>{opt.label}</option>
			))}
		</select>
		{helpText && <p style={{ margin: '6px 0 0', fontSize: '13px', color: '#64748b' }}>{helpText}</p>}
	</div>
);

const LEVEL_STYLE = {
	error:   { bg: '#fef2f2', color: '#dc2626', border: '#fca5a5' },
	warning: { bg: '#fffbeb', color: '#d97706', border: '#fcd34d' },
	info:    { bg: '#eff6ff', color: '#2563eb', border: '#bfdbfe' },
	debug:   { bg: '#f8fafc', color: '#64748b', border: '#e2e8f0' },
};

function DebugLogViewer() {
	const [logLines, setLogLines] = useState([]);
	const [logMeta, setLogMeta] = useState(null);
	const [logLoading, setLogLoading] = useState(false);
	const [logMsg, setLogMsg] = useState('');

	const fetchLog = () => {
		setLogLoading(true);
		fetch('/wp-json/revenuepro-bkash-wc/v1/debug-log', {
			headers: { 'X-WP-Nonce': window.RevenueProGlobal?.nonce || '' }
		})
			.then(r => r.json())
			.then(d => {
				setLogLines(d.lines || []);
				setLogMeta(d);
				setLogMsg(d.message || '');
			})
			.finally(() => setLogLoading(false));
	};

	const clearLog = () => {
		fetch('/wp-json/revenuepro-bkash-wc/v1/debug-log', {
			method: 'DELETE',
			headers: { 'X-WP-Nonce': window.RevenueProGlobal?.nonce || '' }
		}).then(() => { setLogLines([]); setLogMeta(null); setLogMsg('Log cleared.'); });
	};

	const writeTestLog = () => {
		fetch('/wp-json/revenuepro-bkash-wc/v1/test-log', {
			method: 'POST',
			headers: { 'X-WP-Nonce': window.RevenueProGlobal?.nonce || '', 'Content-Type': 'application/json' },
			body: JSON.stringify({ level: 'info', message: 'Test log from RevenuePro dashboard — ' + new Date().toLocaleTimeString() })
		})
			.then(r => r.json())
			.then(d => {
				if (d.success) { setTimeout(fetchLog, 300); }
				else { setLogMsg(d.message || 'Could not write test log.'); }
			});
	};

	useEffect(() => { fetchLog(); }, []);

	return (
		<div style={{ marginTop: '16px', border: '1px solid #334155', borderRadius: '8px', overflow: 'hidden', background: '#0f172a' }}>
			<div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '10px 16px', background: '#1e293b', borderBottom: '1px solid #334155' }}>
				<div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
					<span style={{ width: '8px', height: '8px', borderRadius: '50%', background: '#22c55e', display: 'inline-block' }}></span>
					<span style={{ color: '#94a3b8', fontSize: '12px', fontFamily: 'monospace' }}>
						{logMeta?.file || 'revenuepro-bkash.log'}
						{logMeta?.total != null && <span style={{ marginLeft: '8px', color: '#4ade80' }}>({logMeta.total} total lines)</span>}
					</span>
				</div>
				<div style={{ display: 'flex', gap: '8px' }}>
					<button onClick={(e) => { e.preventDefault(); writeTestLog(); }}
						style={{ padding: '4px 12px', background: '#14532d', border: 'none', borderRadius: '4px', color: '#4ade80', cursor: 'pointer', fontSize: '12px', display: 'flex', alignItems: 'center', gap: '4px' }}>
						<span className="dashicons dashicons-edit" style={{ fontSize: '14px', width: '14px', height: '14px' }}></span>
						Test Log
					</button>
					<button onClick={(e) => { e.preventDefault(); fetchLog(); }} disabled={logLoading}
						style={{ padding: '4px 12px', background: '#334155', border: 'none', borderRadius: '4px', color: '#94a3b8', cursor: 'pointer', fontSize: '12px', display: 'flex', alignItems: 'center', gap: '4px' }}>
						<span className="dashicons dashicons-update" style={{ fontSize: '14px', width: '14px', height: '14px' }}></span>
						{logLoading ? 'Loading...' : 'Refresh'}
					</button>
					<button onClick={(e) => { e.preventDefault(); clearLog(); }}
						style={{ padding: '4px 12px', background: '#450a0a', border: 'none', borderRadius: '4px', color: '#fca5a5', cursor: 'pointer', fontSize: '12px', display: 'flex', alignItems: 'center', gap: '4px' }}>
						<span className="dashicons dashicons-trash" style={{ fontSize: '14px', width: '14px', height: '14px' }}></span>
						Clear Log
					</button>
				</div>
			</div>
			<div style={{ maxHeight: '400px', overflowY: 'auto', padding: '8px 0', fontFamily: 'monospace' }}>
				{logMsg && logLines.length === 0 && (
					<div style={{ padding: '24px', textAlign: 'center', color: '#64748b', fontSize: '13px' }}>{logMsg}</div>
				)}
				{logLines.map((line, i) => {
					const s = LEVEL_STYLE[line.level] || LEVEL_STYLE.info;
					return (
						<div key={i} style={{ display: 'flex', gap: '10px', padding: '5px 16px', borderBottom: '1px solid #1e293b', alignItems: 'flex-start' }}>
							<span style={{ color: '#475569', fontSize: '11px', whiteSpace: 'nowrap', paddingTop: '2px', minWidth: '130px' }}>{line.time}</span>
							<span style={{ display: 'inline-block', padding: '1px 6px', borderRadius: '3px', fontSize: '10px', fontWeight: '700', background: s.bg, color: s.color, border: `1px solid ${s.border}`, minWidth: '46px', textAlign: 'center', flexShrink: 0 }}>{line.level.toUpperCase()}</span>
							<span style={{ color: '#e2e8f0', fontSize: '12px', wordBreak: 'break-all', lineHeight: '1.5' }}>{line.message}</span>
						</div>
					);
				})}
			</div>
		</div>
	);
}

export default function Settings() {
	// Get initial tab from URL hash or default to 'payment'
	const getInitialTab = () => {
		const hash = window.location.hash.replace('#', '');
		const validTabs = ['payment', 'partial', 'fraud', 'recovery', 'sms', 'others', 'license', 'courier', 'tracking', 'quick'];
		return validTabs.includes(hash) ? hash : 'payment';
	};

	const [activeTab, setActiveTab] = useState(getInitialTab());
	const [smsTemplateTab, setSmsTemplateTab] = useState('success'); // success or failure
	const [settings, setSettings] = useState({
		bkash_enabled: false,
		bkash_payment_mode: 'automated',
		bkash_is_sandbox: true,
		bkash_app_key: '',
		bkash_app_secret: '',
		bkash_username: '',
		bkash_password: '',
		bkash_success_url: '',
		bkash_failure_url: '',
		bkash_logo_url: '',
		// Manual bKash Settings
		bkash_manual_number: '',
		bkash_manual_account_type: 'personal',
		bkash_manual_instructions: '',
		bkash_manual_title: 'bKash (Send Money)',
		bkash_manual_description: 'Send money to our bKash number and enter your Transaction ID below.',
		bkash_manual_qr_url: '',
		bkash_manual_sms_token: '',
		bkash_manual_display_mode: 'both',
		// Partial Payment
		bkash_partial_enabled: false,
		bkash_partial_type: 'fixed',
		bkash_partial_amount: '100',
		// SMS Settings
		sms_enabled: false,
		sms_trigger_condition: 'always',
		sms_success_statuses: ['processing', 'completed'],
		sms_api_url: 'http://bulksmsbd.net/api/smsapi',
		sms_api_key: '',
		sms_sender_id: '',
		sms_failure_message_template: 'Dear {customer_name}, your bKash payment for order #{order_id} of {order_total} could not be completed. Please try again or contact us. - {site_name}',
		sms_message_template: 'Dear {customer_name}, your order #{order_id} of {order_total} has been confirmed. Payment received via bKash. TrxID: {trx_id}. Thank you for shopping with {site_name}!',
        
		// Fraud Detection Settings
		fraud_enabled: false,
		fraud_api_key: '',
		fraud_success_threshold: '70',
		fraud_block_zero_ratio: false,
		fraud_action: 'disable_cod',
		fraud_block_message: 'Your order cannot be processed due to high courier cancellation risk. Please contact support.',
		// Anti-Spam Order Prevention
		spam_phone_enabled: false,
		spam_phone_limit: '3',
		spam_phone_duration: '24',
		spam_email_enabled: false,
		spam_email_limit: '3',
		spam_email_duration: '24',
		spam_ip_enabled: false,
		spam_ip_limit: '5',
		spam_ip_duration: '24',
		spam_fingerprint_enabled: false,
		spam_fingerprint_limit: '5',
		spam_fingerprint_duration: '24',
		// Courier Integration
		courier_auto_dispatch: false,
		courier_trigger_status: 'ready-to-ship',
		courier_default: 'steadfast',

		// Steadfast
		courier_steadfast_enabled: false,
		courier_steadfast_api_key: '',
		courier_steadfast_secret_key: '',

		// Pathao
		courier_pathao_enabled: false,
		courier_pathao_client_id: '',
		courier_pathao_client_secret: '',
		courier_pathao_username: '',
		courier_pathao_password: '',
		courier_pathao_store_id: '',

		// Checkout Field Editor Settings
		checkout_fields_config: JSON.stringify({
			billing: {
				billing_first_name: { enabled: true, required: true, label: '', placeholder: '' },
				billing_last_name: { enabled: true, required: true, label: '', placeholder: '' },
				billing_company: { enabled: true, required: false, label: '', placeholder: '' },
				billing_country: { enabled: true, required: true, label: '', placeholder: '' },
				billing_address_1: { enabled: true, required: true, label: '', placeholder: '' },
				billing_address_2: { enabled: true, required: false, label: '', placeholder: '' },
				billing_city: { enabled: true, required: true, label: '', placeholder: '' },
				billing_state: { enabled: true, required: true, label: '', placeholder: '' },
				billing_postcode: { enabled: true, required: false, label: '', placeholder: '' },
				billing_phone: { enabled: true, required: true, label: '', placeholder: '' },
				billing_email: { enabled: true, required: true, label: '', placeholder: '' }
			},
			shipping: {
				shipping_first_name: { enabled: true, required: true, label: '', placeholder: '' },
				shipping_last_name: { enabled: true, required: true, label: '', placeholder: '' },
				shipping_company: { enabled: true, required: false, label: '', placeholder: '' },
				shipping_country: { enabled: true, required: true, label: '', placeholder: '' },
				shipping_address_1: { enabled: true, required: true, label: '', placeholder: '' },
				shipping_address_2: { enabled: true, required: false, label: '', placeholder: '' },
				shipping_city: { enabled: true, required: true, label: '', placeholder: '' },
				shipping_state: { enabled: true, required: true, label: '', placeholder: '' },
				shipping_postcode: { enabled: true, required: false, label: '', placeholder: '' },
				shipping_phone: { enabled: true, required: false, label: '', placeholder: '' }
			},
			order: {
				order_comments: { enabled: true, required: false, label: '', placeholder: '' }
			}
		}),
		general_custom_order_button: '',
		general_enable_logging: false,
		// License Settings
		license_key: '',
		license_plan: 'Free / Unlicensed',
		account_email: 'None',
		// Abandoned Cart Settings
		abandoned_cart_enabled: false,
		abandoned_cart_wait_time: '60', // minutes
		abandoned_cart_email_enabled: true, // send recovery email
		abandoned_cart_sms_enabled: true,   // send recovery SMS
		abandoned_cart_sms_template: 'Hi {name}, you left items worth {cart_total} in your cart at {site_name}. Complete your order now: {checkout_url}',
		// Tracking & Pixel
		tracking_fb_pixel_enabled: false,
		tracking_fb_pixel_id: '',
		tracking_fb_capi_enabled: false,
		tracking_fb_capi_token: '',
		tracking_fb_test_code: '',
		tracking_fb_domain_verification: '',
		tracking_purchase_trigger: 'checkout',
		tracking_purchase_status_trigger: 'wc-completed',
		tracking_events_page_view: true,
		tracking_events_view_content: true,
		tracking_events_add_to_cart: true,
		tracking_events_initiate_checkout: true,
		tracking_events_purchase: true,
		tracking_events_search: false,
		tracking_events_add_to_wishlist: false,
		tracking_google_analytics_enabled: false,
		tracking_google_analytics_id: '',
		tracking_google_ads_enabled: false,
		tracking_google_ads_id: '',
		tracking_google_ads_conversion_label: '',
		tracking_utm_enabled: false,
		tracking_custom_event_name: '',
		quick_order_enabled: false,
		quick_order_button_text: 'ক্যাশ অন ডেলিভারিতে অর্ডার করুন',
		quick_order_button_color: '#16a34a',
		quick_order_popup_title: 'ক্যাশ অন ডেলিভারিতে অর্ডার করতে আপনার তথ্য দিন',
		quick_order_confirm_text: 'ক্যাশ অন ডেলিভারিতে অর্ডার কনফার্ম করুন',
	});
	const [checkoutEditorTab, setCheckoutEditorTab] = useState('billing');
	const [loading, setLoading] = useState(false);
	const [saving, setSaving] = useState(false);
	const [isVerifying, setIsVerifying] = useState(false);
	const [showRevokeModal, setShowRevokeModal] = useState(false);
	const [message, setMessage] = useState(null);
	const [showSteadfastToken, setShowSteadfastToken] = useState(false);

	useEffect(() => {
		fetchSettings();
	}, []);

	// Helper: Parse any expiresAt format into milliseconds
	const parseExpiryToMs = (val) => {
		if (!val) return null;
		// If it's a number or numeric string
		const num = Number(val);
		if (!isNaN(num) && num > 0) {
			return num > 9999999999 ? num : num * 1000; // seconds vs ms
		}
		// If it's an ISO date string
		const d = new Date(val);
		if (!isNaN(d.getTime())) {
			return d.getTime();
		}
		return null;
	};

	const isLicenseActive = () => {
		// Must have a plan that isn't free/invalid/expired
		if (!settings.license_plan || settings.license_plan === 'Free / Unlicensed' || settings.license_plan.includes('Invalid') || settings.license_plan.includes('Expired')) return false;
		
		// If there's a JWT token, validate its expiry
		if (settings.license_token) {
			try {
				const payload = JSON.parse(atob(settings.license_token.split('.')[1]));
				const expiryMs = parseExpiryToMs(payload.expiresAt);
				if (expiryMs && Date.now() > expiryMs) return false;
			} catch (e) {
				return false;
			}
		}
		
		// Check stored expiresAt from API (for token-less plans)
		if (settings.license_expires_at) {
			const expiryMs = parseExpiryToMs(settings.license_expires_at);
			if (expiryMs && Date.now() > expiryMs) {
				return false; // Expired!
			}
		}
		
		// Valid plan with no expiry (Lifetime) or not yet expired
		return true;
	};

	const fetchSettings = async () => {
		setLoading(true);
		try {
			const restUrl = window.RevenueProGlobal?.rest_url || '/wp-json/';
			const response = await fetch(`${restUrl}revenuepro-bkash-wc/v1/settings?_t=${Date.now()}`, {
				headers: {
					'Cache-Control': 'no-cache',
					'X-WP-Nonce': window.RevenueProGlobal?.nonce || ''
				}
			});
			if (response.ok) {
				const data = await response.json();
				// Ensure booleans are correctly typed
				if (data.bkash_enabled !== undefined) {
					data.bkash_enabled = data.bkash_enabled === true || data.bkash_enabled === 'true' || data.bkash_enabled === '1' || data.bkash_enabled === 1;
				}
				if (data.bkash_is_sandbox !== undefined) {
					data.bkash_is_sandbox = data.bkash_is_sandbox === true || data.bkash_is_sandbox === 'true' || data.bkash_is_sandbox === '1' || data.bkash_is_sandbox === 1;
				}
				if (data.email_enabled !== undefined) {
					data.email_enabled = data.email_enabled === true || data.email_enabled === 'true' || data.email_enabled === '1' || data.email_enabled === 1;
				}
				if (data.bkash_partial_enabled !== undefined) {
					data.bkash_partial_enabled = data.bkash_partial_enabled === true || data.bkash_partial_enabled === 'true' || data.bkash_partial_enabled === '1' || data.bkash_partial_enabled === 1;
				}
				if (data.sms_enabled !== undefined) {
					data.sms_enabled = data.sms_enabled === true || data.sms_enabled === 'true' || data.sms_enabled === '1' || data.sms_enabled === 1;
				}
				setSettings(prev => ({ ...prev, ...data }));
			}
		} catch (error) {
			console.error('Error fetching settings:', error);
		} finally {
			setLoading(false);
		}
	};

	const handleSave = async (overrideSettings = null) => {
		setSaving(true);
		setMessage(null);
		try {
			const restUrl = window.RevenueProGlobal?.rest_url || '/wp-json/';
			const payloadData = overrideSettings || settings;
			
			const response = await fetch(`${restUrl}revenuepro-bkash-wc/v1/settings`, {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json',
					'X-WP-Nonce': window.RevenueProGlobal?.nonce || ''
				},
				body: JSON.stringify(payloadData)
			});

			if (response.ok) {
				setMessage({ type: 'success', text: __('Settings saved successfully!', 'revenuepro-bkash-wc') });
				setTimeout(() => setMessage(null), 3000);
			} else {
				setMessage({ type: 'error', text: __('Failed to save settings.', 'revenuepro-bkash-wc') });
			}
		} catch (error) {
			console.error('Error saving settings:', error);
			setMessage({ type: 'error', text: __('An error occurred.', 'revenuepro-bkash-wc') });
		} finally {
			setSaving(false);
		}
	};

	const handleChange = (key, value) => {
		setSettings(prev => ({ ...prev, [key]: value }));
	};

	const verifyLicense = async () => {
		setIsVerifying(true);
		setMessage(null);
		try {
			// Node API stores the precise absolute string with trailing slashes
			const rawUrl = window.RevenueProGlobal?.site_url || window.location.origin;
			const domain = rawUrl.endsWith('/') ? rawUrl : rawUrl + '/';

			const apiBase = window.RevenueProGlobal?.api_base_url || 'http://localhost:3000';
			const response = await fetch(`${apiBase}/api/v1/license/verify`, {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json'
				},
				body: JSON.stringify({
					key: settings.license_key,
					email: settings.account_email,
					domain: domain
				})
			});
			const data = await response.json();
			
			console.log("=== REVENUEPRO VERIFICATION DEBUG ===");
			console.log("Status Code:", response.status);
			console.log("Response Body:", data);
			console.log("=====================================");

			if (response.ok && (data.valid === true || data.status === 'success' || data.success || data.plan)) {
				const plan = data.plan || data.data?.plan || data.license_plan || 'Pro / Activated';
				const token = data.token || '';
				// Normalize expiresAt to unix milliseconds for consistent storage
				let expiresAt = '';
				if (data.expiresAt) {
					const parsed = parseExpiryToMs(data.expiresAt);
					expiresAt = parsed ? String(parsed) : '';
				}
				console.log('License expiresAt raw:', data.expiresAt, '→ parsed ms:', expiresAt);
				
				const newSettings = { ...settings, license_plan: plan, license_token: token, license_expires_at: expiresAt };
				setSettings(newSettings);
				
				// Await the save cleanly using overridden logic to ensure it doesn't utilize stale React states
				await handleSave(newSettings);

				setMessage({ type: 'success', text: __('License verified & saved successfully!', 'revenuepro-bkash-wc') });
			} else {
				console.warn("API Verification Failed! Server rejected the request string.");
				setMessage({ type: 'error', text: data.message || data.error || __('Invalid license key or account.', 'revenuepro-bkash-wc') });
				setSettings(prev => ({ ...prev, license_plan: 'Invalid / Blocked' }));
			}
		} catch (error) {
			console.error('License Verification error:', error);
			setMessage({ type: 'error', text: __('Failed to connect to license server. Please verify your node API.', 'revenuepro-bkash-wc') });
		} finally {
			setIsVerifying(false);
			setTimeout(() => setMessage(null), 4000);
		}
	};

	const revokeLicense = async () => {
		setShowRevokeModal(false);
		setIsVerifying(true);
		setMessage(null);
		try {
			const rawUrl = window.RevenueProGlobal?.site_url || window.location.origin;
			const domain = rawUrl.endsWith('/') ? rawUrl : rawUrl + '/';

			// Tell Node API we are revoking it
			await fetch(`${window.RevenueProGlobal?.api_base_url || 'http://localhost:3000'}/api/v1/license/deactivate`, {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json'
				},
				body: JSON.stringify({
					key: settings.license_key,
					domain: domain
				})
			}).catch(e => console.warn('Silently failed to ping remote API on revoke.', e));

			const newSettings = { ...settings, license_plan: 'Free / Unlicensed', license_key: '', account_email: '', license_token: '' };
			setSettings(newSettings);
			await handleSave(newSettings);
			setMessage({ type: 'success', text: __('License successfully disconnected.', 'revenuepro-bkash-wc') });
		} catch (error) {
			console.error('Revoke error:', error);
			setMessage({ type: 'error', text: __('Failed to disconnect license remotely.', 'revenuepro-bkash-wc') });
		} finally {
			setIsVerifying(false);
			setTimeout(() => setMessage(null), 4000);
		}
	};

	const handleTabChange = (tabId) => {
		if (!isLicenseActive() && tabId !== 'license') {
			setMessage({ type: 'error', text: __('Please activate your license to unlock all plugin features.', 'revenuepro-bkash-wc') });
			setActiveTab('license');
			window.location.hash = 'license';
			return;
		}
		setActiveTab(tabId);
		window.location.hash = tabId;
	};

	useEffect(() => {
		if (!loading && settings.hasOwnProperty('license_plan') && !isLicenseActive() && activeTab !== 'license') {
			setActiveTab('license');
			window.location.hash = 'license';
		}
	}, [loading, settings.license_plan, settings.license_token, activeTab]);

	const tabs = [
		{ id: 'payment', label: __('Payment Gateway', 'revenuepro-bkash-wc'), icon: 'dashicons-money-alt' },
		{ id: 'partial', label: __('Partial Payment', 'revenuepro-bkash-wc'), icon: 'dashicons-chart-pie' },
		{ id: 'fraud', label: __('Fraud Detection', 'revenuepro-bkash-wc'), icon: 'dashicons-shield' },
		{ id: 'recovery', label: __('Abandoned Cart', 'revenuepro-bkash-wc'), icon: 'dashicons-cart' },
		{ id: 'sms', label: __('SMS Notification', 'revenuepro-bkash-wc'), icon: 'dashicons-smartphone' },
		{ id: 'courier', label: __('Courier Automation', 'revenuepro-bkash-wc'), icon: 'dashicons-car' },
		{ id: 'tracking', label: __('Tracking & Pixel', 'revenuepro-bkash-wc'), icon: 'dashicons-chart-area' },
		{ id: 'quick', label: __('Quick Order', 'revenuepro-bkash-wc'), icon: 'dashicons-controls-forward' },
		{ id: 'others', label: __('General', 'revenuepro-bkash-wc'), icon: 'dashicons-admin-settings' },
		{ id: 'license', label: __('License', 'revenuepro-bkash-wc'), icon: 'dashicons-admin-network' },
	];

	return (
		<div className="settings-page" style={{
			padding: '40px',
			maxWidth: '1400px',
			margin: '0 auto',
			fontFamily: '"Inter", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif'
		}}>

			{/* Header */}
			<div style={{ marginBottom: '40px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
				<div>
					<h1 style={{ fontSize: '28px', fontWeight: '700', color: '#0f172a', margin: 0, letterSpacing: '-0.5px' }}>
						{__('Settings', 'revenuepro-bkash-wc')}
					</h1>
					<p style={{ margin: '8px 0 0', color: '#64748b', fontSize: '15px' }}>
						{__('Manage your donation form configurations and preferences.', 'revenuepro-bkash-wc')}
					</p>
				</div>
				<button
					onClick={() => handleSave()}
					disabled={saving}
					style={{
						background: '#0f172a',
						color: '#fff',
						border: 'none',
						padding: '12px 24px',
						borderRadius: '8px',
						cursor: saving ? 'not-allowed' : 'pointer',
						opacity: saving ? 0.8 : 1,
						fontWeight: '600',
						fontSize: '14px',
						boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)',
						transition: 'all 0.2s',
						display: 'flex',
						alignItems: 'center',
						gap: '8px'
					}}
				>
					{saving ? (
						<>
							<span className="dashicons dashicons-update" style={{ animation: 'spin 1s linear infinite' }}></span>
							{__('Saving...', 'revenuepro-bkash-wc')}
						</>
					) : (
						<>
							<span className="dashicons dashicons-saved"></span>
							{__('Save Changes', 'revenuepro-bkash-wc')}
						</>
					)}
				</button>
			</div>

			{/* Notification Toast */}
			{message && (
				<div style={{
					position: 'fixed',
					bottom: '30px',
					right: '30px',
					padding: '16px 24px',
					borderRadius: '8px',
					background: message.type === 'success' ? '#10b981' : '#ef4444',
					color: '#fff',
					boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)',
					zIndex: 1000,
					fontWeight: '500',
					animation: 'slideIn 0.3s ease-out'
				}}>
					{message.text}
				</div>
			)}

			<div style={{ display: 'flex', gap: '40px', alignItems: 'flex-start' }}>

				{/* Sidebar Navigation */}
				<div style={{ width: '240px', flexShrink: 0 }}>
					<div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
						{tabs.map(tab => {
							const isLocked = !isLicenseActive() && tab.id !== 'license';
							return (
								<button
									key={tab.id}
									onClick={() => handleTabChange(tab.id)}
									style={{
										padding: '12px 16px',
										background: activeTab === tab.id ? '#fff' : 'transparent',
										border: 'none',
										borderRadius: '8px',
										color: activeTab === tab.id ? '#0f172a' : (isLocked ? '#cbd5e1' : '#64748b'),
										fontWeight: activeTab === tab.id ? '600' : '500',
										cursor: isLocked ? 'not-allowed' : 'pointer',
										fontSize: '14px',
										textAlign: 'left',
										display: 'flex',
										alignItems: 'center',
										justifyContent: 'space-between',
										transition: 'all 0.2s',
										boxShadow: activeTab === tab.id ? '0 1px 3px rgba(0,0,0,0.05)' : 'none'
									}}
								>
									<div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
										<span className={`dashicons ${tab.icon}`} style={{ fontSize: '18px', width: '18px', height: '18px', color: activeTab === tab.id ? '#3b82f6' : 'inherit' }}></span>
										{tab.label}
									</div>
									{isLocked && <span className="dashicons dashicons-lock" style={{ fontSize: '14px', width: '14px', height: '14px', color: '#cbd5e1' }}></span>}
								</button>
							);
						})}
					</div>
				</div>

				{/* Main Content Area */}
				<div style={{ flex: 1 }}>

					{activeTab === 'payment' && (
						<div style={{ animation: 'fadeIn 0.3s ease-out' }}>
							{/* bKash Card */}
							<div style={{ background: '#fff', borderRadius: '16px', padding: '32px', boxShadow: '0 1px 3px rgba(0,0,0,0.05)', border: '1px solid #f1f5f9' }}>
								<div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '30px', paddingBottom: '20px', borderBottom: '1px solid #f1f5f9' }}>
									<div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
										<div style={{ width: '48px', height: '48px', background: '#e2136e', borderRadius: '12px', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontWeight: 'bold', fontSize: '14px', boxShadow: '0 4px 6px -1px rgba(226, 19, 110, 0.2)' }}>bKash</div>
										<div>
											<h3 style={{ margin: 0, fontSize: '18px', fontWeight: '700', color: '#0f172a' }}>bKash Payment</h3>
											<p style={{ margin: '4px 0 0', color: '#64748b', fontSize: '13px' }}>Configure your bKash merchant credentials</p>
										</div>
									</div>
									<Toggle
										label={settings.bkash_enabled ? "Enabled" : "Disabled"}
										checked={settings.bkash_enabled}
										onChange={(e) => handleChange('bkash_enabled', e.target.checked)}
									/>
								</div>

								{settings.bkash_enabled && (
									<div style={{ display: 'grid', gap: '20px' }}>

										{/* Payment Mode Selector */}
										<div style={{ marginBottom: '8px' }}>
											<label style={{ display: 'block', marginBottom: '12px', fontSize: '14px', fontWeight: '600', color: '#334155' }}>
												{__('Payment Mode', 'revenuepro-bkash-wc')}
											</label>
											<div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
												{[
													{ value: 'automated', label: 'Automated (API)', icon: '⚡', desc: 'bKash Tokenized Gateway' },
													{ value: 'manual', label: 'Manual', icon: '📱', desc: 'Customer sends money manually' },
												].map(mode => (
													<div
														key={mode.value}
														onClick={() => handleChange('bkash_payment_mode', mode.value)}
														style={{
															padding: '16px',
															borderRadius: '12px',
															border: settings.bkash_payment_mode === mode.value ? '2px solid #e2136e' : '2px solid #e2e8f0',
															background: settings.bkash_payment_mode === mode.value ? '#fdf2f8' : '#fff',
															cursor: 'pointer',
															transition: 'all 0.2s',
															textAlign: 'center',
														}}
													>
														<div style={{ fontSize: '24px', marginBottom: '6px' }}>{mode.icon}</div>
														<div style={{ fontSize: '14px', fontWeight: '600', color: '#0f172a', marginBottom: '2px' }}>{mode.label}</div>
														<div style={{ fontSize: '11px', color: '#64748b' }}>{mode.desc}</div>
													</div>
												))}
											</div>
										</div>

										{/* Automated Gateway Settings */}
										{settings.bkash_payment_mode === 'automated' && (
											<div style={{ background: '#f8fafc', padding: '24px', borderRadius: '12px', border: '1px solid #e2e8f0' }}>
												<div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '20px', paddingBottom: '14px', borderBottom: '1px solid #e2e8f0' }}>
													<span style={{ fontSize: '18px' }}>⚡</span>
													<div>
														<h4 style={{ margin: 0, fontSize: '15px', fontWeight: '600', color: '#0f172a' }}>Automated bKash (API)</h4>
														<p style={{ margin: '2px 0 0', fontSize: '12px', color: '#64748b' }}>Tokenized checkout via bKash API</p>
													</div>
												</div>

												<div style={{ background: '#fff', padding: '16px', borderRadius: '8px', border: '1px solid #e2e8f0', marginBottom: '16px' }}>
													<Toggle
														label="Sandbox Mode (Test Environment)"
														checked={settings.bkash_is_sandbox}
														onChange={(e) => handleChange('bkash_is_sandbox', e.target.checked)}
													/>
													<p style={{ margin: '8px 0 0 56px', fontSize: '13px', color: '#64748b' }}>
														Enable this to test payments without real money.
													</p>
												</div>

												<div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '24px' }}>
													<InputGroup
														label={__('Username', 'revenuepro-bkash-wc')}
														value={settings.bkash_username}
														onChange={(e) => handleChange('bkash_username', e.target.value)}
														placeholder="e.g. sandboxUser123"
													/>
													<InputGroup
														label={__('Password', 'revenuepro-bkash-wc')}
														type="password"
														value={settings.bkash_password}
														onChange={(e) => handleChange('bkash_password', e.target.value)}
														placeholder="••••••••"
													/>
												</div>

												<div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '24px' }}>
													<InputGroup
														label={__('App Key', 'revenuepro-bkash-wc')}
														value={settings.bkash_app_key}
														onChange={(e) => handleChange('bkash_app_key', e.target.value)}
														placeholder="Enter your App Key"
													/>
													<InputGroup
														label={__('App Secret', 'revenuepro-bkash-wc')}
														type="password"
														value={settings.bkash_app_secret}
														onChange={(e) => handleChange('bkash_app_secret', e.target.value)}
														placeholder="Enter your App Secret"
													/>
												</div>

												<div style={{ display: 'grid', gap: '20px' }}>
													<InputGroup
														label={__('Title', 'revenuepro-bkash-wc')}
														value={settings.bkash_title}
														onChange={(e) => handleChange('bkash_title', e.target.value)}
														placeholder="bKash"
														helpText="Payment method title that the customer will see on your checkout."
													/>

													<InputGroup
														label={__('Description', 'revenuepro-bkash-wc')}
														value={settings.bkash_description}
														onChange={(e) => handleChange('bkash_description', e.target.value)}
														multiline={true}
														placeholder="Pay securely using your bKash mobile wallet"
														helpText="Payment method description that the customer will see on your checkout."
													/>
												</div>
											</div>
										)}

										{/* Manual Gateway Settings */}
										{settings.bkash_payment_mode === 'manual' && (
											<div style={{ background: '#fdf2f8', padding: '24px', borderRadius: '12px', border: '1px solid #fbcfe8' }}>
												<div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '20px', paddingBottom: '14px', borderBottom: '1px solid #fbcfe8' }}>
													<span style={{ fontSize: '18px' }}>📱</span>
													<div>
														<h4 style={{ margin: 0, fontSize: '15px', fontWeight: '600', color: '#0f172a' }}>Manual bKash Payment</h4>
														<p style={{ margin: '2px 0 0', fontSize: '12px', color: '#64748b' }}>Customer sends money to your number & provides TrxID</p>
													</div>
												</div>

												<div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '24px', marginBottom: '20px' }}>
													<InputGroup
														label={__('bKash Number', 'revenuepro-bkash-wc')}
														value={settings.bkash_manual_number}
														onChange={(e) => handleChange('bkash_manual_number', e.target.value)}
														placeholder="e.g. 01XXXXXXXXX"
														helpText="Your bKash number where customers will send money."
													/>
													<SelectGroup
														label={__('Account Type', 'revenuepro-bkash-wc')}
														value={settings.bkash_manual_account_type}
														onChange={(e) => handleChange('bkash_manual_account_type', e.target.value)}
														options={[
															{ value: 'personal', label: 'Personal' },
															{ value: 'agent', label: 'Agent' },
															{ value: 'merchant', label: 'Merchant' },
														]}
														helpText="Type of bKash account displayed to customers."
													/>
												</div>

												<div style={{ marginBottom: '20px' }}>
													<SelectGroup
														label={__('Checkout Display Mode', 'revenuepro-bkash-wc')}
														value={settings.bkash_manual_display_mode || 'both'}
														onChange={(e) => handleChange('bkash_manual_display_mode', e.target.value)}
														options={[
															{ value: 'both', label: 'Show Both QR Code and Number' },
															{ value: 'number', label: 'Show Number Only' },
															{ value: 'qr_code', label: 'Show QR Code Only' },
														]}
														helpText="Choose whether to show the copyable number, the QR code, or both to the customer."
													/>
												</div>

												<InputGroup
													label={__('Payment Instructions', 'revenuepro-bkash-wc')}
													value={settings.bkash_manual_instructions}
													onChange={(e) => handleChange('bkash_manual_instructions', e.target.value)}
													multiline={true}
													placeholder="e.g. Please Send Money to the above number and enter your TrxID below."
													helpText="Additional instructions shown to customers on checkout."
												/>

												<div style={{ display: 'grid', gap: '20px', marginBottom: '20px' }}>
													<InputGroup
														label={__('Checkout Title', 'revenuepro-bkash-wc')}
														value={settings.bkash_manual_title}
														onChange={(e) => handleChange('bkash_manual_title', e.target.value)}
														placeholder="bKash (Send Money)"
														helpText="Payment method name the customer sees on checkout."
													/>
												</div>

												{/* bKash QR Code Upload */}
												<div style={{ marginTop: '20px', marginBottom: '20px' }}>
													<label style={{ display: 'block', marginBottom: '8px', fontSize: '14px', fontWeight: '600', color: '#334155' }}>
														{__('bKash Personal QR Code', 'revenuepro-bkash-wc')}
													</label>
													<div style={{ display: 'flex', gap: '16px', alignItems: 'flex-start' }}>
														{settings.bkash_manual_qr_url && (
															<div style={{
																width: '80px',
																height: '80px',
																borderRadius: '8px',
																border: '1px solid #e2e8f0',
																padding: '8px',
																display: 'flex',
																alignItems: 'center',
																justifyContent: 'center',
																background: '#fff'
															}}>
																<img src={settings.bkash_manual_qr_url} alt="QR Code" style={{ maxWidth: '100%', maxHeight: '100%', objectFit: 'contain' }} />
															</div>
														)}
														<div style={{ flex: 1 }}>
															<div style={{ display: 'flex', gap: '10px' }}>
																<input
																	type="text"
																	readOnly
																	value={settings.bkash_manual_qr_url || ''}
																	placeholder="No QR code selected"
																	style={{
																		flex: 1,
																		padding: '10px 16px',
																		borderRadius: '8px',
																		border: '1px solid #e2e8f0',
																		backgroundColor: '#f8fafc',
																		color: '#64748b',
																		fontSize: '14px'
																	}}
																/>
																<button
																	type="button"
																	onClick={() => {
																		if (window.wp && window.wp.media) {
																			const frame = window.wp.media({
																				title: __('Select QR Code', 'revenuepro-bkash-wc'),
																				button: { text: __('Use this QR Code', 'revenuepro-bkash-wc') },
																				multiple: false,
																			});
																			frame.on('select', () => {
																				const attachment = frame.state().get('selection').first().toJSON();
																				handleChange('bkash_manual_qr_url', attachment.url);
																			});
																			frame.open();
																		}
																	}}
																	style={{
																		padding: '10px 20px',
																		background: '#fff',
																		border: '1px solid #cbd5e1',
																		borderRadius: '8px',
																		cursor: 'pointer',
																		fontWeight: '600',
																		color: '#475569',
																		fontSize: '14px',
																		transition: '0.2s'
																	}}
																>
																	{__('Choose QR Code', 'revenuepro-bkash-wc')}
																</button>
																{settings.bkash_manual_qr_url && (
																	<button
																		type="button"
																		onClick={() => handleChange('bkash_manual_qr_url', '')}
																		style={{
																			padding: '10px 16px',
																			background: '#fef2f2',
																			border: '1px solid #fee2e2',
																			borderRadius: '8px',
																			color: '#ef4444',
																			cursor: 'pointer',
																			fontWeight: '600',
																			fontSize: '14px'
																		}}
																	>
																		{__('Remove', 'revenuepro-bkash-wc')}
																	</button>
																)}
															</div>
															<p style={{ margin: '6px 0 0', fontSize: '12px', color: '#64748b' }}>
																Upload your bKash personal QR code image to show it to customers on checkout.
															</p>
														</div>
													</div>
												</div>

												{/* SMS Auto-Verification Configuration */}
												<div style={{ marginTop: '24px', paddingTop: '20px', borderTop: '1px dashed #fbcfe8', marginBottom: '20px' }}>
													<h5 style={{ margin: '0 0 10px', fontSize: '14px', fontWeight: '600', color: '#0f172a', display: 'flex', alignItems: 'center', gap: '6px' }}>
														<span>⚡</span> {__('SMS Auto-Verification (Optional)', 'revenuepro-bkash-wc')}
													</h5>
													<p style={{ margin: '0 0 16px', fontSize: '12px', color: '#64748b', lineHeight: '1.5' }}>
														Automate manual bKash orders by forwarding bKash notification SMS from your phone to this site. Order status will be updated to <strong>"Processing"</strong> automatically when a matching Transaction ID is received.
													</p>
													
													<div style={{ display: 'grid', gap: '16px', background: '#fff', padding: '16px', borderRadius: '8px', border: '1px solid #cbd5e1', marginBottom: '20px' }}>
														<div>
															<label style={{ display: 'block', marginBottom: '6px', fontSize: '13px', fontWeight: '500', color: '#475569' }}>
																{__('Webhook Secret Token', 'revenuepro-bkash-wc')}
															</label>
															<div style={{ display: 'flex', gap: '10px' }}>
																<input
																	type="text"
																	value={settings.bkash_manual_sms_token || ''}
																	onChange={(e) => handleChange('bkash_manual_sms_token', e.target.value)}
																	placeholder="Enter or generate a token"
																	style={{
																		flex: 1,
																		padding: '8px 12px',
																		borderRadius: '6px',
																		border: '1px solid #cbd5e1',
																		fontSize: '13px',
																		fontFamily: 'monospace'
																	}}
																/>
																<button
																	type="button"
																	onClick={() => {
																		const randToken = Array.from({length: 24}, () => Math.random().toString(36)[2] || 'A').join('');
																		handleChange('bkash_manual_sms_token', randToken);
																	}}
																	style={{
																		padding: '8px 12px',
																		background: '#fff',
																		border: '1px solid #cbd5e1',
																		borderRadius: '6px',
																		cursor: 'pointer',
																		fontSize: '12px',
																		fontWeight: '500'
																	}}
																>
																	{__('Generate', 'revenuepro-bkash-wc')}
																</button>
															</div>
														</div>

														{settings.bkash_manual_sms_token && (
															<div>
																<label style={{ display: 'block', marginBottom: '4px', fontSize: '13px', fontWeight: '500', color: '#475569' }}>
																	{__('Webhook URL for Android SMS Forwarder App', 'revenuepro-bkash-wc')}
																</label>
																<div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
																	<input
																		type="text"
																		readOnly
																		value={`${window.location.origin}/wp-json/revenuepro-bkash-wc/v1/webhook/bkash-sms?token=${settings.bkash_manual_sms_token}`}
																		style={{
																			flex: 1,
																			padding: '8px 12px',
																			borderRadius: '6px',
																			border: '1px solid #cbd5e1',
																			backgroundColor: '#f8fafc',
																			fontSize: '12px',
																			color: '#475569',
																			fontFamily: 'monospace'
																		}}
																		id="sms_webhook_url"
																	/>
																	<button
																		type="button"
																		onClick={() => {
																			const el = document.getElementById('sms_webhook_url');
																			el.select();
																			document.execCommand('copy');
																			alert('Webhook URL copied!');
																		}}
																		style={{
																			padding: '8px 12px',
																			background: '#e2136e',
																			color: '#fff',
																			border: 'none',
																			borderRadius: '6px',
																			cursor: 'pointer',
																			fontSize: '12px',
																			fontWeight: '600'
																		}}
																	>
																		{__('Copy URL', 'revenuepro-bkash-wc')}
																	</button>
																</div>
																<p style={{ margin: '6px 0 0', fontSize: '11px', color: '#64748b', lineHeight: '1.4' }}>
																	Configure your Android forwarder app to POST the body of SMS from <strong>bKash</strong> to this URL (parameter name: <code>message</code>).
																</p>
															</div>
														)}
													</div>
												</div>

												<div style={{ background: 'rgba(226,19,110,0.08)', border: '1px solid rgba(226,19,110,0.2)', borderRadius: '8px', padding: '14px', display: 'flex', alignItems: 'flex-start', gap: '10px' }}>
													<span style={{ fontSize: '16px', flexShrink: 0, marginTop: '1px' }}>ℹ️</span>
													<p style={{ margin: 0, fontSize: '13px', color: '#831843', lineHeight: '1.5' }}>
														Manual orders will be placed as <strong>"On-Hold"</strong> unless automatically matched via the SMS webhook. You can also manually verify and approve them from WooCommerce → Orders.
													</p>
												</div>
											</div>
										)}

										{/* bKash Logo - shared */}
										<div>
											<label style={{ display: 'block', marginBottom: '8px', fontSize: '14px', fontWeight: '600', color: '#334155' }}>{__('bKash Logo', 'revenuepro-bkash-wc')}</label>
											<div style={{ display: 'flex', gap: '16px', alignItems: 'flex-start' }}>
												{settings.bkash_logo_url && (
													<div style={{
														width: '80px',
														height: '80px',
														borderRadius: '8px',
														border: '1px solid #e2e8f0',
														padding: '8px',
														display: 'flex',
														alignItems: 'center',
														justifyContent: 'center',
														background: '#fff'
													}}>
														<img src={settings.bkash_logo_url} alt="Logo" style={{ maxWidth: '100%', maxHeight: '100%' }} />
													</div>
												)}
												<div style={{ flex: 1 }}>
													<div style={{ display: 'flex', gap: '10px' }}>
														<input
															type="text"
															readOnly
															value={settings.bkash_logo_url || ''}
															placeholder="No image selected"
															style={{
																flex: 1,
																padding: '10px 16px',
																borderRadius: '8px',
																border: '1px solid #e2e8f0',
																backgroundColor: '#f8fafc',
																color: '#64748b',
																fontSize: '14px'
															}}
														/>
														<button
															type="button"
															onClick={() => {
																if (window.wp && window.wp.media) {
																	const frame = window.wp.media({
																		title: __('Select Logo', 'revenuepro-bkash-wc'),
																		button: { text: __('Use this logo', 'revenuepro-bkash-wc') },
																		multiple: false,
																	});
																	frame.on('select', () => {
																		const attachment = frame.state().get('selection').first().toJSON();
																		handleChange('bkash_logo_url', attachment.url);
																	});
																	frame.open();
																}
															}}
															style={{
																padding: '10px 20px',
																background: '#fff',
																border: '1px solid #cbd5e1',
																borderRadius: '8px',
																cursor: 'pointer',
																fontWeight: '600',
																color: '#475569',
																fontSize: '14px',
																transition: 'all 0.2s'
															}}
															onMouseOver={(e) => e.target.style.borderColor = '#94a3b8'}
															onMouseOut={(e) => e.target.style.borderColor = '#cbd5e1'}
														>
															{__('Upload', 'revenuepro-bkash-wc')}
														</button>
													</div>
													<p style={{ margin: '8px 0 0', fontSize: '13px', color: '#94a3b8' }}>Recommended size: 200x100px. Supports PNG, JPG.</p>
												</div>
											</div>
										</div>
									</div>
								)}
							</div>
						</div>
					)}

					{activeTab === 'partial' && (
						<div style={{ animation: 'fadeIn 0.3s ease-out' }}>
							<div style={{ background: '#fff', borderRadius: '16px', padding: '32px', boxShadow: '0 1px 3px rgba(0,0,0,0.05)', border: '1px solid #f1f5f9' }}>
								<div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '30px', paddingBottom: '20px', borderBottom: '1px solid #f1f5f9' }}>
									<div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
										<div style={{ width: '48px', height: '48px', background: '#f59e0b', borderRadius: '12px', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontWeight: 'bold', fontSize: '20px', boxShadow: '0 4px 6px -1px rgba(245, 158, 11, 0.2)' }}>
											<span className="dashicons dashicons-chart-pie" style={{ fontSize: '24px', width: '24px', height: '24px' }}></span>
										</div>
										<div>
											<h3 style={{ margin: 0, fontSize: '18px', fontWeight: '700', color: '#0f172a' }}>Partial Payment</h3>
											<p style={{ margin: '4px 0 0', color: '#64748b', fontSize: '13px' }}>Configure upfront partial payments.</p>
										</div>
									</div>
									<Toggle
										label={settings.bkash_partial_enabled ? "Enabled" : "Disabled"}
										checked={settings.bkash_partial_enabled}
										onChange={(e) => handleChange('bkash_partial_enabled', e.target.checked)}
									/>
								</div>

								{settings.bkash_partial_enabled && (
									<div style={{ display: 'grid', gap: '24px' }}>
										<div style={{ background: '#fff7ed', padding: '20px', borderRadius: '12px', border: '1px solid #ffedd5', color: '#9a3412', fontSize: '14px', lineHeight: '1.6' }}>
											<strong>How it works:</strong> <br/>
											Customers will pay a partial amount (Fixed or %) via bKash to secure their order. The remaining balance will be marked as "Due" and collected via Cash on Delivery.
										</div>

										<div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '24px' }}>
											<div>
												<label style={{ display: 'block', marginBottom: '8px', fontSize: '14px', fontWeight: '600', color: '#334155' }}>
													{__('Payment Type', 'revenuepro-bkash-wc')}
												</label>
												<select
													value={settings.bkash_partial_type}
													onChange={(e) => handleChange('bkash_partial_type', e.target.value)}
													style={{
														width: '100%',
														padding: '12px 16px',
														fontSize: '14px',
														border: '1px solid #e2e8f0',
														borderRadius: '8px',
														backgroundColor: '#f8fafc',
														color: '#1e293b',
														outline: 'none',
														cursor: 'pointer'
													}}
												>
													<option value="fixed">{__('Fixed Amount', 'revenuepro-bkash-wc')}</option>
													<option value="percentage">{__('Percentage of Total (%)', 'revenuepro-bkash-wc')}</option>
													<option value="shipping">{__('Full Shipping Cost', 'revenuepro-bkash-wc')}</option>
													<option value="shipping_percentage">{__('Shipping + Percentage of Product (%)', 'revenuepro-bkash-wc')}</option>
													<option value="shipping_fixed">{__('Shipping + Fixed Amount', 'revenuepro-bkash-wc')}</option>
												</select>
												<p style={{ margin: '6px 0 0', fontSize: '13px', color: '#64748b' }}>Choose how the partial amount is calculated.</p>
											</div>

											{settings.bkash_partial_type !== 'shipping' && (
												<InputGroup
													label={
														(settings.bkash_partial_type === 'percentage' || settings.bkash_partial_type === 'shipping_percentage') 
														? __('Percentage Amount (%)', 'revenuepro-bkash-wc') 
														: __('Fixed Amount', 'revenuepro-bkash-wc')
													}
													type="number"
													value={settings.bkash_partial_amount}
													onChange={(e) => handleChange('bkash_partial_amount', e.target.value)}
													placeholder={
														(settings.bkash_partial_type === 'percentage' || settings.bkash_partial_type === 'shipping_percentage') 
														? "e.g. 10" 
														: "e.g. 100"
													}
													helpText={
														(settings.bkash_partial_type === 'percentage' || settings.bkash_partial_type === 'shipping_percentage') 
														? "Enter percentage (e.g. 10 for 10%)" 
														: "Enter fixed amount in currency (e.g. 100)"
													}
												/>
											)}
										</div>
									</div>
								)}
							</div>
						</div>
					)}

					{activeTab === 'email' && (
						<div style={{ animation: 'fadeIn 0.3s ease-out' }}>
							{/* Configuration Card */}
							<div style={{ background: '#fff', borderRadius: '16px', padding: '32px', boxShadow: '0 1px 3px rgba(0,0,0,0.05)', border: '1px solid #f1f5f9', marginBottom: '30px' }}>
								<div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '30px', paddingBottom: '20px', borderBottom: '1px solid #f1f5f9' }}>
									<div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
										<div style={{ width: '48px', height: '48px', background: '#3b82f6', borderRadius: '12px', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontWeight: 'bold', fontSize: '20px', boxShadow: '0 4px 6px -1px rgba(59, 130, 246, 0.2)' }}>
											<span className="dashicons dashicons-email-alt" style={{ fontSize: '24px', width: '24px', height: '24px' }}></span>
										</div>
										<div>
											<h3 style={{ margin: 0, fontSize: '18px', fontWeight: '700', color: '#0f172a' }}>Email Configuration</h3>
											<p style={{ margin: '4px 0 0', color: '#64748b', fontSize: '13px' }}>Setup your email sending preferences</p>
										</div>
									</div>
									<Toggle
										label={settings.email_enabled ? "Enabled" : "Disabled"}
										checked={settings.email_enabled}
										onChange={(e) => handleChange('email_enabled', e.target.checked)}
									/>
								</div>

								{settings.email_enabled && (
									<div style={{ display: 'grid', gap: '20px' }}>
										<div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '24px' }}>
											<InputGroup
												label={__('Sender Name', 'revenuepro-bkash-wc')}
												value={settings.email_sender_name}
												onChange={(e) => handleChange('email_sender_name', e.target.value)}
												placeholder="e.g. Donation Team"
											/>
											<InputGroup
												label={__('Sender Email', 'revenuepro-bkash-wc')}
												value={settings.email_sender_email}
												onChange={(e) => handleChange('email_sender_email', e.target.value)}
												placeholder="e.g. donations@example.com"
											/>
										</div>

										<div style={{ background: '#f8fafc', padding: '24px', borderRadius: '12px', border: '1px solid #e2e8f0' }}>
											<h4 style={{ margin: '0 0 20px', fontSize: '15px', fontWeight: '600', color: '#334155' }}>SMTP Settings (Sandbox / Production)</h4>
											<div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '24px' }}>
												<InputGroup
													label={__('SMTP Host', 'revenuepro-bkash-wc')}
													value={settings.email_smtp_host}
													onChange={(e) => handleChange('email_smtp_host', e.target.value)}
													placeholder="e.g. smtp.mailtrap.io"
												/>
												<InputGroup
													label={__('SMTP Port', 'revenuepro-bkash-wc')}
													value={settings.email_smtp_port}
													onChange={(e) => handleChange('email_smtp_port', e.target.value)}
													placeholder="e.g. 2525"
												/>
											</div>
											<div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '24px' }}>
												<InputGroup
													label={__('SMTP Username', 'revenuepro-bkash-wc')}
													value={settings.email_smtp_user}
													onChange={(e) => handleChange('email_smtp_user', e.target.value)}
													placeholder="Username"
												/>
												<InputGroup
													label={__('SMTP Password', 'revenuepro-bkash-wc')}
													type="password"
													value={settings.email_smtp_pass}
													onChange={(e) => handleChange('email_smtp_pass', e.target.value)}
													placeholder="Password"
												/>
											</div>
										</div>
									</div>
								)}
							</div>

							{/* Email Templates with Tabs */}
							{settings.email_enabled && (
								<div style={{ background: '#fff', borderRadius: '16px', padding: '32px', boxShadow: '0 1px 3px rgba(0,0,0,0.05)', border: '1px solid #f1f5f9' }}>
									<div style={{ marginBottom: '30px', paddingBottom: '20px', borderBottom: '1px solid #f1f5f9' }}>
										<h3 style={{ margin: 0, fontSize: '18px', fontWeight: '700', color: '#0f172a' }}>Email Templates</h3>
										<p style={{ margin: '4px 0 0', color: '#64748b', fontSize: '13px' }}>Customize emails sent for different payment outcomes</p>
									</div>

									{/* Template Type Tabs */}
									<div style={{ display: 'flex', gap: '8px', marginBottom: '30px', borderBottom: '2px solid #f1f5f9' }}>
										<button
											onClick={() => setEmailTemplateTab('success')}
											style={{
												padding: '12px 24px',
												background: 'transparent',
												border: 'none',
												borderBottom: emailTemplateTab === 'success' ? '2px solid #10b981' : '2px solid transparent',
												color: emailTemplateTab === 'success' ? '#10b981' : '#64748b',
												fontWeight: emailTemplateTab === 'success' ? '600' : '500',
												cursor: 'pointer',
												fontSize: '14px',
												marginBottom: '-2px',
												transition: 'all 0.2s'
											}}
										>
											✓ Success Template
										</button>
										<button
											onClick={() => setEmailTemplateTab('failure')}
											style={{
												padding: '12px 24px',
												background: 'transparent',
												border: 'none',
												borderBottom: emailTemplateTab === 'failure' ? '2px solid #ef4444' : '2px solid transparent',
												color: emailTemplateTab === 'failure' ? '#ef4444' : '#64748b',
												fontWeight: emailTemplateTab === 'failure' ? '600' : '500',
												cursor: 'pointer',
												fontSize: '14px',
												marginBottom: '-2px',
												transition: 'all 0.2s'
											}}
										>
											✗ Failure Template
										</button>
									</div>

									{/* Success Template */}
									{emailTemplateTab === 'success' && (
										<div style={{ display: 'grid', gap: '20px' }}>
											<InputGroup
												label={__('Email Subject', 'revenuepro-bkash-wc')}
												value={settings.email_subject}
												onChange={(e) => handleChange('email_subject', e.target.value)}
												placeholder="e.g. Donation Receipt"
											/>
											<InputGroup
												label={__('Email Heading', 'revenuepro-bkash-wc')}
												value={settings.email_heading}
												onChange={(e) => handleChange('email_heading', e.target.value)}
												placeholder="e.g. Thank you for your donation!"
											/>
											<InputGroup
												label={__('Email Body', 'revenuepro-bkash-wc')}
												value={settings.email_body}
												onChange={(e) => handleChange('email_body', e.target.value)}
												multiline={true}
												placeholder="Enter your email content..."
												helpText="Available placeholders: {name}, {amount}, {trx_id}, {date}, {site_name}"
											/>
										</div>
									)}

									{/* Failure Template */}
									{emailTemplateTab === 'failure' && (
										<div style={{ display: 'grid', gap: '20px' }}>
											<InputGroup
												label={__('Failure Email Subject', 'revenuepro-bkash-wc')}
												value={settings.email_failure_subject}
												onChange={(e) => handleChange('email_failure_subject', e.target.value)}
												placeholder="e.g. Payment Failed"
											/>
											<InputGroup
												label={__('Failure Email Heading', 'revenuepro-bkash-wc')}
												value={settings.email_failure_heading}
												onChange={(e) => handleChange('email_failure_heading', e.target.value)}
												placeholder="e.g. Payment Could Not Be Completed"
											/>
											<InputGroup
												label={__('Failure Email Body', 'revenuepro-bkash-wc')}
												value={settings.email_failure_body}
												onChange={(e) => handleChange('email_failure_body', e.target.value)}
												multiline={true}
												placeholder="Enter your failure email content..."
												helpText="Available placeholders: {name}, {amount}, {reason}, {date}, {site_name}"
											/>
										</div>
									)}
								</div>
							)}
						</div>
					)}

					{activeTab === 'sms' && (
						<div style={{ animation: 'fadeIn 0.3s ease-out' }}>
							{/* SMS Configuration Card */}
							<div style={{ background: '#fff', borderRadius: '16px', padding: '32px', boxShadow: '0 1px 3px rgba(0,0,0,0.05)', border: '1px solid #f1f5f9', marginBottom: '30px' }}>
								<div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '30px', paddingBottom: '20px', borderBottom: '1px solid #f1f5f9' }}>
									<div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
										<div style={{ width: '48px', height: '48px', background: '#06b6d4', borderRadius: '12px', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontWeight: 'bold', fontSize: '20px', boxShadow: '0 4px 6px -1px rgba(6, 182, 212, 0.2)' }}>
											<span className="dashicons dashicons-smartphone" style={{ fontSize: '24px', width: '24px', height: '24px' }}></span>
										</div>
										<div>
											<h3 style={{ margin: 0, fontSize: '18px', fontWeight: '700', color: '#0f172a' }}>SMS Notification</h3>
											<p style={{ margin: '4px 0 0', color: '#64748b', fontSize: '13px' }}>Send SMS to customers after bKash payment</p>
										</div>
									</div>
									<Toggle
										label={settings.sms_enabled ? "Enabled" : "Disabled"}
										checked={settings.sms_enabled}
										onChange={(e) => handleChange('sms_enabled', e.target.checked)}
									/>
								</div>

								{settings.sms_enabled && (
									<div style={{ display: 'grid', gap: '20px' }}>
										{/* Server IP Info */}
										<div style={{ background: '#f0f9ff', padding: '12px 16px', borderRadius: '10px', border: '1px solid #bae6fd', display: 'flex', alignItems: 'center', gap: '10px' }}>
											<span className="dashicons dashicons-info" style={{ color: '#0284c7', fontSize: '16px', width: '16px', height: '16px', flexShrink: 0 }}></span>
											<p style={{ margin: 0, fontSize: '12.5px', color: '#0c4a6e', lineHeight: '1.5' }}>
												Server IP: <code style={{ background: '#e0f2fe', padding: '1px 6px', borderRadius: '3px', fontSize: '12px', fontWeight: '600', color: '#0369a1' }}>{window.RevenueProGlobal?.server_ip || '...'}</code> — Whitelist this in BulkSMSBD → Phonebook → IP Whitelist.
											</p>
										</div>

										{/* Info Box */}
										<div style={{ background: '#ecfeff', padding: '20px', borderRadius: '12px', border: '1px solid #a5f3fc', color: '#164e63', fontSize: '14px', lineHeight: '1.6' }}>
											<strong>How it works:</strong> <br/>
											When a customer completes or fails a bKash payment, an SMS will be automatically sent to their billing phone number.<br/><br/>
											<strong>SMS Provider:</strong> <a href="https://bulksmsbd.net" target="_blank" rel="noopener" style={{ color: '#0891b2', textDecoration: 'underline' }}>BulkSMSBD</a> — Get your API key from your BulkSMSBD dashboard.
										</div>

										{/* SMS Triggers Config */}
										<div style={{ background: '#f8fafc', padding: '24px', borderRadius: '12px', border: '1px solid #e2e8f0' }}>
											<h4 style={{ margin: '0 0 20px', fontSize: '15px', fontWeight: '600', color: '#334155' }}>Sending Conditions & Triggers</h4>
											
											<SelectGroup
												label={__('When to Send SMS?', 'revenuepro-bkash-wc')}
												value={settings.sms_trigger_condition}
												onChange={(e) => handleChange('sms_trigger_condition', e.target.value)}
												options={[
													{ value: 'always', label: 'Always (for all valid orders)' },
													{ value: 'no_email_only', label: 'Only if Email is NOT provided (Phone only)' },
												]}
												helpText="Choose whether to always send an SMS, or only when the customer didn't enter an email address."
											/>
											
											<div style={{ marginBottom: '24px' }}>
												<label style={{ display: 'block', marginBottom: '12px', fontSize: '14px', fontWeight: '600', color: '#334155' }}>
													{__('Send Success SMS on these Order Statuses:', 'revenuepro-bkash-wc')}
												</label>
												<div style={{ display: 'flex', flexWrap: 'wrap', gap: '16px' }}>
													{['pending', 'processing', 'on-hold', 'completed'].map((status) => {
														const isChecked = Array.isArray(settings.sms_success_statuses) && settings.sms_success_statuses.includes(status);
														return (
															<label key={status} style={{ display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer', background: '#fff', padding: '8px 16px', borderRadius: '8px', border: '1px solid #e2e8f0' }}>
																<input
																	type="checkbox"
																	checked={isChecked}
																	onChange={(e) => {
																		let current = Array.isArray(settings.sms_success_statuses) ? [...settings.sms_success_statuses] : [];
																		if (e.target.checked) {
																			current.push(status);
																		} else {
																			current = current.filter(s => s !== status);
																		}
																		handleChange('sms_success_statuses', current);
																	}}
																	style={{ cursor: 'pointer' }}
																/>
																<span style={{ fontSize: '14px', color: '#475569', textTransform: 'capitalize' }}>
																	{status}
																</span>
															</label>
														);
													})}
												</div>
												<p style={{ margin: '8px 0 0', fontSize: '13px', color: '#64748b' }}>Select the order statuses that should trigger the <strong>Success</strong> SMS.</p>
											</div>
										</div>

										{/* API Config */}
										<div style={{ background: '#f8fafc', padding: '24px', borderRadius: '12px', border: '1px solid #e2e8f0' }}>
											<h4 style={{ margin: '0 0 20px', fontSize: '15px', fontWeight: '600', color: '#334155' }}>BulkSMSBD API Configuration</h4>
											<InputGroup
												label={__('API URL', 'revenuepro-bkash-wc')}
												value={settings.sms_api_url}
												onChange={(e) => handleChange('sms_api_url', e.target.value)}
												placeholder="http://bulksmsbd.net/api/smsapi"
												helpText="BulkSMSBD API endpoint. Default: http://bulksmsbd.net/api/smsapi"
											/>
											<div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '24px' }}>
												<InputGroup
													label={__('API Key', 'revenuepro-bkash-wc')}
													type="password"
													value={settings.sms_api_key}
													onChange={(e) => handleChange('sms_api_key', e.target.value)}
													placeholder="Enter your API key"
													helpText="Your BulkSMSBD API key."
												/>
												<InputGroup
													label={__('Sender ID', 'revenuepro-bkash-wc')}
													value={settings.sms_sender_id}
													onChange={(e) => handleChange('sms_sender_id', e.target.value)}
													placeholder="Enter your Sender ID"
													helpText="Your registered Sender ID from BulkSMSBD."
												/>
											</div>
										</div>
									</div>
								)}
							</div>

							{/* SMS Message Templates with Tabs */}
							{settings.sms_enabled && (
								<div style={{ background: '#fff', borderRadius: '16px', padding: '32px', boxShadow: '0 1px 3px rgba(0,0,0,0.05)', border: '1px solid #f1f5f9' }}>
									<div style={{ marginBottom: '30px', paddingBottom: '20px', borderBottom: '1px solid #f1f5f9' }}>
										<h3 style={{ margin: 0, fontSize: '18px', fontWeight: '700', color: '#0f172a' }}>SMS Message Templates</h3>
										<p style={{ margin: '4px 0 0', color: '#64748b', fontSize: '13px' }}>Customize SMS sent for different payment outcomes</p>
									</div>

									{/* Template Type Tabs */}
									<div style={{ display: 'flex', gap: '8px', marginBottom: '30px', borderBottom: '2px solid #f1f5f9' }}>
										<button
											onClick={() => setSmsTemplateTab('success')}
											style={{
												padding: '12px 24px',
												background: 'transparent',
												border: 'none',
												borderBottom: smsTemplateTab === 'success' ? '2px solid #10b981' : '2px solid transparent',
												color: smsTemplateTab === 'success' ? '#10b981' : '#64748b',
												fontWeight: smsTemplateTab === 'success' ? '600' : '500',
												cursor: 'pointer',
												fontSize: '14px',
												marginBottom: '-2px',
												transition: 'all 0.2s'
											}}
										>
											✓ Success Message
										</button>
										<button
											onClick={() => setSmsTemplateTab('failure')}
											style={{
												padding: '12px 24px',
												background: 'transparent',
												border: 'none',
												borderBottom: smsTemplateTab === 'failure' ? '2px solid #ef4444' : '2px solid transparent',
												color: smsTemplateTab === 'failure' ? '#ef4444' : '#64748b',
												fontWeight: smsTemplateTab === 'failure' ? '600' : '500',
												cursor: 'pointer',
												fontSize: '14px',
												marginBottom: '-2px',
												transition: 'all 0.2s'
											}}
										>
											✗ Failure Message
										</button>
									</div>

									{/* Success Template */}
									{smsTemplateTab === 'success' && (
										<div style={{ display: 'grid', gap: '20px' }}>
											<InputGroup
												label={__('Success SMS Template', 'revenuepro-bkash-wc')}
												value={settings.sms_message_template}
												onChange={(e) => handleChange('sms_message_template', e.target.value)}
												multiline={true}
												placeholder="Dear {customer_name}, your order #{order_id} has been confirmed..."
												helpText="Sent when bKash payment is successful (order completed/processing)."
											/>
										</div>
									)}

									{/* Failure Template */}
									{smsTemplateTab === 'failure' && (
										<div style={{ display: 'grid', gap: '20px' }}>
											<InputGroup
												label={__('Failure SMS Template', 'revenuepro-bkash-wc')}
												value={settings.sms_failure_message_template}
												onChange={(e) => handleChange('sms_failure_message_template', e.target.value)}
												multiline={true}
												placeholder="Dear {customer_name}, your bKash payment for order #{order_id} could not be completed..."
												helpText="Sent when bKash payment fails (order failed/cancelled)."
											/>
										</div>
									)}

									{/* Placeholder Reference */}
									<div style={{ marginTop: '20px', background: '#fffbeb', padding: '20px', borderRadius: '12px', border: '1px solid #fde68a' }}>
										<h4 style={{ margin: '0 0 12px', fontSize: '14px', fontWeight: '600', color: '#92400e' }}>📋 Placeholder Reference</h4>
										<div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px', fontSize: '13px', color: '#78350f' }}>
											<div><code style={{ background: '#fef3c7', padding: '2px 6px', borderRadius: '3px', fontSize: '12px' }}>{'{customer_name}'}</code> — Customer full name</div>
											<div><code style={{ background: '#fef3c7', padding: '2px 6px', borderRadius: '3px', fontSize: '12px' }}>{'{order_id}'}</code> — Order number</div>
											<div><code style={{ background: '#fef3c7', padding: '2px 6px', borderRadius: '3px', fontSize: '12px' }}>{'{order_total}'}</code> — Total order amount</div>
											<div><code style={{ background: '#fef3c7', padding: '2px 6px', borderRadius: '3px', fontSize: '12px' }}>{'{trx_id}'}</code> — bKash Transaction ID</div>
											<div><code style={{ background: '#fef3c7', padding: '2px 6px', borderRadius: '3px', fontSize: '12px' }}>{'{site_name}'}</code> — Your site name</div>
											<div><code style={{ background: '#fef3c7', padding: '2px 6px', borderRadius: '3px', fontSize: '12px' }}>{'{date}'}</code> — Order date</div>
											<div><code style={{ background: '#fef3c7', padding: '2px 6px', borderRadius: '3px', fontSize: '12px' }}>{'{paid_amount}'}</code> — Amount paid via bKash</div>
											<div><code style={{ background: '#fef3c7', padding: '2px 6px', borderRadius: '3px', fontSize: '12px' }}>{'{remaining}'}</code> — Remaining COD amount</div>
										</div>
									</div>
								</div>
							)}
						</div>
					)}

						{activeTab === 'fraud' && (
						<div style={{ animation: 'fadeIn 0.3s ease-out' }}>
							<div style={{ background: '#fff', borderRadius: '16px', padding: '32px', boxShadow: '0 1px 3px rgba(0,0,0,0.05)', border: '1px solid #f1f5f9', marginBottom: '30px' }}>
								<div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '30px', paddingBottom: '20px', borderBottom: '1px solid #f1f5f9' }}>
									<div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
										<div style={{ width: '48px', height: '48px', background: '#ef4444', borderRadius: '12px', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontWeight: 'bold', fontSize: '20px', boxShadow: '0 4px 6px -1px rgba(239, 68, 68, 0.2)' }}>
											<span className="dashicons dashicons-shield" style={{ fontSize: '24px', width: '24px', height: '24px' }}></span>
										</div>
										<div>
											<h3 style={{ margin: 0, fontSize: '18px', fontWeight: '700', color: '#0f172a' }}>Advanced Fraud Detection</h3>
											<p style={{ margin: '4px 0 0', color: '#64748b', fontSize: '13px' }}>Block fraudulent orders using intelligent phone number analysis</p>
										</div>
									</div>
									<Toggle
										label={settings.fraud_enabled ? "Protection Enabled" : "Protection Disabled"}
										checked={settings.fraud_enabled}
										onChange={(e) => handleChange('fraud_enabled', e.target.checked)}
									/>
								</div>

								{settings.fraud_enabled && (
									<div style={{ display: 'grid', gap: '20px' }}>

										<div style={{ background: '#fff', padding: '24px', borderRadius: '12px', border: '1px solid #e2e8f0' }}>
											<h4 style={{ margin: '0 0 20px', fontSize: '15px', fontWeight: '600', color: '#334155' }}>Protection Rules</h4>
											
											<InputGroup
												label={__('Success Ratio Threshold (%)', 'revenuepro-bkash-wc')}
												value={settings.fraud_success_threshold}
												type="number"
												min="0"
												max="100"
												onChange={(e) => handleChange('fraud_success_threshold', e.target.value)}
												helpText="If a customer's success ratio is strictly less than this percentage, the action below will trigger."
											/>

											<div style={{ marginBottom: '24px' }}>
												<Toggle
													label={__('Apply rule to 0 history customers (0 parcels / 0% ratio)', 'revenuepro-bkash-wc')}
													checked={settings.fraud_block_zero_ratio}
													onChange={(e) => handleChange('fraud_block_zero_ratio', e.target.checked)}
												/>
												<p style={{ margin: '8px 0 0 0', fontSize: '13px', color: '#64748b', paddingLeft: '56px' }}>If enabled, new users with absolutely no courier data or 0% ratio will also trigger the action below.</p>
											</div>

											<div style={{ marginBottom: '8px' }}>
												<h4 style={{ margin: '0 0 8px', fontSize: '14px', fontWeight: '600', color: '#334155' }}>Action to Take</h4>
												<p style={{ margin: '0', fontSize: '13px', color: '#64748b' }}>When a customer exceeds the risk threshold, Cash on Delivery will be automatically disabled, forcing bKash prepayment.</p>
											</div>
										</div>

										<div style={{ background: '#fff', padding: '24px', borderRadius: '12px', border: '1px solid #e2e8f0' }}>
											<h4 style={{ margin: '0 0 6px', fontSize: '15px', fontWeight: '600', color: '#334155' }}>Order Spam Prevention</h4>
											<p style={{ margin: '0 0 20px', fontSize: '13px', color: '#94a3b8' }}>Prevent customers from spamming orders using different identifiers. Set max orders and time window (in hours) for each method.</p>

											{/* Phone Number Limit */}
											<div style={{ padding: '16px', background: '#f8fafc', borderRadius: '8px', marginBottom: '12px', border: '1px solid #e2e8f0' }}>
												<Toggle
													label={__('📱 Limit by Phone Number', 'revenuepro-bkash-wc')}
													checked={settings.spam_phone_enabled}
													onChange={(e) => handleChange('spam_phone_enabled', e.target.checked)}
												/>
												{settings.spam_phone_enabled && (
													<div style={{ display: 'flex', gap: '12px', marginTop: '12px' }}>
														<InputGroup label="Max Orders" value={settings.spam_phone_limit} type="number" min="1" max="50" onChange={(e) => handleChange('spam_phone_limit', e.target.value)} style={{ flex: 1 }} />
														<InputGroup label="Duration (hours)" value={settings.spam_phone_duration} type="number" min="1" max="720" onChange={(e) => handleChange('spam_phone_duration', e.target.value)} style={{ flex: 1 }} />
													</div>
												)}
											</div>

											{/* Email Limit */}
											<div style={{ padding: '16px', background: '#f8fafc', borderRadius: '8px', marginBottom: '12px', border: '1px solid #e2e8f0' }}>
												<Toggle
													label={__('📧 Limit by Email Address', 'revenuepro-bkash-wc')}
													checked={settings.spam_email_enabled}
													onChange={(e) => handleChange('spam_email_enabled', e.target.checked)}
												/>
												{settings.spam_email_enabled && (
													<div style={{ display: 'flex', gap: '12px', marginTop: '12px' }}>
														<InputGroup label="Max Orders" value={settings.spam_email_limit} type="number" min="1" max="50" onChange={(e) => handleChange('spam_email_limit', e.target.value)} style={{ flex: 1 }} />
														<InputGroup label="Duration (hours)" value={settings.spam_email_duration} type="number" min="1" max="720" onChange={(e) => handleChange('spam_email_duration', e.target.value)} style={{ flex: 1 }} />
													</div>
												)}
											</div>

											{/* IP Address Limit */}
											<div style={{ padding: '16px', background: '#f8fafc', borderRadius: '8px', marginBottom: '12px', border: '1px solid #e2e8f0' }}>
												<Toggle
													label={__('🌐 Limit by IP Address', 'revenuepro-bkash-wc')}
													checked={settings.spam_ip_enabled}
													onChange={(e) => handleChange('spam_ip_enabled', e.target.checked)}
												/>
												{settings.spam_ip_enabled && (
													<div style={{ display: 'flex', gap: '12px', marginTop: '12px' }}>
														<InputGroup label="Max Orders" value={settings.spam_ip_limit} type="number" min="1" max="100" onChange={(e) => handleChange('spam_ip_limit', e.target.value)} style={{ flex: 1 }} />
														<InputGroup label="Duration (hours)" value={settings.spam_ip_duration} type="number" min="1" max="720" onChange={(e) => handleChange('spam_ip_duration', e.target.value)} style={{ flex: 1 }} />
													</div>
												)}
											</div>

											{/* Browser Fingerprint Limit */}
											<div style={{ padding: '16px', background: '#f8fafc', borderRadius: '8px', marginBottom: '16px', border: '1px solid #e2e8f0' }}>
												<Toggle
													label={__('🖥️ Limit by Browser Fingerprint', 'revenuepro-bkash-wc')}
													checked={settings.spam_fingerprint_enabled}
													onChange={(e) => handleChange('spam_fingerprint_enabled', e.target.checked)}
												/>
												<p style={{ margin: '4px 0 0 56px', fontSize: '12px', color: '#94a3b8' }}>Uses screen size, timezone, and browser info to identify repeat devices even with cleared cookies.</p>
												{settings.spam_fingerprint_enabled && (
													<div style={{ display: 'flex', gap: '12px', marginTop: '12px' }}>
														<InputGroup label="Max Orders" value={settings.spam_fingerprint_limit} type="number" min="1" max="100" onChange={(e) => handleChange('spam_fingerprint_limit', e.target.value)} style={{ flex: 1 }} />
														<InputGroup label="Duration (hours)" value={settings.spam_fingerprint_duration} type="number" min="1" max="720" onChange={(e) => handleChange('spam_fingerprint_duration', e.target.value)} style={{ flex: 1 }} />
													</div>
												)}
											</div>

											<InputGroup
												label={__('Spam Block Message', 'revenuepro-bkash-wc')}
												value={settings.spam_block_message}
												onChange={(e) => handleChange('spam_block_message', e.target.value)}
												multiline={true}
												placeholder="You have exceeded the maximum number of orders..."
												helpText="The error message shown when a customer is blocked by any spam rule."
											/>
										</div>
									</div>
								)}
							</div>
						</div>
					)}
					
					{activeTab === 'recovery' && (
							<div style={{ animation: 'fadeIn 0.3s ease-out' }}>
								{/* Abandoned Cart Recovery Card */}
								<div style={{ background: '#fff', borderRadius: '16px', padding: '32px', boxShadow: '0 1px 3px rgba(0,0,0,0.05)', border: '1px solid #f1f5f9', marginBottom: '30px' }}>
									<div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '30px', paddingBottom: '20px', borderBottom: '1px solid #f1f5f9' }}>
										<div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
											<div style={{ width: '48px', height: '48px', background: '#8b5cf6', borderRadius: '12px', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontWeight: 'bold', fontSize: '20px', boxShadow: '0 4px 6px -1px rgba(139, 92, 246, 0.2)' }}>
												<span className="dashicons dashicons-cart" style={{ fontSize: '24px', width: '24px', height: '24px' }}></span>
											</div>
											<div>
												<h3 style={{ margin: 0, fontSize: '18px', fontWeight: '700', color: '#0f172a' }}>Abandoned Cart Recovery</h3>
												<p style={{ margin: '4px 0 0', color: '#64748b', fontSize: '13px' }}>Recover lost sales by tracking and following up with customers</p>
											</div>
										</div>
										<Toggle
											label={settings.abandoned_cart_enabled ? "Enabled" : "Disabled"}
											checked={settings.abandoned_cart_enabled}
											onChange={(e) => handleChange('abandoned_cart_enabled', e.target.checked)}
										/>
									</div>
						
									{settings.abandoned_cart_enabled && (
										<div style={{ display: 'grid', gap: '24px' }}>
											<div style={{ background: '#f0f9ff', padding: '20px', borderRadius: '12px', border: '1px solid #bae6fd', color: '#0c4a6e', fontSize: '14px', lineHeight: '1.6' }}>
												<strong>How it works:</strong> <br/>
												• System tracks when customers add items to cart and fill checkout information<br/>
												• If they don't complete payment within the specified time, cart is marked as abandoned<br/>
												• Automated recovery email is sent with cart details and checkout link<br/>
												• Admin can view all abandoned carts and contact customers directly
											</div>
						
											<div>
												<label style={{ display: 'block', marginBottom: '8px', fontSize: '14px', fontWeight: '600', color: '#334155' }}>
													Wait Time Before Sending Email
												</label>
												<select
													value={settings.abandoned_cart_wait_time}
													onChange={(e) => handleChange('abandoned_cart_wait_time', e.target.value)}
													style={{
														width: '100%',
														padding: '12px 16px',
														fontSize: '14px',
														border: '1px solid #e2e8f0',
														borderRadius: '8px',
														backgroundColor: '#f8fafc',
														color: '#1e293b',
														outline: 'none',
														cursor: 'pointer'
													}}
												>
													<option value="5">5 Minutes</option>
													<option value="10">10 Minutes</option>
													<option value="15">15 Minutes</option>
													<option value="30">30 Minutes</option>
													<option value="60">1 Hour</option>
													<option value="120">2 Hours</option>
													<option value="360">6 Hours</option>
													<option value="720">12 Hours</option>
													<option value="1440">24 Hours</option>
												</select>
												<p style={{ margin: '6px 0 0', fontSize: '13px', color: '#64748b' }}>
													Time to wait after cart abandonment before sending recovery SMS. 
													<br/>
													<strong>Note:</strong> Abandoned carts are auto-deleted after 30 days. SMS uses the API credentials from the SMS Notification tab.
												</p>
											</div>

											{/* Recovery Notification Channels */}
											<div style={{ background: '#f8fafc', borderRadius: '12px', border: '1px solid #e2e8f0', overflow: 'hidden' }}>
												<div style={{ padding: '16px 20px', borderBottom: '1px solid #e2e8f0', background: '#f1f5f9' }}>
													<h4 style={{ margin: 0, fontSize: '14px', fontWeight: '700', color: '#0f172a' }}>Recovery Notification Channels</h4>
													<p style={{ margin: '4px 0 0', fontSize: '12px', color: '#64748b' }}>Choose which channels send recovery messages. Cart tracking stays active regardless.</p>
												</div>
												<div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '18px 20px', borderBottom: '1px solid #f1f5f9' }}>
													<div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
														<div style={{ width: '38px', height: '38px', borderRadius: '10px', background: settings.abandoned_cart_email_enabled ? '#eff6ff' : '#f1f5f9', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
															<span className="dashicons dashicons-email-alt" style={{ fontSize: '20px', width: '20px', height: '20px', color: settings.abandoned_cart_email_enabled ? '#1d4ed8' : '#94a3b8' }}></span>
														</div>
														<div>
															<div style={{ fontSize: '14px', fontWeight: '600', color: '#0f172a' }}>Send Recovery Email</div>
															<div style={{ fontSize: '12px', color: '#64748b', marginTop: '2px' }}>Email the customer their cart details and a checkout link</div>
														</div>
													</div>
													<Toggle label={settings.abandoned_cart_email_enabled ? 'On' : 'Off'} checked={!!settings.abandoned_cart_email_enabled} onChange={(e) => handleChange('abandoned_cart_email_enabled', e.target.checked)} />
												</div>
												<div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '18px 20px' }}>
													<div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
														<div style={{ width: '38px', height: '38px', borderRadius: '10px', background: settings.abandoned_cart_sms_enabled ? '#f0fdf4' : '#f1f5f9', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
															<span className="dashicons dashicons-phone" style={{ fontSize: '20px', width: '20px', height: '20px', color: settings.abandoned_cart_sms_enabled ? '#16a34a' : '#94a3b8' }}></span>
														</div>
														<div>
															<div style={{ fontSize: '14px', fontWeight: '600', color: '#0f172a' }}>Send Recovery SMS</div>
															<div style={{ fontSize: '12px', color: '#64748b', marginTop: '2px' }}>Send SMS via BulkSMSBD (configured in the SMS tab)</div>
														</div>
													</div>
													<Toggle label={settings.abandoned_cart_sms_enabled ? 'On' : 'Off'} checked={!!settings.abandoned_cart_sms_enabled} onChange={(e) => handleChange('abandoned_cart_sms_enabled', e.target.checked)} />
												</div>
											</div>

											{settings.abandoned_cart_sms_enabled && (
												<div style={{ background: '#f8fafc', padding: '24px', borderRadius: '12px', border: '1px solid #e2e8f0' }}>
													<h4 style={{ margin: '0 0 20px', fontSize: '15px', fontWeight: '600', color: '#334155' }}>Recovery SMS Template</h4>
													<InputGroup
														label="SMS Message"
														value={settings.abandoned_cart_sms_template}
														onChange={(e) => handleChange('abandoned_cart_sms_template', e.target.value)}
														multiline={true}
														placeholder="Enter your recovery SMS message..."
														helpText="Available placeholders: {name}, {phone}, {cart_total}, {cart_items}, {checkout_url}, {site_name}"
													/>
													<div style={{ marginTop: '12px', padding: '12px 16px', background: '#eff6ff', borderRadius: '6px', border: '1px solid #bfdbfe', fontSize: '13px', color: '#1d4ed8' }}>
														📨 <strong>SMS Recovery:</strong> SMS will be sent using the BulkSMSBD API configured in the SMS Notification tab.
													</div>
												</div>
											)}
										</div>
									)}
								</div>
							</div>
						)}
						{activeTab === 'quick' && (
							<div className="tab-pane active" style={{ animation: 'fadeIn 0.3s ease-out' }}>
								<div className="settings-section" style={{ background: '#fff', borderRadius: '16px', padding: '32px', boxShadow: '0 4px 6px -1px rgba(0,0,0,0.05)', border: '1px solid #f1f5f9', marginBottom: '24px' }}>
									<div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '24px', borderBottom: '1px solid #f1f5f9', paddingBottom: '20px' }}>
										<div>
											<h3 style={{ margin: 0, fontSize: '20px', fontWeight: '700', color: '#0f172a' }}>Quick COD Order</h3>
											<p style={{ margin: '4px 0 0', color: '#64748b', fontSize: '14px' }}>Enable instant 1-click Cash on Delivery ordering from product pages.</p>
										</div>
										<Toggle checked={settings.quick_order_enabled} onChange={(e) => handleChange('quick_order_enabled', e.target.checked)} />
									</div>

									{settings.quick_order_enabled && (
										<div style={{ display: 'grid', gridTemplateColumns: '1fr', gap: '24px', animation: 'fadeIn 0.3s ease-out' }}>
											<InputGroup
												label="Button Text"
												value={settings.quick_order_button_text}
												onChange={(e) => handleChange('quick_order_button_text', e.target.value)}
												placeholder="ক্যাশ অন ডেলিভারিতে অর্ডার করুন"
											/>
											<div>
												<label style={{ display: 'block', marginBottom: '8px', fontWeight: '600', color: '#334155' }}>Button Color</label>
												<input 
													type="color" 
													value={settings.quick_order_button_color || '#16a34a'}
													onChange={(e) => handleChange('quick_order_button_color', e.target.value)}
													style={{ width: '60px', height: '40px', padding: '0', border: 'none', borderRadius: '8px', cursor: 'pointer' }}
												/>
											</div>
											<InputGroup
												label="Popup Modal Title"
												value={settings.quick_order_popup_title}
												onChange={(e) => handleChange('quick_order_popup_title', e.target.value)}
												placeholder="ক্যাশ অন ডেলিভারিতে অর্ডার করতে আপনার তথ্য দিন"
											/>
											<InputGroup
												label="Popup Confirm Button Text"
												value={settings.quick_order_confirm_text}
												onChange={(e) => handleChange('quick_order_confirm_text', e.target.value)}
												placeholder="ক্যাশ অন ডেলিভারিতে অর্ডার কনফার্ম করুন"
											/>
										</div>
									)}
								</div>
							</div>
						)}
					{activeTab === 'others' && (
						<div style={{ animation: 'fadeIn 0.3s ease-out' }}>
							{/* Checkout Enhancements Card */}
							<div style={{ background: '#fff', borderRadius: '16px', padding: '32px', boxShadow: '0 1px 3px rgba(0,0,0,0.05)', border: '1px solid #f1f5f9', marginBottom: '30px' }}>
								<div style={{ marginBottom: '30px', paddingBottom: '20px', borderBottom: '1px solid #f1f5f9' }}>
									<div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
										<div style={{ width: '48px', height: '48px', background: 'linear-gradient(135deg, #10b981, #059669)', borderRadius: '12px', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontWeight: 'bold', fontSize: '20px', boxShadow: '0 4px 6px -1px rgba(16, 185, 129, 0.2)' }}>
											<span className="dashicons dashicons-cart" style={{ fontSize: '24px', width: '24px', height: '24px' }}></span>
										</div>
										<div>
											<h3 style={{ margin: 0, fontSize: '18px', fontWeight: '700', color: '#0f172a' }}>Checkout UX Enhancements</h3>
											<p style={{ margin: '4px 0 0', color: '#64748b', fontSize: '13px' }}>Optimize your WooCommerce checkout for Cash on Delivery (COD) scenarios.</p>
										</div>
									</div>
								</div>

								{(() => {
									let config = {};
									try {
										config = settings.checkout_fields_config ? JSON.parse(settings.checkout_fields_config) : {};
									} catch(e) {
										config = { billing: {}, shipping: {}, order: {} };
									}
									const getField = (group, key) => config[group]?.[key] || { enabled: true, required: false, label: '', placeholder: '' };

									const updateField = (group, key, prop, val) => {
										const newConfig = { ...config };
										if (!newConfig[group]) newConfig[group] = {};
										if (!newConfig[group][key]) newConfig[group][key] = { enabled: true, required: false, label: '', placeholder: '' };
										newConfig[group][key][prop] = val;
										handleChange('checkout_fields_config', JSON.stringify(newConfig));
									};

									const renderFieldRow = (group, key, title) => {
										const f = getField(group, key);
										return (
											<div key={key} style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr 2fr 2fr', gap: '16px', alignItems: 'center', padding: '12px 16px', background: !f.enabled ? '#fff1f2' : '#fff', borderBottom: '1px solid #f1f5f9', transition: 'all 0.2s' }}>
												<div style={{ fontWeight: '600', color: '#1e293b', fontSize: '13px' }}>{title}</div>
												<div>
													<Toggle checked={f.enabled} onChange={(e) => updateField(group, key, 'enabled', e.target.checked)} />
												</div>
												<div>
													<Toggle checked={f.required} onChange={(e) => updateField(group, key, 'required', e.target.checked)} disabled={!f.enabled} />
												</div>
												<div>
													<input type="text" value={f.label || ''} onChange={(e) => updateField(group, key, 'label', e.target.value)} placeholder="Custom Label" disabled={!f.enabled} style={{ width: '100%', padding: '6px 12px', border: '1px solid #cbd5e1', borderRadius: '4px', fontSize: '13px' }} />
												</div>
												<div>
													<input type="text" value={f.placeholder || ''} onChange={(e) => updateField(group, key, 'placeholder', e.target.value)} placeholder="Custom Placeholder" disabled={!f.enabled} style={{ width: '100%', padding: '6px 12px', border: '1px solid #cbd5e1', borderRadius: '4px', fontSize: '13px' }} />
												</div>
											</div>
										);
									};

									const fieldsMap = [
										{ group: 'billing', key: 'billing_first_name', title: 'First Name' },
										{ group: 'billing', key: 'billing_last_name', title: 'Last Name' },
										{ group: 'billing', key: 'billing_company', title: 'Company Name' },
										{ group: 'billing', key: 'billing_country', title: 'Country / Region' },
										{ group: 'billing', key: 'billing_address_1', title: 'Street Address 1' },
										{ group: 'billing', key: 'billing_address_2', title: 'Street Address 2' },
										{ group: 'billing', key: 'billing_city', title: 'Town / City' },
										{ group: 'billing', key: 'billing_state', title: 'State / County' },
										{ group: 'billing', key: 'billing_postcode', title: 'Postcode / ZIP' },
										{ group: 'billing', key: 'billing_phone', title: 'Phone' },
										{ group: 'billing', key: 'billing_email', title: 'Email Address' },
										{ group: 'shipping', key: 'shipping_first_name', title: 'Shipping First Name' },
										{ group: 'shipping', key: 'shipping_last_name', title: 'Shipping Last Name' },
										{ group: 'shipping', key: 'shipping_company', title: 'Shipping Company' },
										{ group: 'shipping', key: 'shipping_country', title: 'Shipping Country' },
										{ group: 'shipping', key: 'shipping_address_1', title: 'Shipping Address 1' },
										{ group: 'shipping', key: 'shipping_address_2', title: 'Shipping Address 2' },
										{ group: 'shipping', key: 'shipping_city', title: 'Shipping City' },
										{ group: 'shipping', key: 'shipping_state', title: 'Shipping State' },
										{ group: 'shipping', key: 'shipping_postcode', title: 'Shipping Postcode' },
										{ group: 'shipping', key: 'shipping_phone', title: 'Shipping Phone' },
										{ group: 'order', key: 'order_comments', title: 'Order Notes (Additional Info)' }
									];

									const tabs = [
										{ id: 'billing', label: 'Billing Fields' },
										{ id: 'shipping', label: 'Shipping Fields' },
										{ id: 'order', label: 'Additional Fields' }
									];

									return (
										<div style={{ marginTop: '20px' }}>
											<div style={{ display: 'flex', borderBottom: '1px solid #e2e8f0', marginBottom: '16px' }}>
												{tabs.map(tab => (
													<button
														key={tab.id}
														onClick={(e) => { e.preventDefault(); setCheckoutEditorTab(tab.id); }}
														style={{
															padding: '10px 20px',
															background: 'none',
															border: 'none',
															borderBottom: checkoutEditorTab === tab.id ? '2px solid #3b82f6' : '2px solid transparent',
															color: checkoutEditorTab === tab.id ? '#3b82f6' : '#64748b',
															fontWeight: checkoutEditorTab === tab.id ? '600' : '500',
															cursor: 'pointer',
															fontSize: '14px',
															transition: 'all 0.2s'
														}}
													>
														{tab.label}
													</button>
												))}
											</div>

											<div style={{ border: '1px solid #e2e8f0', borderRadius: '8px', overflow: 'hidden' }}>
												<div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr 2fr 2fr', gap: '16px', padding: '12px 16px', background: '#f8fafc', borderBottom: '1px solid #e2e8f0', fontWeight: '600', fontSize: '13px', color: '#64748b' }}>
													<div>Field Name</div>
													<div>Enabled</div>
													<div>Required</div>
													<div>Override Label</div>
													<div>Override Placeholder</div>
												</div>
												<div style={{ maxHeight: '600px', overflowY: 'auto' }}>
													{fieldsMap.filter(f => f.group === checkoutEditorTab).map(f => renderFieldRow(f.group, f.key, f.title))}
												</div>
											</div>
										</div>
									);
								})()}

								<div style={{ marginTop: '24px', paddingTop: '24px', borderTop: '1px solid #f1f5f9' }}>
									<InputGroup
										label="Checkout Action Button Text"
										value={settings.general_custom_order_button}
										onChange={(e) => handleChange('general_custom_order_button', e.target.value)}
										placeholder="e.g. Confirm Order / কনফার্ম করুন"
										helpText="Overrides the default 'Place order' button text on WooCommerce checkout."
									/>
								</div>
							</div>

							{/* Developer & Debug Card */}
							<div style={{ background: '#fff', borderRadius: '16px', padding: '32px', boxShadow: '0 1px 3px rgba(0,0,0,0.05)', border: '1px solid #f1f5f9' }}>
								<div style={{ marginBottom: '30px', paddingBottom: '20px', borderBottom: '1px solid #f1f5f9' }}>
									<div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
										<div style={{ width: '48px', height: '48px', background: 'linear-gradient(135deg, #64748b, #475569)', borderRadius: '12px', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontWeight: 'bold', fontSize: '20px', boxShadow: '0 4px 6px -1px rgba(100, 116, 139, 0.2)' }}>
											<span className="dashicons dashicons-admin-tools" style={{ fontSize: '24px', width: '24px', height: '24px' }}></span>
										</div>
										<div>
											<h3 style={{ margin: 0, fontSize: '18px', fontWeight: '700', color: '#0f172a' }}>Developer Settings</h3>
											<p style={{ margin: '4px 0 0', color: '#64748b', fontSize: '13px' }}>Advanced configuration and debugging tools.</p>
										</div>
									</div>
								</div>

								<div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '16px', background: settings.general_enable_logging ? '#fff1f2' : '#f8fafc', borderRadius: '8px', border: `1px solid ${settings.general_enable_logging ? '#fda4af' : '#e2e8f0'}`, transition: 'all 0.2s' }}>
									<div>
										<h4 style={{ margin: '0 0 4px', fontSize: '14px', color: '#1e293b' }}>Enable System Debug Logging</h4>
										<p style={{ margin: 0, fontSize: '12px', color: '#64748b' }}>Records detailed courier sync, SMS triggers, and Conversions API payloads to WooCommerce Status Logs.</p>
										{settings.general_enable_logging && (
											<div style={{ marginTop: '8px', fontSize: '11px', color: '#e11d48', fontWeight: '500', display: 'flex', alignItems: 'center', gap: '4px' }}>
												<span className="dashicons dashicons-warning" style={{ fontSize: '12px', width: '12px', height: '12px' }}></span>
												Warning: Logging consumes disk space. Keep off in production unless troubleshooting.
											</div>
										)}
									</div>
									<Toggle 
										checked={settings.general_enable_logging} 
										onChange={(e) => handleChange('general_enable_logging', e.target.checked)} 
									/>
								</div>

								{settings.general_enable_logging && <DebugLogViewer />}

							</div>
						</div>
					)}

					{activeTab === 'license' && (
						<div style={{ animation: 'fadeIn 0.3s ease-out' }}>
							<div style={{ background: '#fff', borderRadius: '16px', padding: '32px', boxShadow: '0 1px 3px rgba(0,0,0,0.05)', border: '1px solid #f1f5f9', marginBottom: '30px' }}>
								<div style={{ display: 'flex', alignItems: 'center', gap: '16px', marginBottom: '30px', paddingBottom: '20px', borderBottom: '1px solid #f1f5f9' }}>
									<div style={{ width: '48px', height: '48px', background: isLicenseActive() ? '#10b981' : '#ef4444', borderRadius: '12px', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontSize: '20px', boxShadow: isLicenseActive() ? '0 4px 6px -1px rgba(16, 185, 129, 0.2)' : '0 4px 6px -1px rgba(239, 68, 68, 0.2)' }}>
										<span className={`dashicons dashicons-${isLicenseActive() ? 'unlock' : 'lock'}`} style={{ fontSize: '24px', width: '24px', height: '24px' }}></span>
									</div>
									<div>
										<h3 style={{ margin: 0, fontSize: '18px', fontWeight: '700', color: '#0f172a' }}>License Configuration</h3>
										<p style={{ margin: '4px 0 0', color: '#64748b', fontSize: '13px' }}>{isLicenseActive() ? 'Your product is activated and all features are unlocked.' : 'Please activate your license to use the plugin features.'}</p>
									</div>
								</div>
								
								{!isLicenseActive() && (
									<div style={{ background: '#fef2f2', border: '1px solid #f87171', borderRadius: '8px', padding: '16px', marginBottom: '24px', color: '#b91c1c', display: 'flex', alignItems: 'center', gap: '12px' }}>
										<span className="dashicons dashicons-warning" style={{ fontSize: '20px', width: '20px', height: '20px' }}></span>
										<div>
											<strong>Action Required:</strong> The plugin is currently disabled. Please enter a valid license key and account email to activate it.
										</div>
									</div>
								)}

								<div style={{ display: 'grid', gap: '20px' }}>

									<InputGroup
										label={__('License Key', 'revenuepro-bkash-wc')}
										value={settings.license_key}
										onChange={(e) => handleChange('license_key', e.target.value)}
										placeholder="e.g. REVPRO-WP-XXXXX"
										helpText="Enter the unique license key provided upon your purchase."
										disabled={isLicenseActive()}
									/>

									<InputGroup
										label={__('Account Email', 'revenuepro-bkash-wc')}
										value={settings.account_email}
										onChange={(e) => handleChange('account_email', e.target.value)}
										placeholder="customer@email.com"
										helpText="Enter the email associated with your license purchase."
										disabled={isLicenseActive()}
									/>

									<div style={{ padding: '24px', background: '#f8fafc', borderRadius: '12px', border: '1px solid #e2e8f0', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
										<div>
											<label style={{ display: 'block', marginBottom: '4px', fontSize: '14px', fontWeight: '600', color: '#334155' }}>
												{__('Current Status & Plan Phase', 'revenuepro-bkash-wc')}
											</label>
											<div style={{ color: settings.license_plan && settings.license_plan.includes('Invalid') ? '#ef4444' : '#10b981', fontSize: '18px', fontWeight: '700' }}>
												{settings.license_plan || 'Free / Unlicensed'}
											</div>
										</div>

										{isLicenseActive() ? (
											<button
												onClick={(e) => { e.preventDefault(); setShowRevokeModal(true); }}
												disabled={isVerifying}
												style={{
													background: '#ef4444',
													color: '#fff',
													border: 'none',
													padding: '12px 24px',
													borderRadius: '8px',
													cursor: isVerifying ? 'not-allowed' : 'pointer',
													fontWeight: '600',
													fontSize: '14px',
													boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)',
													transition: 'all 0.2s',
													display: 'flex',
													alignItems: 'center',
													gap: '8px'
												}}
											>
												{isVerifying ? (
													<>
														<span className="dashicons dashicons-update" style={{ animation: 'spin 1s linear infinite' }}></span>
														{__('Revoking...', 'revenuepro-bkash-wc')}
													</>
												) : (
													<>
														<span className="dashicons dashicons-dismiss"></span>
														{__('Revoke License', 'revenuepro-bkash-wc')}
													</>
												)}
											</button>
										) : (
											<button
												onClick={verifyLicense}
												disabled={isVerifying || !settings.license_key || !settings.account_email}
												style={{
													background: isVerifying ? '#94a3b8' : '#3b82f6',
													color: '#fff',
													border: 'none',
													padding: '12px 24px',
													borderRadius: '8px',
													cursor: (isVerifying || !settings.license_key || !settings.account_email) ? 'not-allowed' : 'pointer',
													fontWeight: '600',
													fontSize: '14px',
													boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)',
													transition: 'all 0.2s',
													display: 'flex',
													alignItems: 'center',
													gap: '8px'
												}}
											>
												{isVerifying ? (
													<>
														<span className="dashicons dashicons-update" style={{ animation: 'spin 1s linear infinite' }}></span>
														{__('Connecting...', 'revenuepro-bkash-wc')}
													</>
												) : (
													<>
														<span className="dashicons dashicons-plugins-checked"></span>
														{__('Connect API & Verify', 'revenuepro-bkash-wc')}
													</>
												)}
											</button>
										)}
									</div>
								</div>
							</div>
						</div>
					)}
					{activeTab === 'courier' && (
						<div style={{ animation: 'fadeIn 0.3s ease-out' }}>
							<div style={{ background: '#fff', borderRadius: '16px', padding: '32px', boxShadow: '0 1px 3px rgba(0,0,0,0.05)', border: '1px solid #f1f5f9', marginBottom: '30px' }}>
								<div style={{ display: 'flex', alignItems: 'center', gap: '16px', marginBottom: '30px', paddingBottom: '20px', borderBottom: '1px solid #f1f5f9' }}>
									<div style={{ width: '48px', height: '48px', background: '#eab308', borderRadius: '12px', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontSize: '20px', boxShadow: '0 4px 6px -1px rgba(234, 179, 8, 0.2)' }}>
										<span className="dashicons dashicons-car" style={{ fontSize: '24px', width: '24px', height: '24px' }}></span>
									</div>
									<div>
										<h3 style={{ margin: 0, fontSize: '18px', fontWeight: '700', color: '#0f172a' }}>Courier Integration</h3>
										<p style={{ margin: '4px 0 0', color: '#64748b', fontSize: '13px' }}>Automatically send new orders to your delivery partner</p>
									</div>
								</div>
								
								<div style={{ padding: '24px', background: '#f8fafc', borderRadius: '8px', border: '1px solid #e2e8f0' }}>
									<h4 style={{ margin: '0 0 6px', fontSize: '15px', fontWeight: '600', color: '#334155' }}>Steadfast Courier</h4>
									<p style={{ margin: '0 0 20px', fontSize: '13px', color: '#94a3b8' }}>Automatically dispatch orders to Steadfast when the order status changes.</p>

									<div style={{ marginBottom: '20px' }}>
										<Toggle
											label={__('Enable Steadfast Integration', 'revenuepro-bkash-wc')}
											checked={settings.courier_steadfast_enabled}
											onChange={(e) => handleChange('courier_steadfast_enabled', e.target.checked)}
										/>
									</div>

									{settings.courier_steadfast_enabled && (
										<>
											<InputGroup
												label={__('API Key', 'revenuepro-bkash-wc')}
												value={settings.courier_steadfast_api_key}
												onChange={(e) => handleChange('courier_steadfast_api_key', e.target.value)}
												placeholder="Enter your Steadfast API Key"
												helpText="Get your API Key from Steadfast Courier dashboard."
											/>
											<InputGroup
												label={__('Secret Key', 'revenuepro-bkash-wc')}
												value={settings.courier_steadfast_secret_key}
												onChange={(e) => handleChange('courier_steadfast_secret_key', e.target.value)}
												type="password"
												placeholder="Enter your Steadfast Secret Key"
												helpText="Get your Secret Key from Steadfast Courier dashboard."
											/>
											<div style={{ padding: '12px 16px', background: '#eff6ff', borderRadius: '8px', border: '1px solid #bfdbfe', fontSize: '13px', color: '#1e40af' }}>
												<strong>💡 COD Handling:</strong> If the payment method is Cash on Delivery, the full order total is sent as COD amount. For prepaid orders (bKash, etc.), COD amount is set to ৳0.
											</div>

											{/* Webhook Configuration */}
											<div style={{ marginTop: '20px', padding: '20px', background: '#fefce8', borderRadius: '8px', border: '1px solid #fde68a' }}>
												<h4 style={{ margin: '0 0 4px', fontSize: '14px', fontWeight: '600', color: '#92400e', display: 'flex', alignItems: 'center', gap: '6px' }}>
													<span style={{ fontSize: '16px' }}>🔗</span> Webhook Configuration
												</h4>
												<p style={{ margin: '0 0 16px', fontSize: '12px', color: '#a16207' }}>
													Set these values in your Steadfast dashboard to receive automatic order status updates.
												</p>

												<div style={{ marginBottom: '14px' }}>
													<label style={{ display: 'block', marginBottom: '4px', fontSize: '13px', fontWeight: '500', color: '#78350f' }}>
														Callback URL
													</label>
													<div style={{ display: 'flex', gap: '8px' }}>
														<input
															type="text"
															readOnly
															value={settings.steadfast_webhook_url || ''}
															style={{ flex: 1, padding: '8px 12px', fontSize: '13px', border: '1px solid #fde68a', borderRadius: '6px', backgroundColor: '#fffbeb', color: '#78350f', fontFamily: 'monospace' }}
														/>
														<button
															type="button"
															onClick={() => { navigator.clipboard.writeText(settings.steadfast_webhook_url || ''); }}
															style={{ padding: '8px 14px', background: '#f59e0b', color: '#fff', border: 'none', borderRadius: '6px', fontSize: '12px', fontWeight: '600', cursor: 'pointer', whiteSpace: 'nowrap' }}
														>
															Copy
														</button>
													</div>
												</div>

												<div>
													<label style={{ display: 'block', marginBottom: '4px', fontSize: '13px', fontWeight: '500', color: '#78350f' }}>
														Auth Token (Bearer)
													</label>
													<div style={{ display: 'flex', gap: '8px' }}>
														<div style={{ flex: 1, position: 'relative', display: 'flex', alignItems: 'center' }}>
															<input
																type={showSteadfastToken ? 'text' : 'password'}
																readOnly
																value={settings.steadfast_webhook_token || ''}
																style={{ flex: 1, width: '100%', padding: '8px 38px 8px 12px', fontSize: '13px', border: '1px solid #fde68a', borderRadius: '6px', backgroundColor: '#fffbeb', color: '#78350f', fontFamily: 'monospace', boxSizing: 'border-box' }}
															/>
															<button
																type="button"
																onClick={() => setShowSteadfastToken(v => !v)}
																title={showSteadfastToken ? 'Hide token' : 'Show token'}
																style={{ position: 'absolute', right: '8px', background: 'none', border: 'none', cursor: 'pointer', padding: '0', fontSize: '16px', lineHeight: 1, color: '#a16207' }}
															>
																{showSteadfastToken ? '🙈' : '👁️'}
															</button>
														</div>
														<button
															type="button"
															onClick={() => { navigator.clipboard.writeText(settings.steadfast_webhook_token || ''); }}
															style={{ padding: '8px 14px', background: '#f59e0b', color: '#fff', border: 'none', borderRadius: '6px', fontSize: '12px', fontWeight: '600', cursor: 'pointer', whiteSpace: 'nowrap' }}
														>
															Copy
														</button>
													</div>
													<p style={{ margin: '6px 0 0', fontSize: '11px', color: '#a16207' }}>
														Paste this token in Steadfast's "Auth Token (Bearer)" field.
													</p>
												</div>

												<div style={{ marginTop: '14px', padding: '10px 12px', background: '#fef3c7', borderRadius: '6px', border: '1px solid #fde68a', fontSize: '12px', color: '#92400e', lineHeight: '1.5' }}>
													<strong>Status Mapping:</strong> delivered → Completed | cancelled → Cancelled | tracking_update → Order Note
												</div>
											</div>
										</>
									)}
								</div>
								<div style={{ padding: '24px', background: '#f8fafc', borderRadius: '8px', border: '1px solid #e2e8f0', marginTop: '24px' }}>
									<h4 style={{ margin: '0 0 6px', fontSize: '15px', fontWeight: '600', color: '#334155' }}>Pathao Courier</h4>
									<p style={{ margin: '0 0 20px', fontSize: '13px', color: '#94a3b8' }}>Automatically dispatch orders to Pathao when the order status changes.</p>

									<div style={{ marginBottom: '20px' }}>
										<Toggle
											label={__('Enable Pathao Integration', 'revenuepro-bkash-wc')}
											checked={settings.courier_pathao_enabled}
											onChange={(e) => handleChange('courier_pathao_enabled', e.target.checked)}
										/>
									</div>

									{settings.courier_pathao_enabled && (
										<>
											<InputGroup
												label={__('Client ID', 'revenuepro-bkash-wc')}
												value={settings.courier_pathao_client_id}
												onChange={(e) => handleChange('courier_pathao_client_id', e.target.value)}
												placeholder="Enter your Pathao Client ID"
											/>
											<InputGroup
												label={__('Client Secret', 'revenuepro-bkash-wc')}
												value={settings.courier_pathao_client_secret}
												onChange={(e) => handleChange('courier_pathao_client_secret', e.target.value)}
												type="password"
												placeholder="Enter your Pathao Client Secret"
											/>
											<InputGroup
												label={__('Username / Email', 'revenuepro-bkash-wc')}
												value={settings.courier_pathao_username}
												onChange={(e) => handleChange('courier_pathao_username', e.target.value)}
												placeholder="Enter your Pathao Email"
											/>
											<InputGroup
												label={__('Password', 'revenuepro-bkash-wc')}
												value={settings.courier_pathao_password}
												onChange={(e) => handleChange('courier_pathao_password', e.target.value)}
												type="password"
												placeholder="Enter your Pathao Password"
											/>
											<InputGroup
												label={__('Store ID', 'revenuepro-bkash-wc')}
												value={settings.courier_pathao_store_id}
												onChange={(e) => handleChange('courier_pathao_store_id', e.target.value)}
												placeholder="Enter your Merchant Store ID"
											/>
											<div style={{ padding: '12px 16px', background: '#fdf4ff', borderRadius: '8px', border: '1px solid #fbcfe8', fontSize: '13px', color: '#86198f' }}>
												<strong>💡 Access Token Generation:</strong> Pathao uses rotating access tokens. RevenuePro handles token issuance and caching automatically in the background using your credentials.
											</div>
										</>
									)}
								</div>

								<div style={{ padding: '24px', background: '#f8fafc', borderRadius: '8px', border: '1px solid #e2e8f0', marginTop: '24px' }}>
									<h4 style={{ margin: '0 0 16px', fontSize: '15px', fontWeight: '600', color: '#334155' }}>Automatic Courier Dispatch</h4>

									<div style={{ marginBottom: '16px' }}>
										<Toggle
											label={__('Enable Courier Automation', 'revenuepro-bkash-wc')}
											checked={settings.courier_auto_dispatch}
											onChange={(e) => handleChange('courier_auto_dispatch', e.target.checked)}
										/>
									</div>

									{settings.courier_auto_dispatch && (
										<>
											{(settings.courier_steadfast_enabled || settings.courier_pathao_enabled) ? (
												<>
													<div style={{ marginBottom: '16px' }}>
														<SelectGroup
															label={__('Default Courier', 'revenuepro-bkash-wc')}
															value={settings.courier_default || 'steadfast'}
															onChange={(e) => handleChange('courier_default', e.target.value)}
															options={[
																...(settings.courier_steadfast_enabled ? [{ value: 'steadfast', label: 'Steadfast Courier' }] : []),
																...(settings.courier_pathao_enabled ? [{ value: 'pathao', label: 'Pathao Courier' }] : [])
															]}
														/>
													</div>

													<SelectGroup
														label={__('Trigger When Order Status Is', 'revenuepro-bkash-wc')}
														value={settings.courier_trigger_status || 'ready-to-ship'}
														onChange={(e) => handleChange('courier_trigger_status', e.target.value)}
														options={[
															{ value: 'processing', label: 'Processing' },
															{ value: 'ready-to-ship', label: 'Ready to Ship' },
															{ value: 'completed', label: 'Completed' }
														]}
													/>

													<div style={{ marginTop: '12px', padding: '12px 16px', background: '#eff6ff', borderRadius: '6px', border: '1px solid #bfdbfe', fontSize: '13px', color: '#1d4ed8' }}>
														🤖 <strong>Auto Mode:</strong> When an order reaches the status above, it will be automatically sent to <strong>{settings.courier_default === 'pathao' ? 'Pathao' : 'Steadfast'}</strong> without any manual action.
													</div>
												</>
											) : (
												<div style={{ padding: '12px 16px', background: '#fff7ed', borderRadius: '6px', border: '1px solid #fed7aa', fontSize: '13px', color: '#92400e' }}>
													⚠️ Please enable at least one courier (Steadfast or Pathao) above before configuring automation.
												</div>
											)}
										</>
									)}
								</div>
							</div>
						</div>
					)}

					{activeTab === 'tracking' && (
						<div style={{ animation: 'fadeIn 0.3s ease-out' }}>
							{/* Meta / Facebook Pixel */}
							<div style={{ background: '#fff', borderRadius: '16px', padding: '32px', boxShadow: '0 1px 3px rgba(0,0,0,0.05)', border: '1px solid #f1f5f9', marginBottom: '30px' }}>
								<div style={{ display: 'flex', alignItems: 'center', gap: '16px', marginBottom: settings.tracking_fb_pixel_enabled ? '24px' : '0', paddingBottom: settings.tracking_fb_pixel_enabled ? '20px' : '0', borderBottom: settings.tracking_fb_pixel_enabled ? '1px solid #f1f5f9' : 'none' }}>
									<div style={{ width: '48px', height: '48px', background: 'linear-gradient(135deg, #0668e1, #1877f2)', borderRadius: '12px', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontSize: '20px', boxShadow: '0 4px 6px -1px rgba(24, 119, 242, 0.3)' }}>
										<span className="dashicons dashicons-facebook-alt" style={{ fontSize: '24px', width: '24px', height: '24px' }}></span>
									</div>
									<div style={{ flex: 1 }}>
										<h3 style={{ margin: 0, fontSize: '18px', fontWeight: '700', color: '#0f172a' }}>Meta (Facebook) Pixel</h3>
										<p style={{ margin: '4px 0 0', color: '#64748b', fontSize: '13px' }}>Track conversions, optimize ads, and build audiences for your ad campaigns</p>
									</div>
									<div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
										<span style={{ fontSize: '13px', fontWeight: '500', color: settings.tracking_fb_pixel_enabled ? '#1877f2' : '#94a3b8' }}>
											{settings.tracking_fb_pixel_enabled ? 'Enabled' : 'Disabled'}
										</span>
										<Toggle checked={settings.tracking_fb_pixel_enabled} onChange={(e) => handleChange('tracking_fb_pixel_enabled', e.target.checked)} />
									</div>
								</div>

								{settings.tracking_fb_pixel_enabled && (
									<div style={{ display: 'grid', gap: '20px' }}>
										<InputGroup
											label="Pixel ID"
											value={settings.tracking_fb_pixel_id}
											onChange={(e) => handleChange('tracking_fb_pixel_id', e.target.value)}
											placeholder="e.g. 123456789012345"
											helpText="Your Meta Pixel ID from Events Manager → Data Sources → Your Pixel → Settings."
										/>
										
										{/* Server-Side (CAPI) Section */}
										<div style={{ background: '#f8fafc', padding: '24px', borderRadius: '12px', border: '1px solid #e2e8f0' }}>
											<div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '16px' }}>
												<div>
													<h4 style={{ margin: 0, fontSize: '15px', fontWeight: '600', color: '#334155' }}>
														<span className="dashicons dashicons-cloud" style={{ fontSize: '16px', width: '16px', height: '16px', marginRight: '8px', color: '#3b82f6' }}></span>
														Conversions API (Server-Side)
													</h4>
													<p style={{ margin: '4px 0 0', fontSize: '12px', color: '#64748b' }}>Send events directly from your server for better accuracy & iOS 14+ compatibility</p>
												</div>
												<Toggle checked={settings.tracking_fb_capi_enabled} onChange={(e) => handleChange('tracking_fb_capi_enabled', e.target.checked)} />
											</div>
											
											{settings.tracking_fb_capi_enabled && (
												<div style={{ display: 'grid', gap: '16px' }}>
													<InputGroup
														label="Access Token"
														value={settings.tracking_fb_capi_token}
														onChange={(e) => handleChange('tracking_fb_capi_token', e.target.value)}
														placeholder="EAAxxxxxxx..."
														helpText="Generate from Events Manager → Settings → Conversions API → Generate Access Token"
													/>
													<InputGroup
														label="Test Event Code (Optional)"
														value={settings.tracking_fb_test_code}
														onChange={(e) => handleChange('tracking_fb_test_code', e.target.value)}
														placeholder="e.g. TEST12345"
														helpText="Use this during development. Events will appear in the Test Events tab in Events Manager."
													/>
												</div>
											)}
										</div>

										{/* Domain Verification */}
										<div style={{ background: '#f8fafc', padding: '24px', borderRadius: '12px', border: '1px solid #e2e8f0' }}>
											<h4 style={{ margin: '0 0 16px', fontSize: '15px', fontWeight: '600', color: '#334155' }}>
												<span className="dashicons dashicons-admin-links" style={{ fontSize: '16px', width: '16px', height: '16px', marginRight: '8px', color: '#8b5cf6' }}></span>
												Domain Verification
											</h4>
											<p style={{ margin: '0 0 16px', fontSize: '12px', color: '#64748b' }}>Required for iOS 14+ event tracking and configuring aggregated event measurement.</p>
											
											<InputGroup
												label="Meta-tag Verification Code"
												value={settings.tracking_fb_domain_verification}
												onChange={(e) => handleChange('tracking_fb_domain_verification', e.target.value)}
												placeholder='<meta name="facebook-domain-verification" content="xxxxxxxx" />'
												helpText="Paste the entire meta tag provided by Facebook Business Manager here."
											/>
										</div>

										{/* UTM Attribution Tracking */}
										<div style={{ background: '#f8fafc', padding: '24px', borderRadius: '12px', border: '1px solid #e2e8f0' }}>
											<div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '16px' }}>
												<div>
													<h4 style={{ margin: 0, fontSize: '15px', fontWeight: '600', color: '#0f172a' }}>
														<span className="dashicons dashicons-admin-links" style={{ fontSize: '16px', width: '16px', height: '16px', marginRight: '8px', color: '#8b5cf6' }}></span>
														UTM Attribution Tracking
													</h4>
													<p style={{ margin: '4px 0 0', fontSize: '12px', color: '#64748b' }}>Automatically capture UTM parameters from ad URLs and save them to orders</p>
												</div>
												<Toggle checked={settings.tracking_utm_enabled} onChange={(e) => handleChange('tracking_utm_enabled', e.target.checked)} />
											</div>

											{settings.tracking_utm_enabled && (
												<div style={{ marginTop: '16px', paddingTop: '16px', borderTop: '1px dashed #cbd5e1' }}>
													<div style={{ background: '#eff6ff', border: '1px solid #bfdbfe', borderRadius: '8px', padding: '12px', marginBottom: '16px' }}>
														<p style={{ margin: 0, fontSize: '12px', color: '#1e40af', lineHeight: '1.5' }}>
															<strong>How it works:</strong> When a user clicks your Facebook Ad, the URL parameters (e.g. <code>utm_campaign</code>, <code>utm_adset</code>, <code>fbclid</code>) are stored in their browser cookie for 30 days. When they checkout, we attach this exact ad data directly to their WooCommerce order.
														</p>
													</div>
													
													<p style={{ margin: '0 0 10px', fontSize: '12px', fontWeight: '600', color: '#334155' }}>Tracked Parameters:</p>
													<div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px' }}>
														{[
															{ param: 'utm_source', example: 'facebook', desc: 'Traffic source' },
															{ param: 'utm_campaign', example: 'summer_sale', desc: 'Campaign name' },
															{ param: 'utm_adset', example: 'lookalike_2%', desc: 'Facebook Ad Set' },
															{ param: 'utm_ad', example: 'video_ad_1', desc: 'Specific ad name' },
															{ param: 'fbclid', example: 'Auto-captured', desc: 'FB Click ID' },
														].map((item, idx) => (
															<div key={idx} style={{ background: '#fff', border: '1px solid #e2e8f0', borderRadius: '6px', padding: '8px 12px' }}>
																<div style={{ fontSize: '12px', fontWeight: '700', color: '#0ea5e9', fontFamily: 'monospace' }}>{item.param}</div>
																<div style={{ fontSize: '11px', color: '#64748b', marginTop: '2px' }}>{item.desc} <span style={{ color: '#94a3b8' }}>({item.example})</span></div>
															</div>
														))}
													</div>

													<div style={{ marginTop: '20px', padding: '16px', background: '#f8fafc', border: '1px solid #cbd5e1', borderRadius: '8px' }}>
														<p style={{ margin: '0 0 8px', fontSize: '13px', fontWeight: '600', color: '#0f172a' }}>Facebook Ads Setup</p>
														<p style={{ margin: '0 0 12px', fontSize: '12px', color: '#475569', lineHeight: '1.5' }}>
															Copy and paste this exact snippet into the <strong>"URL parameters"</strong> field at the bottom of your Facebook Ad setup (under the Tracking section):
														</p>
														<div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
															<code style={{ flex: 1, padding: '10px 12px', background: '#fff', border: '1px solid #cbd5e1', borderRadius: '6px', fontSize: '11px', color: '#334155', wordBreak: 'break-all' }}>
																utm_source=facebook&utm_medium=cpc&utm_campaign=&#123;&#123;campaign.name&#125;&#125;&utm_adset=&#123;&#123;adset.name&#125;&#125;&utm_ad=&#123;&#123;ad.name&#125;&#125;
															</code>
															<button 
																onClick={(e) => {
																	e.preventDefault();
																	navigator.clipboard.writeText('utm_source=facebook&utm_medium=cpc&utm_campaign={{campaign.name}}&utm_adset={{adset.name}}&utm_ad={{ad.name}}');
																	const btn = e.currentTarget;
																	const originalText = btn.innerText;
																	btn.innerText = 'Copied!';
																	setTimeout(() => btn.innerText = originalText, 2000);
																}}
																style={{ padding: '8px 12px', background: '#e2e8f0', color: '#475569', border: 'none', borderRadius: '6px', fontSize: '12px', fontWeight: '600', cursor: 'pointer', whiteSpace: 'nowrap' }}
															>
																Copy
															</button>
														</div>
													</div>
												</div>
											)}
										</div>

										{/* Event Tracking Toggles */}
										<div style={{ background: '#f8fafc', padding: '24px', borderRadius: '12px', border: '1px solid #e2e8f0' }}>
											<h4 style={{ margin: '0 0 16px', fontSize: '15px', fontWeight: '600', color: '#334155' }}>
												<span className="dashicons dashicons-flag" style={{ fontSize: '16px', width: '16px', height: '16px', marginRight: '8px', color: '#f59e0b' }}></span>
												WooCommerce Event Tracking
											</h4>
											<p style={{ margin: '0 0 16px', fontSize: '12px', color: '#64748b' }}>Choose which events are fired for both browser-side pixel and server-side CAPI</p>
											
											<div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
												{[
													{ key: 'tracking_events_page_view', label: 'PageView', desc: 'All pages' },
													{ key: 'tracking_events_view_content', label: 'ViewContent', desc: 'Product pages' },
													{ key: 'tracking_events_add_to_cart', label: 'AddToCart', desc: 'Add to cart action' },
													{ key: 'tracking_events_initiate_checkout', label: 'InitiateCheckout', desc: 'Checkout page' },
													{ key: 'tracking_events_purchase', label: 'Purchase', desc: 'Order complete' },
													{ key: 'tracking_events_search', label: 'Search', desc: 'Search results' },
													{ key: 'tracking_events_add_to_wishlist', label: 'AddToWishlist', desc: 'Wishlist add' },
												].map(evt => (
													<div key={evt.key} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '10px 14px', background: settings[evt.key] ? '#eff6ff' : '#fff', borderRadius: '8px', border: `1px solid ${settings[evt.key] ? '#93c5fd' : '#e2e8f0'}`, transition: 'all 0.15s' }}>
														<div>
															<span style={{ fontSize: '13px', fontWeight: '600', color: '#0f172a' }}>{evt.label}</span>
															<span style={{ display: 'block', fontSize: '11px', color: '#94a3b8' }}>{evt.desc}</span>
														</div>
														<Toggle checked={settings[evt.key]} onChange={(e) => handleChange(evt.key, e.target.checked)} />
													</div>
												))}
											</div>

											{settings.tracking_events_purchase && (
												<div style={{ marginTop: '20px', paddingTop: '20px', borderTop: '1px solid #e2e8f0' }}>
													<label style={{ display: 'block', marginBottom: '12px', fontSize: '14px', fontWeight: '600', color: '#334155' }}>Custom Order Status Event (Server-Side)</label>
													
													<div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '12px 16px', background: settings.tracking_purchase_trigger === 'order_status' ? '#eff6ff' : '#fff', borderRadius: '8px', border: `1px solid ${settings.tracking_purchase_trigger === 'order_status' ? '#93c5fd' : '#e2e8f0'}`, transition: 'all 0.15s', marginBottom: settings.tracking_purchase_trigger === 'order_status' ? '12px' : '0' }}>
														<div>
															<span style={{ fontSize: '13px', fontWeight: '600', color: '#0f172a' }}>Fire Custom Event on Status Change</span>
															<span style={{ display: 'block', fontSize: '11px', color: '#64748b', marginTop: '2px' }}>Fires an additional custom event (e.g. 'Order_Delivered') without disabling the checkout Purchase.</span>
														</div>
														<Toggle 
															checked={settings.tracking_purchase_trigger === 'order_status'} 
															onChange={(e) => handleChange('tracking_purchase_trigger', e.target.checked ? 'order_status' : 'checkout')} 
														/>
													</div>

													{settings.tracking_purchase_trigger === 'order_status' && (
														<div style={{ padding: '16px', background: '#f1f5f9', borderRadius: '8px', border: '1px solid #e2e8f0' }}>
															<div style={{ display: 'flex', gap: '16px' }}>
																<div style={{ flex: 1 }}>
																	<label style={{ display: 'block', marginBottom: '8px', fontSize: '13px', fontWeight: '600', color: '#334155' }}>Select WooCommerce Order Status</label>
																	<select 
																		value={settings.tracking_purchase_status_trigger} 
																		onChange={(e) => handleChange('tracking_purchase_status_trigger', e.target.value)}
																		style={{ width: '100%', padding: '8px 12px', borderRadius: '6px', border: '1px solid #cbd5e1', fontSize: '13px', background: '#fff' }}
																	>
																		{RevenueProGlobal?.wc_order_statuses && Object.entries(RevenueProGlobal.wc_order_statuses).map(([key, label]) => (
																			<option key={key} value={key}>{label}</option>
																		))}
																		{(!RevenueProGlobal?.wc_order_statuses || Object.keys(RevenueProGlobal.wc_order_statuses).length === 0) && (
																			<option value="wc-completed">Completed</option>
																		)}
																	</select>
																</div>
																<div style={{ flex: 1 }}>
																	<label style={{ display: 'block', marginBottom: '8px', fontSize: '13px', fontWeight: '600', color: '#334155' }}>Event Name in Facebook</label>
																	<input
																		type="text"
																		value={settings.tracking_custom_event_name || 'Purchase_Delivered'}
																		onChange={(e) => handleChange('tracking_custom_event_name', e.target.value)}
																		placeholder="e.g. Purchase_Delivered"
																		style={{ width: '100%', padding: '8px 12px', borderRadius: '6px', border: '1px solid #cbd5e1', fontSize: '13px', background: '#fff' }}
																	/>
																</div>
															</div>
															<p style={{ margin: '8px 0 0', fontSize: '11px', color: '#64748b' }}>The Conversions API will send this custom event when the order changes to this status.</p>
														</div>
													)}
												</div>
											)}
										</div>
									</div>
								)}
							</div>

							{/* Google Analytics 4 */}
							<div style={{ background: '#fff', borderRadius: '16px', padding: '32px', boxShadow: '0 1px 3px rgba(0,0,0,0.05)', border: '1px solid #f1f5f9', marginBottom: '30px' }}>
								<div style={{ display: 'flex', alignItems: 'center', gap: '16px', marginBottom: settings.tracking_google_analytics_enabled ? '24px' : '0', paddingBottom: settings.tracking_google_analytics_enabled ? '20px' : '0', borderBottom: settings.tracking_google_analytics_enabled ? '1px solid #f1f5f9' : 'none' }}>
									<div style={{ width: '48px', height: '48px', background: 'linear-gradient(135deg, #ea8600, #f9ab00)', borderRadius: '12px', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontSize: '20px', boxShadow: '0 4px 6px -1px rgba(249, 171, 0, 0.3)' }}>
										<span className="dashicons dashicons-chart-bar" style={{ fontSize: '24px', width: '24px', height: '24px' }}></span>
									</div>
									<div style={{ flex: 1 }}>
										<h3 style={{ margin: 0, fontSize: '18px', fontWeight: '700', color: '#0f172a' }}>Google Analytics 4</h3>
										<p style={{ margin: '4px 0 0', color: '#64748b', fontSize: '13px' }}>Track site traffic and eCommerce conversions with GA4</p>
									</div>
									<div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
										<span style={{ fontSize: '13px', fontWeight: '500', color: settings.tracking_google_analytics_enabled ? '#f59e0b' : '#94a3b8' }}>
											{settings.tracking_google_analytics_enabled ? 'Enabled' : 'Disabled'}
										</span>
										<Toggle checked={settings.tracking_google_analytics_enabled} onChange={(e) => handleChange('tracking_google_analytics_enabled', e.target.checked)} />
									</div>
								</div>

								{settings.tracking_google_analytics_enabled && (
									<InputGroup
										label="Measurement ID"
										value={settings.tracking_google_analytics_id}
										onChange={(e) => handleChange('tracking_google_analytics_id', e.target.value)}
										placeholder="e.g. G-XXXXXXXXXX"
										helpText="Find this in GA4 → Admin → Data Streams → Web → Measurement ID"
									/>
								)}
							</div>

							{/* Google Analytics */}
							<div style={{ background: '#fff', borderRadius: '16px', padding: '32px', boxShadow: '0 1px 3px rgba(0,0,0,0.05)', border: '1px solid #f1f5f9', marginBottom: '30px' }}>
								<div style={{ display: 'flex', alignItems: 'center', gap: '16px', marginBottom: settings.tracking_google_ads_enabled ? '24px' : '0', paddingBottom: settings.tracking_google_ads_enabled ? '20px' : '0', borderBottom: settings.tracking_google_ads_enabled ? '1px solid #f1f5f9' : 'none' }}>
									<div style={{ width: '48px', height: '48px', background: 'linear-gradient(135deg, #34a853, #4285f4)', borderRadius: '12px', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontSize: '20px', boxShadow: '0 4px 6px -1px rgba(66, 133, 244, 0.3)' }}>
										<span className="dashicons dashicons-megaphone" style={{ fontSize: '24px', width: '24px', height: '24px' }}></span>
									</div>
									<div style={{ flex: 1 }}>
										<div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
											<h3 style={{ margin: 0, fontSize: '18px', fontWeight: '700', color: '#0f172a' }}>Google Ads</h3>
											<span style={{ padding: '4px 8px', background: '#f1f5f9', color: '#64748b', fontSize: '11px', fontWeight: '600', borderRadius: '20px', textTransform: 'uppercase', letterSpacing: '0.5px' }}>Coming soon</span>
										</div>
										<p style={{ margin: '4px 0 0', color: '#64748b', fontSize: '13px' }}>Track purchase conversions for Google Ads campaigns</p>
									</div>
									<div style={{ display: 'flex', alignItems: 'center', gap: '10px', opacity: 0.5 }}>
										<span style={{ fontSize: '13px', fontWeight: '500', color: '#94a3b8' }}>
											Disabled
										</span>
										<div style={{ pointerEvents: 'none' }}>
											<Toggle checked={false} onChange={() => {}} />
										</div>
									</div>
								</div>

								{settings.tracking_google_ads_enabled && (
									<div style={{ display: 'grid', gap: '16px' }}>
										<InputGroup
											label="Google Ads ID"
											value={settings.tracking_google_ads_id}
											onChange={(e) => handleChange('tracking_google_ads_id', e.target.value)}
											placeholder="e.g. AW-123456789"
											helpText="Your Google Ads conversion tracking ID"
										/>
										<InputGroup
											label="Conversion Label"
											value={settings.tracking_google_ads_conversion_label}
											onChange={(e) => handleChange('tracking_google_ads_conversion_label', e.target.value)}
											placeholder="e.g. AbCdEfGhIjK"
											helpText="The conversion label from your Google Ads purchase conversion action"
										/>
									</div>
								)}
							</div>
						</div>
					)}
					{/* Bottom Save Button */}
					<div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: '20px' }}>
						<button
							className="button button-primary"
							onClick={() => handleSave()}
							disabled={saving}
							style={{
								padding: '8px 24px',
								height: '42px',
								background: '#0f172a',
								borderColor: '#0f172a',
								color: '#fff',
								borderRadius: '6px',
								fontSize: '14px',
								fontWeight: '600',
								display: 'inline-flex',
								alignItems: 'center',
								gap: '8px'
							}}
						>
							{saving ? (
								<>
									<span className="dashicons dashicons-update" style={{ animation: 'spin 1s linear infinite' }}></span>
									{__('Saving...', 'revenuepro-bkash-wc')}
								</>
							) : (
								<>
									<span className="dashicons dashicons-saved"></span>
									{__('Save Changes', 'revenuepro-bkash-wc')}
								</>
							)}
						</button>
					</div>
				</div>
			</div>

			{/* Custom Revoke License Modal */}
			{showRevokeModal && (
				<div style={{
					position: 'fixed', top: 0, left: 0, right: 0, bottom: 0,
					background: 'rgba(15, 23, 42, 0.6)', backdropFilter: 'blur(4px)',
					display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 9999,
					animation: 'fadeIn 0.2s ease-out'
				}}>
					<div style={{
						background: '#fff', borderRadius: '16px', padding: '32px', maxWidth: '400px', width: '100%',
						boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)',
						textAlign: 'center', animation: 'slideIn 0.3s cubic-bezier(0.16, 1, 0.3, 1)'
					}}>
						<div style={{
							width: '64px', height: '64px', background: '#fef2f2', borderRadius: '50%',
							display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 20px'
						}}>
							<span className="dashicons dashicons-warning" style={{ fontSize: '32px', width: '32px', height: '32px', color: '#ef4444' }}></span>
						</div>
						<h2 style={{ margin: '0 0 12px', fontSize: '20px', fontWeight: '700', color: '#0f172a' }}>
							{__('Revoke License?', 'revenuepro-bkash-wc')}
						</h2>
						<p style={{ margin: '0 0 32px', color: '#64748b', fontSize: '15px', lineHeight: '1.5' }}>
							{__('Are you sure you want to revoke and disconnect your license? All premium features will be disabled immediately.', 'revenuepro-bkash-wc')}
						</p>
						<div style={{ display: 'flex', gap: '12px' }}>
							<button
								onClick={(e) => { e.preventDefault(); setShowRevokeModal(false); }}
								style={{
									flex: 1, padding: '12px', background: '#f1f5f9', color: '#475569',
									border: 'none', borderRadius: '8px', fontWeight: '600', cursor: 'pointer',
									transition: 'all 0.2s', fontSize: '14px'
								}}
							>
								{__('Cancel', 'revenuepro-bkash-wc')}
							</button>
							<button
								onClick={(e) => { e.preventDefault(); revokeLicense(); }}
								style={{
									flex: 1, padding: '12px', background: '#ef4444', color: '#fff',
									border: 'none', borderRadius: '8px', fontWeight: '600', cursor: 'pointer',
									transition: 'all 0.2s', fontSize: '14px', boxShadow: '0 4px 6px -1px rgba(239, 68, 68, 0.3)'
								}}
							>
								{__('Yes, Revoke', 'revenuepro-bkash-wc')}
							</button>
						</div>
					</div>
				</div>
			)}

			<style>{`
                @keyframes spin { 100% { transform: rotate(360deg); } }
                @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
                @keyframes slideIn { from { transform: translateY(100%); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
            `}</style>
		</div >
	);
}
