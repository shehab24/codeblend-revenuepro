import React, { useEffect, useState } from 'react';
import { __ } from '@wordpress/i18n';
import { useLocation, useNavigate, Link } from 'react-router-dom';
import { route_path } from '@Utils/helper';

const FormSubmissions = () => {
    const navigate = useNavigate();
    const query = new URLSearchParams(useLocation().search);
    const formId = query.get('id');

    const [submissions, setSubmissions] = useState([]);
    const [form, setForm] = useState(null);
    const [loading, setLoading] = useState(true);
    const [columns, setColumns] = useState([]);
    const [selectedIds, setSelectedIds] = useState(new Set());
    const [isDeleting, setIsDeleting] = useState(false);
    const [buttonFieldIdsState, setButtonFieldIdsState] = useState(new Set());

    useEffect(() => {
        if (!formId) {
            navigate({ search: 'page=revenuepro-bkash-wc-all-forms' });
            return;
        }
        fetchData();
    }, [formId]);

    const fetchData = async () => {
        setLoading(true);
        try {
            // Fetch form details to get fields
            const formRes = await fetch(`/wp-json/wp/v2/revenuepro_bkash_wc/${formId}`);
            if (!formRes.ok) throw new Error('Form not found');
            const formData = await formRes.json();
            setForm(formData);

            // Extract columns from form fields
            const formFields = formData.meta?.form_fields || [];
            const extractedColumns = [];
            const buttonFieldIds = new Set(); // Local set for this fetch operation
            let hasButtons = false;
            let buttonGroupLabel = __('Selected Option', 'revenuepro-bkash-wc');

            const extractFields = (fields, parentLabel = null) => {
                fields.forEach(field => {
                    if (field.type === 'columns') {
                        const currentLabel = field.label || parentLabel;
                        field.columns?.forEach(col => {
                            if (col.fields) extractFields(col.fields, currentLabel);
                        });
                    } else if (field.type === 'button') {
                        buttonFieldIds.add(String(field.id));
                        hasButtons = true;
                        if (parentLabel) {
                            buttonGroupLabel = parentLabel;
                        }
                    } else if (field.type !== 'heading') {
                        extractedColumns.push({
                            id: field.id,
                            label: field.label || field.id
                        });
                    }
                });
            };
            extractFields(formFields);

            // Add a single column for button selection if buttons exist
            if (hasButtons) {
                extractedColumns.unshift({ // Add to beginning or specific position? Let's add after Date.
                    id: 'button_selection',
                    label: buttonGroupLabel
                });
            }

            setColumns(extractedColumns);
            setButtonFieldIdsState(buttonFieldIds); // Update state with button field IDs

            // Fetch submissions
            const subRes = await fetch(`/wp-json/wp/v2/revenuepro_submission?form_id=${formId}&per_page=100`);
            const subData = await subRes.json();
            setSubmissions(subData);

        } catch (error) {
            console.error('Error fetching data:', error);
        } finally {
            setLoading(false);
        }
    };

    const [showDeleteModal, setShowDeleteModal] = useState(false);

    const handleSelectAll = (e) => {
        if (e.target.checked) {
            const allIds = new Set(submissions.map(sub => sub.id));
            setSelectedIds(allIds);
        } else {
            setSelectedIds(new Set());
        }
    };

    const handleSelectOne = (id) => {
        const newSelected = new Set(selectedIds);
        if (newSelected.has(id)) {
            newSelected.delete(id);
        } else {
            newSelected.add(id);
        }
        setSelectedIds(newSelected);
    };

    const handleBulkDeleteClick = () => {
        if (selectedIds.size === 0) return;
        setShowDeleteModal(true);
    };

    const confirmDelete = async () => {
        setIsDeleting(true);
        setShowDeleteModal(false);
        try {
            const promises = Array.from(selectedIds).map(id =>
                fetch(`/wp-json/wp/v2/revenuepro_submission/${id}`, {
                    method: 'DELETE',
                    headers: {
                        'X-WP-Nonce': window.RevenueProGlobal?.nonce || ''
                    }
                })
            );

            await Promise.all(promises);

            // Refresh data
            setSelectedIds(new Set());
            fetchData();

        } catch (error) {
            console.error('Error deleting items:', error);
            alert(__('Failed to delete some items.', 'revenuepro-bkash-wc'));
        } finally {
            setIsDeleting(false);
        }
    };

    const handleExportCSV = () => {
        if (!submissions.length) return;

        // Headers
        const headers = [
            'Date',
            'Payment Status',
            'Transaction ID',
            ...columns.map(col => col.label)
        ];

        // Rows
        const rows = submissions.map(sub => {
            const data = sub.meta?.submission_data || {};
            const paymentStatus = sub.meta?.payment_status || 'pending';
            const trxId = sub.meta?.bkash_trx_id || '-';
            const date = new Date(sub.date).toLocaleDateString() + ' ' + new Date(sub.date).toLocaleTimeString();

            const rowData = [
                date,
                paymentStatus,
                trxId
            ];

            columns.forEach(col => {
                let cellValue = data[col.id]?.value || '';
                if (col.id === 'button_selection') {
                    for (const key in data) {
                        if (buttonFieldIdsState.has(key)) {
                            const val = data[key]?.value;
                            if (val) {
                                cellValue = val;
                                break;
                            }
                        }
                    }
                }
                // Escape quotes for CSV
                rowData.push(`"${String(cellValue).replace(/"/g, '""')}"`);
            });

            return rowData.join(',');
        });

        const csvContent = [headers.join(','), ...rows].join('\n');
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = `${form?.title?.rendered || 'submissions'}_${new Date().toISOString().split('T')[0]}.csv`;
        link.click();
    };

    const handleExportExcel = () => {
        if (!submissions.length) return;

        let table = '<table border="1"><thead><tr>';

        // Headers
        table += `<th>Date</th><th>Payment Status</th><th>Transaction ID</th>`;
        columns.forEach(col => {
            table += `<th>${col.label}</th>`;
        });
        table += '</tr></thead><tbody>';

        // Rows
        submissions.forEach(sub => {
            const data = sub.meta?.submission_data || {};
            const paymentStatus = sub.meta?.payment_status || 'pending';
            const trxId = sub.meta?.bkash_trx_id || '-';
            const date = new Date(sub.date).toLocaleDateString() + ' ' + new Date(sub.date).toLocaleTimeString();

            table += `<tr>
                <td>${date}</td>
                <td>${paymentStatus}</td>
                <td style="mso-number-format:'\@'">${trxId}</td>`; // Force text format for ID

            columns.forEach(col => {
                let cellValue = data[col.id]?.value || '';
                if (col.id === 'button_selection') {
                    for (const key in data) {
                        if (buttonFieldIdsState.has(key)) {
                            const val = data[key]?.value;
                            if (val) {
                                cellValue = val;
                                break;
                            }
                        }
                    }
                }
                table += `<td>${cellValue}</td>`;
            });
            table += '</tr>';
        });
        table += '</tbody></table>';

        const blob = new Blob([table], { type: 'application/vnd.ms-excel' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = `${form?.title?.rendered || 'submissions'}_${new Date().toISOString().split('T')[0]}.xls`;
        link.click();
    };

    return (
        <div className="form-submissions-page" style={{ padding: '40px', fontFamily: '"Inter", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif', maxWidth: '1200px', margin: '0 auto' }}>

            {/* Header */}
            <div style={{ marginBottom: '30px', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
                <div>
                    <button
                        onClick={() => navigate({ search: 'page=revenuepro-bkash-wc-all-forms' })}
                        style={{
                            background: 'transparent',
                            border: 'none',
                            padding: '0',
                            cursor: 'pointer',
                            display: 'inline-flex',
                            alignItems: 'center',
                            gap: '6px',
                            color: '#64748b',
                            fontSize: '14px',
                            fontWeight: '500',
                            marginBottom: '12px',
                            transition: 'color 0.2s'
                        }}
                        onMouseEnter={(e) => e.currentTarget.style.color = '#0f172a'}
                        onMouseLeave={(e) => e.currentTarget.style.color = '#64748b'}
                    >
                        <span className="dashicons dashicons-arrow-left-alt2" style={{ fontSize: '16px' }}></span>
                        {__('Back to Forms', 'revenuepro-bkash-wc')}
                    </button>
                    <h1 style={{ fontSize: '28px', fontWeight: '700', margin: 0, color: '#0f172a', letterSpacing: '-0.5px' }}>
                        {form ? form.title.rendered : __('Submissions', 'revenuepro-bkash-wc')}
                    </h1>
                    <p style={{ margin: '5px 0 0 0', color: '#64748b', fontSize: '14px' }}>
                        {__('View and manage all submissions for this form.', 'revenuepro-bkash-wc')}
                    </p>
                </div>

                <div style={{ display: 'flex', gap: '10px' }}>
                    {submissions.length > 0 && (
                        <>
                            <button
                                onClick={handleExportCSV}
                                style={{
                                    background: '#fff',
                                    border: '1px solid #cbd5e1',
                                    color: '#475569',
                                    padding: '10px 16px',
                                    borderRadius: '6px',
                                    cursor: 'pointer',
                                    fontWeight: '600',
                                    fontSize: '14px',
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '8px',
                                    transition: 'all 0.2s'
                                }}
                            >
                                <span className="dashicons dashicons-media-spreadsheet" style={{ fontSize: '16px', width: '16px', height: '16px' }}></span>
                                {__('CSV', 'revenuepro-bkash-wc')}
                            </button>
                            <button
                                onClick={handleExportExcel}
                                style={{
                                    background: '#fff',
                                    border: '1px solid #cbd5e1',
                                    color: '#166534',
                                    padding: '10px 16px',
                                    borderRadius: '6px',
                                    cursor: 'pointer',
                                    fontWeight: '600',
                                    fontSize: '14px',
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '8px',
                                    transition: 'all 0.2s'
                                }}
                            >
                                <span className="dashicons dashicons-media-spreadsheet" style={{ fontSize: '16px', width: '16px', height: '16px' }}></span>
                                {__('Excel', 'revenuepro-bkash-wc')}
                            </button>
                        </>
                    )}

                    {selectedIds.size > 0 && (
                        <button
                            onClick={handleBulkDeleteClick}
                            disabled={isDeleting}
                            style={{
                                background: '#ef4444',
                                color: '#fff',
                                border: 'none',
                                padding: '10px 20px',
                                borderRadius: '6px',
                                cursor: isDeleting ? 'not-allowed' : 'pointer',
                                fontWeight: '600',
                                fontSize: '14px',
                                display: 'flex',
                                alignItems: 'center',
                                gap: '8px',
                                boxShadow: '0 1px 2px rgba(0,0,0,0.05)'
                            }}
                        >
                            <span className="dashicons dashicons-trash" style={{ fontSize: '16px', width: '16px', height: '16px' }}></span>
                            {isDeleting ? __('Deleting...', 'revenuepro-bkash-wc') : __(`Delete Selected (${selectedIds.size})`, 'revenuepro-bkash-wc')}
                        </button>
                    )}
                </div>
            </div>

            {/* Main Card */}
            <div style={{ background: '#fff', borderRadius: '16px', boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03)', overflow: 'hidden', border: '1px solid #f1f5f9' }}>

                {/* Table */}
                {loading ? (
                    <div style={{ padding: '60px', textAlign: 'center', color: '#64748b' }}>
                        <div className="spinner" style={{ margin: '0 auto 15px' }}></div>
                        {__('Loading submissions...', 'revenuepro-bkash-wc')}
                    </div>
                ) : submissions.length === 0 ? (
                    <div style={{ padding: '80px 20px', textAlign: 'center', color: '#64748b' }}>
                        <div style={{ fontSize: '48px', marginBottom: '20px', opacity: 0.3 }}>📭</div>
                        <h3 style={{ margin: '0 0 8px 0', color: '#0f172a', fontSize: '18px' }}>{__('No submissions yet', 'revenuepro-bkash-wc')}</h3>
                        <p style={{ margin: 0, fontSize: '14px' }}>{__('When users submit this form, their responses will appear here.', 'revenuepro-bkash-wc')}</p>
                    </div>
                ) : (
                    <div style={{ overflowX: 'auto' }}>
                        <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: '800px' }}>
                            <thead>
                                <tr style={{ borderBottom: '1px solid #e2e8f0' }}>
                                    <th style={{ padding: '20px 24px', width: '40px', background: '#f8fafc' }}>
                                        <input
                                            type="checkbox"
                                            checked={submissions.length > 0 && selectedIds.size === submissions.length}
                                            onChange={handleSelectAll}
                                            style={{ cursor: 'pointer', width: '16px', height: '16px' }}
                                        />
                                    </th>
                                    <th style={{ padding: '20px 24px', textAlign: 'left', fontSize: '12px', fontWeight: '600', color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.5px', background: '#f8fafc' }}>
                                        {__('Date', 'revenuepro-bkash-wc')}
                                    </th>
                                    <th style={{ padding: '20px 24px', textAlign: 'left', fontSize: '12px', fontWeight: '600', color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.5px', background: '#f8fafc' }}>
                                        {__('Payment Status', 'revenuepro-bkash-wc')}
                                    </th>
                                    <th style={{ padding: '20px 24px', textAlign: 'left', fontSize: '12px', fontWeight: '600', color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.5px', background: '#f8fafc' }}>
                                        {__('Transaction ID', 'revenuepro-bkash-wc')}
                                    </th>
                                    {columns.map(col => (
                                        <th key={col.id} style={{ padding: '20px 24px', textAlign: 'left', fontSize: '12px', fontWeight: '600', color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.5px', background: '#f8fafc' }}>
                                            {col.label}
                                        </th>
                                    ))}
                                </tr>
                            </thead>
                            <tbody>
                                {submissions.map((sub, index) => {
                                    const data = sub.meta?.submission_data || {};
                                    const paymentStatus = sub.meta?.payment_status || 'pending';
                                    const trxId = sub.meta?.bkash_trx_id || '-';
                                    const isSelected = selectedIds.has(sub.id);

                                    return (
                                        <tr key={sub.id} style={{ borderBottom: index === submissions.length - 1 ? 'none' : '1px solid #f1f5f9', transition: 'background 0.15s', background: isSelected ? '#f1f5f9' : '#fff' }} onMouseEnter={(e) => !isSelected && (e.currentTarget.style.background = '#f8fafc')} onMouseLeave={(e) => !isSelected && (e.currentTarget.style.background = '#fff')}>
                                            <td style={{ padding: '20px 24px' }}>
                                                <input
                                                    type="checkbox"
                                                    checked={isSelected}
                                                    onChange={() => handleSelectOne(sub.id)}
                                                    style={{ cursor: 'pointer', width: '16px', height: '16px' }}
                                                />
                                            </td>
                                            <td style={{ padding: '20px 24px', whiteSpace: 'nowrap', color: '#334155', fontSize: '14px', fontWeight: '500' }}>
                                                {new Date(sub.date).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' })}
                                                <div style={{ fontSize: '12px', color: '#94a3b8', marginTop: '2px' }}>
                                                    {new Date(sub.date).toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' })}
                                                </div>
                                            </td>
                                            <td style={{ padding: '20px 24px', fontSize: '14px', verticalAlign: 'top' }}>
                                                <span style={{
                                                    display: 'inline-block',
                                                    padding: '4px 8px',
                                                    borderRadius: '4px',
                                                    fontSize: '12px',
                                                    fontWeight: '600',
                                                    textTransform: 'capitalize',
                                                    background: paymentStatus === 'completed' ? '#dcfce7' : '#f1f5f9',
                                                    color: paymentStatus === 'completed' ? '#166534' : '#64748b'
                                                }}>
                                                    {paymentStatus}
                                                </span>
                                            </td>
                                            <td style={{ padding: '20px 24px', fontSize: '14px', color: '#334155', verticalAlign: 'top', fontFamily: 'monospace' }}>
                                                {trxId}
                                            </td>
                                            {columns.map(col => {
                                                let cellValue = data[col.id]?.value;

                                                if (col.id === 'button_selection') {
                                                    let selectedButtonValue = null;
                                                    for (const key in data) {
                                                        if (buttonFieldIdsState.has(key)) {
                                                            const val = data[key]?.value;
                                                            if (val) {
                                                                selectedButtonValue = val;
                                                                break;
                                                            }
                                                        }
                                                    }
                                                    return (
                                                        <td key={col.id} style={{ padding: '20px 24px', fontSize: '14px', color: '#334155', verticalAlign: 'top' }}>
                                                            {selectedButtonValue || <span style={{ color: '#cbd5e1' }}>-</span>}
                                                        </td>
                                                    );
                                                }

                                                return (
                                                    <td key={col.id} style={{ padding: '20px 24px', fontSize: '14px', color: '#334155', verticalAlign: 'top' }}>
                                                        {cellValue || <span style={{ color: '#cbd5e1' }}>-</span>}
                                                    </td>
                                                );
                                            })}
                                        </tr>
                                    );
                                })}
                            </tbody>
                        </table>
                    </div>
                )}
            </div>

            {/* Delete Confirmation Modal */}
            {showDeleteModal && (
                <div style={{
                    position: 'fixed',
                    top: 0,
                    left: 0,
                    right: 0,
                    bottom: 0,
                    background: 'rgba(0,0,0,0.5)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    zIndex: 99999,
                    backdropFilter: 'blur(2px)'
                }}>
                    <div style={{
                        background: '#fff',
                        borderRadius: '12px',
                        padding: '30px',
                        width: '400px',
                        maxWidth: '90%',
                        boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)',
                        textAlign: 'center'
                    }}>
                        <div style={{
                            width: '60px',
                            height: '60px',
                            background: '#fee2e2',
                            borderRadius: '50%',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            margin: '0 auto 20px',
                            color: '#ef4444'
                        }}>
                            <span className="dashicons dashicons-trash" style={{ fontSize: '30px', width: '30px', height: '30px' }}></span>
                        </div>
                        <h3 style={{ margin: '0 0 10px 0', color: '#1f2937', fontSize: '20px', fontWeight: '600' }}>
                            {__('Delete Submissions?', 'revenuepro-bkash-wc')}
                        </h3>
                        <p style={{ margin: '0 0 25px 0', color: '#6b7280', fontSize: '15px', lineHeight: '1.5' }}>
                            {__(`Are you sure you want to delete ${selectedIds.size} selected items? This action cannot be undone.`, 'revenuepro-bkash-wc')}
                        </p>
                        <div style={{ display: 'flex', gap: '12px', justifyContent: 'center' }}>
                            <button
                                onClick={() => setShowDeleteModal(false)}
                                style={{
                                    padding: '10px 20px',
                                    borderRadius: '6px',
                                    border: '1px solid #d1d5db',
                                    background: '#fff',
                                    color: '#374151',
                                    fontSize: '14px',
                                    fontWeight: '500',
                                    cursor: 'pointer',
                                    transition: 'all 0.2s'
                                }}
                                onMouseEnter={(e) => e.currentTarget.style.background = '#f9fafb'}
                                onMouseLeave={(e) => e.currentTarget.style.background = '#fff'}
                            >
                                {__('Cancel', 'revenuepro-bkash-wc')}
                            </button>
                            <button
                                onClick={confirmDelete}
                                style={{
                                    padding: '10px 20px',
                                    borderRadius: '6px',
                                    border: 'none',
                                    background: '#ef4444',
                                    color: '#fff',
                                    fontSize: '14px',
                                    fontWeight: '500',
                                    cursor: 'pointer',
                                    boxShadow: '0 1px 2px rgba(0,0,0,0.05)',
                                    transition: 'all 0.2s'
                                }}
                                onMouseEnter={(e) => e.currentTarget.style.background = '#dc2626'}
                                onMouseLeave={(e) => e.currentTarget.style.background = '#ef4444'}
                            >
                                {__('Delete', 'revenuepro-bkash-wc')}
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default FormSubmissions;
