import React, { useState, useEffect } from 'react';
import { __ } from '@wordpress/i18n';

const InputGroup = ({ label, type = "text", value, onChange, placeholder, helpText, multiline = false, required = false, disabled = false }) => (
	<div style={{ marginBottom: '24px' }}>
		<label style={{ display: 'block', marginBottom: '8px', fontSize: '14px', fontWeight: '600', color: '#334155' }}>
			{label} {required && <span style={{ color: '#ef4444' }}>*</span>}
		</label>
		{multiline ? (
			<textarea
				value={value}
				onChange={onChange}
				placeholder={placeholder}
				required={required}
				disabled={disabled}
				rows="6"
				style={{
					width: '100%', padding: '12px 16px', fontSize: '14px',
					border: '1px solid #e2e8f0', borderRadius: '8px',
					backgroundColor: disabled ? '#e2e8f0' : '#f8fafc',
					color: '#1e293b', outline: 'none', transition: 'all 0.2s',
					fontFamily: 'inherit', resize: 'vertical'
				}}
				onFocus={(e) => { if (!disabled) { e.target.style.borderColor = '#3b82f6'; e.target.style.backgroundColor = '#fff'; e.target.style.boxShadow = '0 0 0 3px rgba(59, 130, 246, 0.1)'; }}}
				onBlur={(e) => { e.target.style.borderColor = '#e2e8f0'; e.target.style.backgroundColor = disabled ? '#e2e8f0' : '#f8fafc'; e.target.style.boxShadow = 'none'; }}
			/>
		) : (
			<input
				type={type} value={value} onChange={onChange}
				placeholder={placeholder} required={required} disabled={disabled}
				style={{
					width: '100%', padding: '12px 16px', fontSize: '14px',
					border: '1px solid #e2e8f0', borderRadius: '8px',
					backgroundColor: disabled ? '#e2e8f0' : '#f8fafc',
					color: '#1e293b', outline: 'none', transition: 'all 0.2s'
				}}
				onFocus={(e) => { if (!disabled) { e.target.style.borderColor = '#3b82f6'; e.target.style.backgroundColor = '#fff'; e.target.style.boxShadow = '0 0 0 3px rgba(59, 130, 246, 0.1)'; }}}
				onBlur={(e) => { e.target.style.borderColor = '#e2e8f0'; e.target.style.backgroundColor = disabled ? '#e2e8f0' : '#f8fafc'; e.target.style.boxShadow = 'none'; }}
			/>
		)}
		{helpText && <p style={{ margin: '6px 0 0', fontSize: '13px', color: '#64748b' }}>{helpText}</p>}
	</div>
);

export default function FeatureRequest() {
	const [formData, setFormData] = useState({
		title: '', description: '', priority: 'medium', email: ''
	});
	const [submitting, setSubmitting] = useState(false);
	const [message, setMessage] = useState(null);
	const [limitReached, setLimitReached] = useState(false);
	const [checking, setChecking] = useState(true);

	// Load license email from WP settings on mount
	useEffect(() => {
		const fetchEmail = async () => {
			try {
				const restUrl = window.RevenueProGlobal?.rest_url || '/wp-json/';
				const res = await fetch(`${restUrl}revenuepro-bkash-wc/v1/settings?_t=${Date.now()}`, {
					headers: { 'X-WP-Nonce': window.RevenueProGlobal?.nonce || '' }
				});
				if (res.ok) {
					const data = await res.json();
					const licenseEmail = data.account_email && data.account_email !== 'None' ? data.account_email : '';
					setFormData(prev => ({ ...prev, email: licenseEmail }));
					if (licenseEmail) checkActiveLimit(licenseEmail);
					else setChecking(false);
				} else { setChecking(false); }
			} catch { setChecking(false); }
		};
		fetchEmail();
	}, []);

	const checkActiveLimit = async (emailToCheck) => {
		setChecking(true);
		try {
			const apiBase = window.RevenueProGlobal?.api_base_url || 'http://localhost:3000';
			const url = `${apiBase}/api/v1/requests?email=${encodeURIComponent(emailToCheck)}`;
			console.log('[FeatureRequest] Checking limit for:', emailToCheck, url);
			const res = await fetch(url);
			const data = await res.json();
			console.log('[FeatureRequest] Limit check response:', data);
			if (res.ok && data.activeCount >= 2) {
				setLimitReached(true);
			} else {
				setLimitReached(false);
			}
		} catch (e) {
			console.error('[FeatureRequest] Limit check error:', e);
			setLimitReached(false);
		}
		setChecking(false);
	};

	const handleChange = (key, value) => {
		setFormData(prev => ({ ...prev, [key]: value }));
	};

	const handleSubmit = async (e) => {
		e.preventDefault();
		const emailUsed = formData.email;
		setSubmitting(true);
		setMessage(null);
		try {
			const apiBase = window.RevenueProGlobal?.api_base_url || 'http://localhost:3000';
			const rawUrl = window.RevenueProGlobal?.site_url || window.location.origin;
			const response = await fetch(`${apiBase}/api/v1/requests`, {
				method: 'POST',
				headers: { 'Content-Type': 'application/json' },
				body: JSON.stringify({ ...formData, domain: rawUrl })
			});
			const data = await response.json();
			console.log('[FeatureRequest] Submit response:', response.status, data);
			if (response.ok && data.success) {
				setMessage({ type: 'success', text: __('Feature request submitted successfully! Thank you for your feedback.', 'revenuepro-bkash-wc') });
				setFormData(prev => ({ ...prev, title: '', description: '', priority: 'medium' }));
				// Re-check limit after successful submit
				await checkActiveLimit(emailUsed);
			} else if (data.limitReached) {
				setLimitReached(true);
			} else {
				setMessage({ type: 'error', text: data.error || data.message || __('Failed to submit feature request.', 'revenuepro-bkash-wc') });
			}
		} catch (error) {
			console.error('[FeatureRequest] Submit error:', error);
			setMessage({ type: 'error', text: __('Network error. Please try again later.', 'revenuepro-bkash-wc') });
		} finally {
			setSubmitting(false);
			setTimeout(() => setMessage(null), 5000);
		}
	};

	return (
		<div className="feature-request-page" style={{
			padding: '40px', maxWidth: '800px', margin: '0 auto',
			fontFamily: '"Inter", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif'
		}}>
			{/* Header */}
			<div style={{ marginBottom: '40px', textAlign: 'center' }}>
				<div style={{ width: '64px', height: '64px', background: '#eff6ff', borderRadius: '16px', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 20px' }}>
					<span className="dashicons dashicons-lightbulb" style={{ fontSize: '32px', width: '32px', height: '32px', color: '#3b82f6' }}></span>
				</div>
				<h1 style={{ fontSize: '28px', fontWeight: '700', color: '#0f172a', margin: 0, letterSpacing: '-0.5px' }}>
					{__('Feature Request', 'revenuepro-bkash-wc')}
				</h1>
				<p style={{ margin: '8px 0 0', color: '#64748b', fontSize: '15px' }}>
					{__('Have an idea to improve RevenuePro? We would love to hear from you.', 'revenuepro-bkash-wc')}
				</p>
			</div>

			{/* Notification */}
			{message && (
				<div style={{
					marginBottom: '24px', padding: '16px 24px', borderRadius: '8px',
					background: message.type === 'success' ? '#d1fae5' : '#fee2e2',
					color: message.type === 'success' ? '#065f46' : '#991b1b',
					border: `1px solid ${message.type === 'success' ? '#a7f3d0' : '#fecaca'}`,
					display: 'flex', alignItems: 'center', gap: '12px', fontWeight: '500'
				}}>
					<span className={`dashicons ${message.type === 'success' ? 'dashicons-saved' : 'dashicons-warning'}`}></span>
					{message.text}
				</div>
			)}

			{/* Limit Reached Banner */}
			{limitReached ? (
				<div style={{
					background: '#fff', borderRadius: '16px', padding: '48px 32px',
					boxShadow: '0 4px 6px -1px rgba(0,0,0,0.05)', border: '1px solid #f1f5f9',
					textAlign: 'center'
				}}>
					<div style={{ width: '72px', height: '72px', background: '#fef3c7', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 24px' }}>
						<span className="dashicons dashicons-info-outline" style={{ fontSize: '36px', width: '36px', height: '36px', color: '#d97706' }}></span>
					</div>
					<h2 style={{ fontSize: '22px', fontWeight: '700', color: '#0f172a', margin: '0 0 12px' }}>
						{__('Request Limit Reached', 'revenuepro-bkash-wc')}
					</h2>
					<p style={{ color: '#64748b', fontSize: '15px', lineHeight: '1.6', maxWidth: '480px', margin: '0 auto 28px' }}>
						{__('You already have 2 active feature requests. To track progress or manage your requests, please login to our portal.', 'revenuepro-bkash-wc')}
					</p>
					<a
						href="https://codeblend.co/"
						target="_blank"
						rel="noopener noreferrer"
						style={{
							display: 'inline-flex', alignItems: 'center', gap: '8px',
							background: '#3b82f6', color: '#fff', padding: '14px 28px',
							borderRadius: '8px', textDecoration: 'none', fontWeight: '600', fontSize: '15px',
							boxShadow: '0 4px 6px -1px rgba(59,130,246,0.4)', transition: 'all 0.2s'
						}}
					>
						<span className="dashicons dashicons-external" style={{ fontSize: '18px', width: '18px', height: '18px' }}></span>
						{__('Login to Portal', 'revenuepro-bkash-wc')}
					</a>
				</div>
			) : checking ? (
				<div style={{ textAlign: 'center', padding: '60px', color: '#64748b' }}>
					<style>{`@keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }`}</style>
					<span className="dashicons dashicons-update" style={{ fontSize: '28px', width: '28px', height: '28px', animation: 'spin 1s linear infinite' }}></span>
					<p style={{ marginTop: '12px' }}>{__('Checking request status...', 'revenuepro-bkash-wc')}</p>
				</div>
			) : (
				<>
					{/* Form Container */}
					<div style={{ background: '#fff', borderRadius: '16px', padding: '32px', boxShadow: '0 4px 6px -1px rgba(0,0,0,0.05)', border: '1px solid #f1f5f9' }}>
						<form onSubmit={handleSubmit}>
							<InputGroup
								label={__('Email Address', 'revenuepro-bkash-wc')}
								type="email"
								value={formData.email}
								onChange={(e) => handleChange('email', e.target.value)}
								placeholder={__('Enter your email', 'revenuepro-bkash-wc')}
								required={true}
								helpText={__('This should match your license account email.', 'revenuepro-bkash-wc')}
							/>
							<InputGroup
								label={__('Feature Title', 'revenuepro-bkash-wc')}
								value={formData.title}
								onChange={(e) => handleChange('title', e.target.value)}
								placeholder={__('e.g., Add support for new payment gateway', 'revenuepro-bkash-wc')}
								required={true}
							/>
							<InputGroup
								label={__('Description', 'revenuepro-bkash-wc')}
								value={formData.description}
								onChange={(e) => handleChange('description', e.target.value)}
								placeholder={__('Please describe the feature in detail. What problem does it solve?', 'revenuepro-bkash-wc')}
								multiline={true}
								required={true}
							/>
							<div style={{ marginBottom: '24px' }}>
								<label style={{ display: 'block', marginBottom: '8px', fontSize: '14px', fontWeight: '600', color: '#334155' }}>
									{__('Priority', 'revenuepro-bkash-wc')}
								</label>
								<select
									value={formData.priority}
									onChange={(e) => handleChange('priority', e.target.value)}
									style={{
										width: '100%', padding: '12px 16px', fontSize: '14px',
										border: '1px solid #e2e8f0', borderRadius: '8px',
										backgroundColor: '#f8fafc', color: '#1e293b',
										outline: 'none', transition: 'all 0.2s', appearance: 'none',
										backgroundImage: `url("data:image/svg+xml;charset=US-ASCII,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%22292.4%22%20height%3D%22292.4%22%3E%3Cpath%20fill%3D%22%23475569%22%20d%3D%22M287%2069.4a17.6%2017.6%200%200%200-13-5.4H18.4c-5%200-9.3%201.8-12.9%205.4A17.6%2017.6%200%200%200%200%2082.2c0%205%201.8%209.3%205.4%2012.9l128%20127.9c3.6%203.6%207.8%205.4%2012.8%205.4s9.2-1.8%2012.8-5.4L287%2095c3.5-3.5%205.4-7.8%205.4-12.8%200-5-1.9-9.2-5.5-12.8z%22%2F%3E%3C%2Fsvg%3E")`,
										backgroundRepeat: 'no-repeat', backgroundPosition: 'right 16px center', backgroundSize: '12px'
									}}
								>
									<option value="low">{__('Low - Nice to have', 'revenuepro-bkash-wc')}</option>
									<option value="medium">{__('Medium - Important but not urgent', 'revenuepro-bkash-wc')}</option>
									<option value="high">{__('High - Critical for my business', 'revenuepro-bkash-wc')}</option>
								</select>
							</div>
							<div style={{ marginTop: '32px', display: 'flex', justifyContent: 'flex-end' }}>
								<button type="submit" disabled={submitting} style={{
									background: '#3b82f6', color: '#fff', border: 'none',
									padding: '14px 28px', borderRadius: '8px',
									cursor: submitting ? 'not-allowed' : 'pointer',
									opacity: submitting ? 0.8 : 1, fontWeight: '600', fontSize: '15px',
									boxShadow: '0 4px 6px -1px rgba(59,130,246,0.4)',
									transition: 'all 0.2s', display: 'flex', alignItems: 'center', gap: '8px'
								}}>
									{submitting ? (
										<><span className="dashicons dashicons-update" style={{ animation: 'spin 1s linear infinite' }}></span>{__('Submitting...', 'revenuepro-bkash-wc')}</>
									) : (
										<><span className="dashicons dashicons-paperplane"></span>{__('Submit Request', 'revenuepro-bkash-wc')}</>
									)}
								</button>
							</div>
						</form>
					</div>

					{/* Login to Dashboard Button */}
					<div style={{
						marginTop: '24px', textAlign: 'center', padding: '24px',
						background: '#f8fafc', borderRadius: '12px', border: '1px solid #e2e8f0'
					}}>
						<p style={{ margin: '0 0 16px', color: '#64748b', fontSize: '14px' }}>
							{__('Already submitted a request? Track your requests on our portal.', 'revenuepro-bkash-wc')}
						</p>
						<a
							href="https://codeblend.co/"
							target="_blank"
							rel="noopener noreferrer"
							style={{
								display: 'inline-flex', alignItems: 'center', gap: '8px',
								background: '#0f172a', color: '#fff', padding: '12px 24px',
								borderRadius: '8px', textDecoration: 'none', fontWeight: '600', fontSize: '14px',
								transition: 'all 0.2s'
							}}
						>
							<span className="dashicons dashicons-admin-home" style={{ fontSize: '16px', width: '16px', height: '16px' }}></span>
							{__('Login to Dashboard', 'revenuepro-bkash-wc')}
						</a>
					</div>
				</>
			)}
		</div>
	);
}
