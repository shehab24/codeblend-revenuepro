import React, { useEffect, useState } from 'react';
import { __ } from '@wordpress/i18n';
import { Link } from 'react-router-dom';
import { route_path } from '@Utils/helper';

const AllForms = () => {
    const [forms, setForms] = useState([]);
    const [loading, setLoading] = useState(true);
    const [filter, setFilter] = useState('all');
    const [searchTerm, setSearchTerm] = useState('');
    const [deleting, setDeleting] = useState(null);
    const [deleteModal, setDeleteModal] = useState({ isOpen: false, formId: null, formTitle: '' });
    const [notification, setNotification] = useState(null);

    useEffect(() => {
        fetchForms();
    }, []);

    useEffect(() => {
        if (notification) {
            const timer = setTimeout(() => setNotification(null), 3000);
            return () => clearTimeout(timer);
        }
    }, [notification]);

    const fetchForms = async () => {
        setLoading(true);
        try {
            const response = await fetch('/wp-json/wp/v2/revenuepro_bkash_wc?per_page=100&_embed', {
                headers: {
                    'X-WP-Nonce': window.RevenueProGlobal?.nonce || '',
                },
                credentials: 'same-origin',
            });

            if (response.ok) {
                const data = await response.json();
                const formattedForms = data.map(form => ({
                    id: form.id,
                    title: form.title.rendered || 'Untitled Form',
                    author: form._embedded?.author?.[0]?.name || 'Unknown',
                    date: new Date(form.date).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }),
                    time: new Date(form.date).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' }),
                    status: form.status,
                    shortcode: `[revenuepro_bkash_wc id="${form.id}"]`,
                }));
                setForms(formattedForms);
            } else {
                console.error('Failed to fetch forms:', response.status);
            }
        } catch (error) {
            console.error('Error fetching forms:', error);
        } finally {
            setLoading(false);
        }
    };

    const confirmDelete = (formId, formTitle) => {
        setDeleteModal({ isOpen: true, formId, formTitle });
    };

    const handleDelete = async () => {
        const { formId, formTitle } = deleteModal;
        setDeleteModal({ isOpen: false, formId: null, formTitle: '' });

        setDeleting(formId);
        try {
            const response = await fetch(`/wp-json/wp/v2/revenuepro_bkash_wc/${formId}?force=true`, {
                method: 'DELETE',
                headers: {
                    'X-WP-Nonce': window.RevenueProGlobal?.nonce || '',
                },
                credentials: 'same-origin',
            });

            if (response.ok) {
                setForms(forms.filter(f => f.id !== formId));
                setNotification({ type: 'success', message: __('Form deleted successfully!', 'revenuepro-bkash-wc') });
            } else {
                const error = await response.json();
                setNotification({ type: 'error', message: __('Failed to delete form: ', 'revenuepro-bkash-wc') + (error.message || response.statusText) });
            }
        } catch (error) {
            console.error('Error deleting form:', error);
            setNotification({ type: 'error', message: __('Error deleting form. Please try again.', 'revenuepro-bkash-wc') });
        } finally {
            setDeleting(null);
        }
    };

    const getStatusBadge = (status) => {
        const isPublished = status === 'publish';
        return (
            <span style={{
                background: isPublished ? 'rgba(70, 180, 80, 0.1)' : 'rgba(108, 117, 125, 0.1)',
                color: isPublished ? '#46b450' : '#6c757d',
                padding: '6px 14px',
                borderRadius: '20px',
                fontSize: '13px',
                fontWeight: '600',
                display: 'inline-flex',
                alignItems: 'center',
                gap: '6px'
            }}>
                {status.charAt(0).toUpperCase() + status.slice(1)} {isPublished ? '✓' : ''}
            </span>
        );
    };

    const filteredForms = forms.filter(f => {
        const matchesFilter = filter === 'all' || f.status === filter;
        const matchesSearch = f.title.toLowerCase().includes(searchTerm.toLowerCase());
        return matchesFilter && matchesSearch;
    });

    return (
        <div className="all-forms-page" style={{ padding: '20px', fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif' }}>

            {/* Header */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '25px' }}>
                <h1 style={{ fontSize: '24px', fontWeight: '600', margin: 0, color: '#1d2327' }}>
                    {__('RevenuePros', 'revenuepro-bkash-wc')}
                </h1>
                <Link
                    to={`${route_path}admin.php?page=revenuepro-bkash-wc-create`}
                    style={{
                        background: '#6c5ce7', // Purple color from screenshot
                        color: '#fff',
                        padding: '10px 20px',
                        borderRadius: '6px',
                        textDecoration: 'none',
                        fontSize: '14px',
                        fontWeight: '500',
                        display: 'inline-flex',
                        alignItems: 'center',
                        gap: '8px',
                        boxShadow: '0 2px 5px rgba(108, 92, 231, 0.3)'
                    }}
                >
                    {__('Add New Form', 'revenuepro-bkash-wc')}
                </Link>
            </div>

            {/* Main Card */}
            <div style={{ background: '#fff', borderRadius: '12px', boxShadow: '0 2px 15px rgba(0,0,0,0.05)', overflow: 'hidden' }}>

                {/* Toolbar */}
                <div style={{ padding: '20px', borderBottom: '1px solid #f0f0f1', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '20px' }}>

                    {/* Tabs */}
                    <div style={{ display: 'flex', gap: '25px' }}>
                        {['all', 'publish', 'draft', 'pending', 'private', 'trash'].map(status => (
                            <button
                                key={status}
                                onClick={() => setFilter(status)}
                                style={{
                                    background: 'none',
                                    border: 'none',
                                    padding: '0 0 8px 0',
                                    cursor: 'pointer',
                                    color: filter === status ? '#6c5ce7' : '#646970',
                                    borderBottom: filter === status ? '2px solid #6c5ce7' : '2px solid transparent',
                                    fontWeight: filter === status ? '600' : '500',
                                    fontSize: '14px',
                                    textTransform: 'capitalize',
                                    transition: 'all 0.2s'
                                }}
                            >
                                {status}
                            </button>
                        ))}
                    </div>

                    {/* Search & Actions */}
                    <div style={{ display: 'flex', gap: '15px' }}>
                        <div style={{ position: 'relative' }}>
                            <input
                                type="text"
                                placeholder={__('Search Form', 'revenuepro-bkash-wc')}
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                                style={{
                                    padding: '8px 15px 8px 35px',
                                    border: '1px solid #e2e4e7',
                                    borderRadius: '6px',
                                    fontSize: '14px',
                                    width: '250px',
                                    outline: 'none',
                                    color: '#646970'
                                }}
                            />
                            <span className="dashicons dashicons-search" style={{ position: 'absolute', left: '10px', top: '50%', transform: 'translateY(-50%)', color: '#a0a0a0' }}></span>
                        </div>
                        <button style={{
                            background: '#fff',
                            border: '1px solid #e2e4e7',
                            borderRadius: '6px',
                            padding: '8px 15px',
                            display: 'flex',
                            alignItems: 'center',
                            gap: '8px',
                            color: '#646970',
                            cursor: 'pointer',
                            fontSize: '14px',
                            fontWeight: '500'
                        }}>
                            <span className="dashicons dashicons-columns"></span>
                            {__('Columns', 'revenuepro-bkash-wc')}
                        </button>
                    </div>
                </div>

                {/* Table */}
                {loading ? (
                    <div style={{ padding: '40px', textAlign: 'center', color: '#646970' }}>{__('Loading...', 'revenuepro-bkash-wc')}</div>
                ) : filteredForms.length === 0 ? (
                    <div style={{ padding: '60px', textAlign: 'center', color: '#646970' }}>
                        <div style={{ fontSize: '48px', marginBottom: '15px', opacity: 0.5 }}>📭</div>
                        <p>{__('No forms found matching your criteria.', 'revenuepro-bkash-wc')}</p>
                    </div>
                ) : (
                    <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                        <thead>
                            <tr style={{ background: '#f8f9fa' }}>
                                <th style={{ padding: '15px 20px', textAlign: 'left', width: '40px', borderBottom: '1px solid #eee' }}>
                                    <input type="checkbox" style={{ borderRadius: '3px', border: '1px solid #ccc' }} />
                                </th>
                                <th style={{ padding: '15px 20px', textAlign: 'left', fontSize: '13px', fontWeight: '600', color: '#1d2327', borderBottom: '1px solid #eee' }}>{__('Title', 'revenuepro-bkash-wc')}</th>
                                <th style={{ padding: '15px 20px', textAlign: 'left', fontSize: '13px', fontWeight: '600', color: '#1d2327', borderBottom: '1px solid #eee' }}>{__('Shortcode', 'revenuepro-bkash-wc')}</th>
                                <th style={{ padding: '15px 20px', textAlign: 'left', fontSize: '13px', fontWeight: '600', color: '#1d2327', borderBottom: '1px solid #eee' }}>{__('Date', 'revenuepro-bkash-wc')}</th>
                                <th style={{ padding: '15px 20px', textAlign: 'left', fontSize: '13px', fontWeight: '600', color: '#1d2327', borderBottom: '1px solid #eee' }}>{__('Author', 'revenuepro-bkash-wc')}</th>
                                <th style={{ padding: '15px 20px', textAlign: 'left', fontSize: '13px', fontWeight: '600', color: '#1d2327', borderBottom: '1px solid #eee' }}>{__('Status', 'revenuepro-bkash-wc')}</th>
                                <th style={{ padding: '15px 20px', textAlign: 'center', fontSize: '13px', fontWeight: '600', color: '#1d2327', borderBottom: '1px solid #eee' }}>{__('Action', 'revenuepro-bkash-wc')}</th>
                            </tr>
                        </thead>
                        <tbody>
                            {filteredForms.map((form) => (
                                <tr key={form.id} style={{ borderBottom: '1px solid #f0f0f1', transition: 'background 0.2s' }} onMouseEnter={(e) => e.currentTarget.style.background = '#fcfcfc'} onMouseLeave={(e) => e.currentTarget.style.background = '#fff'}>
                                    <td style={{ padding: '15px 20px' }}>
                                        <input type="checkbox" style={{ borderRadius: '3px', border: '1px solid #ccc' }} />
                                    </td>
                                    <td style={{ padding: '15px 20px' }}>
                                        <div style={{ fontWeight: '600', color: '#6c5ce7', fontSize: '14px', marginBottom: '4px' }}>
                                            <Link to={`${route_path}admin.php?page=revenuepro-bkash-wc-edit&id=${form.id}`} style={{ color: 'inherit', textDecoration: 'none' }}>
                                                {form.title} <span className="dashicons dashicons-external" style={{ fontSize: '12px', marginLeft: '4px' }}></span>
                                            </Link>
                                        </div>
                                        <div style={{ fontSize: '12px', color: '#a0a0a0' }}>ID: {form.id}</div>
                                    </td>
                                    <td style={{ padding: '15px 20px' }}>
                                        <code style={{ background: '#f6f7f7', padding: '4px 8px', borderRadius: '4px', fontSize: '12px', color: '#50575e', border: '1px solid #dcdcde' }}>
                                            {form.shortcode}
                                        </code>
                                    </td>
                                    <td style={{ padding: '15px 20px' }}>
                                        <div style={{ fontSize: '14px', color: '#1d2327' }}>{form.date}</div>
                                        <div style={{ fontSize: '12px', color: '#a0a0a0' }}>{form.time}</div>
                                    </td>
                                    <td style={{ padding: '15px 20px', fontSize: '14px', color: '#1d2327' }}>
                                        {form.author}
                                    </td>
                                    <td style={{ padding: '15px 20px' }}>
                                        {getStatusBadge(form.status)}
                                    </td>
                                    <td style={{ padding: '15px 20px', textAlign: 'center' }}>
                                        <div style={{ display: 'flex', justifyContent: 'center', gap: '8px' }}>
                                            <Link
                                                to={`${route_path}admin.php?page=revenuepro-bkash-wc-submissions&id=${form.id}`}
                                                style={{
                                                    width: '32px',
                                                    height: '32px',
                                                    borderRadius: '50%',
                                                    display: 'flex',
                                                    alignItems: 'center',
                                                    justifyContent: 'center',
                                                    background: '#e0f2f1',
                                                    color: '#00695c',
                                                    textDecoration: 'none',
                                                    transition: 'all 0.2s'
                                                }}
                                                title={__('Submissions', 'revenuepro-bkash-wc')}
                                            >
                                                <span className="dashicons dashicons-list-view" style={{ fontSize: '16px' }}></span>
                                            </Link>
                                            <Link
                                                to={`${route_path}admin.php?page=revenuepro-bkash-wc-edit&id=${form.id}`}
                                                style={{
                                                    width: '32px',
                                                    height: '32px',
                                                    borderRadius: '50%',
                                                    display: 'flex',
                                                    alignItems: 'center',
                                                    justifyContent: 'center',
                                                    background: '#f0f0f1',
                                                    color: '#50575e',
                                                    textDecoration: 'none',
                                                    transition: 'all 0.2s'
                                                }}
                                                title={__('Edit', 'revenuepro-bkash-wc')}
                                            >
                                                <span className="dashicons dashicons-edit" style={{ fontSize: '16px' }}></span>
                                            </Link>
                                            <button
                                                onClick={() => confirmDelete(form.id, form.title)}
                                                style={{
                                                    width: '32px',
                                                    height: '32px',
                                                    borderRadius: '50%',
                                                    display: 'flex',
                                                    alignItems: 'center',
                                                    justifyContent: 'center',
                                                    background: 'rgba(214, 54, 56, 0.1)',
                                                    color: '#d63638',
                                                    border: 'none',
                                                    cursor: 'pointer',
                                                    transition: 'all 0.2s'
                                                }}
                                                title={__('Delete', 'revenuepro-bkash-wc')}
                                            >
                                                <span className="dashicons dashicons-trash" style={{ fontSize: '16px' }}></span>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                )}

                {/* Footer / Pagination */}
                {filteredForms.length > 0 && (
                    <div style={{ padding: '20px', borderTop: '1px solid #f0f0f1', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <div style={{ fontSize: '13px', color: '#646970' }}>
                            {__('Showing result', 'revenuepro-bkash-wc')} 1 {__('out of', 'revenuepro-bkash-wc')} {filteredForms.length}
                        </div>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                            <span style={{ fontSize: '13px', color: '#646970' }}>{__('Rows per page', 'revenuepro-bkash-wc')}</span>
                            <select style={{ padding: '4px 8px', borderRadius: '4px', border: '1px solid #ccc', fontSize: '13px' }}>
                                <option>10</option>
                                <option>20</option>
                                <option>50</option>
                            </select>
                        </div>
                    </div>
                )}
            </div>

            {/* Delete Confirmation Modal */}
            {deleteModal.isOpen && (
                <div style={{
                    position: 'fixed',
                    top: 0,
                    left: 0,
                    right: 0,
                    bottom: 0,
                    background: 'rgba(0,0,0,0.5)',
                    backdropFilter: 'blur(2px)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    zIndex: 100000,
                }}>
                    <div style={{
                        background: '#fff',
                        padding: '30px',
                        borderRadius: '12px',
                        maxWidth: '400px',
                        width: '90%',
                        textAlign: 'center',
                        boxShadow: '0 10px 25px rgba(0,0,0,0.1)',
                        animation: 'popIn 0.2s cubic-bezier(0.175, 0.885, 0.32, 1.275)'
                    }}>
                        <div style={{
                            width: '60px',
                            height: '60px',
                            borderRadius: '50%',
                            background: '#fee2e2',
                            color: '#ef4444',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            fontSize: '24px',
                            margin: '0 auto 20px auto'
                        }}>
                            <span className="dashicons dashicons-trash"></span>
                        </div>
                        <h3 style={{ margin: '0 0 10px 0', color: '#111827', fontSize: '20px' }}>{__('Delete Form?', 'revenuepro-bkash-wc')}</h3>
                        <p style={{ color: '#6b7280', marginBottom: '25px', fontSize: '15px', lineHeight: '1.5' }}>
                            {__('Are you sure you want to delete', 'revenuepro-bkash-wc')} <strong>"{deleteModal.formTitle}"</strong>? {__('This action cannot be undone.', 'revenuepro-bkash-wc')}
                        </p>
                        <div style={{ display: 'flex', gap: '12px', justifyContent: 'center' }}>
                            <button
                                onClick={() => setDeleteModal({ isOpen: false, formId: null, formTitle: '' })}
                                style={{
                                    padding: '10px 24px',
                                    background: '#fff',
                                    color: '#374151',
                                    border: '1px solid #d1d5db',
                                    borderRadius: '6px',
                                    cursor: 'pointer',
                                    fontWeight: '500',
                                    fontSize: '14px',
                                    transition: 'all 0.2s'
                                }}
                            >
                                {__('Cancel', 'revenuepro-bkash-wc')}
                            </button>
                            <button
                                onClick={handleDelete}
                                style={{
                                    padding: '10px 24px',
                                    background: '#ef4444',
                                    color: '#fff',
                                    border: 'none',
                                    borderRadius: '6px',
                                    cursor: 'pointer',
                                    fontWeight: '500',
                                    fontSize: '14px',
                                    boxShadow: '0 2px 5px rgba(239, 68, 68, 0.3)',
                                    transition: 'all 0.2s'
                                }}
                            >
                                {__('Delete', 'revenuepro-bkash-wc')}
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* Notification Banner */}
            {notification && (
                <div style={{
                    position: 'fixed',
                    bottom: '30px',
                    right: '30px',
                    zIndex: 100001,
                    minWidth: '300px',
                    animation: 'slideIn 0.3s ease-out'
                }}>
                    <div style={{
                        background: notification.type === 'success' ? '#10b981' : '#ef4444',
                        color: '#fff',
                        padding: '16px 20px',
                        borderRadius: '8px',
                        boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '12px',
                    }}>
                        <span style={{ fontSize: '18px' }}>{notification.type === 'success' ? '✓' : '✕'}</span>
                        <span style={{ fontSize: '14px', fontWeight: '500' }}>
                            {notification.message}
                        </span>
                    </div>
                </div>
            )}

            <style>{`
                @keyframes popIn {
                    from { transform: scale(0.9); opacity: 0; }
                    to { transform: scale(1); opacity: 1; }
                }
                @keyframes slideIn {
                    from { transform: translateY(20px); opacity: 0; }
                    to { transform: translateY(0); opacity: 1; }
                }
            `}</style>
        </div>
    );
};

export default AllForms;
