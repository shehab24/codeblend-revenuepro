import React, { useState, useEffect } from 'react';
import { __, sprintf } from '@wordpress/i18n';

// --- Components ---

const Modal = ({ isOpen, onClose, onConfirm, title, message, processing }) => {
    if (!isOpen) return null;

    return (
        <div style={{
            position: 'fixed',
            top: 0, left: 0, right: 0, bottom: 0,
            backgroundColor: 'rgba(15, 23, 42, 0.6)',
            backdropFilter: 'blur(4px)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 99999,
            animation: 'fadeIn 0.2s ease-out'
        }}>
            <div style={{
                background: '#fff',
                width: '100%',
                maxWidth: '450px',
                borderRadius: '16px',
                boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.25)',
                padding: '32px',
                textAlign: 'center',
                animation: 'scaleUp 0.2s ease-out',
                margin: '20px'
            }}>
                <div style={{
                    width: '64px',
                    height: '64px',
                    borderRadius: '50%',
                    background: '#fef2f2',
                    color: '#dc2626',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    margin: '0 auto 24px'
                }}>
                    <span className="dashicons dashicons-trash" style={{ fontSize: '32px', width: '32px', height: '32px' }}></span>
                </div>
                
                <h3 style={{ margin: '0 0 12px', fontSize: '20px', fontWeight: '700', color: '#1e293b' }}>
                    {title}
                </h3>
                
                <p style={{ margin: '0 0 32px', fontSize: '15px', lineHeight: '1.6', color: '#64748b' }}>
                    {message}
                </p>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
                    <button
                        onClick={onClose}
                        disabled={processing}
                        style={{
                            padding: '12px',
                            borderRadius: '8px',
                            border: '1px solid #e2e8f0',
                            background: '#fff',
                            color: '#475569',
                            fontSize: '14px',
                            fontWeight: '600',
                            cursor: 'pointer',
                            transition: 'all 0.2s'
                        }}
                        onMouseOver={(e) => e.target.style.background = '#f8fafc'}
                        onMouseOut={(e) => e.target.style.background = '#fff'}
                    >
                        {__('Cancel', 'revenuepro-bkash-wc')}
                    </button>
                    <button
                        onClick={onConfirm}
                        disabled={processing}
                        style={{
                            padding: '12px',
                            borderRadius: '8px',
                            border: 'none',
                            background: '#dc2626',
                            color: '#fff',
                            fontSize: '14px',
                            fontWeight: '600',
                            cursor: processing ? 'not-allowed' : 'pointer',
                            transition: 'all 0.2s',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            gap: '8px',
                            opacity: processing ? 0.7 : 1
                        }}
                        onMouseOver={(e) => !processing && (e.target.style.background = '#b91c1c')}
                        onMouseOut={(e) => !processing && (e.target.style.background = '#dc2626')}
                    >
                        {processing ? (
                            <>
                                <span className="dashicons dashicons-update" style={{ animation: 'spin 1s linear infinite', fontSize: '16px' }}></span>
                                {__('Deleting...', 'revenuepro-bkash-wc')}
                            </>
                        ) : (
                            __('Delete Permanently', 'revenuepro-bkash-wc')
                        )}
                    </button>
                </div>
            </div>
        </div>
    );
};

const Toast = ({ message, type, onClose }) => {
    useEffect(() => {
        const timer = setTimeout(onClose, 3000);
        return () => clearTimeout(timer);
    }, [onClose]);

    return (
        <div style={{
            position: 'fixed',
            bottom: '30px',
            right: '30px',
            padding: '16px 24px',
            background: type === 'success' ? '#10b981' : '#ef4444',
            color: '#fff',
            borderRadius: '12px',
            boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)',
            display: 'flex',
            alignItems: 'center',
            gap: '12px',
            zIndex: 99999,
            animation: 'slideIn 0.3s ease-out',
            fontWeight: '500',
            fontSize: '14px'
        }}>
            <span className={`dashicons dashicons-${type === 'success' ? 'yes' : 'warning'}`} style={{ fontSize: '20px', width: '20px', height: '20px' }}></span>
            {message}
        </div>
    );
};

// --- Main Page Component ---

export default function Logs() {
    const [logs, setLogs] = useState([]);
    const [loading, setLoading] = useState(false);
    const [page, setPage] = useState(1);
    const [totalPages, setTotalPages] = useState(1);
    const [selectedIds, setSelectedIds] = useState([]);
    
    // Process State
    const [deleteModalOpen, setDeleteModalOpen] = useState(false);
    const [idsToDelete, setIdsToDelete] = useState([]);
    const [processing, setProcessing] = useState(false);
    const [exporting, setExporting] = useState(false);
    const [toast, setToast] = useState(null);

    useEffect(() => {
        fetchLogs();
    }, [page]);

    const fetchLogs = async () => {
        setLoading(true);
        try {
            const restUrl = window.RevenueProGlobal?.rest_url || '/wp-json/';
            const response = await fetch(`${restUrl}revenuepro-bkash-wc/v1/transactions?page=${page}&_t=${Date.now()}`, {
                headers: { 'X-WP-Nonce': window.RevenueProGlobal?.nonce || '' }
            });
            if (response.ok) {
                const data = await response.json();
                setLogs(data.logs);
                setTotalPages(data.pages);
                setSelectedIds([]);
            }
        } catch (error) {
            console.error('Error fetching logs:', error);
            setToast({ type: 'error', message: 'Failed to load transactions.' });
        } finally {
            setLoading(false);
        }
    };

    const handleSelectAll = (e) => {
        if (e.target.checked) {
            setSelectedIds(logs.map(log => log.id));
        } else {
            setSelectedIds([]);
        }
    };

    const toggleSelect = (id) => {
        setSelectedIds(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
    };

    const promptDelete = (ids) => {
        setIdsToDelete(ids);
        setDeleteModalOpen(true);
    };

    const confirmDelete = async () => {
        setProcessing(true);
        try {
            const restUrl = window.RevenueProGlobal?.rest_url || '/wp-json/';
            const response = await fetch(`${restUrl}revenuepro-bkash-wc/v1/transactions`, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json',
                    'X-WP-Nonce': window.RevenueProGlobal?.nonce || ''
                },
                body: JSON.stringify({ ids: idsToDelete })
            });

            if (response.ok) {
                const result = await response.json();
                setToast({ type: 'success', message: sprintf(__('%s transaction(s) deleted successfully.', 'revenuepro-bkash-wc'), result.deleted) });
                fetchLogs();
                setDeleteModalOpen(false);
                setIdsToDelete([]);
                if (idsToDelete.length === selectedIds.length && idsToDelete.every(val => selectedIds.includes(val))) {
                     setSelectedIds([]); // Clear selection if we deleted everything selected
                }
            } else {
                setToast({ type: 'error', message: __('Failed to delete transactions.', 'revenuepro-bkash-wc') });
            }
        } catch (error) {
            console.error('Error deleting logs:', error);
            setToast({ type: 'error', message: __('An error occurred while deleting.', 'revenuepro-bkash-wc') });
        } finally {
            setProcessing(false);
        }
    };

    const handleExport = async (idsToExport = []) => {
        setExporting(true);
        try {
            const restUrl = window.RevenueProGlobal?.rest_url || '/wp-json/';
            const queryParams = new URLSearchParams({
                _t: Date.now()
            });
            
            if (idsToExport.length > 0) {
                queryParams.append('ids', idsToExport.join(','));
            }

            const response = await fetch(`${restUrl}revenuepro-bkash-wc/v1/transactions/export?${queryParams.toString()}`, {
                headers: { 'X-WP-Nonce': window.RevenueProGlobal?.nonce || '' }
            });

            if (response.ok) {
                const data = await response.json();
                if (data.csv_data) {
                    const blob = new Blob([data.csv_data], { type: 'text/csv;charset=utf-8;' });
                    const url = URL.createObjectURL(blob);
                    const link = document.createElement('a');
                    link.href = url;
                    link.setAttribute('download', data.filename || 'transactions.csv');
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);
                    setToast({ type: 'success', message: __('Transactions exported successfully!', 'revenuepro-bkash-wc') });
                }
            } else {
                setToast({ type: 'error', message: __('Failed to export transactions.', 'revenuepro-bkash-wc') });
            }
        } catch (error) {
            console.error('Error exporting:', error);
            setToast({ type: 'error', message: __('An error occurred while exporting.', 'revenuepro-bkash-wc') });
        } finally {
            setExporting(false);
        }
    };

    return (
        <div style={{ padding: '40px', fontFamily: '"Inter", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif' }}>
            
            {/* --- Global Styles for Animations --- */}
            <style>{`
                @keyframes spin { 100% { transform: rotate(360deg); } }
                @keyframes scaleUp { from { transform: scale(0.95); opacity: 0; } to { transform: scale(1); opacity: 1; } }
                @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
                @keyframes slideIn { from { transform: translateY(100%); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
            `}</style>
            
            {/* --- Modal --- */}
            <Modal 
                isOpen={deleteModalOpen}
                onClose={() => !processing && setDeleteModalOpen(false)}
                onConfirm={confirmDelete}
                processing={processing}
                title={__('Delete Transactions?', 'revenuepro-bkash-wc')}
                message={sprintf(
                    __('Are you sure you want to delete %s transaction(s)? This action will move the associated Orders to Trash.', 'revenuepro-bkash-wc'),
                    idsToDelete.length
                )}
            />

            {/* --- Toast --- */}
            {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}

            {/* --- Header --- */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '24px' }}>
                <div>
                    <h1 style={{ fontSize: '28px', margin: 0, fontWeight: '700', color: '#0f172a', letterSpacing: '-0.5px' }}>
                        {__('bKash Transactions', 'revenuepro-bkash-wc')}
                    </h1>
                    <p style={{ margin: '6px 0 0', color: '#64748b', fontSize: '14px' }}>
                        {__('Monitor and manage your bKash payment history.', 'revenuepro-bkash-wc')}
                    </p>
                </div>

                <div style={{ display: 'flex', gap: '12px' }}>
                    {/* Export Button - Always Visible */}
                    <button 
                        onClick={() => handleExport(selectedIds)} 
                        disabled={exporting}
                        style={{
                            background: '#fff',
                            color: '#0f172a',
                            border: '1px solid #e2e8f0',
                            padding: '10px 20px',
                            borderRadius: '8px',
                            cursor: 'pointer',
                            fontSize: '14px',
                            fontWeight: '600',
                            display: 'flex',
                            alignItems: 'center',
                            gap: '8px',
                            transition: 'all 0.2s',
                            boxShadow: '0 1px 2px rgba(0,0,0,0.05)'
                        }}
                        onMouseOver={(e) => e.target.style.background = '#f8fafc'}
                        onMouseOut={(e) => e.target.style.background = '#fff'}
                    >
                        {exporting ? (
                            <span className="dashicons dashicons-update" style={{ animation: 'spin 1s linear infinite' }}></span>
                        ) : (
                            <span className="dashicons dashicons-download"></span>
                        )}
                        {selectedIds.length > 0 ? sprintf(__('Export Selected (%s)', 'revenuepro-bkash-wc'), selectedIds.length) : __('Export All CSV', 'revenuepro-bkash-wc')}
                    </button>

                    {selectedIds.length > 0 && (
                        <button 
                            onClick={() => promptDelete(selectedIds)} 
                            disabled={processing}
                            style={{
                                background: '#fee2e2',
                                color: '#dc2626',
                                border: '1px solid #fecaca',
                                padding: '10px 20px',
                                borderRadius: '8px',
                                cursor: 'pointer',
                                fontSize: '14px',
                                fontWeight: '600',
                                display: 'flex',
                                alignItems: 'center',
                                gap: '8px',
                                transition: 'all 0.2s',
                                boxShadow: '0 1px 2px rgba(0,0,0,0.05)'
                            }}
                            onMouseOver={(e) => e.target.style.background = '#fecaca'}
                            onMouseOut={(e) => e.target.style.background = '#fee2e2'}
                        >
                            <span className="dashicons dashicons-trash"></span>
                            {sprintf(__('Delete Selected (%s)', 'revenuepro-bkash-wc'), selectedIds.length)}
                        </button>
                    )}
                </div>
            </div>

            {/* --- Table Card --- */}
            <div style={{ background: '#fff', borderRadius: '16px', border: '1px solid #e2e8f0', boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)', overflow: 'hidden' }}>
                {loading ? (
                    <div style={{ padding: '60px', textAlign: 'center', color: '#64748b' }}>
                        <span className="dashicons dashicons-update" style={{ animation: 'spin 1.5s linear infinite', fontSize: '32px', color: '#cbd5e1', marginBottom: '16px', width: '32px', height: '32px' }}></span>
                        <p>{__('Loading transactions...', 'revenuepro-bkash-wc')}</p>
                    </div>
                ) : logs.length === 0 ? (
                    <div style={{ padding: '80px 20px', textAlign: 'center' }}>
                         <div style={{ width: '80px', height: '80px', border: '1px dashed #cbd5e1', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 24px' }}>
                            <span className="dashicons dashicons-list-view" style={{ fontSize: '40px', color: '#94a3b8', width: '40px', height: '40px' }}></span>
                         </div>
                         <h3 style={{ margin: '0 0 8px 0', color: '#1e293b', fontSize: '18px', fontWeight: '600' }}>{__('No Transactions Found', 'revenuepro-bkash-wc')}</h3>
                         <p style={{ color: '#64748b', fontSize: '14px', maxWidth: '400px', margin: '0 auto' }}>{__('Transactions made via bKash payment gateway will appear here automatically.', 'revenuepro-bkash-wc')}</p>
                    </div>
                ) : (
                    <>
                    <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
                        <thead style={{ background: '#f8fafc', borderBottom: '1px solid #e2e8f0' }}>
                            <tr>
                                <th style={{ padding: '16px 24px', width: '40px' }}>
                                    <input 
                                        type="checkbox" 
                                        checked={logs.length > 0 && selectedIds.length === logs.length}
                                        onChange={handleSelectAll}
                                        style={{ cursor: 'pointer', borderRadius: '4px', width: '16px', height: '16px' }}
                                    />
                                </th>
                                <th style={{ padding: '16px 24px', fontSize: '12px', textTransform: 'uppercase', letterSpacing: '0.05em', fontWeight: '600', color: '#64748b' }}>{__('Transaction ID', 'revenuepro-bkash-wc')}</th>
                                <th style={{ padding: '16px 24px', fontSize: '12px', textTransform: 'uppercase', letterSpacing: '0.05em', fontWeight: '600', color: '#64748b' }}>{__('bKash Number', 'revenuepro-bkash-wc')}</th>
                                <th style={{ padding: '16px 24px', fontSize: '12px', textTransform: 'uppercase', letterSpacing: '0.05em', fontWeight: '600', color: '#64748b' }}>{__('Amount', 'revenuepro-bkash-wc')}</th>
                                <th style={{ padding: '16px 24px', fontSize: '12px', textTransform: 'uppercase', letterSpacing: '0.05em', fontWeight: '600', color: '#64748b' }}>{__('Order', 'revenuepro-bkash-wc')}</th>
                                <th style={{ padding: '16px 24px', fontSize: '12px', textTransform: 'uppercase', letterSpacing: '0.05em', fontWeight: '600', color: '#64748b' }}>{__('Date', 'revenuepro-bkash-wc')}</th>
                                <th style={{ padding: '16px 24px', fontSize: '12px', textTransform: 'uppercase', letterSpacing: '0.05em', fontWeight: '600', color: '#64748b' }}>{__('Status', 'revenuepro-bkash-wc')}</th>
                                <th style={{ padding: '16px 24px', fontSize: '12px', textTransform: 'uppercase', letterSpacing: '0.05em', fontWeight: '600', color: '#64748b' }}>{__('Action', 'revenuepro-bkash-wc')}</th>
                            </tr>
                        </thead>
                        <tbody style={{ background: '#fff' }}>
                            {logs.map((log) => (
                                <tr key={log.id} style={{ borderBottom: '1px solid #f1f5f9', transition: 'background 0.2s' }} className="hover-row">
                                    <td style={{ padding: '16px 24px' }}>
                                        <input 
                                            type="checkbox" 
                                            checked={selectedIds.includes(log.id)}
                                            onChange={() => toggleSelect(log.id)}
                                            style={{ cursor: 'pointer', borderRadius: '4px', width: '16px', height: '16px' }}
                                        />
                                    </td>
                                    <td style={{ padding: '16px 24px', fontSize: '14px', color: '#0f172a', fontWeight: '600', fontFamily: 'Monaco, monospace' }}>{log.trx_id}</td>
                                    <td style={{ padding: '16px 24px', fontSize: '14px', color: '#334155' }}>{log.customer_number}</td>
                                    <td style={{ padding: '16px 24px', fontSize: '14px', color: '#0f172a', fontWeight: '700' }}>
                                        <span dangerouslySetInnerHTML={{ __html: log.amount }}></span>
                                    </td>
                                    <td style={{ padding: '16px 24px', fontSize: '14px', color: '#3b82f6', fontWeight: '500' }}>#{log.order_number}</td>
                                    <td style={{ padding: '16px 24px', fontSize: '13px', color: '#64748b' }}>{log.date}</td>
                                    <td style={{ padding: '16px 24px' }}>
                                        <span style={{
                                            padding: '4px 10px',
                                            borderRadius: '999px',
                                            fontSize: '12px',
                                            fontWeight: '600',
                                            backgroundColor: log.status === 'completed' || log.status === 'processing' ? '#dcfce7' : '#fee2e2',
                                            color: log.status === 'completed' || log.status === 'processing' ? '#15803d' : '#991b1b',
                                            textTransform: 'capitalize'
                                        }}>
                                            {log.status}
                                        </span>
                                    </td>
                                    <td style={{ padding: '16px 24px' }}>
                                        <div style={{ display: 'flex', gap: '12px', alignItems: 'center' }}>
                                            <a 
                                                href={log.view_url} 
                                                target="_blank" 
                                                style={{ 
                                                    color: '#64748b', 
                                                    textDecoration: 'none', 
                                                    fontSize: '16px'
                                                }}
                                                title={__('View Order', 'revenuepro-bkash-wc')}
                                            >
                                                <span className="dashicons dashicons-visibility"></span>
                                            </a>
                                            <button 
                                                onClick={() => promptDelete([log.id])}
                                                style={{ 
                                                    background: 'transparent', 
                                                    border: 'none', 
                                                    color: '#ef4444', 
                                                    cursor: 'pointer',
                                                    padding: 0,
                                                    display: 'flex',
                                                    fontSize: '16px'
                                                }}
                                                title={__('Delete', 'revenuepro-bkash-wc')}
                                            >
                                                <span className="dashicons dashicons-trash"></span>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                    
                    {totalPages > 1 && (
                        <div style={{ padding: '20px', display: 'flex', justifyContent: 'center', gap: '10px', borderTop: '1px solid #e2e8f0' }}>
                            <button 
                                disabled={page === 1} 
                                onClick={() => setPage(p => Math.max(1, p - 1))}
                                style={{ 
                                    padding: '8px 16px', 
                                    background: '#fff', 
                                    border: '1px solid #e2e8f0', 
                                    borderRadius: '8px', 
                                    cursor: page === 1 ? 'not-allowed' : 'pointer',
                                    color: page === 1 ? '#cbd5e1' : '#475569',
                                    fontSize: '14px',
                                    fontWeight: '500' 
                                }}
                            >
                                ← {__('Previous', 'revenuepro-bkash-wc')}
                            </button>
                            <span style={{ display: 'flex', alignItems: 'center', fontSize: '14px', color: '#64748b', fontWeight: '500' }}>
                                {sprintf(__('Page %s of %s', 'revenuepro-bkash-wc'), page, totalPages)}
                            </span>
                            <button 
                                disabled={page === totalPages} 
                                onClick={() => setPage(p => Math.min(totalPages, p + 1))}
                                style={{ 
                                    padding: '8px 16px', 
                                    background: '#fff', 
                                    border: '1px solid #e2e8f0', 
                                    borderRadius: '8px', 
                                    cursor: page === totalPages ? 'not-allowed' : 'pointer',
                                    color: page === totalPages ? '#cbd5e1' : '#475569',
                                    fontSize: '14px',
                                    fontWeight: '500' 
                                }}
                            >
                                {__('Next', 'revenuepro-bkash-wc')} →
                            </button>
                        </div>
                    )}
                    </>
                )}
            </div>
        </div>
    );
}
