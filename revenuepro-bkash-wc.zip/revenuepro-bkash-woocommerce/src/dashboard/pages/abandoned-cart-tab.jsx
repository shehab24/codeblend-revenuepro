{activeTab === 'recovery' && (
	<div style={{ animation: 'fadeIn 0.3s ease-out' }}>
		{/* Abandoned Cart Recovery Card */}
		<div style={{ background: '#fff', borderRadius: '16px', padding: '32px', boxShadow: '0 1px 3px rgba(0,0,0,0.05)', border: '1px solid #f1f5f9', marginBottom: '30px' }}>
			<div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '30px', paddingBottom: '20px', borderBottom: '1px solid #f1f5f9' }}>
				<div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
					<div style={{ width: '48px', height: '48px', background: '#8b5cf6', borderRadius: '12px', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontWeight: 'bold', fontSize: '20px', boxShadow: '0 4px 6px -1px rgba(139, 92, 246, 0.2)' }}>
						<span className="dashicons dashicons-cart" style={{ fontSize: '24px', width: '24px', height: '24px' }}></span>
					</div>
					<div>
						<h3 style={{ margin: 0, fontSize: '18px', fontWeight: '700', color: '#0f172a' }}>Abandoned Cart Recovery</h3>
						<p style={{ margin: '4px 0 0', color: '#64748b', fontSize: '13px' }}>Recover lost sales by tracking and following up with customers</p>
					</div>
				</div>
				<Toggle
					label={settings.abandoned_cart_enabled ? "Enabled" : "Disabled"}
					checked={settings.abandoned_cart_enabled}
					onChange={(e) => handleChange('abandoned_cart_enabled', e.target.checked)}
				/>
			</div>

			{settings.abandoned_cart_enabled && (
				<div style={{ display: 'grid', gap: '24px' }}>
					<div style={{ background: '#f0f9ff', padding: '20px', borderRadius: '12px', border: '1px solid #bae6fd', color: '#0c4a6e', fontSize: '14px', lineHeight: '1.6' }}>
						<strong>How it works:</strong> <br/>
						• System tracks when customers add items to cart and fill checkout information<br/>
						• If they don't complete payment within the specified time, cart is marked as abandoned<br/>
						• Automated recovery email is sent with cart details and checkout link<br/>
						• Admin can view all abandoned carts and contact customers directly
					</div>

					<div>
						<label style={{ display: 'block', marginBottom: '8px', fontSize: '14px', fontWeight: '600', color: '#334155' }}>
							Wait Time Before Sending Email
						</label>
						<select
							value={settings.abandoned_cart_wait_time}
							onChange={(e) => handleChange('abandoned_cart_wait_time', e.target.value)}
							style={{
								width: '100%',
								padding: '12px 16px',
								fontSize: '14px',
								border: '1px solid #e2e8f0',
								borderRadius: '8px',
								backgroundColor: '#f8fafc',
								color: '#1e293b',
								outline: 'none',
								cursor: 'pointer'
							}}
						>
							<option value="30">30 Minutes</option>
							<option value="60">1 Hour</option>
							<option value="120">2 Hours</option>
							<option value="360">6 Hours</option>
							<option value="720">12 Hours</option>
							<option value="1440">24 Hours</option>
						</select>
						<p style={{ margin: '6px 0 0', fontSize: '13px', color: '#64748b' }}>Time to wait after cart abandonment before sending recovery email</p>
					</div>

					<div style={{ background: '#f8fafc', padding: '24px', borderRadius: '12px', border: '1px solid #e2e8f0' }}>
						<h4 style={{ margin: '0 0 20px', fontSize: '15px', fontWeight: '600', color: '#334155' }}>Recovery Email Template</h4>
						
						<InputGroup
							label="Email Subject"
							value={settings.abandoned_cart_email_subject}
							onChange={(e) => handleChange('abandoned_cart_email_subject', e.target.value)}
							placeholder="e.g. Complete Your Order"
						/>

						<InputGroup
							label="Email Heading"
							value={settings.abandoned_cart_email_heading}
							onChange={(e) => handleChange('abandoned_cart_email_heading', e.target.value)}
							placeholder="e.g. You Left Something Behind!"
						/>

						<InputGroup
							label="Email Body"
							value={settings.abandoned_cart_email_body}
							onChange={(e) => handleChange('abandoned_cart_email_body', e.target.value)}
							multiline={true}
							placeholder="Enter your email content..."
							helpText="Available placeholders: {name}, {email}, {phone}, {cart_total}, {cart_items}, {checkout_url}, {site_name}"
						/>
					</div>
				</div>
			)}
		</div>
	</div>
)}
