import React from 'react';
import { __ } from '@wordpress/i18n';

const GetPro = () => {
    // TODO: Replace with your actual Google Form URL
    const GOOGLE_FORM_URL = 'https://forms.gle/YOUR_FORM_ID';

    const handleOpenForm = () => {
        window.open(GOOGLE_FORM_URL, '_blank');
    };

    return (
        <div className="revenuepro-bkash-wc-get-pro-page" style={{
            maxWidth: '800px',
            margin: '40px auto',
            textAlign: 'center',
            padding: '40px',
            background: '#fff',
            borderRadius: '8px',
            boxShadow: '0 4px 20px rgba(0,0,0,0.05)'
        }}>
            <div style={{ marginBottom: '40px' }}>
                <span className="dashicons dashicons-awards" style={{ fontSize: '64px', width: '64px', height: '64px', color: '#7b68ee' }}></span>
            </div>

            <h1 style={{ fontSize: '32px', fontWeight: '700', marginBottom: '16px', color: '#1e1e1e' }}>
                {__('Pro Version Coming Soon', 'revenuepro-bkash-wc')}
            </h1>

            <p style={{ fontSize: '16px', color: '#50575e', marginBottom: '40px', lineHeight: '1.6', maxWidth: '600px', margin: '0 auto 40px' }}>
                {__('We are working hard to bring you advanced features like recurring donations, multi-currency support, and premium integrations. Stay tuned!', 'revenuepro-bkash-wc')}
            </p>

            <div style={{
                background: '#f8f9fa',
                padding: '30px',
                borderRadius: '8px',
                textAlign: 'center',
                border: '1px solid #eee'
            }}>
                <h3 style={{ marginTop: 0, marginBottom: '20px', fontSize: '20px' }}>{__('Request a Feature', 'revenuepro-bkash-wc')}</h3>
                <p style={{ marginBottom: '20px', color: '#666' }}>{__('What features would you like to see in the Pro version? Let us know!', 'revenuepro-bkash-wc')}</p>

                <button
                    onClick={handleOpenForm}
                    style={{
                        background: '#2271b1',
                        color: '#fff',
                        border: 'none',
                        padding: '12px 24px',
                        borderRadius: '4px',
                        cursor: 'pointer',
                        fontSize: '16px',
                        fontWeight: '600',
                        display: 'inline-flex',
                        alignItems: 'center',
                        gap: '8px'
                    }}
                    onMouseEnter={(e) => e.target.style.background = '#135e96'}
                    onMouseLeave={(e) => e.target.style.background = '#2271b1'}
                >
                    <span className="dashicons dashicons-external" style={{ fontSize: '18px', width: '18px', height: '18px' }}></span>
                    {__('Submit Feature Request', 'revenuepro-bkash-wc')}
                </button>
            </div>
        </div>
    );
};

export default GetPro;
