import React, { useState, useEffect } from 'react';
import { __ } from '@wordpress/i18n';
import { Link } from 'react-router-dom';

export default function Welcome() {
    const [stats, setStats] = useState({
        total_sales: '...',
        partial_orders: 0,
        fraud_blocked: 0,
        abandoned_carts: 0,
        recovery_rate: '0%',
        courier_sent: 0
    });
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchStats = async () => {
            try {
                const restUrl = window.RevenueProGlobal?.rest_url || '/wp-json/';
                const response = await fetch(`${restUrl}revenuepro-bkash-wc/v1/dashboard/stats`, {
                    headers: { 'X-WP-Nonce': window.RevenueProGlobal?.nonce || '' }
                });
                if (response.ok) {
                    const data = await response.json();
                    setStats(data);
                }
            } catch (err) {
                console.error(err);
            } finally {
                setLoading(false);
            }
        };
        fetchStats();
    }, []);

    if (loading) {
        return (
            <div style={{ padding: '60px', textAlign: 'center', color: '#64748b' }}>
                <span className="dashicons dashicons-update" style={{ animation: 'spin 2s linear infinite', fontSize: '32px', width: '32px', height: '32px', marginBottom: '16px' }}></span>
                <p>Loading Dashboard Stats...</p>
                <style>{`@keyframes spin { 100% { transform: rotate(360deg); } }`}</style>
            </div>
        );
    }

    return (
        <div className="dashboard-overview" style={{ padding: '32px 24px', fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif' }}>
            <div style={{ marginBottom: '32px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div>
                    <h1 style={{ margin: '0 0 8px', fontSize: '28px', color: '#0f172a', fontWeight: '700' }}>{__('Dashboard Overview', 'revenuepro-bkash-wc')}</h1>
                    <p style={{ margin: 0, color: '#64748b', fontSize: '15px' }}>Here is what's happening with your store today.</p>
                </div>
            </div>
            
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '24px', marginBottom: '40px' }}>
                <StatCard 
                    title={__('Total bKash Sales', 'revenuepro-bkash-wc')} 
                    value={stats.total_sales} 
                    icon="money-alt" 
                    color="#059669" 
                    bg="#d1fae5"
                />
                <StatCard 
                    title={__('Partial Payments', 'revenuepro-bkash-wc')} 
                    value={stats.partial_orders} 
                    icon="chart-pie" 
                    color="#2563eb" 
                    bg="#dbeafe"
                />
                <StatCard 
                    title={__('Fraud Prevented', 'revenuepro-bkash-wc')} 
                    value={stats.fraud_blocked} 
                    icon="shield" 
                    color="#dc2626" 
                    bg="#fee2e2"
                />
                <StatCard 
                    title={__('Abandoned Carts', 'revenuepro-bkash-wc')} 
                    value={stats.abandoned_carts} 
                    subValue={`Recovery Rate: ${stats.recovery_rate}`}
                    icon="cart" 
                    color="#d97706" 
                    bg="#fef3c7"
                />
                <StatCard 
                    title={__('Courier Dispatches', 'revenuepro-bkash-wc')} 
                    value={stats.courier_sent || 0} 
                    subValue="Sent to Steadfast / Pathao"
                    icon="car" 
                    color="#7c3aed" 
                    bg="#ede9fe"
                />
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1.5fr 1fr', gap: '24px' }}>
                <div style={{ background: '#fff', padding: '32px', borderRadius: '16px', boxShadow: '0 4px 6px -1px rgba(0,0,0,0.05), 0 2px 4px -1px rgba(0,0,0,0.03)', border: '1px solid #f1f5f9' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
                        <h3 style={{ margin: 0, fontSize: '18px', color: '#1e293b' }}>{__('Recent bKash Transactions', 'revenuepro-bkash-wc')}</h3>
                        <Link to="?page=revenuepro-bkash-wc-logs" style={{ fontSize: '13px', color: '#2563eb', textDecoration: 'none', fontWeight: '500' }}>View All</Link>
                    </div>
                    
                    {stats.recent_transactions && stats.recent_transactions.length > 0 ? (
                        <div style={{ overflowX: 'auto' }}>
                            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '14px', textAlign: 'left' }}>
                                <thead>
                                    <tr style={{ borderBottom: '1px solid #e2e8f0', color: '#64748b' }}>
                                        <th style={{ padding: '12px 0', fontWeight: '600' }}>Order</th>
                                        <th style={{ padding: '12px 0', fontWeight: '600' }}>TrxID</th>
                                        <th style={{ padding: '12px 0', fontWeight: '600' }}>Amount</th>
                                        <th style={{ padding: '12px 0', fontWeight: '600' }}>Status</th>
                                        <th style={{ padding: '12px 0', fontWeight: '600', textAlign: 'right' }}>Time</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {stats.recent_transactions.map((trx, index) => (
                                        <tr key={index} style={{ borderBottom: '1px solid #f1f5f9' }}>
                                            <td style={{ padding: '12px 0' }}>
                                                <a href={trx.url} style={{ color: '#2563eb', textDecoration: 'none', fontWeight: '500' }}>#{trx.order_number}</a>
                                            </td>
                                            <td style={{ padding: '12px 0', fontFamily: 'monospace', color: '#475569' }}>{trx.trx_id}</td>
                                            <td style={{ padding: '12px 0', fontWeight: '500', color: '#0f172a' }} dangerouslySetInnerHTML={{ __html: trx.amount }}></td>
                                            <td style={{ padding: '12px 0' }}>
                                                <span style={{ padding: '4px 8px', borderRadius: '4px', fontSize: '12px', fontWeight: '600', background: trx.status === 'Completed' ? '#dcfce7' : '#f1f5f9', color: trx.status === 'Completed' ? '#16a34a' : '#475569' }}>
                                                    {trx.status}
                                                </span>
                                            </td>
                                            <td style={{ padding: '12px 0', textAlign: 'right', color: '#64748b', fontSize: '13px' }}>{trx.time}</td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    ) : (
                        <div style={{ textAlign: 'center', padding: '40px 0', color: '#94a3b8' }}>
                            <span className="dashicons dashicons-portfolio" style={{ fontSize: '32px', width: '32px', height: '32px', marginBottom: '12px', opacity: 0.5 }}></span>
                            <p style={{ margin: 0 }}>No recent transactions found.</p>
                        </div>
                    )}
                </div>

                <div style={{ background: 'linear-gradient(135deg, #1e293b, #0f172a)', padding: '32px', borderRadius: '16px', color: '#fff', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)', height: 'fit-content' }}>
                    <h3 style={{ margin: '0 0 16px', fontSize: '20px', color: '#fff', display: 'flex', alignItems: 'center', gap: '8px' }}>
                        <span className="dashicons dashicons-megaphone"></span> What's New
                    </h3>
                    <ul style={{ margin: 0, padding: '0 0 0 20px', color: '#cbd5e1', lineHeight: '1.8', fontSize: '15px' }}>
                        <li><strong>Courier Webhooks:</strong> Steadfast webhook integration is now live for automatic status updates.</li>
                        <li><strong>Inline Fraud Errors:</strong> Spam prevention errors now show directly inside your checkout form!</li>
                        <li><strong>Compact Checkout:</strong> Redesigned the manual bKash gateway for a premium look.</li>
                    </ul>
                </div>
            </div>
        </div>
    );
}

const StatCard = ({ title, value, subValue, icon, color, bg }) => (
    <div style={{ background: '#fff', padding: '24px', borderRadius: '16px', boxShadow: '0 4px 6px -1px rgba(0,0,0,0.05), 0 2px 4px -1px rgba(0,0,0,0.03)', border: '1px solid #f1f5f9', display: 'flex', alignItems: 'center', gap: '20px', transition: 'transform 0.2s', cursor: 'default' }} onMouseEnter={(e) => e.currentTarget.style.transform = 'translateY(-2px)'} onMouseLeave={(e) => e.currentTarget.style.transform = 'none'}>
        <div style={{ width: '64px', height: '64px', borderRadius: '16px', background: bg, color: color, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '32px' }}>
            <span className={`dashicons dashicons-${icon}`}></span>
        </div>
        <div>
            <div style={{ fontSize: '14px', color: '#64748b', marginBottom: '6px', fontWeight: '500', textTransform: 'uppercase', letterSpacing: '0.5px' }}>{title}</div>
            <div style={{ fontSize: '32px', fontWeight: '800', color: '#0f172a', lineHeight: '1.1' }}>{value}</div>
            {subValue && <div style={{ fontSize: '13px', color: color, marginTop: '6px', fontWeight: '600' }}>{subValue}</div>}
        </div>
    </div>
);

const QuickLink = ({ icon, title, url }) => (
    <a href={url} style={{ display: 'flex', alignItems: 'center', gap: '12px', padding: '12px 16px', background: '#f8fafc', borderRadius: '8px', color: '#334155', textDecoration: 'none', fontWeight: '500', transition: 'all 0.2s' }} onMouseEnter={(e) => { e.currentTarget.style.background = '#f1f5f9'; e.currentTarget.style.color = '#0f172a'; }} onMouseLeave={(e) => { e.currentTarget.style.background = '#f8fafc'; e.currentTarget.style.color = '#334155'; }}>
        <span className={`dashicons dashicons-${icon}`} style={{ color: '#64748b' }}></span>
        {title}
        <span className="dashicons dashicons-arrow-right-alt2" style={{ marginLeft: 'auto', color: '#cbd5e1' }}></span>
    </a>
);
