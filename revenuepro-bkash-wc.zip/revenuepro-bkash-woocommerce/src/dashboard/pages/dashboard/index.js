import React from 'react';
import TopBar from '../../TopBar';
import { useQuery } from '@Utils/helper';
import Welcome from './welcome';
// import Blocks from './blocks';

const renderSwitch = (path) => {
	switch (path) {
		case 'blocks':
			return <Blocks />;
		default:
			return <Welcome />;
	}
};

export default function Dashboard() {
	const location = useQuery();
	const path = location.get('path');
	return (
		<React.Fragment>
			<div className="ablocks-page-content">{renderSwitch(path)}</div>
		</React.Fragment>
	);
}
