import React, { useState, useEffect } from 'react';
import { __ } from '@wordpress/i18n';
import { useLocation, useNavigate } from 'react-router-dom';
import './form-builder.scss';
import {
    DndContext,
    closestCenter,
    closestCorners,
    PointerSensor,
    useSensor,
    useSensors,
    DragOverlay,
    useDraggable,
    useDroppable,
    defaultDropAnimationSideEffects,
} from '@dnd-kit/core';
import {
    arrayMove,
    SortableContext,
    verticalListSortingStrategy,
    useSortable,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import FormSettingsPanel from '../components/FormSettingsPanel';

// Field types
const STANDARD_FIELDS = [
    { id: 'columns', label: 'Columns', icon: '▦' },
    { id: 'button', label: 'Button', icon: '🔘' },
    { id: 'text', label: 'Single Line Text', icon: '📝' },
    { id: 'textarea', label: 'Paragraph Text', icon: '¶' },
    { id: 'dropdown', label: 'Dropdown', icon: '▼' },
    { id: 'checkboxes', label: 'Checkboxes', icon: '☑' },
    { id: 'radio', label: 'Multiple Choice', icon: '⚪' },
    { id: 'number', label: 'Numbers', icon: '#' },
    { id: 'name', label: 'Name', icon: '👤' },
    { id: 'email', label: 'Email', icon: '📧' },
];

const FANCY_FIELDS = [
    { id: 'phone', label: 'Phone', icon: '📞' },
    { id: 'address', label: 'Address', icon: '📍' },
    { id: 'date', label: 'Date / Time', icon: '📅' },
    { id: 'website', label: 'Website / URL', icon: '🌐' },
    { id: 'password', label: 'Password', icon: '🔒' },
    { id: 'file', label: 'File Upload', icon: '📎' },
];

// Draggable field button (from palette)
// Draggable field button (from palette)
function DraggableFieldButton({ fieldType, color }) {
    const { attributes, listeners, setNodeRef, isDragging } = useDraggable({
        id: `new-${fieldType.id}`,
        data: { fieldType, isNew: true },
    });

    return (
        <div ref={setNodeRef} {...attributes} {...listeners} style={{ width: '100%' }}>
            <button
                style={{
                    display: 'flex',
                    alignItems: 'center',
                    width: '100%',
                    padding: '10px 12px',
                    background: isDragging ? color : color,
                    border: 'none',
                    borderRadius: '4px',
                    color: '#fff',
                    cursor: isDragging ? 'grabbing' : 'grab',
                    textAlign: 'left',
                    fontSize: '13px',
                    fontWeight: '500',
                    fontSize: '13px',
                    fontWeight: '500',
                    opacity: isDragging ? 0 : 1, // Hide the original button completely when dragging
                    boxShadow: '0 1px 2px rgba(0,0,0,0.1)',
                    height: '44px',
                    overflow: 'hidden',
                    boxSizing: 'border-box',
                    // No transform here - we use DragOverlay for the moving part
                }}
                onMouseEnter={(e) => {
                    if (!isDragging) {
                        e.currentTarget.style.filter = 'brightness(1.1)';
                        e.currentTarget.style.transform = 'translateY(-1px)';
                        e.currentTarget.style.boxShadow = '0 2px 4px rgba(0,0,0,0.15)';
                    }
                }}
                onMouseLeave={(e) => {
                    if (!isDragging) {
                        e.currentTarget.style.filter = 'none';
                        e.currentTarget.style.transform = 'none';
                        e.currentTarget.style.boxShadow = '0 1px 2px rgba(0,0,0,0.1)';
                    }
                }}
            >
                <span style={{ marginRight: '8px', fontSize: '16px', display: 'flex', alignItems: 'center' }}>{fieldType.icon}</span>
                <span style={{ whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{fieldType.label}</span>
            </button>
        </div>
    );
}

// Sortable Nested Field Item
function SortableNestedFieldItem(props) {
    const {
        attributes,
        listeners,
        setNodeRef,
        transform,
        transition,
        isDragging,
        isOver
    } = useSortable({ id: props.field.id });

    const style = {
        transform: CSS.Transform.toString(transform),
        transition,
        opacity: isDragging ? 0.5 : 1,
        marginBottom: '10px',
        position: 'relative',
        borderTop: isOver && props.isDraggingNewField ? '3px solid #0073aa' : 'none',
        marginTop: isOver && props.isDraggingNewField ? '-3px' : '0', // Compensate for border
        zIndex: isOver && props.isDraggingNewField ? 1 : 'auto',
    };

    return (
        <div ref={setNodeRef} style={style}>
            <NestedFieldItem {...props} dragHandleProps={{ ...attributes, ...listeners }} />
        </div>
    );
}

// Nested field item component (Presentation only)
function NestedFieldItem({ field, parentFieldId, columnId, onDeleteNestedField, onSelect, isSelected, dragHandleProps }) {
    const [isHovered, setIsHovered] = React.useState(false);

    const fieldStyle = {
        textAlign: field.textAlign || (field.type === 'button' ? 'center' : 'left'),
        padding: field.padding || '10px',
        margin: field.margin || '0',
        color: field.color || 'inherit',
    };

    const renderFieldInput = () => {
        const commonStyle = {
            width: '100%',
            padding: '8px',
            border: '1px solid #ddd',
            borderRadius: '3px',
            boxSizing: 'border-box'
        };

        switch (field.type) {
            case 'button':
                const buttonStyles = {
                    primary: { background: '#0073aa', color: '#fff' },
                    secondary: { background: '#666', color: '#fff' },
                    success: { background: '#46b450', color: '#fff' },
                };
                const style = buttonStyles[field.buttonStyle] || buttonStyles.primary;
                return (
                    <button style={{
                        ...style,
                        padding: '10px 20px',
                        border: 'none',
                        borderRadius: '3px',
                        fontSize: '14px',
                        fontWeight: '600',
                        cursor: 'pointer',
                        width: '100%',
                        textAlign: 'center',
                    }}>
                        {field.buttonText || field.label}
                    </button>
                );

            case 'text':
            case 'email':
            case 'phone':
            case 'url':
            case 'password':
                return <input type={field.type} placeholder={field.placeholder} style={commonStyle} disabled />;
            case 'textarea':
                return <textarea placeholder={field.placeholder} rows="4" style={commonStyle} disabled />;
            case 'number':
                return <input type="number" placeholder={field.placeholder} style={commonStyle} disabled />;
            case 'dropdown':
                return (
                    <select style={commonStyle} disabled>
                        <option>{field.placeholder || 'Select...'}</option>
                        {field.options?.map((opt, i) => <option key={i}>{opt}</option>)}
                    </select>
                );
            case 'radio':
                return field.options?.map((opt, i) => (
                    <label key={i} style={{ display: 'block', marginBottom: '8px', textAlign: 'left' }}>
                        <input type="radio" name={field.id} disabled style={{ marginRight: '8px' }} />
                        {opt}
                    </label>
                ));
            case 'checkboxes':
                return field.options?.map((opt, i) => (
                    <label key={i} style={{ display: 'block', marginBottom: '8px', textAlign: 'left' }}>
                        <input type="checkbox" disabled style={{ marginRight: '8px' }} />
                        {opt}
                    </label>
                ));
            default:
                return <input type="text" placeholder={field.placeholder} style={commonStyle} disabled />;
        }
    };

    return (
        <div
            style={{
                position: 'relative',
                cursor: 'pointer'
            }}
            onMouseEnter={() => setIsHovered(true)}
            onMouseLeave={() => setIsHovered(false)}
            onClick={(e) => {
                e.stopPropagation();
                onSelect(field);
            }}
        >
            <div style={{
                ...fieldStyle,
                background: isSelected ? '#e3f2fd' : '#fff',
                border: isSelected ? '1px solid #0073aa' : '1px solid #ddd',
                borderRadius: '3px',
                minHeight: '36px',
                paddingLeft: '45px', // Space for drag handle
                paddingRight: '15px',
                position: 'relative'
            }}>
                {/* Drag Handle */}
                <div
                    {...dragHandleProps}
                    style={{
                        position: 'absolute',
                        left: '0',
                        top: '0',
                        bottom: '0',
                        width: '30px',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        cursor: 'grab',
                        color: isSelected ? '#0073aa' : '#999',
                        borderRight: isSelected ? '1px solid #0073aa' : '1px solid #eee',
                        background: isSelected ? '#dcebf5' : '#f1f1f1',
                        borderTopLeftRadius: '2px',
                        borderBottomLeftRadius: '2px',
                        zIndex: 2
                    }}
                    title="Drag to reorder"
                    onClick={(e) => e.stopPropagation()}
                >
                    <span className="dashicons dashicons-move" style={{ fontSize: '14px', height: '14px', width: '14px' }}></span>
                </div>

                <div style={{ width: '100%' }}>
                    {field.type !== 'button' && (
                        <label style={{ display: 'block', fontWeight: '600', marginBottom: '8px', fontSize: '13px' }}>
                            {field.label}
                            {field.required && <span style={{ color: '#d63638' }}> *</span>}
                        </label>
                    )}
                    {renderFieldInput()}
                </div>
            </div>

            {isHovered && (
                <button
                    onClick={(e) => {
                        e.stopPropagation();
                        onDeleteNestedField(parentFieldId, columnId, field.id);
                    }}
                    style={{
                        position: 'absolute',
                        top: '5px',
                        right: '5px',
                        background: '#d63638',
                        border: 'none',
                        borderRadius: '3px',
                        color: '#fff',
                        cursor: 'pointer',
                        width: '24px',
                        height: '24px',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: '14px',
                        lineHeight: 1,
                        boxShadow: '0 1px 2px rgba(0,0,0,0.2)'
                    }}
                    title="Delete"
                >
                    <span className="dashicons dashicons-trash" style={{ fontSize: '14px', height: '14px', width: '14px', color: '#fff' }}></span>
                </button>
            )}
        </div>
    );
}

// Droppable column for nested fields
function DroppableColumn({ columnId, fields, columnIndex, parentFieldId, onFieldsChange, onDeleteNestedField, onSelect, selectedFieldId, isDraggingNewField }) {
    const { setNodeRef, isOver } = useDroppable({
        id: columnId,
        data: { type: 'column', parentFieldId, columnIndex }
    });

    return (
        <div
            ref={setNodeRef}
            style={{
                flex: 1,
                background: isOver ? '#e3f2fd' : '#fff',
                border: isOver ? '2px solid #0073aa' : '1px dashed #ddd',
                borderRadius: '3px',
                padding: '10px',
                minHeight: fields && fields.length > 0 ? 'auto' : '80px',
                transition: 'all 0.2s ease',
                display: 'flex',
                flexDirection: 'column'
            }}
        >
            {fields && fields.length > 0 ? (
                <SortableContext items={fields.map(f => f.id)} strategy={verticalListSortingStrategy}>
                    {fields.map((field) => (
                        <SortableNestedFieldItem
                            key={field.id}
                            field={field}
                            parentFieldId={parentFieldId}
                            columnId={columnId}
                            onDeleteNestedField={onDeleteNestedField}
                            onSelect={onSelect}
                            isSelected={selectedFieldId === field.id}
                            isDraggingNewField={isDraggingNewField}
                        />
                    ))}
                </SortableContext>
            ) : (
                <div style={{
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    justifyContent: 'center',
                    height: '100%',
                    minHeight: '60px',
                    color: isOver ? '#0073aa' : '#999',
                    fontSize: '13px',
                    textAlign: 'center'
                }}>
                    <div>Column {columnIndex + 1}</div>
                    <small style={{ fontSize: '11px', marginTop: '4px' }}>
                        {isOver ? 'Drop here' : 'Drop fields here'}
                    </small>
                </div>
            )}
        </div>
    );
}

// Drop zone for new fields between existing fields
function DropZoneBetweenFields({ id, isDraggingNewField }) {
    const { setNodeRef, isOver } = useDroppable({
        id: id,
        data: { type: 'dropzone' }
    });

    if (!isDraggingNewField) return null;

    return (
        <div
            ref={setNodeRef}
            style={{
                width: '100%',
                height: isOver ? '60px' : '20px',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                transition: 'all 0.2s ease',
                marginBottom: '10px',
            }}
        >
            {isOver && (
                <div style={{
                    width: '100%',
                    height: '50px',
                    background: 'linear-gradient(135deg, #0073aa 0%, #005a87 100%)',
                    borderRadius: '6px',
                    border: '2px dashed rgba(255,255,255,0.3)',
                    boxShadow: '0 4px 12px rgba(0, 115, 170, 0.3), inset 0 1px 0 rgba(255,255,255,0.1)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    position: 'relative',
                    overflow: 'hidden',
                }}>                   {/* Animated background effect */}
                    <div style={{
                        position: 'absolute',
                        top: 0,
                        left: 0,
                        right: 0,
                        bottom: 0,
                        background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.1), transparent)',
                        animation: 'shimmer 2s infinite',
                    }} />

                    <div style={{
                        display: 'flex',
                        alignItems: 'center',
                        gap: '10px',
                        position: 'relative',
                        zIndex: 1,
                    }}>
                        <div style={{
                            width: '24px',
                            height: '24px',
                            borderRadius: '50%',
                            background: '#fff',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            fontSize: '14px',
                            fontWeight: 'bold',
                            color: '#0073aa',
                        }}>
                            ↓
                        </div>
                        <span style={{
                            color: '#fff',
                            fontSize: '14px',
                            fontWeight: '600',
                            letterSpacing: '0.5px',
                            textShadow: '0 1px 2px rgba(0,0,0,0.2)',
                        }}>
                            {__('Drop Here', 'revenuepro-bkash-wc')}
                        </span>
                        <div style={{
                            width: '24px',
                            height: '24px',
                            borderRadius: '50%',
                            background: '#fff',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            fontSize: '14px',
                            fontWeight: 'bold',
                            color: '#0073aa',
                        }}>
                            ↓
                        </div>
                    </div>
                </div>
            )}

            {!isOver && (
                <div style={{
                    width: '100%',
                    height: '2px',
                    background: 'rgba(0, 115, 170, 0.2)',
                    borderRadius: '1px',
                }} />
            )}
        </div>
    );
}

// Sortable field in canvas
function SortableField({ field, isSelected, onSelect, onDelete, onDeleteNestedField, onSelectNested, selectedFieldId }) {
    const [isHovered, setIsHovered] = React.useState(false);
    const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({
        id: field.id,
    });

    const style = {
        transform: CSS.Transform.toString(transform),
        transition,
        opacity: isDragging ? 0.5 : 1,
        marginBottom: '15px',
    };

    const renderFieldInput = () => {
        const commonStyle = {
            width: '100%',
            padding: field.padding || '8px',
            margin: field.margin || '0',
            color: field.color || 'inherit',
            textAlign: field.textAlign || 'left',
            border: '1px solid #ddd',
            borderRadius: '3px'
        };

        switch (field.type) {
            case 'columns':
                // Render column layout container
                const columnCount = field.columnCount || 2;
                const columnWidth = `${100 / columnCount}%`;
                return (
                    <div style={{
                        display: 'flex',
                        gap: '15px',
                        padding: field.padding || '20px',
                        margin: field.margin || '0',
                        background: '#f9f9f9',
                        border: '2px dashed #ccc',
                        borderRadius: '4px',
                        minHeight: '100px'
                    }}>
                        {Array.from({ length: columnCount }).map((_, i) => {
                            const columns = field.columns || [];
                            const column = columns[i] || { id: `col-${field.id}-${i}`, fields: [] };
                            return (
                                <DroppableColumn
                                    key={column.id}
                                    columnId={column.id}
                                    fields={column.fields}
                                    columnIndex={i}
                                    parentFieldId={field.id}
                                    onDeleteNestedField={onDeleteNestedField}
                                    onSelect={onSelectNested}
                                    selectedFieldId={selectedFieldId}
                                />
                            );
                        })}
                    </div>
                );

            case 'button':
                // Render button
                const buttonStyles = {
                    primary: { background: '#0073aa', color: '#fff' },
                    secondary: { background: '#666', color: '#fff' },
                    success: { background: '#46b450', color: '#fff' },
                };
                const style = buttonStyles[field.buttonStyle] || buttonStyles.primary;
                return (
                    <button
                        type={field.buttonType || 'submit'}
                        style={{
                            ...style,
                            padding: field.padding || '12px 24px',
                            margin: field.margin || '0',
                            border: 'none',
                            borderRadius: '3px',
                            fontSize: '14px',
                            fontWeight: '600',
                            cursor: 'pointer',
                            width: field.width ? `${field.width}%` : '100%',
                            textAlign: field.textAlign || 'center',
                        }}
                    >
                        {field.buttonText || field.label}
                    </button>
                );

            case 'text':
            case 'email':
            case 'phone':
            case 'url':
            case 'password':
                return <input type={field.type} placeholder={field.placeholder} style={commonStyle} disabled />;
            case 'textarea':
                return <textarea placeholder={field.placeholder} rows="4" style={commonStyle} disabled />;
            case 'number':
                return <input type="number" placeholder={field.placeholder} style={commonStyle} disabled />;
            case 'dropdown':
                return (
                    <select style={commonStyle} disabled>
                        <option>{field.placeholder || 'Select...'}</option>
                        {field.options?.map((opt, i) => <option key={i}>{opt}</option>)}
                    </select>
                );
            case 'radio':
                return field.options?.map((opt, i) => (
                    <label key={i} style={{ display: 'block', marginBottom: '8px', textAlign: field.textAlign || 'left', color: field.color || 'inherit' }}>
                        <input type="radio" name={field.id} disabled style={{ marginRight: '8px' }} />
                        {opt}
                    </label>
                ));
            case 'checkboxes':
                return field.options?.map((opt, i) => (
                    <label key={i} style={{ display: 'block', marginBottom: '8px', textAlign: field.textAlign || 'left', color: field.color || 'inherit' }}>
                        <input type="checkbox" disabled style={{ marginRight: '8px' }} />
                        {opt}
                    </label>
                ));
            default:
                return <input type="text" placeholder={field.placeholder} style={commonStyle} disabled />;
        }
    };

    return (
        <div ref={setNodeRef} style={style}>
            <div
                onMouseEnter={() => setIsHovered(true)}
                onMouseLeave={() => setIsHovered(false)}
                style={{
                    padding: '15px',
                    margin: '0 15px', // Add horizontal margin here
                    background: isSelected ? '#e3f2fd' : '#fff',
                    border: isSelected ? '2px solid #0073aa' : '1px solid #ddd',
                    borderRadius: '4px',
                    position: 'relative',
                    cursor: 'pointer',
                }}
            >
                {/* Delete icon on hover - top right */}
                {isHovered && !isDragging && (
                    <button
                        onClick={(e) => {
                            e.stopPropagation();
                            onDelete();
                        }}
                        style={{
                            position: 'absolute',
                            top: '10px',
                            right: '10px',
                            background: '#d63638',
                            border: 'none',
                            borderRadius: '3px',
                            color: '#fff',
                            width: '28px',
                            height: '28px',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            cursor: 'pointer',
                            zIndex: 10,
                            boxShadow: '0 1px 2px rgba(0,0,0,0.1)'
                        }}
                        title="Delete field"
                    >
                        <span className="dashicons dashicons-trash" style={{ fontSize: '16px', height: '16px', width: '16px', color: '#fff' }}></span>
                    </button>
                )}

                {/* Drag Handle */}
                <div
                    {...attributes}
                    {...listeners}
                    style={{
                        position: 'absolute',
                        top: '15px',
                        left: '15px',
                        cursor: 'grab',
                        padding: '5px',
                        color: '#666',
                        fontSize: '18px',
                        lineHeight: '1',
                    }}
                    title="Drag to reorder"
                >
                    ⋮⋮
                </div>

                {/* Field Content - Click to select */}
                <div onClick={onSelect} style={{ paddingLeft: '30px', cursor: 'pointer' }}>
                    <label style={{ display: 'block', fontWeight: '600', marginBottom: '8px', fontSize: '14px' }}>
                        {field.label}
                        {field.required && <span style={{ color: '#d63638' }}> *</span>}
                    </label>
                    {renderFieldInput()}
                </div>
            </div>
        </div>
    );
}

// Success Modal
function SuccessModal({ isOpen, onClose, message }) {
    if (!isOpen) return null;

    return (
        <div style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            background: 'rgba(0,0,0,0.5)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 99999
        }}>
            <div style={{
                background: '#fff',
                padding: '30px',
                borderRadius: '8px',
                width: '400px',
                maxWidth: '90%',
                boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
                textAlign: 'center'
            }}>
                <div style={{ fontSize: '48px', marginBottom: '15px', color: '#46b450' }}>✓</div>
                <h3 style={{ margin: '0 0 10px 0', color: '#1d2327' }}>{__('Success!', 'revenuepro-bkash-wc')}</h3>
                <p style={{ color: '#646970', marginBottom: '25px', fontSize: '15px' }}>
                    {message || __('Form saved successfully!', 'revenuepro-bkash-wc')}
                </p>
                <div style={{ display: 'flex', justifyContent: 'center' }}>
                    <button
                        onClick={onClose}
                        style={{
                            padding: '10px 30px',
                            background: '#2271b1',
                            color: '#fff',
                            border: 'none',
                            borderRadius: '4px',
                            cursor: 'pointer',
                            fontWeight: '600',
                            fontSize: '14px'
                        }}
                    >
                        {__('OK', 'revenuepro-bkash-wc')}
                    </button>
                </div>
            </div>
        </div>
    );
}

// Droppable empty canvas
function EmptyCanvas({ isDragging }) {
    const { setNodeRef, isOver } = useDroppable({
        id: 'empty-canvas',
    });

    return (
        <div
            ref={setNodeRef}
            style={{
                textAlign: 'center',
                padding: '80px 40px',
                border: isOver ? '3px dashed #0073aa' : '2px dashed #ddd',
                borderRadius: '8px',
                background: isOver ? 'rgba(0, 115, 170, 0.05)' : '#fafafa',
                transition: 'all 0.2s ease',
            }}
        >
            <div style={{ fontSize: '48px', marginBottom: '20px', opacity: 0.3 }}>📝</div>
            <p style={{
                fontSize: '18px',
                margin: '0 0 10px 0',
                color: '#555',
                fontWeight: '500'
            }}>
                {isOver ? __('Drop field here', 'revenuepro-bkash-wc') : __('Your form is empty', 'revenuepro-bkash-wc')}
            </p>
            <p style={{
                fontSize: '14px',
                margin: 0,
                color: '#999'
            }}>
                {__('Drag fields from the left sidebar to build your form', 'revenuepro-bkash-wc')}
            </p>
        </div>
    );
}


// Bottom Drop Zone
function BottomDropZone({ isDragging }) {
    const { setNodeRef, isOver } = useDroppable({
        id: 'bottom-drop-zone',
    });

    if (!isDragging) return null;

    return (
        <div
            ref={setNodeRef}
            style={{
                height: isOver ? '80px' : '20px',
                margin: '10px 0',
                border: isOver ? '2px dashed #0073aa' : '1px dashed transparent',
                borderRadius: '4px',
                background: isOver ? 'rgba(0, 115, 170, 0.05)' : 'transparent',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: '#0073aa',
                fontWeight: '500',
                fontSize: '13px',
                transition: 'all 0.2s ease',
            }}
        >
            {isOver && __('Drop at the end', 'revenuepro-bkash-wc')}
        </div>
    );
}

// Delete Confirmation Modal
function DeleteConfirmationModal({ isOpen, onClose, onConfirm, message }) {
    if (!isOpen) return null;

    return (
        <div style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            background: 'rgba(0,0,0,0.5)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 99999
        }}>
            <div style={{
                background: '#fff',
                padding: '25px',
                borderRadius: '8px',
                width: '400px',
                maxWidth: '90%',
                boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
                textAlign: 'center'
            }}>
                <div style={{ fontSize: '48px', marginBottom: '15px' }}>🗑️</div>
                <h3 style={{ margin: '0 0 10px 0', color: '#1d2327' }}>{__('Are you sure?', 'revenuepro-bkash-wc')}</h3>
                <p style={{ color: '#646970', marginBottom: '25px' }}>
                    {message || __('Do you really want to delete this field? This process cannot be undone.', 'revenuepro-bkash-wc')}
                </p>
                <div style={{ display: 'flex', justifyContent: 'center', gap: '10px' }}>
                    <button
                        onClick={onClose}
                        style={{
                            padding: '10px 20px',
                            background: '#f0f0f1',
                            color: '#2271b1',
                            border: '1px solid #2271b1',
                            borderRadius: '4px',
                            cursor: 'pointer',
                            fontWeight: '600'
                        }}
                    >
                        {__('Cancel', 'revenuepro-bkash-wc')}
                    </button>
                    <button
                        onClick={onConfirm}
                        style={{
                            padding: '10px 20px',
                            background: '#d63638',
                            color: '#fff',
                            border: 'none',
                            borderRadius: '4px',
                            cursor: 'pointer',
                            fontWeight: '600'
                        }}
                    >
                        {__('Yes, Delete it!', 'revenuepro-bkash-wc')}
                    </button>
                </div>
            </div>
        </div>
    );
}

const FormBuilder = () => {
    const navigate = useNavigate();
    const query = new URLSearchParams(useLocation().search);
    const formId = query.get('id');
    const isEdit = !!formId;

    const [formTitle, setFormTitle] = useState('');
    const [fields, setFields] = useState([]);
    const [selectedField, setSelectedField] = useState(null);
    const [showStandard, setShowStandard] = useState(true);
    const [showFancy, setShowFancy] = useState(true);
    const [loading, setLoading] = useState(false);
    const [saving, setSaving] = useState(false);
    const [notification, setNotification] = useState(null); // {type: 'success'|'error', message: ''}
    const [activeId, setActiveId] = useState(null); // Track what's being dragged
    const [overId, setOverId] = useState(null); // Track where we're hovering
    const [deleteModal, setDeleteModal] = useState({ isOpen: false, onConfirm: null, message: '' });
    const [successModal, setSuccessModal] = useState({ isOpen: false, message: '' });
    const [showSettings, setShowSettings] = useState(true);
    const [searchTerm, setSearchTerm] = useState('');
    const [submitButton, setSubmitButton] = useState({
        text: 'Submit',
        width: '100',
        style: 'primary' // primary, secondary, success
    });
    const [formSettings, setFormSettings] = useState({
        paymentEnabled: false,
    });
    const [settingsTab, setSettingsTab] = useState('field'); // 'field' or 'form'
    const [styleTab, setStyleTab] = useState('general'); // 'general', 'style'
    const dropPlacementRef = React.useRef(null); // { id: string, position: 'before' | 'after' }

    const handleHoverPositionChange = (id, position) => {
        dropPlacementRef.current = { id, position };
    };

    const sensors = useSensors(
        useSensor(PointerSensor, {
            activationConstraint: {
                distance: 8, // 8px movement required to start drag
            },
        })
    );

    // Make the main canvas droppable
    const { setNodeRef: setCanvasRef, isOver: isOverCanvas } = useDroppable({
        id: 'canvas-container',
        data: { type: 'container' }
    });

    // Drop animation config - make ghost disappear instantly at drop position
    const dropAnimation = {
        duration: 0, // No animation duration
        sideEffects: defaultDropAnimationSideEffects({
            styles: {
                active: {
                    opacity: '0', // Fade out instantly
                },
            },
        }),
    };

    useEffect(() => {
        if (isEdit) {
            // Fetch existing form data
            setLoading(true);
            fetch(`/wp-json/wp/v2/revenuepro_bkash_wc/${formId}`)
                .then(res => res.json())
                .then(data => {
                    setFormTitle(data.title.rendered || '');
                    const formFields = data.meta?.form_fields || data.meta?.revenuepro_bkash_wc_fields || [];
                    setFields(formFields);

                    if (data.meta?.submit_button_settings) {
                        setSubmitButton(data.meta.submit_button_settings);
                    }



                    // Merge form settings with defaults to ensure all properties exist
                    if (data.meta?.form_settings) {
                        // Filter out styling-related properties
                        const { styling, padding, margin, border, shadow, typography, colors, ...cleanSettings } = data.meta.form_settings;
                        setFormSettings(prev => ({
                            ...prev,
                            ...cleanSettings,
                        }));
                    }

                    setLoading(false);
                })
                .catch(err => {
                    console.error('Error loading form:', err);
                    setLoading(false);
                });
        }
    }, [isEdit, formId]);

    const handleDragStart = (event) => {
        setActiveId(event.active.id);
    };

    // Helper to find field path
    const findFieldPath = (id, currentFields) => {
        for (let i = 0; i < currentFields.length; i++) {
            const field = currentFields[i];
            if (field.id === id) {
                return { parentField: null, column: null, index: i, field, list: currentFields };
            }
            if (field.type === 'columns' && field.columns) {
                for (let c = 0; c < field.columns.length; c++) {
                    const col = field.columns[c];
                    const fields = col.fields || [];
                    for (let f = 0; f < fields.length; f++) {
                        if (fields[f].id === id) {
                            return { parentField: field, column: col, index: f, field: fields[f], list: fields };
                        }
                    }
                }
            }
        }
        return null;
    };

    const handleDragOver = (event) => {
        const { over } = event;
        setOverId(over ? over.id : null);
    };

    const handleDragEnd = (event) => {
        const { active, over } = event;

        // Always clear drag states at the end
        const clearStates = () => {
            setActiveId(null);
            setOverId(null);
            dropPlacementRef.current = null;
        };

        if (!over) {
            clearStates();
            return;
        }

        // Adding new field from palette
        if (active.data.current?.isNew) {
            const fieldType = active.data.current.fieldType;
            const newField = {
                id: `field-${Date.now()}`,
                type: fieldType.id,
                label: fieldType.label,
                placeholder: '',
                required: false,
                width: '100',
                options: ['dropdown', 'radio', 'checkboxes'].includes(fieldType.id)
                    ? ['Option 1', 'Option 2', 'Option 3']
                    : [],
            };

            // Special handling for columns field
            if (fieldType.id === 'columns') {
                newField.columnCount = 2; // Default to 2 columns
                newField.columns = [
                    { id: `col-${Date.now()}-1`, fields: [] },
                    { id: `col-${Date.now()}-2`, fields: [] },
                ];
                newField.label = 'Column Layout';
            }

            // Special handling for button field
            if (fieldType.id === 'button') {
                newField.label = 'Click Me';
                newField.buttonText = 'Click Me';
                newField.buttonValue = '';
                newField.buttonStyle = 'primary'; // primary, secondary, success
            }

            // Check if dropping into a column
            if (over.data?.current?.type === 'column') {
                const parentFieldId = over.data.current.parentFieldId;
                const columnIndex = over.data.current.columnIndex;

                setFields(fields.map(field => {
                    if (field.id === parentFieldId && field.type === 'columns') {
                        const updatedColumns = [...(field.columns || [])];
                        if (updatedColumns[columnIndex]) {
                            updatedColumns[columnIndex] = {
                                ...updatedColumns[columnIndex],
                                fields: [...(updatedColumns[columnIndex].fields || []), newField]
                            };
                        }
                        return { ...field, columns: updatedColumns };
                    }
                    return field;
                }));

                setSelectedField(newField);
                clearStates();
                return;
            }

            // Handle drop zones (drop-before-xxx or drop-after-xxx)
            if (over.id.startsWith('drop-before-') || over.id.startsWith('drop-after-')) {
                const targetFieldId = over.id.replace('drop-before-', '').replace('drop-after-', '');
                const targetIndex = fields.findIndex(f => f.id === targetFieldId);

                if (targetIndex !== -1) {
                    const insertIndex = over.id.startsWith('drop-before-') ? targetIndex : targetIndex + 1;
                    const newFields = [...fields];
                    newFields.splice(insertIndex, 0, newField);
                    setFields(newFields);
                    setSelectedField(newField);
                    clearStates();
                    return;
                }
            }

            // Handle dropping on canvas / bottom zone / empty canvas
            if (over.id === 'canvas-container' || over.id === 'bottom-drop-zone' || over.id === 'empty-canvas') {
                setFields([...fields, newField]);
                setSelectedField(newField);
                clearStates();
                return;
            }

            // If dropped elsewhere (not on a valid drop zone), just clear states and don't add the field
            clearStates();
            return;
        }

        // Reordering existing fields
        if (active.id !== over.id) {
            const activePath = findFieldPath(active.id, fields);
            const overPath = findFieldPath(over.id, fields);

            if (activePath && overPath) {
                // Case 1: Reordering within the same list (top-level or same column)
                if (activePath.list === overPath.list) {
                    let newIndex = overPath.index;

                    // Adjust index based on drop position (top/bottom)
                    if (dropPlacementRef.current &&
                        dropPlacementRef.current.id === over.id &&
                        dropPlacementRef.current.position === 'after') {
                        // If moving down: no change needed (arrayMove handles it)
                        // If moving up: we might need to adjust?
                        // Actually arrayMove(from, to) moves 'from' to 'to'.
                        // If I drag 0 to 1 (bottom), I want it at 1.
                        // arrayMove(0, 1) -> [1, 0]. Correct.

                        // But wait, if I drag 2 to 1 (bottom).
                        // [0, 1, 2]. Drag 2 to 1.
                        // Hover 1 bottom. 'after'.
                        // Target index should be 2 (after 1).
                        // arrayMove(2, 2) -> no change.
                        // But visually I am below 1. So I want to stay at 2.

                        // If I drag 2 to 1 (top).
                        // Hover 1 top. 'before'.
                        // Target index should be 1.
                        // arrayMove(2, 1) -> [0, 2, 1]. Correct.

                        // So 'after' implies target index is overIndex + 1?
                        // But arrayMove logic is tricky.
                        // Let's rely on standard arrayMove for reordering unless it feels wrong.
                        // Standard dnd-kit reordering is based on 'over'.
                        // If I am over the bottom half, dnd-kit usually swaps.
                        // Let's stick to standard reordering for now to avoid breaking it.
                    }

                    const newList = arrayMove(activePath.list, activePath.index, overPath.index);

                    if (activePath.parentField) {
                        // Update nested list
                        setFields(fields.map(f => {
                            if (f.id === activePath.parentField.id) {
                                return {
                                    ...f,
                                    columns: f.columns.map(c => {
                                        if (c.id === activePath.column.id) {
                                            return { ...c, fields: newList };
                                        }
                                        return c;
                                    })
                                };
                            }
                            return f;
                        }));
                    } else {
                        // Update top-level list
                        setFields(newList);
                    }
                }
            }
        }

        // Clear drag states
        clearStates();
    };

    const updateField = (updates) => {
        const updateRecursive = (currentFields) => {
            return currentFields.map(f => {
                if (f.id === selectedField.id) {
                    return { ...f, ...updates };
                }
                if (f.type === 'columns' && f.columns) {
                    return {
                        ...f,
                        columns: f.columns.map(col => ({
                            ...col,
                            fields: updateRecursive(col.fields || [])
                        }))
                    };
                }
                return f;
            });
        };

        setFields(updateRecursive(fields));
        setSelectedField({ ...selectedField, ...updates });
    };



    const confirmDelete = (onConfirm) => {
        setDeleteModal({
            isOpen: true,
            message: __('Are you sure you want to delete this field?', 'revenuepro-bkash-wc'),
            onConfirm: () => {
                onConfirm();
                setDeleteModal({ isOpen: false, onConfirm: null, message: '' });
            }
        });
    };

    const deleteField = () => {
        confirmDelete(() => {
            const deleteRecursive = (currentFields) => {
                return currentFields.filter(f => f.id !== selectedField.id).map(f => {
                    if (f.type === 'columns' && f.columns) {
                        return {
                            ...f,
                            columns: f.columns.map(col => ({
                                ...col,
                                fields: deleteRecursive(col.fields || [])
                            }))
                        };
                    }
                    return f;
                });
            };

            setFields(deleteRecursive(fields));
            setSelectedField(null);
        });
    };

    const handleDeleteNestedField = (parentFieldId, columnId, fieldId) => {
        confirmDelete(() => {
            setFields(fields.map(field => {
                if (field.id === parentFieldId && field.type === 'columns') {
                    const updatedColumns = field.columns.map(col => {
                        if (col.id === columnId) {
                            return {
                                ...col,
                                fields: col.fields.filter(f => f.id !== fieldId)
                            };
                        }
                        return col;
                    });
                    return { ...field, columns: updatedColumns };
                }
                return field;
            }));
        });
    };

    const handleSave = async () => {
        if (!formTitle.trim()) {
            setNotification({ type: 'error', message: __('Please enter a form title', 'revenuepro-bkash-wc') });
            return;
        }


        setSaving(true);

        const formData = {
            title: formTitle,
            status: 'publish',
            meta: {
                form_fields: fields,
                submit_button_settings: submitButton,
                form_settings: {
                    paymentEnabled: formSettings.paymentEnabled || false,
                },
            },
        };

        console.log('Saving form with data:', formData);


        try {
            // Get WordPress REST API nonce from localized script
            const nonce = window.RevenueProGlobal?.nonce || window.wp?.apiFetch?.nonceMiddleware?.nonce || window.wpApiSettings?.nonce || '';

            if (!nonce) {
                alert(__('Authentication error. Please refresh the page and try again.', 'revenuepro-bkash-wc'));
                setSaving(false);
                return;
            }

            let response;
            if (isEdit && formId) {
                // Update existing form
                response = await fetch(`/wp-json/wp/v2/revenuepro_bkash_wc/${formId}`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-WP-Nonce': nonce,
                    },
                    credentials: 'same-origin',
                    body: JSON.stringify(formData),
                });
            } else {
                // Create new form
                response = await fetch('/wp-json/wp/v2/revenuepro_bkash_wc', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-WP-Nonce': nonce,
                    },
                    credentials: 'same-origin',
                    body: JSON.stringify(formData),
                });
            }

            const result = await response.json();

            if (response.ok) {
                setSuccessModal({ isOpen: true, message: __('Form saved successfully!', 'revenuepro-bkash-wc') });
                // Redirect to edit page if creating new
                if (!isEdit && result.id) {
                    setTimeout(() => {
                        navigate(`?page=revenuepro-bkash-wc-edit&id=${result.id}`);
                    }, 1500);
                }
            } else {
                console.error('Save failed:', result);
                const errorMsg = result.message || result.code || JSON.stringify(result);
                setNotification({ type: 'error', message: __('Error saving form: ', 'revenuepro-bkash-wc') + errorMsg });
            }
        } catch (error) {
            console.error('Save error:', error);
            setNotification({ type: 'error', message: __('Error saving form. Please try again. Check console for details.', 'revenuepro-bkash-wc') });
        } finally {
            setSaving(false);
        }
    };

    // Hide body overflow for SPA-style experience within admin
    React.useEffect(() => {
        document.body.style.overflow = 'hidden';
        // Add class to fix WP admin menu positioning if needed
        document.documentElement.style.overflow = 'hidden';

        return () => {
            document.body.style.overflow = '';
            document.documentElement.style.overflow = '';
        };
    }, []);

    return (
        <div style={{
            display: 'flex',
            height: 'calc(100vh - 52px)', // Subtract Admin Bar (32px) + Top Padding (20px)
            margin: '0 -20px 0 -20px', // Reset top margin to push content down
            background: '#f0f0f1',
        }}>
            <DeleteConfirmationModal
                isOpen={deleteModal.isOpen}
                onClose={() => setDeleteModal({ ...deleteModal, isOpen: false })}
                onConfirm={deleteModal.onConfirm}
                message={deleteModal.message}
            />

            <SuccessModal
                isOpen={successModal.isOpen}
                onClose={() => setSuccessModal({ ...successModal, isOpen: false })}
                message={successModal.message}
            />

            {/* Notification Banner (Errors only) */}
            {notification && notification.type === 'error' && (
                <div style={{
                    position: 'fixed',
                    top: '32px',
                    left: '50%',
                    transform: 'translateX(-50%)',
                    zIndex: 100000,
                    minWidth: '400px',
                    maxWidth: '600px',
                }}>
                    <div style={{
                        background: '#d63638',
                        color: '#fff',
                        padding: '16px 24px',
                        borderRadius: '4px',
                        boxShadow: '0 2px 8px rgba(0,0,0,0.2)',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        animation: 'slideDown 0.3s ease-out',
                    }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                            <span style={{ fontSize: '20px' }}>✕</span>
                            <span style={{ fontSize: '14px', fontWeight: '500' }}>
                                {notification.message}
                            </span>
                        </div>
                        <button
                            onClick={() => setNotification(null)}
                            style={{
                                background: 'transparent',
                                border: 'none',
                                color: '#fff',
                                cursor: 'pointer',
                                fontSize: '20px',
                                padding: '0 8px',
                                opacity: 0.8,
                            }}
                            onMouseEnter={(e) => e.target.style.opacity = '1'}
                            onMouseLeave={(e) => e.target.style.opacity = '0.8'}
                        >
                            ×
                        </button>
                    </div>
                </div>
            )}


            <DndContext
                sensors={sensors}
                collisionDetection={closestCenter}
                onDragStart={handleDragStart}
                onDragOver={handleDragOver}
                onDragEnd={handleDragEnd}
            >
                <DragOverlay dropAnimation={dropAnimation}>
                    {activeId && activeId.startsWith('new-') ? (
                        (() => {
                            const isFancy = FANCY_FIELDS.some(f => `new-${f.id}` === activeId);
                            const overlayColor = isFancy ? '#6699cc' : '#0073aa';
                            const field = STANDARD_FIELDS.find(f => `new-${f.id}` === activeId) ||
                                FANCY_FIELDS.find(f => `new-${f.id}` === activeId);

                            return (
                                <div style={{
                                    padding: '10px 15px',
                                    background: overlayColor,
                                    color: '#fff',
                                    borderRadius: '4px',
                                    boxShadow: '0 5px 15px rgba(0,0,0,0.2)',
                                    fontSize: '13px',
                                    fontWeight: '500',
                                    display: 'flex',
                                    alignItems: 'center',
                                    width: 'auto', // Auto width to fit content
                                    maxWidth: '220px',
                                    opacity: 0.9,
                                    cursor: 'grabbing',
                                    pointerEvents: 'none',
                                }}>
                                    <span style={{ marginRight: '8px', fontSize: '16px', display: 'flex', alignItems: 'center' }}>
                                        {field?.icon}
                                    </span>
                                    {field?.label}
                                </div>
                            );
                        })()
                    ) : null}
                </DragOverlay>


                {/* Left Sidebar - Field Palette */}
                <div style={{ width: '300px', background: '#f8f9fa', borderRight: '1px solid #ddd', display: 'flex', flexDirection: 'column', height: '100%', overflowX: 'hidden', boxSizing: 'border-box', flexShrink: 0 }}>

                    {/* Tabs */}
                    <div style={{ display: 'flex', borderBottom: '1px solid #ddd', background: '#fff', boxSizing: 'border-box' }}>
                        <div style={{
                            flex: 1,
                            padding: '12px',
                            textAlign: 'center',
                            background: '#f0f0f1',
                            borderBottom: '1px solid transparent',
                            fontWeight: '600',
                            fontSize: '13px',
                            color: '#1d2327',
                            cursor: 'default'
                        }}>
                            <span style={{ marginRight: '5px' }}>⊞</span> {__('Add Fields', 'revenuepro-bkash-wc')}
                        </div>
                    </div>

                    {/* Search */}
                    <div style={{ padding: '15px', background: '#fff', borderBottom: '1px solid #eee' }}>
                        <div style={{ position: 'relative' }}>
                            <input
                                type="text"
                                placeholder={__('Search fields...', 'revenuepro-bkash-wc')}
                                value={searchTerm}
                                onChange={(e) => setSearchTerm(e.target.value)}
                                style={{
                                    width: '100%',
                                    padding: '8px 10px 8px 30px',
                                    border: '1px solid #ccc',
                                    borderRadius: '4px',
                                    fontSize: '13px',
                                    boxSizing: 'border-box'
                                }}
                            />
                            <span className="dashicons dashicons-search" style={{ position: 'absolute', left: '8px', top: '50%', transform: 'translateY(-50%)', color: '#999', fontSize: '16px' }}></span>
                        </div>
                    </div>

                    <div style={{ flex: 1, overflowY: 'auto', padding: '0' }}>
                        {/* Standard Fields */}
                        <div style={{ borderBottom: '1px solid #eee' }}>
                            <button
                                onClick={() => setShowStandard(!showStandard)}
                                style={{
                                    width: '100%',
                                    padding: '12px 15px',
                                    background: 'transparent',
                                    border: 'none',
                                    color: '#1d2327',
                                    textAlign: 'left',
                                    cursor: 'pointer',
                                    fontSize: '13px',
                                    fontWeight: '600',
                                    display: 'flex',
                                    justifyContent: 'space-between',
                                    alignItems: 'center'
                                }}
                            >
                                <span>{__('Standard Fields', 'revenuepro-bkash-wc')}</span>
                                <span style={{ fontSize: '12px', color: '#666' }}>{showStandard ? '▼' : '▶'}</span>
                            </button>
                            {showStandard && (
                                <div className="field-grid-container" style={{ padding: '0 30px 15px 15px', display: 'grid', gridTemplateColumns: 'repeat(2, minmax(0, 1fr))', gap: '8px', boxSizing: 'border-box' }}>
                                    {STANDARD_FIELDS.filter(f => f.label.toLowerCase().includes(searchTerm.toLowerCase())).map(field => (
                                        <DraggableFieldButton key={field.id} fieldType={field} color="#0073aa" />
                                    ))}
                                </div>
                            )}
                        </div>

                        {/* Fancy Fields */}
                        <div>
                            <button
                                onClick={() => setShowFancy(!showFancy)}
                                style={{
                                    width: '100%',
                                    padding: '12px 15px',
                                    background: 'transparent',
                                    border: 'none',
                                    color: '#1d2327',
                                    textAlign: 'left',
                                    cursor: 'pointer',
                                    fontSize: '13px',
                                    fontWeight: '600',
                                    display: 'flex',
                                    justifyContent: 'space-between',
                                    alignItems: 'center'
                                }}
                            >
                                <span>{__('Fancy Fields', 'revenuepro-bkash-wc')}</span>
                                <span style={{ fontSize: '12px', color: '#666' }}>{showFancy ? '▼' : '▶'}</span>
                            </button>
                            {showFancy && (
                                <div className="field-grid-container" style={{ padding: '0 30px 15px 15px', display: 'grid', gridTemplateColumns: 'repeat(2, minmax(0, 1fr))', gap: '8px', boxSizing: 'border-box' }}>
                                    {FANCY_FIELDS.filter(f => f.label.toLowerCase().includes(searchTerm.toLowerCase())).map(field => (
                                        <DraggableFieldButton key={field.id} fieldType={field} color="#6699cc" />
                                    ))}
                                </div>
                            )}
                        </div>
                    </div>
                </div>

                {/* Center - Form Canvas */}
                <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
                    <div style={{ background: '#fff', borderBottom: '1px solid #e0e0e0', padding: '12px 24px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: '20px', height: '60px', boxSizing: 'border-box' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '16px', flex: 1, overflow: 'hidden' }}>
                            <button
                                onClick={() => navigate({ search: 'page=revenuepro-bkash-wc-all-forms' })}
                                style={{
                                    background: 'transparent',
                                    border: 'none',
                                    padding: '0',
                                    cursor: 'pointer',
                                    fontSize: '14px',
                                    color: '#50575e',
                                    fontWeight: '500',
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '6px',
                                    transition: 'color 0.2s'
                                }}
                                onMouseEnter={(e) => e.target.style.color = '#2271b1'}
                                onMouseLeave={(e) => e.target.style.color = '#50575e'}
                                title={__('Back to All Forms', 'revenuepro-bkash-wc')}
                            >
                                <span className="dashicons dashicons-arrow-left-alt2" style={{ fontSize: '16px', height: '16px', width: '16px' }}></span>
                                {__('Back', 'revenuepro-bkash-wc')}
                            </button>

                            <div style={{ width: '1px', height: '24px', background: '#e0e0e0' }}></div>

                            <div style={{ display: 'flex', alignItems: 'center', gap: '12px', flex: 1, maxWidth: '400px' }}>
                                <input
                                    type="text"
                                    value={formTitle}
                                    onChange={(e) => setFormTitle(e.target.value)}
                                    placeholder={__('Untitled Form', 'revenuepro-bkash-wc')}
                                    style={{
                                        flex: 1,
                                        padding: '4px 0 2px 0',
                                        border: 'none',
                                        borderBottom: '1px solid #2271b1',
                                        borderRadius: '0',
                                        fontSize: '18px',
                                        fontWeight: '600',
                                        outline: 'none',
                                        boxShadow: 'none',
                                        backgroundColor: 'transparent',
                                        color: '#1d2327',
                                        transition: 'border-color 0.2s'
                                    }}
                                    onFocus={(e) => e.target.style.borderBottomColor = '#2271b1'}
                                    onBlur={(e) => e.target.style.borderBottomColor = '#2271b1'}
                                />
                                <span className="dashicons dashicons-edit" style={{ color: '#a7aaad', fontSize: '16px' }}></span>
                            </div>
                        </div>

                        <div style={{ display: 'flex', gap: '12px', alignItems: 'center', flexShrink: 0 }}>
                            <button
                                onClick={() => setShowSettings(!showSettings)}
                                style={{
                                    width: '36px',
                                    height: '36px',
                                    background: showSettings ? '#f0f0f1' : 'transparent',
                                    border: 'none',
                                    borderRadius: '4px',
                                    color: showSettings ? '#2271b1' : '#50575e',
                                    cursor: 'pointer',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    transition: 'all 0.2s'
                                }}
                                title={showSettings ? __('Hide Settings', 'revenuepro-bkash-wc') : __('Show Settings', 'revenuepro-bkash-wc')}
                            >
                                <span className="dashicons dashicons-admin-generic" style={{ fontSize: '20px', height: '20px', width: '20px' }}></span>
                            </button>

                            <button
                                onClick={handleSave}
                                disabled={saving}
                                style={{
                                    padding: '0 20px',
                                    height: '36px',
                                    background: saving ? '#ccc' : '#2271b1',
                                    border: 'none',
                                    borderRadius: '4px',
                                    color: '#fff',
                                    cursor: saving ? 'not-allowed' : 'pointer',
                                    fontWeight: '600',
                                    fontSize: '14px',
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '8px',
                                    boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
                                }}
                            >
                                {saving ? __('Saving...', 'revenuepro-bkash-wc') : (
                                    <>
                                        {__('Save', 'revenuepro-bkash-wc')}
                                    </>
                                )}
                            </button>
                        </div>
                    </div>

                    {/* Form Canvas */}
                    <div
                        ref={setCanvasRef}
                        style={{
                            flex: 1,
                            overflowY: 'auto',
                            padding: '30px',
                            transition: 'all 0.3s ease',
                            backgroundColor: isOverCanvas ? 'rgba(0, 115, 170, 0.05)' : 'transparent'
                        }}
                    >
                        <div style={{ maxWidth: showSettings ? '100%' : '1000px', margin: '0 auto', background: '#fff', padding: '40px', borderRadius: '4px', boxShadow: '0 1px 3px rgba(0,0,0,0.1)', transition: 'max-width 0.3s ease', minHeight: '400px' }}>

                            {fields.length === 0 ? (
                                <EmptyCanvas isDragging={!!activeId} />
                            ) : (
                                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '15px' }}>
                                    <SortableContext items={fields.map(f => f.id)} strategy={verticalListSortingStrategy}>
                                        {fields.map((field, index) => (
                                            <React.Fragment key={field.id}>
                                                {/* Drop zone before each field */}
                                                <DropZoneBetweenFields
                                                    id={`drop-before-${field.id}`}
                                                    isDraggingNewField={activeId?.startsWith('new-')}
                                                />

                                                <div style={{ width: `calc(${field.width}% - 8px)`, minWidth: '200px' }}>
                                                    <SortableField
                                                        field={field}
                                                        isSelected={selectedField?.id === field.id}
                                                        onSelect={() => {
                                                            setSelectedField(field);
                                                            setShowSettings(true);
                                                        }}
                                                        onDelete={() => {
                                                            setFields(fields.filter(f => f.id !== field.id));
                                                            if (selectedField?.id === field.id) {
                                                                setSelectedField(null);
                                                            }
                                                        }}
                                                        onDeleteNestedField={handleDeleteNestedField}
                                                        onSelectNested={(nested) => {
                                                            setSelectedField(nested);
                                                            setShowSettings(true);
                                                        }}
                                                        selectedFieldId={selectedField?.id}
                                                    />
                                                </div>

                                                {/* Drop zone after the last field */}
                                                {index === fields.length - 1 && (
                                                    <DropZoneBetweenFields
                                                        id={`drop-after-${field.id}`}
                                                        isDraggingNewField={activeId?.startsWith('new-')}
                                                    />
                                                )}
                                            </React.Fragment>
                                        ))}
                                    </SortableContext>
                                </div>
                            )}

                            {/* Fixed Submit Button */}
                            {fields.length > 0 && (
                                <div style={{ marginTop: '30px', display: 'flex', justifyContent: 'flex-start' }}>
                                    <button
                                        type="submit"
                                        onClick={() => setSelectedField(null)} // Deselect fields to show submit button settings
                                        style={{
                                            padding: '12px 24px',
                                            background: submitButton.style === 'primary' ? '#0073aa' :
                                                submitButton.style === 'success' ? '#46b450' : '#666',
                                            color: '#fff',
                                            border: 'none',
                                            borderRadius: '3px',
                                            cursor: 'pointer',
                                            fontSize: '14px',
                                            fontWeight: '600',
                                            width: `${submitButton.width}%`,
                                            transition: 'all 0.2s',
                                        }}
                                        onMouseEnter={(e) => e.target.style.opacity = '0.9'}
                                        onMouseLeave={(e) => e.target.style.opacity = '1'}
                                    >
                                        {submitButton.text}
                                    </button>
                                </div>
                            )}
                        </div>
                    </div>
                </div>

                {/* Right Sidebar - Settings */}
                {showSettings && (
                    <div className="revenuepro-bkash-wc-builder-sidebar">
                        {/* Settings Tabs */}
                        <div className="sidebar-tabs">
                            <button onClick={() => setSettingsTab("field")} className={settingsTab === "field" ? "active" : ""}>{__("Field Settings", "revenuepro-bkash-wc")}</button>
                            <button onClick={() => setSettingsTab("form")} className={settingsTab === "form" ? "active" : ""}>{__("Form Settings", "revenuepro-bkash-wc")}</button>
                        </div>

                        {/* Content Area - Scrollable */}
                        <div className="sidebar-content">
                            {settingsTab === 'field' && (
                                <div className="settings-panel field-settings-wrapper">

                                    {selectedField ? (
                                        <div>
                                            {/* Field Label */}
                                            <div className="control-row">
                                                <label>
                                                    {__("Field Label", "revenuepro-bkash-wc")}
                                                </label>
                                                <input
                                                    type="text"
                                                    value={selectedField.label}
                                                    onChange={(e) => updateField({ label: e.target.value })}
                                                />
                                            </div>

                                            <div className="control-row">
                                                <label>
                                                    {__("Placeholder", "revenuepro-bkash-wc")}
                                                </label>
                                                <input
                                                    type="text"
                                                    value={selectedField.placeholder}
                                                    onChange={(e) => updateField({ placeholder: e.target.value })}
                                                />
                                            </div>

                                            <div className="control-row">
                                                <label>
                                                    {__("Field Width", "revenuepro-bkash-wc")}
                                                </label>
                                                <select
                                                    value={selectedField.width || "100"}
                                                    onChange={(e) => updateField({ width: e.target.value })}
                                                >
                                                    <option value="100">100% - Full Width</option>
                                                    <option value="50">50% - 2 Columns</option>
                                                    <option value="33">33% - 3 Columns</option>
                                                    <option value="25">25% - 4 Columns</option>
                                                </select>
                                                <p style={{ margin: "5px 0 0 0", fontSize: "12px", color: "#666" }}>
                                                    {__("Set to 50% to place 2 fields side-by-side", "revenuepro-bkash-wc")}
                                                </p>
                                            </div>

                                            {/* Required */}
                                            <div className="control-row">
                                                <label style={{ display: "flex", alignItems: "center", cursor: "pointer" }}>
                                                    <input
                                                        type="checkbox"
                                                        checked={selectedField.required}
                                                        onChange={(e) => updateField({ required: e.target.checked })}
                                                        style={{ marginRight: "8px", width: "auto", height: "auto" }}
                                                    />
                                                    {__("Required field", "revenuepro-bkash-wc")}
                                                </label>
                                            </div>

                                            {/* Options for select/radio/checkbox */}
                                            {(selectedField.type === "dropdown" || selectedField.type === "radio" || selectedField.type === "checkboxes") && (
                                                <div className="control-row">
                                                    <label>
                                                        {__("Options (one per line)", "revenuepro-bkash-wc")}
                                                    </label>
                                                    <textarea
                                                        value={selectedField.options.join("\n")}
                                                        onChange={(e) => updateField({ options: e.target.value.split("\n").filter(o => o.trim()) })}
                                                        rows="6"
                                                        style={{ width: "100%", padding: "8px", border: "1px solid #ddd", borderRadius: "3px", fontSize: "14px", boxSizing: "border-box" }}
                                                    />
                                                </div>
                                            )}

                                            {/* Column Count - for columns field */}
                                            {selectedField.type === "columns" && (
                                                <div className="control-row">
                                                    <label>
                                                        {__("Number of Columns", "revenuepro-bkash-wc")}
                                                    </label>
                                                    <select
                                                        value={selectedField.columnCount || 2}
                                                        onChange={(e) => {
                                                            const count = parseInt(e.target.value);
                                                            const columns = Array.from({ length: count }).map((_, i) => ({
                                                                id: `col-${Date.now()}-${i}`,
                                                                fields: selectedField.columns?.[i]?.fields || []
                                                            }));
                                                            updateField({ columnCount: count, columns });
                                                        }}
                                                    >
                                                        <option value="2">2 Columns</option>
                                                        <option value="3">3 Columns</option>
                                                        <option value="4">4 Columns</option>
                                                    </select>
                                                </div>
                                            )}


                                            {/* Button Settings - for button field */}
                                            {selectedField.type === 'button' && (
                                                <>
                                                    <div className="control-row">
                                                        <label>
                                                            {__("Button Text", "revenuepro-bkash-wc")}
                                                        </label>
                                                        <input
                                                            type="text"
                                                            value={selectedField.buttonText || ""}
                                                            onChange={(e) => updateField({ buttonText: e.target.value })}
                                                            placeholder="Click Me"
                                                        />
                                                    </div>
                                                    <div className="control-row">
                                                        <label>
                                                            {__("Button Value", "revenuepro-bkash-wc")}
                                                        </label>
                                                        <input
                                                            type="text"
                                                            value={selectedField.buttonValue || ""}
                                                            onChange={(e) => updateField({ buttonValue: e.target.value })}
                                                            placeholder="value"
                                                        />
                                                    </div>
                                                    <div className="control-row">
                                                        <label>
                                                            {__("Button Style", "revenuepro-bkash-wc")}
                                                        </label>
                                                        <select
                                                            value={selectedField.buttonStyle || "primary"}
                                                            onChange={(e) => updateField({ buttonStyle: e.target.value })}
                                                        >
                                                            <option value="primary">Primary (Blue)</option>
                                                            <option value="secondary">Secondary (Gray)</option>
                                                            <option value="success">Success (Green)</option>
                                                        </select>
                                                    </div>

                                                </>
                                            )}

                                            {/* Advanced Styling */}
                                            <div style={{ marginBottom: '15px', borderTop: '1px solid #ddd', paddingTop: '15px' }}>
                                                <h4 style={{ margin: '0 0 10px 0', fontSize: '14px', color: '#23282d' }}>{__('Styling', 'revenuepro-bkash-wc')}</h4>

                                                {/* Text Align */}
                                                <div style={{ marginBottom: '10px' }}>
                                                    <label style={{ display: 'block', fontWeight: '600', marginBottom: '5px', fontSize: '13px' }}>
                                                        {__('Text Align', 'revenuepro-bkash-wc')}
                                                    </label>
                                                    <select
                                                        value={selectedField.textAlign || 'left'}
                                                        onChange={(e) => updateField({ textAlign: e.target.value })}
                                                        style={{ width: '100%', padding: '8px', border: '1px solid #ddd', borderRadius: '3px', fontSize: '14px' }}
                                                    >
                                                        <option value="left">Left</option>
                                                        <option value="center">Center</option>
                                                        <option value="right">Right</option>
                                                    </select>
                                                </div>

                                                {/* Color */}
                                                <div style={{ marginBottom: '10px' }}>
                                                    <label style={{ display: 'block', fontWeight: '600', marginBottom: '5px', fontSize: '13px' }}>
                                                        {__('Text Color', 'revenuepro-bkash-wc')}
                                                    </label>
                                                    <input
                                                        type="text"
                                                        value={selectedField.color || ''}
                                                        onChange={(e) => updateField({ color: e.target.value })}
                                                        placeholder="#000000"
                                                        style={{ width: '100%', padding: '8px', border: '1px solid #ddd', borderRadius: '3px', fontSize: '14px', boxSizing: 'border-box' }}
                                                    />
                                                </div>

                                            </div>

                                            {/* CSS Class */}
                                            <div style={{ marginBottom: '15px' }}>
                                                <label style={{ display: 'block', fontWeight: '600', marginBottom: '5px', fontSize: '13px' }}>
                                                    {__('CSS Class', 'revenuepro-bkash-wc')}
                                                </label>
                                                <input
                                                    type="text"
                                                    value={selectedField.cssClass || ''}
                                                    onChange={(e) => updateField({ cssClass: e.target.value })}
                                                    placeholder="custom-class"
                                                    style={{ width: '100%', padding: '8px', border: '1px solid #ddd', borderRadius: '3px', fontSize: '14px', boxSizing: 'border-box' }}
                                                />
                                                <p style={{ margin: '5px 0 0 0', fontSize: '12px', color: '#666' }}>
                                                    {__('Add custom CSS class for styling', 'revenuepro-bkash-wc')}
                                                </p>
                                            </div>

                                            {/* Field Description */}
                                            <div style={{ marginBottom: '15px' }}>
                                                <label style={{ display: 'block', fontWeight: '600', marginBottom: '5px', fontSize: '13px' }}>
                                                    {__('Description', 'revenuepro-bkash-wc')}
                                                </label>
                                                <textarea
                                                    value={selectedField.description || ''}
                                                    onChange={(e) => updateField({ description: e.target.value })}
                                                    rows="3"
                                                    placeholder="Help text for this field"
                                                    style={{ width: '100%', padding: '8px', border: '1px solid #ddd', borderRadius: '3px', fontSize: '14px', boxSizing: 'border-box' }}
                                                />
                                                <p style={{ margin: '5px 0 0 0', fontSize: '12px', color: '#666' }}>
                                                    {__('Help text shown below the field', 'revenuepro-bkash-wc')}
                                                </p>
                                            </div>

                                            {/* Delete Button */}
                                            <button
                                                onClick={deleteField}
                                                style={{
                                                    width: '100%',
                                                    padding: '10px',
                                                    background: '#d63638',
                                                    color: '#fff',
                                                    border: 'none',
                                                    borderRadius: '3px',
                                                    cursor: 'pointer',
                                                    fontSize: '14px',
                                                    fontWeight: '600',
                                                    marginTop: '20px',
                                                }}
                                            >
                                                🗑️ {__('Delete Field', 'revenuepro-bkash-wc')}
                                            </button>
                                        </div>
                                    ) : (
                                        <div>
                                            <h4 style={{ margin: '0 0 15px 0', fontSize: '15px', fontWeight: '600', color: '#23282d', borderBottom: '2px solid #0073aa', paddingBottom: '10px' }}>
                                                {__('Submit Button', 'revenuepro-bkash-wc')}
                                            </h4>

                                            {/* Button Text */}
                                            <div style={{ marginBottom: '15px' }}>
                                                <label style={{ display: 'block', fontWeight: '600', marginBottom: '5px', fontSize: '13px' }}>
                                                    {__('Button Text', 'revenuepro-bkash-wc')}
                                                </label>
                                                <input
                                                    type="text"
                                                    value={submitButton.text}
                                                    onChange={(e) => setSubmitButton({ ...submitButton, text: e.target.value })}
                                                    placeholder="Submit"
                                                    style={{ width: '95%', padding: '8px', border: '1px solid #ddd', borderRadius: '3px', fontSize: '14px', boxSizing: 'border-box' }}
                                                />
                                            </div>

                                            {/* Button Width */}
                                            <div style={{ marginBottom: '15px' }}>
                                                <label style={{ display: 'block', fontWeight: '600', marginBottom: '5px', fontSize: '13px' }}>
                                                    {__('Button Width', 'revenuepro-bkash-wc')}
                                                </label>
                                                <select
                                                    value={submitButton.width}
                                                    onChange={(e) => setSubmitButton({ ...submitButton, width: e.target.value })}
                                                    style={{ width: '95%', padding: '8px', border: '1px solid #ddd', borderRadius: '3px', fontSize: '14px' }}
                                                >
                                                    <option value="25">25% - Quarter Width</option>
                                                    <option value="33">33% - One Third</option>
                                                    <option value="50">50% - Half Width</option>
                                                    <option value="75">75% - Three Quarters</option>
                                                    <option value="100">100% - Full Width</option>
                                                </select>
                                            </div>

                                            {/* Button Style */}
                                            <div style={{ marginBottom: '15px' }}>
                                                <label style={{ display: 'block', fontWeight: '600', marginBottom: '5px', fontSize: '13px' }}>
                                                    {__('Button Style', 'revenuepro-bkash-wc')}
                                                </label>
                                                <select
                                                    value={submitButton.style}
                                                    onChange={(e) => setSubmitButton({ ...submitButton, style: e.target.value })}
                                                    style={{ width: '95%', padding: '8px', border: '1px solid #ddd', borderRadius: '3px', fontSize: '14px' }}
                                                >
                                                    <option value="primary">Primary (Blue)</option>
                                                    <option value="secondary">Secondary (Gray)</option>
                                                    <option value="success">Success (Green)</option>
                                                </select>
                                            </div>

                                            <div style={{ width: '95%', marginTop: '20px', padding: '15px', background: '#e7f3ff', borderRadius: '4px', border: '1px solid #b3d9ff' }}>
                                                <p style={{ margin: '0', fontSize: '13px', color: '#0073aa', lineHeight: '1.6' }}>
                                                    💡 <strong>{__('Tip:', 'revenuepro-bkash-wc')}</strong> {__('Click on any field in the canvas to edit its settings, or stay here to customize the submit button.', 'revenuepro-bkash-wc')}
                                                </p>
                                            </div>
                                        </div>
                                    )}
                                </div>
                            )}

                            {/* Form Settings Panel */}
                            {settingsTab === 'form' && (
                                <FormSettingsPanel
                                    formSettings={formSettings}
                                    setFormSettings={setFormSettings}
                                    styleTab={styleTab}
                                    setStyleTab={setStyleTab}
                                />
                            )}
                        </div>
                    </div>
                )}

                {/* Drag Overlay - Shows what you're dragging */}
                <DragOverlay dropAnimation={dropAnimation}>
                    {activeId ? (
                        <div style={{
                            padding: '12px 20px',
                            background: '#0073aa',
                            color: '#fff',
                            borderRadius: '4px',
                            boxShadow: '0 4px 12px rgba(0,0,0,0.3)',
                            cursor: 'grabbing',
                            fontSize: '14px',
                            fontWeight: '500',
                        }}>
                            {activeId.startsWith('new-') ? (
                                <>
                                    {/* Dragging from palette */}
                                    {(() => {
                                        const fieldType = [...STANDARD_FIELDS, ...FANCY_FIELDS].find(
                                            f => `new- ${f.id} ` === activeId
                                        );
                                        return fieldType ? (
                                            <>
                                                <span style={{ marginRight: '10px' }}>{fieldType.icon}</span>
                                                {fieldType.label}
                                            </>
                                        ) : 'Field';
                                    })()}
                                </>
                            ) : (
                                <>
                                    {/* Dragging existing field */}
                                    {(() => {
                                        const field = fields.find(f => f.id === activeId);
                                        return field ? field.label : 'Field';
                                    })()}
                                </>
                            )}
                        </div>
                    ) : null}
                </DragOverlay>
            </DndContext>
        </div>
    );
};

export default FormBuilder;
