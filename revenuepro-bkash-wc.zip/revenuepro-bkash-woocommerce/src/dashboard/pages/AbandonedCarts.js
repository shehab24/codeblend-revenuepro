import React, { useState, useEffect } from 'react';
import { __, sprintf } from '@wordpress/i18n';

const STATUS_COLORS = {
    abandoned: { bg: '#fee2e2', color: '#991b1b' },
    recovered: { bg: '#dcfce7', color: '#15803d' },
    active:    { bg: '#e2e8f0', color: '#475569' },
};

// Strip HTML tags from wc_price() output for plain text use
function stripHtml(html) {
    if (!html) return '';
    return html.replace(/<[^>]+>/g, '').replace(/&nbsp;/g, ' ').trim();
}

function CartItems({ items }) {
    if (!items || !items.length) return <span style={{ color: '#94a3b8' }}>—</span>;
    return (
        <div>
            {items.map((item, i) => (
                <div key={i} style={{ fontSize: '12px', color: '#334155', marginBottom: '3px' }}>
                    <span style={{ fontWeight: 700 }}>{item.name}</span>
                    {' × '}<span style={{ color: '#0f172a' }}>{item.quantity}</span>
                    {' · '}
                    <span style={{ color: '#64748b' }}>৳{parseFloat(item.price || 0).toFixed(2)}</span>
                </div>
            ))}
        </div>
    );
}

// ─── Professional Confirm Modal ──────────────────────────────────────────────
function ConfirmModal({ config, onConfirm, onCancel }) {
    if (!config) return null;
    const { title, description, items, totalRaw, hasAddress, address, confirmLabel, confirmColor, icon, showNoteInput } = config;
    const [note, setNote] = useState('');

    return (
        <div style={{
            position: 'fixed', inset: 0, zIndex: 999999,
            background: 'rgba(15,23,42,0.55)', display: 'flex',
            alignItems: 'center', justifyContent: 'center', padding: '20px',
        }}>
            <div style={{
                background: '#fff', borderRadius: '20px', maxWidth: '480px', width: '100%',
                boxShadow: '0 32px 64px rgba(0,0,0,0.2)',
                animation: 'rpModalIn 0.25s cubic-bezier(0.34,1.56,0.64,1)',
            }}>
                {/* Header */}
                <div style={{ padding: '28px 28px 0', textAlign: 'center' }}>
                    <div style={{
                        width: '56px', height: '56px', borderRadius: '50%',
                        background: confirmColor === '#dc2626' ? '#fee2e2' : '#eff6ff',
                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                        margin: '0 auto 16px', fontSize: '26px',
                    }}>{icon}</div>
                    <h2 style={{ margin: '0 0 8px', fontSize: '20px', fontWeight: '800', color: '#0f172a' }}>{title}</h2>
                    <p style={{ margin: 0, color: '#64748b', fontSize: '14px', lineHeight: 1.6 }}>{description}</p>
                </div>

                {/* Cart Summary */}
                {items && items.length > 0 && (
                    <div style={{ margin: '20px 28px 0', background: '#f8fafc', borderRadius: '12px', padding: '16px', border: '1px solid #e2e8f0' }}>
                        <div style={{ fontSize: '11px', fontWeight: '700', color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '10px' }}>Cart Items</div>
                        {items.map((item, i) => (
                            <div key={i} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '6px', fontSize: '13px' }}>
                                <span style={{ color: '#334155', fontWeight: 600 }}>{item.name} <span style={{ color: '#94a3b8', fontWeight: 400 }}>× {item.quantity}</span></span>
                                <span style={{ fontWeight: '700', color: '#0f172a' }}>৳{parseFloat(item.price || 0).toFixed(2)}</span>
                            </div>
                        ))}
                        <div style={{ borderTop: '1px solid #e2e8f0', marginTop: '10px', paddingTop: '10px', display: 'flex', justifyContent: 'space-between', fontWeight: '800', fontSize: '15px' }}>
                            <span style={{ color: '#0f172a' }}>Total</span>
                            <span style={{ color: '#0f172a' }}>৳{parseFloat(totalRaw || 0).toFixed(2)}</span>
                        </div>
                    </div>
                )}

                {/* Order Note Input */}
                {showNoteInput && (
                    <div style={{ margin: '20px 28px 0' }}>
                        <div style={{ fontSize: '11px', fontWeight: '700', color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '8px' }}>Order Notes (Internal/Customer Note)</div>
                        <textarea
                            value={note}
                            onChange={(e) => setNote(e.target.value)}
                            placeholder="Add note to this order..."
                            style={{
                                width: '100%',
                                height: '70px',
                                padding: '10px 12px',
                                border: '1px solid #cbd5e1',
                                borderRadius: '10px',
                                fontSize: '13px',
                                color: '#334155',
                                fontFamily: 'inherit',
                                resize: 'none',
                                boxSizing: 'border-box',
                                transition: 'border-color 0.2s',
                                outline: 'none',
                            }}
                            onFocus={(e) => e.target.style.borderColor = confirmColor || '#1d4ed8'}
                            onBlur={(e) => e.target.style.borderColor = '#cbd5e1'}
                        />
                    </div>
                )}

                {/* Address Warning */}
                {!hasAddress && (
                    <div style={{ margin: '16px 28px 0', background: '#fffbeb', border: '1px solid #fde68a', borderRadius: '10px', padding: '12px 16px', display: 'flex', gap: '10px', alignItems: 'flex-start' }}>
                        <span style={{ fontSize: '18px' }}>⚠️</span>
                        <p style={{ margin: 0, fontSize: '13px', color: '#92400e', lineHeight: 1.5 }}>
                            <strong>No billing address was captured.</strong> The order will be created but you may need to fill in the address manually.
                        </p>
                    </div>
                )}

                {/* Buttons */}
                <div style={{ display: 'flex', gap: '12px', padding: '24px 28px 28px' }}>
                    <button onClick={onCancel} style={{
                        flex: 1, padding: '13px', background: '#f1f5f9', color: '#475569', border: 'none',
                        borderRadius: '10px', fontSize: '14px', fontWeight: '700', cursor: 'pointer',
                    }}>Cancel</button>
                    <button onClick={() => onConfirm(note)} style={{
                        flex: 1, padding: '13px', background: confirmColor || '#1d4ed8', color: '#fff', border: 'none',
                        borderRadius: '10px', fontSize: '14px', fontWeight: '700', cursor: 'pointer',
                        boxShadow: `0 4px 12px ${confirmColor || '#1d4ed8'}44`,
                    }}>{confirmLabel}</button>
                </div>
            </div>
        </div>
    );
}

// ─── Main Page ────────────────────────────────────────────────────────────────
export default function AbandonedCarts() {
    const [carts, setCarts] = useState([]);
    const [loading, setLoading] = useState(false);
    const [page, setPage] = useState(1);
    const [totalPages, setTotalPages] = useState(1);
    const [totalCarts, setTotalCarts] = useState(0);
    const [statusFilter, setStatusFilter] = useState('abandoned');
    const [actionLoading, setActionLoading] = useState({});
    const [toast, setToast] = useState(null);
    const [modal, setModal] = useState(null); // { config, onConfirm }

    // Initial load on mount
    useEffect(() => { fetchCarts(); }, []);
    // Re-fetch when page or filter changes (skip first mount to avoid double-fetch)
    useEffect(() => { fetchCarts(); }, [page, statusFilter]);

    const restUrl = window.RevenueProGlobal?.rest_url || '/wp-json/';
    const nonce   = window.RevenueProGlobal?.nonce || '';

    const fetchCarts = async () => {
        setLoading(true);
        try {
            const res = await fetch(
                `${restUrl}revenuepro-bkash-wc/v1/abandoned-carts?page=${page}&status=${statusFilter}&_t=${Date.now()}`,
                { headers: { 'X-WP-Nonce': nonce } }
            );
            if (res.ok) {
                const data = await res.json();
                setCarts(data.carts || []);
                setTotalPages(data.pages || 1);
                setTotalCarts(data.total || 0);
            }
        } catch (e) { console.error(e); }
        finally { setLoading(false); }
    };

    const showToast = (msg, type = 'success') => {
        setToast({ msg, type });
        setTimeout(() => setToast(null), 4500);
    };

    const openModal = (config) => new Promise((resolve) => {
        setModal({ config, resolve });
    });

    const handleModalConfirm = (note) => {
        modal?.resolve({ confirmed: true, note });
        setModal(null);
    };
    const handleModalCancel = () => {
        modal?.resolve({ confirmed: false });
        setModal(null);
    };

    // ── Mark Recovered ──
    const markRecovered = async (cart) => {
        const result = await openModal({
            title: 'Mark as Recovered?',
            description: `This will mark cart #${cart.id} for ${cart.customer_name || 'this customer'} as manually recovered — no order will be created.`,
            icon: '✅',
            confirmLabel: 'Yes, Mark Recovered',
            confirmColor: '#16a34a',
            items: cart.cart_contents,
            totalRaw: cart.cart_total_raw,
            hasAddress: cart.has_address,
        });
        if (!result || !result.confirmed) return;

        setActionLoading(p => ({ ...p, [`recover_${cart.id}`]: true }));
        try {
            const res = await fetch(
                `${restUrl}revenuepro-bkash-wc/v1/abandoned-carts/${cart.id}/recover`,
                { method: 'POST', headers: { 'X-WP-Nonce': nonce, 'Content-Type': 'application/json' } }
            );
            const data = await res.json();
            if (res.ok && data.success) { showToast('✅ Cart marked as recovered.'); fetchCarts(); }
            else showToast('❌ ' + (data.message || 'Failed.'), 'error');
        } catch { showToast('❌ Network error.', 'error'); }
        finally { setActionLoading(p => ({ ...p, [`recover_${cart.id}`]: false })); }
    };

    // ── Create Order ──
    const createOrder = async (cart) => {
        const result = await openModal({
            title: 'Create WooCommerce Order?',
            description: `An order will be created for ${cart.customer_name || 'this customer'} as Cash on Delivery. The cart will be marked recovered.`,
            icon: '🛒',
            confirmLabel: 'Create Order',
            confirmColor: '#1d4ed8',
            items: cart.cart_contents,
            totalRaw: cart.cart_total_raw,
            hasAddress: cart.has_address,
            address: cart.checkout_data,
            showNoteInput: true,
        });
        if (!result || !result.confirmed) return;

        setActionLoading(p => ({ ...p, [`order_${cart.id}`]: true }));
        try {
            const res = await fetch(
                `${restUrl}revenuepro-bkash-wc/v1/abandoned-carts/${cart.id}/create-order`,
                { 
                    method: 'POST', 
                    headers: { 'X-WP-Nonce': nonce, 'Content-Type': 'application/json' },
                    body: JSON.stringify({ note: result.note || '' })
                }
            );
            const data = await res.json();
            if (res.ok && data.success) {
                showToast(`✅ Order #${data.order_id} created successfully!`);
                fetchCarts();
                if (data.order_url) window.open(data.order_url, '_blank');
            } else {
                showToast('❌ ' + (data.message || data.data?.message || 'Failed.'), 'error');
            }
        } catch { showToast('❌ Network error.', 'error'); }
        finally { setActionLoading(p => ({ ...p, [`order_${cart.id}`]: false })); }
    };

    return (
        <div style={{ padding: '40px', fontFamily: '"Inter", -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif' }}>
            <style>{`
                @keyframes spin { 100% { transform: rotate(360deg); } }
                @keyframes rpFadeIn { from { opacity:0; transform:translateY(-8px); } to { opacity:1; transform:translateY(0); } }
                @keyframes rpModalIn { from { opacity:0; transform:scale(0.9) translateY(20px); } to { opacity:1; transform:scale(1) translateY(0); } }
                .rp-ac-btn { display:inline-flex; align-items:center; gap:5px; padding:6px 12px; border:none; border-radius:7px; font-size:12px; font-weight:700; cursor:pointer; transition:all 0.15s; white-space:nowrap; }
                .rp-ac-btn:hover:not(:disabled) { transform:translateY(-1px); box-shadow:0 4px 12px rgba(0,0,0,0.15); }
                .rp-ac-btn:disabled { opacity:0.5; cursor:not-allowed; }
                .rp-filter-tab { padding:8px 18px; border:1.5px solid #e2e8f0; border-radius:8px; font-size:13px; font-weight:600; cursor:pointer; transition:all 0.15s; background:#fff; color:#475569; }
                .rp-filter-tab.active { background:#0f172a; color:#fff; border-color:#0f172a; }
                tr:hover td { background-color:#f8fafc; }
            `}</style>

            {/* Confirm Modal */}
            {modal && (
                <ConfirmModal
                    config={modal.config}
                    onConfirm={handleModalConfirm}
                    onCancel={handleModalCancel}
                />
            )}

            {/* Toast */}
            {toast && (
                <div style={{
                    position:'fixed', top:'32px', right:'32px', zIndex:99998,
                    background: toast.type === 'error' ? '#fef2f2' : '#f0fdf4',
                    border: `1px solid ${toast.type === 'error' ? '#fca5a5' : '#86efac'}`,
                    color: toast.type === 'error' ? '#991b1b' : '#15803d',
                    padding:'14px 20px', borderRadius:'12px', fontWeight:700, fontSize:'14px',
                    boxShadow:'0 4px 20px rgba(0,0,0,0.12)', animation:'rpFadeIn 0.3s ease-out',
                }}>{toast.msg}</div>
            )}

            {/* Header */}
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:'28px' }}>
                <div>
                    <h1 style={{ fontSize:'28px', margin:0, fontWeight:'800', color:'#0f172a', letterSpacing:'-0.5px' }}>
                        {__('Abandoned Carts', 'revenuepro-bkash-wc')}
                    </h1>
                    <p style={{ margin:'6px 0 16px', color:'#64748b', fontSize:'14px' }}>
                        {sprintf(__('%s carts in this view', 'revenuepro-bkash-wc'), totalCarts)}
                    </p>
                    <div style={{ display:'flex', gap:'8px' }}>
                        {['abandoned','recovered','active'].map(s => (
                            <button key={s} className={`rp-filter-tab${statusFilter===s?' active':''}`}
                                onClick={() => { setPage(1); setStatusFilter(s); }}>
                                {s.charAt(0).toUpperCase()+s.slice(1)}
                            </button>
                        ))}
                    </div>
                </div>
                <button onClick={fetchCarts} disabled={loading}
                    style={{ padding:'10px 18px', background:'#0f172a', color:'#fff', border:'none', borderRadius:'10px', fontSize:'14px', fontWeight:'700', cursor:loading?'not-allowed':'pointer', display:'flex', alignItems:'center', gap:'8px', opacity:loading?0.7:1 }}>
                    <span className="dashicons dashicons-update" style={{ animation:loading?'spin 1.5s linear infinite':'none', fontSize:'16px', width:'16px', height:'16px' }}></span>
                    Refresh
                </button>
            </div>

            {/* Table Card */}
            <div style={{ background:'#fff', borderRadius:'16px', border:'1px solid #e2e8f0', boxShadow:'0 4px 24px rgba(0,0,0,0.07)', overflow:'hidden' }}>
                {loading ? (
                    <div style={{ padding:'80px', textAlign:'center', color:'#64748b' }}>
                        <span className="dashicons dashicons-update" style={{ animation:'spin 1.5s linear infinite', fontSize:'36px', color:'#cbd5e1', width:'36px', height:'36px' }}></span>
                        <p style={{ marginTop:'16px' }}>Loading carts...</p>
                    </div>
                ) : carts.length === 0 ? (
                    <div style={{ padding:'80px 20px', textAlign:'center' }}>
                        <div style={{ width:'80px', height:'80px', border:'2px dashed #cbd5e1', borderRadius:'50%', display:'flex', alignItems:'center', justifyContent:'center', margin:'0 auto 24px' }}>
                            <span className="dashicons dashicons-cart" style={{ fontSize:'40px', color:'#94a3b8', width:'40px', height:'40px' }}></span>
                        </div>
                        <h3 style={{ margin:'0 0 8px', color:'#1e293b', fontSize:'18px', fontWeight:'700' }}>No Carts Found</h3>
                        <p style={{ color:'#64748b', fontSize:'14px' }}>
                            {statusFilter === 'abandoned' ? 'No abandoned carts yet.' : `No ${statusFilter} carts.`}
                        </p>
                    </div>
                ) : (
                    <>
                        <div style={{ overflowX:'auto' }}>
                            <table style={{ width:'100%', borderCollapse:'collapse', textAlign:'left' }}>
                                <thead style={{ background:'#f8fafc', borderBottom:'2px solid #e2e8f0' }}>
                                    <tr>
                                        {['ID','Customer','Items','Cart Total','Address','Status','Abandoned','Email','Actions'].map(h => (
                                            <th key={h} style={{ padding:'14px 18px', fontSize:'11px', textTransform:'uppercase', letterSpacing:'0.06em', fontWeight:'700', color:'#64748b', whiteSpace:'nowrap' }}>{h}</th>
                                        ))}
                                    </tr>
                                </thead>
                                <tbody>
                                    {carts.map((cart) => {
                                        const sc = STATUS_COLORS[cart.status] || STATUS_COLORS.active;
                                        const isRecovering = actionLoading[`recover_${cart.id}`];
                                        const isOrdering   = actionLoading[`order_${cart.id}`];
                                        const canAct = cart.status !== 'recovered';
                                        return (
                                            <tr key={cart.id} style={{ borderBottom:'1px solid #f1f5f9', transition:'background 0.15s' }}>
                                                <td style={{ padding:'14px 18px', fontSize:'13px', color:'#94a3b8', fontWeight:'700' }}>#{cart.id}</td>
                                                <td style={{ padding:'14px 18px' }}>
                                                    <div style={{ fontWeight:'700', color:'#0f172a', fontSize:'14px' }}>{cart.customer_name}</div>
                                                    {cart.customer_email && <div style={{ fontSize:'12px', color:'#64748b' }}>{cart.customer_email}</div>}
                                                    {cart.customer_phone && <div style={{ fontSize:'12px', color:'#64748b' }}>{cart.customer_phone}</div>}
                                                </td>
                                                <td style={{ padding:'14px 18px', minWidth:'160px' }}>
                                                    <CartItems items={cart.cart_contents} />
                                                </td>
                                                <td style={{ padding:'14px 18px', fontWeight:'800', color:'#0f172a', whiteSpace:'nowrap' }}>
                                                    <span dangerouslySetInnerHTML={{ __html: cart.cart_total }} />
                                                </td>
                                                <td style={{ padding:'14px 18px' }}>
                                                    {cart.has_address ? (
                                                        <div style={{ fontSize:'12px', color:'#334155' }}>
                                                            {cart.checkout_data?.billing_address_1 && <div>{cart.checkout_data.billing_address_1}</div>}
                                                            {cart.checkout_data?.billing_city && <div style={{ color:'#64748b' }}>{cart.checkout_data.billing_city}</div>}
                                                        </div>
                                                    ) : <span style={{ fontSize:'12px', color:'#94a3b8' }}>—</span>}
                                                </td>
                                                <td style={{ padding:'14px 18px' }}>
                                                    <span style={{ padding:'4px 12px', borderRadius:'999px', fontSize:'12px', fontWeight:'700', background:sc.bg, color:sc.color, textTransform:'capitalize', whiteSpace:'nowrap' }}>
                                                        {cart.status}
                                                    </span>
                                                    {cart.recovery_order_id > 0 && (
                                                        <div style={{ fontSize:'11px', color:'#64748b', marginTop:'4px' }}>Order #{cart.recovery_order_id}</div>
                                                    )}
                                                </td>
                                                <td style={{ padding:'14px 18px', fontSize:'12px', color:'#64748b', whiteSpace:'nowrap' }}>{cart.abandoned_time}</td>
                                                <td style={{ padding:'14px 18px' }}>
                                                    {cart.email_sent ? (
                                                        <div style={{ display:'flex', alignItems:'center', gap:'4px', color:'#16a34a', fontSize:'12px', fontWeight:'600' }}>
                                                            <span className="dashicons dashicons-yes-alt" style={{ fontSize:'16px', width:'16px', height:'16px' }}></span>
                                                            <span>Sent<br /><span style={{ color:'#64748b', fontWeight:400 }}>{cart.email_sent_at}</span></span>
                                                        </div>
                                                    ) : <span style={{ color:'#94a3b8', fontSize:'12px' }}>Not sent</span>}
                                                </td>
                                                <td style={{ padding:'14px 18px' }}>
                                                    {canAct ? (
                                                        <div style={{ display:'flex', flexDirection:'column', gap:'6px' }}>
                                                            <button className="rp-ac-btn" onClick={() => markRecovered(cart)}
                                                                disabled={isRecovering || isOrdering}
                                                                style={{ background:'#f0fdf4', color:'#15803d', border:'1px solid #86efac' }}>
                                                                <span className="dashicons dashicons-yes" style={{ fontSize:'14px', width:'14px', height:'14px', animation: isRecovering ? 'spin 1s linear infinite' : 'none' }}></span>
                                                                {isRecovering ? 'Marking...' : 'Mark Recovered'}
                                                            </button>
                                                            <button className="rp-ac-btn" onClick={() => createOrder(cart)}
                                                                disabled={isOrdering || isRecovering}
                                                                style={{ background:'#eff6ff', color:'#1d4ed8', border:'1px solid #93c5fd' }}>
                                                                <span className="dashicons dashicons-cart" style={{ fontSize:'14px', width:'14px', height:'14px', animation: isOrdering ? 'spin 1s linear infinite' : 'none' }}></span>
                                                                {isOrdering ? 'Creating...' : 'Create Order'}
                                                            </button>
                                                        </div>
                                                    ) : (
                                                        <span style={{ fontSize:'12px', color:'#16a34a', fontWeight:'700', display:'flex', alignItems:'center', gap:'4px' }}>
                                                            <span className="dashicons dashicons-yes-alt" style={{ fontSize:'16px', width:'16px', height:'16px' }}></span>
                                                            Recovered
                                                        </span>
                                                    )}
                                                </td>
                                            </tr>
                                        );
                                    })}
                                </tbody>
                            </table>
                        </div>
                        {totalPages > 1 && (
                            <div style={{ padding:'20px', display:'flex', justifyContent:'center', alignItems:'center', gap:'10px', borderTop:'1px solid #e2e8f0' }}>
                                <button disabled={page===1} onClick={() => setPage(p => Math.max(1, p-1))}
                                    style={{ padding:'8px 16px', background:'#fff', border:'1px solid #e2e8f0', borderRadius:'8px', cursor:page===1?'not-allowed':'pointer', color:page===1?'#cbd5e1':'#475569', fontSize:'14px', fontWeight:'600' }}>← Previous</button>
                                <span style={{ fontSize:'14px', color:'#64748b', fontWeight:'600' }}>Page {page} of {totalPages}</span>
                                <button disabled={page===totalPages} onClick={() => setPage(p => Math.min(totalPages, p+1))}
                                    style={{ padding:'8px 16px', background:'#fff', border:'1px solid #e2e8f0', borderRadius:'8px', cursor:page===totalPages?'not-allowed':'pointer', color:page===totalPages?'#cbd5e1':'#475569', fontSize:'14px', fontWeight:'600' }}>Next →</button>
                            </div>
                        )}
                    </>
                )}
            </div>
        </div>
    );
}
