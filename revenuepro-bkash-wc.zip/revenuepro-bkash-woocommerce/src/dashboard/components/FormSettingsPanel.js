import React, { useState } from 'react';
import { __ } from '@wordpress/i18n';

// Collapsible Panel Component (Gutenberg-style)
function PanelSection({ title, children, defaultOpen = true, className = '' }) {
    const [isOpen, setIsOpen] = useState(defaultOpen);

    return (
        <div className={`panel-section ${className}`}>
            <button
                onClick={() => setIsOpen(!isOpen)}
                className="panel-header"
            >
                <span>{title}</span>
                <span style={{ transform: isOpen ? "rotate(0deg)" : "rotate(-90deg)", transition: "transform 0.2s" }}>▼</span>
            </button>
            {isOpen && (
                <div className="panel-content">
                    {children}
                </div>
            )}
        </div>
    );
}

// Control Row Component
function ControlRow({ label, children, helpText }) {
    return (
        <div className="control-row">
            {label && (
                <label>
                    {label}
                </label>
            )}
            {children}
            {helpText && (
                <p style={{ margin: "6px 0 0", fontSize: "11px", color: "#757575", fontStyle: "italic" }}>
                    {helpText}
                </p>
            )}
        </div>
    );
}

export default function FormSettingsPanel({ formSettings, setFormSettings, styleTab, setStyleTab }) {

    // Safety check - ensure formSettings has the required structure
    if (!formSettings || !formSettings.styling) {
        return (
            <div style={{ padding: '20px', textAlign: 'center', color: '#94a3b8' }}>
                <p>Loading settings...</p>
            </div>
        );
    }

    const updateFormSetting = (key, value) => {
        setFormSettings(prev => ({
            ...prev,
            [key]: value
        }));
    };

    return (
        <div className="settings-panel">
            {/* Single Tab */}
            <div className="sub-tabs">
                <button
                    onClick={() => setStyleTab("general")}
                    className="active"
                >
                    {__("Settings", "revenuepro-bkash-wc")}
                </button>
            </div>

            {/* General Tab */}
            {styleTab === 'general' && (
                <div style={{ padding: "0 16px", boxSizing: "border-box" }}>
                    <PanelSection title={__('Payment Settings', 'revenuepro-bkash-wc')} className="payment-settings-section">
                        <div
                            style={{
                                display: 'flex',
                                justifyContent: 'space-between',
                                alignItems: 'center',
                                padding: '12px 0',
                                borderBottom: '1px solid #f0f0f0'
                            }}
                        >
                            <div>
                                <div style={{ fontWeight: '600', fontSize: '13px', color: '#1e1e1e', marginBottom: '4px' }}>
                                    {__('Enable Payment', 'revenuepro-bkash-wc')}
                                </div>
                                <div style={{ fontSize: '12px', color: '#757575' }}>
                                    {__('Allow users to make payments through this form', 'revenuepro-bkash-wc')}
                                </div>
                            </div>
                            <label style={{ display: 'flex', alignItems: 'center', cursor: 'pointer' }}>
                                <input
                                    type="checkbox"
                                    checked={formSettings.paymentEnabled || false}
                                    onChange={(e) => updateFormSetting('paymentEnabled', e.target.checked)}
                                    style={{
                                        width: '18px',
                                        height: '18px',
                                        cursor: 'pointer',
                                        accentColor: '#2271b1'
                                    }}
                                />
                            </label>
                        </div>

                        {formSettings.paymentEnabled && (
                            <div style={{ marginTop: '16px', padding: '12px', background: '#f0f6fc', borderRadius: '4px', border: '1px solid #c3e0f7' }}>
                                <p style={{ margin: 0, fontSize: '12px', color: '#1e1e1e', lineHeight: '1.6' }}>
                                    <strong>{__('Note:', 'revenuepro-bkash-wc')}</strong> {__('Payment settings can be configured in the global settings page.', 'revenuepro-bkash-wc')}
                                </p>
                            </div>
                        )}
                    </PanelSection>

                    <PanelSection title={__('Form Information', 'revenuepro-bkash-wc')}>
                        <div style={{ padding: '12px 0' }}>
                            <p style={{ margin: 0, fontSize: '13px', color: '#757575', lineHeight: '1.6' }}>
                                {__('Additional form settings and customization options will appear here.', 'revenuepro-bkash-wc')}
                            </p>
                        </div>
                    </PanelSection>
                </div>
            )}
        </div>
    );
}
