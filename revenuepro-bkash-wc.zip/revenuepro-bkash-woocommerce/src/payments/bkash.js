const { registerPaymentMethod } = window.wc.wcBlocksRegistry;
const { getSetting } = window.wc.wcSettings;
const { decodeEntities } = window.wp.htmlEntities; 
const { createElement } = window.wp.element;

const settings = getSetting( 'paymentMethodData', {} ).revenuepro_bkash || {};

const labelText = decodeEntities( settings.title || 'bKash' );
const content = decodeEntities( settings.description || 'Pay with bKash.' );
const iconUrl = settings.icon || '';

const Label = () => {
    return createElement( 'span', { style: { display: 'flex', alignItems: 'center', gap: '10px', width: '100%' } },
        iconUrl && createElement( 'img', { 
            src: iconUrl, 
            alt: labelText,
            style: { maxHeight: '24px', marginRight: '5px' } 
        } ),
        labelText
    );
};

const BkashContent = () => {
    return createElement('div', {}, content);
};

const block_payment_method_config = {
    name: 'revenuepro_bkash', // Must match PHP ID
    label: createElement( Label ),
    content: createElement(BkashContent),
    edit: createElement(BkashContent),
    canMakePayment: () => true,
    ariaLabel: labelText,
    supports: {
        features: settings.supports || ['products'],
    },
};

registerPaymentMethod( block_payment_method_config );
