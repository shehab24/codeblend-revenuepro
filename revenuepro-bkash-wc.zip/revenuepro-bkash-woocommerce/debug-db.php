<?php
require_once(__DIR__ . '/../../../wp-load.php');
require_once(__DIR__ . '/includes/fraud-detection-db.php');

$stats = RevenuePro\FraudDetectionDB::get_stats('01736312720');
print_r($stats);
