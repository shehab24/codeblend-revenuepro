<?php
/**
 * Plugin Name:       RevenuePro With Bkash
 * Description:       RevenuePro With Bkash
 * Requires at least: 6.3
 * Requires PHP:      7.4
 * Version:           1.0.0
 * Author:            Codeblend
 * Author URI:        https://codeblend.co
 * License:           GPL-3.0+
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       revenuepro-bkash-wc
 * Requires Plugins:  woocommerce
 */

if (!defined('ABSPATH')) {
	exit;
}

final class RevenuePro
{
	public function __construct()
	{
		// define constants
		$this->define_constants();
		$this->load_dependency();
		register_activation_hook(__FILE__, [$this, 'activate']);
		register_deactivation_hook(__FILE__, [$this, 'deactivate']);
		register_deactivation_hook(__FILE__, ['\RevenuePro\LicenseManager', 'deactivate_plugin']);
		add_action('plugins_loaded', [$this, 'on_plugins_loaded']);
		add_action('revenuepro_bkash_wc_loaded', [$this, 'init_plugin']);
	}

	public static function init()
	{
		static $instance = false;
		if (!$instance) {
			$instance = new self();
		}
		return $instance;
	}

	/**
	 * Define the plugin constants
	 */
	private function define_constants()
	{
		// Define core base URL for the license/API server (always live)
		if (!defined('REVENUEPRO_API_BASE_URL')) {
		    define('REVENUEPRO_API_BASE_URL', 'https://codeblend.co');
		}
		define('REVENUEPRO_VERSION', '1.0.0');
		define('REVENUEPRO_FORM_SLUG', 'revenuepro-bkash-wc');
		define('REVENUEPRO_FORM_BASENAME', plugin_basename(__FILE__));
		define('REVENUEPRO_FORM_ROOT_URL', plugin_dir_url(__FILE__));
		define('REVENUEPRO_FORM_ASSETS_URL', REVENUEPRO_FORM_ROOT_URL . 'assets/');
		define('REVENUEPRO_FORM_ROOT_DIR_PATH', plugin_dir_path(__FILE__));
		define('REVENUEPRO_FORM_ASSETS_PATH', REVENUEPRO_FORM_ROOT_DIR_PATH . 'assets/');
		define('REVENUEPRO_INCLUDES_DIR_PATH', REVENUEPRO_FORM_ROOT_DIR_PATH . 'includes/');
	}

	public function load_dependency()
	{
		require_once REVENUEPRO_INCLUDES_DIR_PATH . 'autoload.php';
	}


	/**
	 * When WP has loaded all plugins, trigger the `ablocks_loaded` hook.
	 *
	 * This ensures `ablocks_loaded` is called only after all other plugins
	 * are loaded, to avoid issues caused by plugin directory naming changing
	 *
	 * @since 1.0.0
	 */
	public function on_plugins_loaded()
	{
		do_action('revenuepro_bkash_wc_loaded');
	}

	public function init_plugin()
	{
		// 1. Core Admin & Licensing (Always Loads to allow settings access)
		RevenuePro\Assets::init();
		RevenuePro\Api::init(); // REST API must load before license gate so settings can be saved
		if (is_admin()) {
			RevenuePro\Admin::init();
		}
		RevenuePro\LicenseManager::init();

		// 2. ENFORCE LICENSE LOCKOUT 
		// If license is not active, halt all premium features
		if (!RevenuePro\LicenseManager::is_license_active()) {
			return; 
		}

		// 3. Load Premium Plugin Features & Gateways
		RevenuePro\Form::init();
		RevenuePro\Submission::init();
		RevenuePro\Api::init();
		RevenuePro\Frontend::init();
		
		// Show admin notice if checkout was converted
		if (is_admin()) {
			add_action('admin_notices', [$this, 'show_checkout_conversion_notice']);
		}

		// New Features
		RevenuePro\PartialPayment::init();
		RevenuePro\FraudDetection::init();
		RevenuePro\AbandonedCart::init();
		RevenuePro\Sms::init();
		RevenuePro\CourierManager::init();
		RevenuePro\BkashManualVerifier::init();
		RevenuePro\TrackingPixel::init();
		RevenuePro\UtmTracking::init();
		RevenuePro\QuickOrder::init();

		// Intercept manual bKash redirect success callback
		add_action('template_redirect', function() {
			if (isset($_GET['trx_id']) && isset($_GET['status']) && $_GET['status'] === 'success') {
				global $wp;
				$order_id = 0;
				if (isset($wp->query_vars['order-received'])) {
					$order_id = intval($wp->query_vars['order-received']);
				} elseif (is_wc_endpoint_url('order-received') && isset($_GET['order_id'])) {
					$order_id = intval($_GET['order_id']);
				}
				
				if ($order_id > 0) {
					$order = wc_get_order($order_id);
					if ($order && ($order->get_status() === 'pending' || $order->get_status() === 'on-hold')) {
						$trx_id = sanitize_text_field(wp_unslash($_GET['trx_id']));
						$order->payment_complete($trx_id);
						$order->add_order_note(
							sprintf(
								__('✅ Manual bKash payment automatically verified & completed via pay.codeblend.co. TrxID: %s', 'revenuepro-bkash-wc'),
								$trx_id
							)
						);
						$order->save();
					}
				}
			}
		});

		// Initialize admin columns
		if (is_admin()) {
			require_once REVENUEPRO_INCLUDES_DIR_PATH . 'admin-orders-list.php';
			RevenuePro\AdminOrdersList::init();
		}

		// Register Payment Gateways (mutually exclusive: either automated OR manual)
		add_filter('woocommerce_payment_gateways', function ($gateways) {
			$rp_settings = get_option('revenuepro_bkash_wc_settings', []);
			$payment_mode = !empty($rp_settings['bkash_payment_mode']) ? $rp_settings['bkash_payment_mode'] : 'automated';

			if ($payment_mode === 'manual') {
				// Manual bKash Gateway only
				if (!class_exists('RevenuePro\BkashManualGateway')) {
					require_once REVENUEPRO_INCLUDES_DIR_PATH . 'bkash-manual-gateway.php';
				}
				$gateways[] = 'RevenuePro\BkashManualGateway';
			} else {
				// Automated bKash Gateway (default)
				if (!class_exists('RevenuePro\BkashGateway')) {
					require_once REVENUEPRO_INCLUDES_DIR_PATH . 'bkash-gateway.php';
				}
				$gateways[] = 'RevenuePro\BkashGateway';
			}

			return $gateways;
		});

		// DEBUG: Check if gateway is available in frontend
		add_filter('woocommerce_available_payment_gateways', function($gateways) {
			if (is_admin()) return $gateways;
			if (!isset($gateways['revenuepro_bkash'])) {
				error_log('RevenuePro Bkash MISSING from available gateways. Available: ' . implode(', ', array_keys($gateways)));
			}
			return $gateways;
		});

        add_action('woocommerce_blocks_payment_method_type_registration', function($payment_method_registry) {
            if (!class_exists('\Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType')) {
                return;
            }
            require_once REVENUEPRO_INCLUDES_DIR_PATH . 'bkash-block-support.php';
            $payment_method_registry->register(new \RevenuePro\BkashBlockSupport());
        });

		// Reverse Sync: WC -> Dashboard
		// Hook into update_option_{option_name}
		add_action('update_option_woocommerce_revenuepro_bkash_settings', ['RevenuePro\Helper', 'sync_wc_settings_to_dashboard'], 10, 3);

        // Flush rewrite rules to ensure WC API endpoint works
        add_action('admin_init', function() {
            if (!get_option('revenuepro_bkash_rewrites_flushed')) {
                flush_rewrite_rules();
                update_option('revenuepro_bkash_rewrites_flushed', true);
            }
        });
	}

	public function activate()
	{
		// Convert WooCommerce Checkout page to Classic Checkout
		$this->convert_to_classic_checkout();
		
		// Create abandoned cart database table
		require_once REVENUEPRO_INCLUDES_DIR_PATH . 'abandoned-cart-db.php';
		\RevenuePro\AbandonedCartDB::create_table();
		
		// Create fraud detection database table
		require_once REVENUEPRO_INCLUDES_DIR_PATH . 'fraud-detection-db.php';
		\RevenuePro\FraudDetectionDB::create_table();

		// Create bkash manual verifier database table
		require_once REVENUEPRO_INCLUDES_DIR_PATH . 'bkash-manual-verifier.php';
		\RevenuePro\BkashManualVerifier::create_table();
	}

	public function deactivate()
	{
	}
	
	/**
	 * Convert WooCommerce Checkout page to use Classic Checkout shortcode
	 */
	private function convert_to_classic_checkout()
	{
		// Get the WooCommerce checkout page ID
		$checkout_page_id = wc_get_page_id('checkout');
		
		if (!$checkout_page_id || $checkout_page_id <= 0) {
			return;
		}
		
		// Get the current page content
		$page = get_post($checkout_page_id);
		
		if (!$page) {
			return;
		}
		
		// Check if it's already using the classic shortcode
		if (strpos($page->post_content, '[woocommerce_checkout]') !== false) {
			// Already using classic checkout
			return;
		}
		
		// Check if it's using blocks (contains <!-- wp: -->)
		if (strpos($page->post_content, '<!-- wp:') !== false) {
			// It's using blocks, convert to classic
			wp_update_post([
				'ID' => $checkout_page_id,
				'post_content' => '[woocommerce_checkout]'
			]);
			
			// Add a notice that we converted the checkout page
			update_option('revenuepro_bkash_checkout_converted', true);
		}
	}
	
	/**
	 * Show admin notice when checkout page is converted
	 */
	public function show_checkout_conversion_notice()
	{
		if (get_option('revenuepro_bkash_checkout_converted')) {
			?>
			<div class="notice notice-success is-dismissible">
				<p><strong>RevenuePro bKash:</strong> Your checkout page has been automatically converted to Classic Checkout to ensure partial payment messages display correctly.</p>
			</div>
			<?php
			// Delete the option so the notice only shows once
			delete_option('revenuepro_bkash_checkout_converted');
		}
	}
}

/**
 * Kickoff
 */

RevenuePro::init();
