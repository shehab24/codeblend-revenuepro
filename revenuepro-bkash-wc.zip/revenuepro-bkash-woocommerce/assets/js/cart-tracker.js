(function($) {
    'use strict';

    let cartSaveTimeout;
    let lastSavedData = '';

    function saveCart() {
        const customerName = $('#billing_first_name').val() + ' ' + $('#billing_last_name').val();
        const customerEmail = $('#billing_email').val();
        const customerPhone = $('#billing_phone').val();

        // Only save if we have at least email or phone
        if (!customerEmail && !customerPhone) {
            return;
        }

        const checkoutData = {
            billing_first_name: $('#billing_first_name').val(),
            billing_last_name: $('#billing_last_name').val(),
            billing_company: $('#billing_company').val(),
            billing_address_1: $('#billing_address_1').val(),
            billing_address_2: $('#billing_address_2').val(),
            billing_city: $('#billing_city').val(),
            billing_state: $('#billing_state').val(),
            billing_postcode: $('#billing_postcode').val(),
            billing_country: $('#billing_country').val(),
            billing_email: customerEmail,
            billing_phone: customerPhone,
            order_comments: $('#order_comments').val(),
        };

        const dataString = JSON.stringify(checkoutData);
        
        // Don't save if data hasn't changed
        if (dataString === lastSavedData) {
            return;
        }

        lastSavedData = dataString;

        $.ajax({
            url: revenueProCart.ajax_url,
            type: 'POST',
            data: {
                action: 'revenuepro_save_cart',
                nonce: revenueProCart.nonce,
                session_id: revenueProCart.session_id,
                customer_name: customerName.trim(),
                customer_email: customerEmail,
                customer_phone: customerPhone,
                checkout_data: checkoutData,
            },
            success: function(response) {
                if (response.success) {
                    console.log('RevenuePro: Cart saved successfully');
                }
            },
            error: function(xhr, status, error) {
                console.error('RevenuePro: Failed to save cart', error);
            }
        });
    }

    function debouncedSaveCart() {
        clearTimeout(cartSaveTimeout);
        cartSaveTimeout = setTimeout(saveCart, 2000); // Save after 2 seconds of inactivity
    }

    // Initialize tracking
    $(document).ready(function() {
        if (typeof revenueProCart === 'undefined') {
            return;
        }

        // Track form field changes
        const fieldsToTrack = [
            '#billing_first_name',
            '#billing_last_name',
            '#billing_email',
            '#billing_phone',
            '#billing_address_1',
            '#billing_city',
            '#billing_postcode',
        ];

        fieldsToTrack.forEach(function(field) {
            $(document).on('change blur', field, debouncedSaveCart);
            $(document).on('input', field, debouncedSaveCart);
        });

        // Save cart when user leaves the page
        $(window).on('beforeunload', function() {
            saveCart();
        });

        // Track cart updates
        $(document.body).on('updated_cart_totals updated_checkout', function() {
            debouncedSaveCart();
        });
    });

})(jQuery);
