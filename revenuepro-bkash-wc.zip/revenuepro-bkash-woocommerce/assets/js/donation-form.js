document.addEventListener('DOMContentLoaded', function () {
    const forms = document.querySelectorAll('.revenuepro-bkash-wc-wrapper');

    forms.forEach(form => {
        const typeBtns = form.querySelectorAll('.donation-type-btn');
        const amountBtns = form.querySelectorAll('.donation-amount-btn');
        const amountInput = form.querySelector('input[name="donation_amount"]');
        const typeInput = form.querySelector('input[name="donation_type"]');

        // Type Toggle
        typeBtns.forEach(btn => {
            btn.addEventListener('click', function () {
                typeBtns.forEach(b => b.classList.remove('active'));
                this.classList.add('active');
                if (typeInput) typeInput.value = this.dataset.value;
            });
        });

        // Amount Buttons
        amountBtns.forEach(btn => {
            btn.addEventListener('click', function () {
                amountBtns.forEach(b => b.classList.remove('active'));
                this.classList.add('active');
                if (amountInput) amountInput.value = this.dataset.value;
            });
        });

        // Custom Amount Input
        if (amountInput) {
            amountInput.addEventListener('input', function () {
                amountBtns.forEach(b => b.classList.remove('active'));
            });
        }

        // Generic Buttons (New Builder)
        const genericBtns = form.querySelectorAll('.donation-button');
        genericBtns.forEach(btn => {
            btn.addEventListener('click', function () {
                // Deselect all others to enforce single selection (Radio behavior)
                genericBtns.forEach(b => {
                    if (b !== this) {
                        b.classList.remove('active');
                        const fId = b.dataset.fieldId;
                        const hInput = form.querySelector(`input[name="field_${fId}"]`);
                        if (hInput) hInput.value = '';
                    }
                });

                // Toggle this
                this.classList.toggle('active');
                const isActive = this.classList.contains('active');

                const fieldId = this.dataset.fieldId;
                const hiddenInput = form.querySelector(`input[name="field_${fieldId}"]`);
                if (hiddenInput) {
                    hiddenInput.value = isActive ? this.dataset.value : '';
                }
            });
        });
    });
});
