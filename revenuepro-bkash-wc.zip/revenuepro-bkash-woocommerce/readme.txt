=== RevenuePro ===
Contributors: shehabmahamud
Tags: donation, form, payment, bkash
Requires at least: 6.3
Tested up to: 6.9
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

A customizable donation form plugin with bKash payment support.

== Description ==

RevenuePro is a powerful and flexible plugin that allows you to create and manage donation forms on your WordPress site. It includes a drag-and-drop form builder and supports bKash payment gateway integration.

**Features:**

*   **Drag-and-Drop Form Builder:** Easily create donation forms with a user-friendly interface.
*   **bKash Payment Integration:** Accept donations via bKash, a popular mobile financial service in Bangladesh.
*   **Submission Management:** View and manage donation submissions directly from the dashboard.
*   **Email Notifications:** Send automated receipt emails to donors and failure notifications if payments fail.
*   **Customizable Design:** Style your forms to match your website's theme.
*   **Shortcode Support:** Embed donation forms anywhere on your site using shortcodes.

== Installation ==

1.  Upload the plugin files to the `/wp-content/plugins/revenuepro-bkash-wc` directory, or install the plugin through the WordPress plugins screen directly.
2.  Activate the plugin through the 'Plugins' screen in WordPress.
3.  Navigate to the "RevenuePro" menu in the admin dashboard to create your first form.
4.  Configure bKash settings in the "Settings" page.

== Frequently Asked Questions ==

= How do I add a donation form to a page? =

After creating a form, copy the shortcode (e.g., `[revenuepro_bkash_wc id="123"]`) and paste it into any page or post.

= Does it support recurring donations? =

Currently, the plugin supports one-time donations. Recurring donations may be added in future updates.

== Screenshots ==

1.  **Dashboard:** Overview of your donation forms.
2.  **Form Builder:** The drag-and-drop interface for creating forms.
3.  **Settings:** Configuration options for payments and emails.

== Changelog ==

= 1.0.0 =
*   Initial release.



